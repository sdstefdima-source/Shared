"""Verify every hashed member in the extracted package; no dependencies."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent

def main():
    manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text(encoding='ascii'))
    failures=[]
    for item in manifest['files']:
        relative=Path(item['path'])
        path=(ROOT/relative).resolve()
        if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(ROOT):
            failures.append('Unsafe manifest path: '+item['path'])
            continue
        if not path.is_file():
            failures.append('Missing: '+item['path'])
            continue
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=item['sha256'] or path.stat().st_size!=item['bytes']:
            failures.append('Changed: '+item['path'])
    print(f"Checked {len(manifest['files'])} package files: {'PASS' if not failures else 'FAIL'}")
    for failure in failures:print(failure)
    print('The manifest excludes itself and the containing ZIP; hashes do not authenticate a publisher.')
    return 1 if failures else 0

if __name__=='__main__':
    sys.exit(main())
