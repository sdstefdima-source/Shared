"""Independent targeted probes for the atlas software audit.

This script reports observed results and exits nonzero when a targeted invariant
fails. It does not modify the kernel, the official fixtures, or official reports.
"""
import hashlib
import json
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "checks"))
import atlas_kernel as k


def claim():
    actor = k.Entity("worker", "person")
    interviewer = k.Entity("interviewer", "person")
    proposition = k.Proposition(actor, "removed", (), k.Scope("case", "Monday", "one"))
    return k.Claim("C1", proposition, actor, interviewer, "ASSERT", "POSSIBLE", 1,
                   ("record:1",), ("uncertain",), ("source-1",))


def must_reject(action, allowed=(k.CheckError, TypeError, AttributeError)):
    try:
        result = action()
    except allowed as exc:
        return {"passed": True, "rejection": type(exc).__name__}
    return {"passed": False, "accepted": repr(result)}


def strict_reject(action):
    return must_reject(action, (k.CheckError,))


def malformed_lineage(nodes):
    try:
        result = k.lineage_audit(nodes, "r")
    except k.CheckError:
        return {"passed": True, "rejection": "CheckError"}
    return {"passed": not result["valid"], "result": result}


def speaker_change():
    old = claim()
    flags = k.transition_guard(old, replace(old, id="C2", utterer=k.Entity("other", "person")))
    return {"passed": "UTTERER_CHANGE" in flags, "flags": flags}


def ledger_mutation():
    ledger = k.EvidenceLedger()
    old = claim()
    ledger.add(old)
    try:
        ledger.records[old.id] = replace(old, modality="CERTAIN")
    except (TypeError, AttributeError):
        return {"passed": ledger.records[old.id] == old, "write_rejected": True}
    return {"passed": False, "write_rejected": False, "changed": ledger.records[old.id] != old}


def ledger_rebind():
    ledger = k.EvidenceLedger()
    old = claim()
    ledger.add(old)
    try:
        ledger.records = {"C1": replace(old, modality="CERTAIN")}
    except (TypeError, AttributeError):
        return {"passed": ledger.records[old.id] == old, "write_rejected": True}
    return {"passed": False, "write_rejected": False}


def supported_controls():
    contradictory = [k.HardPremise("h1", "p", "adopted"),
                     k.HardPremise("h2", ["not", "p"], "adopted")]
    a = k.classify(contradictory, "q")
    b = k.discharge([], "p", "p")
    c = k.partition_audit([], [[], []])
    d = k.lineage_audit({"a": {"dependencies": ["b"]},
                         "b": {"dependencies": ["a"]}}, "a")
    e = k.lineage_audit({"s": {"source": True, "origin": "source"},
                         "a": {"dependencies": ["s", "b"]},
                         "b": {"dependencies": ["a"]}}, "a")
    return {"passed": a["status"] == "INCONSISTENT"
            and b["accepted"] and b["unconditional"] == "UNDETERMINED"
            and c["valid"] and not d["valid"] and not e["valid"],
            "empty_world_status": a["status"],
            "conditional_unconditional_status": b["unconditional"],
            "empty_structural_partition_valid": c["valid"],
            "unseeded_cycle_valid": d["valid"], "seeded_cycle_valid": e["valid"]}


PROBES = [
    ("A01", "Speaker reassignment requires a transition flag", speaker_change),
    ("A02", "Entity identifier rejects a mutable list", lambda: strict_reject(lambda: k.Entity(["worker"], "person"))),
    ("A03", "Proposition predicate rejects a mutable list", lambda: strict_reject(lambda: replace(claim().proposition, predicate=["removed"]))),
    ("A04", "Utterance recording time rejects a mutable list", lambda: strict_reject(lambda: k.Utterance("u", "text", (), None, ["t"], "span"))),
    ("A05", "Hard premise identifier rejects a mutable list", lambda: strict_reject(lambda: k.HardPremise(["h"], "p", "adopted"))),
    ("A06", "Claim identifier rejects a mutable list", lambda: strict_reject(lambda: replace(claim(), id=["C1"]))),
    ("A07", "Lineage Boolean cannot be an unparsed string", lambda: malformed_lineage({"r": {"source": "false", "origin": "x"}})),
    ("A08", "Lineage dependency sequence cannot be a string", lambda: malformed_lineage({"r": {"dependencies": "a"}, "a": {"source": True, "origin": "x"}})),
    ("A09", "Published ledger mapping rejects record replacement", ledger_mutation),
    ("A10", "Published ledger mapping rejects wholesale rebinding", ledger_rebind),
    ("A11", "Direct evaluator rejects an empty atom", lambda: strict_reject(lambda: k.evaluate("", {"": True}))),
    ("A12", "Model rows reject an empty atom", lambda: strict_reject(lambda: k.freeze_model({"": True}))),
    ("A13", "Empty partition input still validates focal formula", lambda: strict_reject(lambda: k.split_partition([], ["and", "p"]))),
    ("A14", "Mixed atom types receive an intentional validation error", lambda: strict_reject(lambda: list(k.valuations(["p", 1])))),
    ("A15", "Empty-model, discharge, and cycle controls remain correct", supported_controls),
]


def main():
    rows = []
    for identifier, description, action in PROBES:
        try:
            result = action()
        except Exception as exc:
            result = {"passed": False, "unexpected_exception": type(exc).__name__, "detail": str(exc)}
        rows.append({"id": identifier, "description": description, **result})
    report = {
        "schema": "atlas.independent_software_probes.v1",
        "scope": "Targeted structural and semantic boundary probes; no NLP or empirical interviewing validation.",
        "kernel_sha256": hashlib.sha256((ROOT / "checks" / "atlas_kernel.py").read_bytes()).hexdigest(),
        "runner_sha256": hashlib.sha256((ROOT / "checks" / "run_checks.py").read_bytes()).hexdigest(),
        "probe_count": len(rows), "passed_count": sum(row["passed"] for row in rows),
        "passed": all(row["passed"] for row in rows), "results": rows,
    }
    output = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "audits" / "software_probe_results.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="ascii")
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
