"""Execute the finite checks with before/after hashes and provenance."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent

def digest(name):
    return hashlib.sha256((ROOT/name).read_bytes()).hexdigest()

def main():
    names=['checks/atlas_kernel.py','checks/run_checks.py','tests/scenarios.json','run_verification.py']
    declared=['checks/results.json','checks/results.txt']
    before={name:digest(name) for name in names}
    started=datetime.now(timezone.utc).isoformat()
    clock=time.perf_counter()
    completed=subprocess.run([sys.executable,'checks/run_checks.py'],cwd=ROOT,
        capture_output=True,text=True,timeout=300)
    runtime=time.perf_counter()-clock
    (ROOT/'verification_execution.log').write_text(completed.stdout+completed.stderr,encoding='utf-8')
    after={name:digest(name) for name in names}
    results=json.loads((ROOT/'checks/results.json').read_text(encoding='ascii'))
    passed=completed.returncode==0 and results['passed'] and before==after
    nonclaims=results['limits']
    manifest={
      'schema_version':2,'claim_id':'ATLAS-FINITE-REFERENCE-KERNEL-1.0',
      'repository':{'commit':'unavailable; artifact snapshot identified by input hashes','dirty':True},
      'command':[sys.executable,'checks/run_checks.py'],
      'environment':{'software':[{'name':'Python','version':platform.python_version()}],
                     'hardware':platform.machine(),'platform':platform.platform()},
      'mathematics':{
        'assertion_tested':'Finite Boolean evaluator/classifier agreement and explicit annotation guards pass the declared fixtures.',
        'coefficient_domain':'Boolean {False,True}; integer counters and exact rational rate values where specified',
        'conventions':'Classical Boolean semantics; inconsistent premise families reported separately; record support is not world truth.',
        'inputs':names,
        'bounds':{'kernel_atom_cap':12,'oracle_atoms':3,'oracle_max_ast_depth':2,
                  'oracle_operators':['not','and','or','implies','iff','xor'],
                  'oracle_constants':[False,True],'model_families_over_three_atoms':256},
        'non_claims':nonclaims},
      'randomness':{'used':False,'generator':'none','seed':None},
      'run':{'started_at':started,'runtime_seconds':round(runtime,6),
             'exit_status':completed.returncode,
             'status':'completed' if passed else 'failed',
             'wall_timeout_seconds':300,
             'resource_limits':{'memory_bytes':None,'cpu_seconds':None,'max_cores':None,'max_threads':None}},
      'input_artifacts':[{'path':n,'sha256':before[n],'sha256_after':after[n]} for n in names],
      'execution_artifacts':names,'declared_results':declared,
      'outputs':[{'path':n,'sha256':digest(n),'kind':'result'} for n in declared]
                +[{'path':'verification_execution.log','sha256':digest('verification_execution.log'),'kind':'log'}],
      'checks':[{'name':'inputs_unchanged','passed':before==after},
                {'name':'runner_zero_exit','passed':completed.returncode==0},
                {'name':'declared_results_pass','passed':results['passed']}],
      'result':'PASS for the declared finite inputs' if passed else 'FAIL; inspect logs',
      'residual_risks':nonclaims+['The wrapper records input/output hashes; it is not a formal proof assistant or sandbox.']}
    (ROOT/'computation_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='ascii')
    print(completed.stdout,end='')
    print(f'Execution provenance: {runtime:.3f} seconds; inputs unchanged={before==after}; exit={completed.returncode}')
    return 0 if passed else 1

if __name__=='__main__':
    sys.exit(main())
