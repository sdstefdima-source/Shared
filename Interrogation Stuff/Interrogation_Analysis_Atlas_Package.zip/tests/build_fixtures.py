"""Deterministically materialize explicit, hand-annotated scenario fixtures.

The examples are synthetic. Expected results are semantic annotations, not
measured outcomes from interrogation participants or an NLP classifier.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
cases = []


def add(identifier, family, description, data, expected):
    cases.append({"id": identifier, "family": family, "description": description,
                  "input": data, "expected": expected})


def boolean(name, description, premises, query, status):
    add(name, "boolean", description, {"premises": premises, "query": query}, status)


boolean("B01", "No premise establishes a world fact merely mentioned in speech.", [], "p", "UNDETERMINED")
boolean("B02", "An explicitly adopted premise entails itself.", ["p"], "p", "ENTAILED")
boolean("B03", "An explicit contrary premise refutes the positive query.", [["not", "p"]], "p", "REFUTED")
boolean("B04", "Contradictory hard premises report inconsistency rather than universal establishment.", ["p", ["not", "p"]], "q", "INCONSISTENT")
boolean("B05", "The zero-atom true formula has one model.", [], True, "ENTAILED")
boolean("B06", "The zero-atom false formula is refuted.", [], False, "REFUTED")
boolean("B07", "A false hard premise produces an empty family even without atoms.", [False], True, "INCONSISTENT")
boolean("B08", "A conditional and its antecedent license the consequent.", [["implies", "p", "q"], "p"], "q", "ENTAILED")
boolean("B09", "Affirming the consequent does not establish the antecedent.", [["implies", "p", "q"], "q"], "p", "UNDETERMINED")
boolean("B10", "Denying the antecedent does not establish the negated consequent.", [["implies", "p", "q"], ["not", "p"]], "q", "UNDETERMINED")
boolean("B11", "A conditional with a false consequent entails a false antecedent.", [["implies", "p", "q"], ["not", "q"]], ["not", "p"], "ENTAILED")
boolean("B12", "A disjunction does not choose a source or acquisition route.", [["or", "p", "q"]], "p", "UNDETERMINED")
boolean("B13", "A conjunction permits its component.", [["and", "p", "q"]], "p", "ENTAILED")
boolean("B14", "One admitted component does not establish a compound account.", ["p"], ["and", "p", "q"], "UNDETERMINED")
boolean("B15", "Exclusive alternatives cannot both hold.", [["xor", "p", "q"]], ["and", "p", "q"], "REFUTED")
boolean("B16", "Pairwise-compatible exclusive constraints may be jointly inconsistent.", [["xor", "p", "q"], ["xor", "q", "r"], ["xor", "p", "r"]], "p", "INCONSISTENT")
boolean("B17", "Shared conclusions survive different complete scenarios.", [["or", ["and", "p", "q"], ["and", "p", ["not", "q"]]]], "p", "ENTAILED")
boolean("B18", "A new unconstrained proposition remains unsettled.", ["p"], "new_detail", "UNDETERMINED")
boolean("B19", "A focal proposition and its complement cover every classical case.", [], ["or", "p", ["not", "p"]], "ENTAILED")
boolean("B20", "A focal proposition and its complement have disjoint extensions.", [], ["and", "p", ["not", "p"]], "REFUTED")

for identifier, positive, negative, expected in [
    ("S01", [], [], "NEITHER"), ("S02", ["record-a"], [], "POSITIVE_ONLY"),
    ("S03", [], ["record-b"], "NEGATIVE_ONLY"), ("S04", ["record-a"], ["record-b"], "BOTH"),
    ("S05", ["record-a", "record-a"], [], "POSITIVE_ONLY")]:
    add(identifier, "support", "Support bookkeeping remains separate from world truth; repeated IDs deduplicate.",
        {"positive": positive, "negative": negative}, expected)

for identifier, changes, expected, description in [
    ("T01", {}, [], "A faithful copied claim preserves meaning and source."),
    ("T02", {"actor": "person-b"}, ["ACTOR_CHANGE"], "A correspondent is silently replaced by the depicted person."),
    ("T03", {"predicate": "prefers"}, ["PREDICATE_CHANGE"], "An encountered age range becomes a preferred age range."),
    ("T04", {"argument": "file-b"}, ["ARGUMENT_CHANGE"], "General admission is attached to a different particular file."),
    ("T05", {"context": "hypothetical-room"}, ["CONTEXT_CHANGE"], "A claim crosses actual and hypothetical contexts."),
    ("T06", {"event_time": "receipt-date"}, ["EVENT_TIME_CHANGE"], "Present identification becomes knowledge at earlier receipt."),
    ("T07", {"quantifier": "every_event"}, ["QUANTIFIER_CHANGE"], "One occasion becomes every occasion."),
    ("T08", {"speech_act": "ASSERT"}, ["SPEECH_ACT_CHANGE"], "Discussion acceptance becomes an assertion."),
    ("T09", {"modality": "CERTAIN"}, ["MODALITY_CHANGE"], "Possible saving becomes certain saving."),
    ("T10", {"qualifications": []}, ["QUALIFICATION_CHANGE"], "The at-most qualification disappears."),
    ("T11", {"introducer": "person-b"}, ["INTRODUCER_CHANGE"], "Interviewer-originated content is assigned to the respondent."),
    ("T12", {"source_spans": ["recap-2"]}, ["SOURCE_LINEAGE_LOSS"], "A recap loses its original quotation span."),
    ("T13", {"dependencies": []}, ["DEPENDENCY_LOSS"], "A local assumption dependency disappears."),
    ("T14", {"modality": "CERTAIN", "qualifications": [], "predicate": "prefers"},
     ["PREDICATE_CHANGE", "MODALITY_CHANGE", "QUALIFICATION_CHANGE"], "A summary strengthens three dimensions simultaneously."),
    ("T15", {"source_spans": ["source-1", "recap-2"], "dependencies": ["assumption-1", "note-2"]}, [],
     "Appending provenance and dependencies does not delete the existing meaning."),
    ("T16", {"argument_kind": "person"}, ["ARGUMENT_CHANGE"], "A file identifier is retyped as a person even if its string matches.")]:
    add(identifier, "transition", description, {"changes": changes}, expected)

for identifier, data, expected, description in [
    ("A01", {}, [], "An explicit single-slot response follows the addressed question."),
    ("A02", {"answer_order": 9}, ["ANSWER_NOT_AFTER_QUESTION"], "A yes before the preference question cannot answer it."),
    ("A03", {"answer_order": 10}, ["ANSWER_NOT_AFTER_QUESTION"], "An equal-index response has unresolved event ordering."),
    ("A04", {"target": None}, ["UNRESOLVED_OR_WRONG_ATTACHMENT"], "An unlinked yes remains unresolved."),
    ("A05", {"target": "other-question"}, ["UNRESOLVED_OR_WRONG_ATTACHMENT"], "An answer is attached to the wrong question."),
    ("A06", {"speaker": "other-person"}, ["WRONG_RESPONDENT"], "A bystander's response is attributed to the suspect."),
    ("A07", {"slots": ["p", "q"], "agreed": ["p", "q"]}, ["COMPOUND_SCOPE_UNRESOLVED"], "A bare affirmative is expanded over two components without scoped annotation."),
    ("A08", {"slots": ["p", "q"], "agreed": ["p", "q"], "all": True}, [], "An explicitly annotated all-components answer is recorded at speech level."),
    ("A09", {"slots": ["p", "q"], "agreed": ["p"]}, [], "A compound question receives a clearly delimited answer to one component."),
    ("A10", {"agreed": ["presupposition"]}, ["ANSWER_OUTSIDE_SLOTS"], "Answering an explicit slot does not directly endorse its background presupposition."),
    ("A11", {"agreed": []}, ["NO_EXPLICIT_COMMITMENT"], "A missing response is not fabricated as assent."),
    ("A12", {"slots": ["p", "q"], "agreed": ["p"], "all": True}, ["ALL_SLOTS_MARKER_MISMATCH"], "An all-components label contradicts the listed narrow commitment.")]:
    add(identifier, "answer", description, data, expected)

add("Q01", "quantity", "Matched event counts permit a descriptive rate under the declared sample frame.", {}, [])
for i, (field, value) in enumerate([("actor", "group-b"), ("activity", "adult_viewing"), ("material", "clothed_photographs"),
                                   ("context", "other-platform"), ("period", "weekly"), ("unit", "files"),
                                   ("denominator", "all-internet-events")], 2):
    add("Q%02d" % i, "quantity", "A rate requires the same " + field + " key in this explicitly matched-count adapter.",
        {"changes": {field: value}}, [field.upper() + "_MISMATCH"])
add("Q09", "quantity", "A frequency recap changes both time period and event unit.",
    {"changes": {"period": "weekly", "unit": "persons"}}, ["PERIOD_MISMATCH", "UNIT_MISMATCH"])

for identifier, assumptions, local, conclusion, accepted, reason in [
    ("D01", [], "p", "p", True, "CONDITIONAL_ONLY"),
    ("D02", [["implies", "p", "q"]], "p", "q", True, "CONDITIONAL_ONLY"),
    ("D03", [], "p", "q", False, "CONCLUSION_NOT_DERIVED"),
    ("D04", [["not", "p"]], "p", "q", False, "INCONSISTENT_LOCAL_BRANCH"),
    ("D05", ["q"], "p", "q", True, "CONDITIONAL_ONLY"),
    ("D06", [False], True, "q", False, "INCONSISTENT_LOCAL_BRANCH")]:
    add(identifier, "discharge", "A local proof discharges only to a conditional; impossible branches are explicitly blocked as evidence.",
        {"premises": assumptions, "local": local, "conclusion": conclusion}, {"accepted": accepted, "reason": reason})

lineage_cases = [
    ("L01", {"s": {"source": True, "origin": "recording-a"}, "d": {"dependencies": ["s"]}}, "d", True, 1,
     "A direct quotation grounds in its recorded source."),
    ("L02", {"s": {"source": True, "origin": "recording-a"}, "d": {"dependencies": ["s", "s"]}}, "d", True, 1,
     "Repeated dependencies do not manufacture two origins."),
    ("L03", {"s": {"source": True, "origin": "recording-a"}, "r": {"dependencies": ["s"]}, "d": {"dependencies": ["s", "r"]}}, "d", True, 1,
     "The original and a recap remain one origin."),
    ("L04", {"d": {"dependencies": ["missing"]}}, "d", False, 0, "A missing provenance dependency blocks grounding."),
    ("L05", {"d": {"dependencies": []}}, "d", False, 0, "An unsupported derived assertion has no source root."),
    ("L06", {"a": {"dependencies": ["b"]}, "b": {"dependencies": ["a"]}}, "a", False, 0, "A cycle cannot ground itself."),
    ("L07", {"s": {"source": True, "origin": "recording-a"}, "a": {"dependencies": ["s", "b"]}, "b": {"dependencies": ["a"]}}, "a", False, 1,
     "A cycle remains invalid even if an external root also exists."),
    ("L08", {"s": {"source": True}, "d": {"dependencies": ["s"]}}, "d", False, 0, "An unnamed source origin cannot support an independence claim."),
    ("L09", {"s": {"source": True, "origin": "recording-a"}, "t": {"source": True, "origin": "recording-b"}, "d": {"dependencies": ["s", "t"]}}, "d", True, 2,
     "Two declared roots remain distinct without a claim of statistical independence."),
    ("L10", {"s": {"source": True, "origin": "recording-a"}, "t": {"source": True, "origin": "recording-a"}, "d": {"dependencies": ["s", "t"]}}, "d", True, 1,
     "Two files copied from the same origin remain one source origin.")]
for identifier, nodes, target, valid, count, description in lineage_cases:
    add(identifier, "lineage", description, {"nodes": nodes, "target": target}, {"valid": valid, "origin_count": count})

for identifier, parent, children, valid, description in [
    ("P01", [{"p": False}, {"p": True}], [[{"p": True}], [{"p": False}]], True, "A focal split is disjoint and exhaustive."),
    ("P02", [{"p": False}, {"p": True}], [[{"p": True}]], False, "Dropping the negative branch loses coverage."),
    ("P03", [{"p": False}, {"p": True}], [[{"p": True}], [{"p": True}, {"p": False}]], False, "Overlapping children are not an orthogonal partition."),
    ("P04", [{"p": True}], [[{"p": True}], [{"p": False}]], False, "A child cannot invent a parent-forbidden assignment."),
    ("P05", [{"p": True}], [[{"p": True}], []], True, "An empty negative child is valid when the parent already entails the focal proposition."),
    ("P06", [], [[], []], True, "Empty-set partition algebra is valid; entailment classification still marks inconsistency."),
    ("P07", [{"p": True}], [], False, "No children cannot reconstruct a nonempty parent."),
    ("P08", [{"p": True}], [[{"p": True}, {"p": True}]], True, "Repeated descriptions of the same model do not create new models.")]:
    add(identifier, "partition", description, {"parent": parent, "children": children}, valid)

for identifier, old, new, expected, description in [
    ("R01", [{"p": False}, {"p": True}], [{"p": False, "q": False}, {"p": False, "q": True}, {"p": True, "q": False}, {"p": True, "q": True}], True,
     "Adding an unconstrained atom preserves every old assignment."),
    ("R02", [{"p": False}, {"p": True}], [{"p": False, "q": False}, {"p": True, "q": True}], True,
     "A new definition can preserve exactly the old vocabulary's models."),
    ("R03", [{"p": False}, {"p": True}], [{"p": True, "q": False}], False,
     "Discarding an old possibility is evidential restriction, not pure extension."),
    ("R04", [{"p": True}], [{"p": False, "q": True}, {"p": True, "q": True}], False,
     "An extension cannot invent an old assignment excluded before refinement."),
    ("R05", [], [], True, "Set reconstruction alone does not certify nonempty epistemic consistency.")]:
    add(identifier, "reconstruction", description, {"old": old, "new": new, "atoms": ["p"]}, expected)

(HERE / "scenarios.json").write_text(json.dumps({"schema": "atlas.scenarios.v1", "synthetic": True,
    "annotation_note": "Examples are explicitly scoped logical fixtures, not measured psychological outcomes.",
    "cases": cases}, indent=2, ensure_ascii=True) + "\n", encoding="ascii")
print("Wrote %d distinct hand-annotated scenarios." % len(cases))
