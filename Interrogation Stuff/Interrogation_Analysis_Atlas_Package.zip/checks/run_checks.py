"""Run bounded semantic checks and write deterministic reports next to this file.

Usage: python checks/run_checks.py
The process returns a nonzero exit status if any check fails. No network,
third-party dependency, transcript parsing, or nondeterministic sampling occurs.
"""
import json
import sys
import traceback
from collections import Counter
from dataclasses import FrozenInstanceError, replace
from itertools import product
from pathlib import Path

import atlas_kernel as k

ROOT = Path(__file__).resolve().parent.parent
CHECKS = ROOT / "checks"
TESTS = ROOT / "tests"


def assert_equal(actual, expected):
    if actual != expected:
        raise AssertionError("Expected %r; received %r" % (expected, actual))


def must_raise(action, error=k.CheckError):
    try:
        action()
    except error:
        return
    expected_names = ", ".join(kind.__name__ for kind in error) if isinstance(error, tuple) else error.__name__
    raise AssertionError("Expected " + expected_names)


def premises(formulae):
    return [k.HardPremise("H%03d" % i, formula, "Synthetic explicitly adopted premise.")
            for i, formula in enumerate(formulae)]


def base_claim():
    a, interviewer = k.Entity("person-a", "person"), k.Entity("interviewer", "person")
    p = k.Proposition(a, "encountered", (k.Entity("file-a", "file"),), k.Scope("actual-case", "current-event", "some_event"))
    return k.Claim("C1", p, a, interviewer, "ACCEPT_FOR_DISCUSSION", "POSSIBLE", 12,
                   ("source-1",), ("at-most",), ("assumption-1",))


def modify_claim(old, changes):
    new = replace(old, id="C2", utterance_order=13)
    p, scope = old.proposition, old.proposition.scope
    if "actor" in changes:
        p = replace(p, actor=k.Entity(changes["actor"], "person"))
    if "predicate" in changes:
        p = replace(p, predicate=changes["predicate"])
    if "argument" in changes or "argument_kind" in changes:
        p = replace(p, arguments=(k.Entity(changes.get("argument", "file-a"), changes.get("argument_kind", "file")),))
    for name in ("context", "event_time", "quantifier"):
        if name in changes:
            scope = replace(scope, **{name: changes[name]})
    new = replace(new, proposition=replace(p, scope=scope))
    for name in ("speech_act", "modality"):
        if name in changes:
            new = replace(new, **{name: changes[name]})
    for name in ("qualifications", "source_spans", "dependencies"):
        if name in changes:
            new = replace(new, **{name: tuple(changes[name])})
    if "introducer" in changes:
        new = replace(new, introducer=k.Entity(changes["introducer"], "person"))
    return new


def question_answer(data):
    question = k.Question("q1", "detective", "respondent", 10, tuple(data.get("slots", ["p"])), ("presupposition",))
    answer = k.Answer("a1", data.get("speaker", "respondent"), data.get("answer_order", 11),
                      data.get("target", "q1"), tuple(data.get("agreed", ["p"])), data.get("all", False))
    return question, answer


def quantity_base():
    return k.QuantityKey("person-a", "underage_material_encounters", "specified_material", "specified-platform", "annual", "occasions", "all-specified-encounters")


def scenario(case):
    family, data, expected = case["family"], case["input"], case["expected"]
    if family == "boolean":
        actual = k.classify(premises(data["premises"]), data["query"])
        assert_equal(actual["status"], expected)
        for key, truth in (("positive_witness", True), ("negative_witness", False)):
            witness = actual[key]
            if witness is not None:
                assert_equal(all(k.evaluate(p, witness) for p in data["premises"]), True)
                assert_equal(k.evaluate(data["query"], witness), truth)
        return actual
    if family == "support":
        actual = k.support_state(data["positive"], data["negative"])
        assert_equal(actual["status"], expected)
        return actual
    if family == "transition":
        old = base_claim()
        actual = k.transition_guard(old, modify_claim(old, data["changes"]))
        assert_equal(actual, expected)
        return {"flags": actual}
    if family == "answer":
        actual = k.answer_guard(*question_answer(data))
        assert_equal(actual, expected)
        if not actual:
            report = k.question_commitments(*question_answer(data))
            assert_equal("presupposition" in report["propositions"], False)
            assert_equal(report["level"], "reported_assent")
            return report
        return {"flags": actual}
    if family == "quantity":
        base = quantity_base()
        actual = k.quantity_guard(base, replace(base, **data.get("changes", {})))
        assert_equal(actual, expected)
        return {"flags": actual}
    if family == "discharge":
        actual = k.discharge(premises(data["premises"]), data["local"], data["conclusion"])
        for key, val in expected.items():
            assert_equal(actual[key], val)
        return actual
    if family == "lineage":
        actual = k.lineage_audit(data["nodes"], data["target"])
        assert_equal(actual["valid"], expected["valid"])
        assert_equal(actual["distinct_origin_count"], expected["origin_count"])
        return actual
    if family == "partition":
        actual = k.partition_audit(data["parent"], data["children"])
        assert_equal(actual["valid"], expected)
        return actual
    if family == "reconstruction":
        actual = k.reconstruction_audit(data["old"], data["new"], data["atoms"])
        assert_equal(actual["conservative"], expected)
        return actual
    raise AssertionError("Unknown fixture family " + family)


# Independent oracle: compile each formula to a postfix stack program and
# evaluate all assignments at once as a bit word. The kernel uses recursive
# evaluation of one assignment at a time. No kernel evaluator is called here.
ORACLE_ROWS = list(product((False, True), repeat=3))
ORACLE_NAMES = ("p", "q", "r")
ORACLE_MASK = (1 << len(ORACLE_ROWS)) - 1
ORACLE_ATOMS = {name: sum(int(row[i]) << j for j, row in enumerate(ORACLE_ROWS))
                for i, name in enumerate(ORACLE_NAMES)}


def oracle_word(formula):
    pending, postfix = [(formula, False)], []
    while pending:
        node, seen = pending.pop()
        if type(node) is bool or isinstance(node, str):
            postfix.append(node)
        elif seen:
            postfix.append((node[0],))
        else:
            pending.append((node, True))
            for child in reversed(node[1:]):
                pending.append((child, False))
    stack = []
    for instruction in postfix:
        if type(instruction) is bool:
            stack.append(ORACLE_MASK if instruction else 0)
        elif isinstance(instruction, str):
            stack.append(ORACLE_ATOMS[instruction])
        elif instruction[0] == "not":
            stack.append(ORACLE_MASK ^ stack.pop())
        else:
            right, left = stack.pop(), stack.pop()
            op = instruction[0]
            if op == "and":
                stack.append(left & right)
            elif op == "or":
                stack.append(left | right)
            elif op == "xor":
                stack.append(left ^ right)
            elif op == "iff":
                stack.append(ORACLE_MASK ^ (left ^ right))
            elif op == "implies":
                stack.append((ORACLE_MASK ^ left) | right)
            else:
                raise AssertionError("Oracle operator absent")
    if len(stack) != 1:
        raise AssertionError("Oracle stack imbalance")
    return stack[0]


def depth_one():
    leaves = [False, True, "p", "q", "r"]
    yield from leaves
    for leaf in leaves:
        yield ["not", leaf]
    for op in ("and", "or", "implies", "iff", "xor"):
        for a in leaves:
            for b in leaves:
                yield [op, a, b]


def depth_two():
    leaves = [False, True, "p", "q", "r"]
    children = list(depth_one())
    yield from leaves
    for child in children:
        yield ["not", child]
    for op in ("and", "or", "implies", "iff", "xor"):
        for a in children:
            for b in children:
                yield [op, a, b]


def exhaustive_evaluation():
    formula_count, comparison_count = 0, 0
    assignments = [dict(zip(ORACLE_NAMES, row)) for row in ORACLE_ROWS]
    for formula in depth_two():
        word = oracle_word(formula)
        formula_count += 1
        for index, assignment in enumerate(assignments):
            actual = k.evaluate(formula, assignment)
            expected = bool((word >> index) & 1)
            if actual != expected:
                raise AssertionError("Oracle disagreement for %r under %r" % (formula, assignment))
            comparison_count += 1
    assert_equal(formula_count, 91265)
    assert_equal(comparison_count, 730120)
    return {"formula_count": formula_count, "formula_assignment_comparisons": comparison_count,
            "grammar": "All distinct ordered ASTs of depth <= 2; leaves False,True,p,q,r; unary not; binary and,or,implies,iff,xor.",
            "oracle": "Independent postfix stack program evaluated as 8-bit truth words."}


def exhaustive_classification():
    # Every subset of the eight assignments is explicitly represented as H.
    # Six query predicates test nonempty, inconsistent, both-sided, and one-sided
    # populations across all 256 finite model families.
    queries = ["p", "q", "r", ["not", "p"], ["not", "q"], ["not", "r"]]
    count, classification_counts = 0, Counter()
    for family in range(256):
        clauses = []
        for i, row in enumerate(ORACLE_ROWS):
            if (family >> i) & 1:
                literals = [name if bit else ["not", name] for name, bit in zip(ORACLE_NAMES, row)]
                clauses.append(["and", literals[0], ["and", literals[1], literals[2]]])
        formula = False
        for clause in clauses:
            formula = ["or", formula, clause]
        # Ensure exactly the same three declared atoms even for the empty family.
        formula = ["and", formula, ["and", ["or", "p", ["not", "p"]],
                                     ["and", ["or", "q", ["not", "q"]], ["or", "r", ["not", "r"]]]]]
        for query in queries:
            word = oracle_word(query)
            yes, no = family & word, family & (ORACLE_MASK ^ word)
            expected = "INCONSISTENT" if not family else "ENTAILED" if not no else "REFUTED" if not yes else "UNDETERMINED"
            actual = k.classify(premises([formula]), query)
            assert_equal(actual["status"], expected)
            assert_equal(actual["model_count"], family.bit_count())
            assert_equal(actual["true_count"], yes.bit_count())
            assert_equal(actual["false_count"], no.bit_count())
            classification_counts[expected] += 1
            count += 1
    assert_equal(count, 1536)
    return {"finite_model_families": 256, "query_classifications": count,
            "classification_counts": dict(sorted(classification_counts.items())),
            "scope": "Every subset of three-atom valuations crossed with p,q,r and their negations."}


def rename(formula, mapping):
    if type(formula) is bool:
        return formula
    if isinstance(formula, str):
        return mapping.get(formula, formula)
    return [formula[0]] + [rename(c, mapping) for c in formula[1:]]


def metamorphic_checks():
    cases = [([], "p"), (["p"], "q"), (["p", ["not", "p"]], "q"),
             ([["implies", "p", "q"], "p"], "q"),
             ([["xor", "p", "q"], ["xor", "q", "r"]], ["iff", "p", "r"]),
             ([["or", "p", "q"]], ["and", "p", "q"])]
    count = 0
    for h, query in cases:
        original = k.classify(premises(h), query)
        variants = [
            (h[::-1], query),
            (h + h, query),
            ([rename(p, {"p": "z", "q": "a", "r": "m"}) for p in h], rename(query, {"p": "z", "q": "a", "r": "m"})),
            (h + [["or", "fresh", ["not", "fresh"]]], query),
            (h, ["not", ["not", query]])]
        for index, (new_h, new_query) in enumerate(variants):
            actual = k.classify(premises(new_h), new_query)
            assert_equal(actual["status"], original["status"])
            expected_multiplier = 2 if index == 3 else 1
            assert_equal(actual["model_count"], original["model_count"] * expected_multiplier)
            count += 1
    return {"transformations_checked": count, "seed_cases": len(cases),
            "transformations": ["premise permutation", "premise repetition under fresh record IDs",
                                "bijective atom renaming", "unconstrained fresh-atom extension", "double negation"]}


def boundary_and_integration_checks():
    records = []

    def check(identifier, description, action):
        action()
        records.append({"id": identifier, "description": description, "passed": True})

    check("I01", "Malformed AST arity is rejected.", lambda: must_raise(lambda: k.classify([], ["and", "p"])))
    check("I02", "Unknown operator is rejected.", lambda: must_raise(lambda: k.classify([], ["probably", "p"])))
    check("I03", "Numeric one is not silently a Boolean truth constant.", lambda: must_raise(lambda: k.classify([], 1)))
    check("I04", "Missing valuation is rejected.", lambda: must_raise(lambda: k.evaluate("p", {})))
    check("I05", "Non-Boolean valuation is rejected.", lambda: must_raise(lambda: k.evaluate("p", {"p": 1})))
    check("I06", "A cap above twelve cannot silently enable unsupported enumeration.", lambda: must_raise(lambda: k.classify([], "p", cap=13)))

    twelve = "p0"
    for i in range(1, 12):
        twelve = ["or", twelve, "p%d" % i]
    check("I07", "The twelve-atom boundary examines 4096 valuations.", lambda: assert_equal(k.classify([], twelve)["assignments_examined"], 4096))
    check("I08", "A thirteen-atom query is rejected.", lambda: must_raise(lambda: k.classify([], ["or", twelve, "p12"])))
    check("I09", "Repeated immutable premise IDs are rejected.", lambda: must_raise(lambda: k.classify([k.HardPremise("h", "p", "a"), k.HardPremise("h", "q", "b")], "p")))
    check("I10", "Hard premises require explicit justification.", lambda: must_raise(lambda: k.HardPremise("h", "p", "")))
    check("I11", "Untyped formulae do not bypass the hard-premise interface.", lambda: must_raise(lambda: k.classify(["p"], "p")))
    check("I12", "An unsupported entity kind is rejected.", lambda: must_raise(lambda: k.Entity("x", "guilt")))
    check("I13", "Mutable proposition argument lists are rejected.", lambda: must_raise(lambda: k.Proposition(k.Entity("a", "person"), "saw", [], k.Scope("c", "t", "some"))))
    check("I14", "An account cannot be silently used as an authenticated human utterer.", lambda: must_raise(lambda: replace(base_claim(), utterer=k.Entity("a", "account"))))
    check("I15", "Claims require source spans.", lambda: must_raise(lambda: replace(base_claim(), source_spans=())))

    ledger = k.EvidenceLedger()
    ledger.add(base_claim())
    check("I16", "A reported claim does not become a world premise.", lambda: assert_equal(ledger.world_query("embedded_claim")["status"], "UNDETERMINED"))
    ledger.add(base_claim())
    check("I17", "Re-adding the same immutable record is idempotent.", lambda: assert_equal(len(ledger.records), 1))
    check("I18", "Changing an existing claim ID is rejected.", lambda: must_raise(lambda: ledger.add(replace(base_claim(), modality="CERTAIN"))))
    check("I19", "A separately declared hard premise changes world status explicitly.", lambda: assert_equal(ledger.world_query("embedded_claim", premises(["embedded_claim"]))["status"], "ENTAILED"))
    check("I20", "A speech claim cannot be passed as a hard world premise.", lambda: must_raise(lambda: k.classify([base_claim()], "embedded_claim")))

    q, a = question_answer({})
    check("I21", "The answer commitment excludes the background presupposition.", lambda: assert_equal(k.question_commitments(q, a)["propositions"], ["p"]))
    check("I22", "An invalid attachment cannot issue a commitment certificate.", lambda: must_raise(lambda: k.question_commitments(q, replace(a, order=9))))
    check("I23", "A duplicate compound slot is rejected.", lambda: assert_equal("INVALID_QUESTION_SLOTS" in k.answer_guard(replace(q, slots=("p", "p")), a), True))

    qb = quantity_base()
    check("I24", "A valid matched rate is computed.", lambda: assert_equal(k.bounded_rate(2, 5, qb, qb), 0.4))
    check("I25", "A zero denominator is rejected.", lambda: must_raise(lambda: k.bounded_rate(0, 0, qb, qb)))
    check("I26", "A numerator above the matched event population is rejected.", lambda: must_raise(lambda: k.bounded_rate(6, 5, qb, qb)))
    check("I27", "Negative event counts are rejected.", lambda: must_raise(lambda: k.bounded_rate(-1, 5, qb, qb)))
    check("I28", "Mismatched units prevent rate computation.", lambda: must_raise(lambda: k.bounded_rate(1, 5, qb, replace(qb, unit="files"))))
    check("I29", "A local conclusion remains non-unconditional after discharge.", lambda: assert_equal(k.discharge([], "p", "p")["unconditional"], "UNDETERMINED"))

    nodes = {"a": {"source": True, "origin": "recording-a"}, "b": {"source": True, "origin": "recording-b"}, "recap": {"dependencies": ["a"]}}
    check("I30", "Original and recap have a shared origin.", lambda: assert_equal(k.independence_guard(nodes, "a", "recap")["status"], "SHARED_ORIGIN"))
    check("I31", "Disjoint recorded origins do not prove statistical independence.", lambda: assert_equal(k.independence_guard(nodes, "a", "b")["statistical_independence_established"], False))
    check("I32", "Invalid provenance cannot establish independence.", lambda: assert_equal(k.independence_guard(nodes, "missing", "b")["status"], "INVALID_LINEAGE"))
    check("I33", "A root with dependencies is flagged as malformed.", lambda: assert_equal(k.lineage_audit({"a": {"source": True, "origin": "a", "dependencies": ["b"]}, "b": {"source": True, "origin": "b"}}, "a")["valid"], False))

    old = list(k.valuations(["p", "q"]))
    pos, neg = k.split_partition(old, ["and", "p", "q"])
    check("I34", "A joint focal split reconstructs all four old assignments.", lambda: assert_equal(k.partition_audit(old, [pos, neg])["valid"], True))
    check("I35", "Restriction to old vocabulary rejects an erased old atom.", lambda: must_raise(lambda: k.reconstruction_audit([{"p": True}], [{"q": True}], ["p"])))
    check("I36", "Old row vocabulary cannot silently change.", lambda: must_raise(lambda: k.reconstruction_audit([{"p": True, "r": False}], [{"p": True, "q": True}], ["p"])))
    check("I37", "Non-Boolean model data cannot enter partition checks.", lambda: must_raise(lambda: k.partition_audit([{"p": 1}], [])))

    # Every pair is satisfiable but the three constraints are not jointly satisfiable.
    joint = [["xor", "p", "q"], ["xor", "q", "r"], ["xor", "p", "r"]]
    check("I38", "All three pairwise projections have witnesses.", lambda: assert_equal(all(k.classify(premises([joint[i], joint[j]]), True)["model_count"] > 0 for i, j in ((0, 1), (0, 2), (1, 2))), True))
    check("I39", "The full hyperedge rejects the pairwise-compatible family.", lambda: assert_equal(k.classify(premises(joint), True)["status"], "INCONSISTENT"))
    check("I40", "A true zero-atom query has exactly one empty assignment model.", lambda: assert_equal(k.classify([], True)["model_count"], 1))
    external_formula = ["not", "p"]
    frozen_premise = k.HardPremise("frozen", external_formula, "Explicit immutable input.")
    external_formula[1] = "q"
    check("I41", "Mutating a caller-owned AST cannot alter an adopted hard premise.", lambda: assert_equal(frozen_premise.formula, ("not", "p")))
    check("I42", "Claim records reject in-place attribute mutation.", lambda: must_raise(lambda: setattr(base_claim(), "modality", "CERTAIN"), FrozenInstanceError))
    utterance = k.Utterance("u1", "Maybe... [unclear]", ("speaker-a", "speaker-b"), None, "recorded-t1", "audio:10-12")
    check("I43", "Original wording and unresolved speaker candidates survive the typed record.", lambda: assert_equal((utterance.original_text, utterance.speaker_candidates), ("Maybe... [unclear]", ("speaker-a", "speaker-b"))))
    check("I44", "Mutable speaker-candidate lists are rejected.", lambda: must_raise(lambda: k.Utterance("u1", "text", ["a", "b"], None, "t", "span")))
    check("I45", "Boolean values cannot masquerade as utterance order integers.", lambda: must_raise(lambda: replace(q, order=True)))
    check("I46", "The all-slots marker cannot be an unparsed string.", lambda: must_raise(lambda: replace(a, explicit_all_slots="yes")))
    check("I47", "Incomplete quantity keys cannot authorize a denominator match.", lambda: must_raise(lambda: replace(qb, denominator="")))
    check("I48", "A parent family cannot mix incompatible variable vocabularies.", lambda: must_raise(lambda: k.partition_audit([{"p": True}, {"q": True}], [[{"p": True}, {"q": True}]])))
    check("I49", "Projection cannot hide inconsistent extended vocabularies.", lambda: must_raise(lambda: k.reconstruction_audit([{"p": True}], [{"p": True, "q": True}, {"p": True, "r": False}], ["p"])))
    check("I50", "Speaker reassignment cannot pass a meaning-preserving transition guard.", lambda: assert_equal(k.transition_guard(base_claim(), replace(base_claim(), utterer=k.Entity("other-speaker", "person"))), ["UTTERER_CHANGE"]))
    check("I51", "Entity identifiers reject mutable lists.", lambda: must_raise(lambda: k.Entity(["person-a"], "person")))
    check("I52", "Entity kinds reject mutable lists with CheckError.", lambda: must_raise(lambda: k.Entity("person-a", ["person"])))
    check("I53", "Predicates reject mutable lists.", lambda: must_raise(lambda: replace(base_claim().proposition, predicate=["encountered"])))
    check("I54", "Claim identifiers reject mutable lists.", lambda: must_raise(lambda: replace(base_claim(), id=["C1"])))
    check("I55", "Hard-premise identifiers reject mutable lists.", lambda: must_raise(lambda: k.HardPremise(["H1"], "p", "explicit")))
    check("I56", "Hard-premise justification rejects mutable nested objects.", lambda: must_raise(lambda: k.HardPremise("H1", "p", {"reason": "explicit"})))
    check("I57", "Hard-premise status rejects mutable lists with CheckError.", lambda: must_raise(lambda: k.HardPremise("H1", "p", "explicit", ["explicit_assumption"])))
    check("I58", "Utterance identifiers reject mutable lists.", lambda: must_raise(lambda: replace(utterance, id=["u1"])))
    check("I59", "Recording-time labels reject mutable lists.", lambda: must_raise(lambda: replace(utterance, recording_time=["t1"])))
    check("I60", "Source-span labels reject mutable dictionaries.", lambda: must_raise(lambda: replace(utterance, source_span={"start": 1})))
    check("I61", "Original utterance text rejects non-string objects.", lambda: must_raise(lambda: replace(utterance, original_text=["text"])))
    check("I62", "A string false cannot masquerade as a source-root Boolean.", lambda: assert_equal(k.lineage_audit({"a": {"source": "false", "origin": "x"}}, "a")["valid"], False))
    check("I63", "A dependency string cannot be iterated as a list of character IDs.", lambda: assert_equal(k.lineage_audit({"a": {"source": True, "origin": "x"}, "b": {"dependencies": "a"}}, "b")["valid"], False))
    check("I64", "A lineage node must have a mapping schema.", lambda: assert_equal(k.lineage_audit({"a": ["source"]}, "a")["valid"], False))
    check("I65", "Lineage node identifiers require nonempty string labels.", lambda: assert_equal(k.lineage_audit({1: {"source": True, "origin": "x"}}, 1)["valid"], False))
    check("I66", "Nested mutable dependency identifiers are rejected.", lambda: assert_equal(k.lineage_audit({"a": {"dependencies": [{"id": "b"}]}}, "a")["valid"], False))
    check("I67", "Mutable source-origin labels are rejected.", lambda: assert_equal(k.lineage_audit({"a": {"source": True, "origin": ["x"]}}, "a")["valid"], False))
    check("I68", "Unknown lineage schema keys cannot silently hide a misspelled dependency field.", lambda: assert_equal(k.lineage_audit({"a": {"source": True, "origin": "x", "dependences": ["b"]}}, "a")["valid"], False))
    check("I69", "The public ledger mapping rejects direct item replacement.", lambda: must_raise(lambda: ledger.records.__setitem__("C1", replace(base_claim(), modality="CERTAIN")), (TypeError, AttributeError)))
    check("I70", "The public ledger mapping itself cannot be replaced.", lambda: must_raise(lambda: setattr(ledger, "records", {}), AttributeError))
    check("I71", "Direct evaluation cannot bypass empty-atom grammar validation.", lambda: must_raise(lambda: k.evaluate("", {"": True})))
    check("I72", "Direct evaluation cannot bypass whitespace-atom grammar validation.", lambda: must_raise(lambda: k.evaluate(" ", {" ": True})))
    check("I73", "Model rows reject empty atom labels.", lambda: must_raise(lambda: k.freeze_model({"": True})))
    check("I74", "An empty parent does not bypass malformed focal-formula validation.", lambda: must_raise(lambda: k.split_partition([], ["and", "p"])))
    check("I75", "Mixed-type vocabulary raises the documented CheckError before sorting.", lambda: must_raise(lambda: list(k.valuations(["p", 1]))))
    check("I76", "A vocabulary string cannot silently become separate character atoms.", lambda: must_raise(lambda: list(k.valuations("pq"))))
    check("I77", "Mutable speech-act labels are rejected with CheckError.", lambda: must_raise(lambda: replace(base_claim(), speech_act=["ASSERT"])))
    check("I78", "Whitespace-only speaker-candidate labels are rejected.", lambda: must_raise(lambda: replace(utterance, speaker_candidates=(" ",))))
    check("I79", "Whitespace-only scope labels are rejected.", lambda: must_raise(lambda: k.Scope(" ", "t", "some")))
    check("I80", "Model rows require mappings rather than arbitrary iterables.", lambda: must_raise(lambda: k.freeze_model([("p", True)])))
    check("I81", "Whitespace-only answer targets are rejected.", lambda: must_raise(lambda: replace(a, target=" ")))
    check("I82", "The transition guard rejects untyped inputs with CheckError.", lambda: must_raise(lambda: k.transition_guard({}, base_claim())))
    check("I83", "The answer guard rejects untyped inputs with CheckError.", lambda: must_raise(lambda: k.answer_guard({}, a)))
    check("I84", "Quantity matching rejects untyped inputs with CheckError.", lambda: must_raise(lambda: k.quantity_guard({}, qb)))
    check("I85", "Evidence-support identifiers cannot be mutable or non-string objects.", lambda: must_raise(lambda: k.support_state([["a"]], [])))
    return {"named_checks": len(records), "checks": records}


def run():
    fixture = json.loads((TESTS / "scenarios.json").read_text(encoding="ascii"))
    cases = fixture["cases"]
    if len({c["id"] for c in cases}) != len(cases):
        raise AssertionError("Duplicate scenario identifier")
    results, failures = [], []
    for case in cases:
        try:
            detail = scenario(case)
            results.append({"id": case["id"], "family": case["family"], "passed": True, "detail": detail})
        except Exception as exc:
            failures.append({"id": case["id"], "message": str(exc), "traceback": traceback.format_exc()})
            results.append({"id": case["id"], "family": case["family"], "passed": False})
    suites = {}
    for name, function in [("exhaustive_evaluation", exhaustive_evaluation), ("exhaustive_classification", exhaustive_classification),
                           ("metamorphic", metamorphic_checks), ("boundary_integration", boundary_and_integration_checks)]:
        try:
            suites[name] = {"passed": True, **function()}
        except Exception as exc:
            suites[name] = {"passed": False, "message": str(exc)}
            failures.append({"id": name, "message": str(exc), "traceback": traceback.format_exc()})
    report = {
        "schema": "atlas.verification.v1", "deterministic": True, "passed": not failures,
        "tested_kernel_atom_cap": 12,
        "scenario_count": len(cases), "scenario_passed": sum(r["passed"] for r in results),
        "scenario_families": dict(sorted(Counter(c["family"] for c in cases).items())),
        "suites": suites, "scenarios": results, "failures": failures,
        "limits": ["Finite Boolean world semantics only; no quantified, temporal, modal, or causal solver.",
                   "Typed temporal/modality/quantifier labels are compared; their rich semantics are not automatically proved.",
                   "Human annotation supplies propositions, sources, identity, scope, and answer linkage.",
                   "No speech-to-world bridge is inferred automatically.",
                   "Source ancestry is recorded provenance, not authentication or statistical-independence proof.",
                   "The guards flag changes for review; flags do not diagnose deceit, false memory, guilt, or inadmissibility.",
                   "Scenario checks are synthetic regression controls, not empirical measurements of interviewing accuracy.",
                   "Full model checking is complete only for each accepted finite input within the declared atom cap.",
                   "Tests do not prove arbitrary future implementation behavior or the truth of natural-language annotations."]}
    (CHECKS / "results.json").write_text(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="ascii")
    lines = ["INTERROGATION ANALYSIS ATLAS: EXECUTED VERIFICATION REPORT", "",
             "Overall: " + ("PASS" if not failures else "FAIL"),
             "Distinct hand-annotated scenarios: %d of %d passed." % (report["scenario_passed"], len(cases)),
             "No aggregate accuracy percentage is inferred from these synthetic fixtures.", "", "Scenario families:"]
    lines.extend("  %s: %d" % pair for pair in report["scenario_families"].items())
    lines += ["", "Separately counted implementation checks:"]
    for name, suite in suites.items():
        lines.append("  %s: %s" % (name, "PASS" if suite["passed"] else "FAIL"))
        for key in ("formula_count", "formula_assignment_comparisons", "finite_model_families", "query_classifications", "transformations_checked", "named_checks"):
            if key in suite:
                lines.append("    %s: %s" % (key, suite[key]))
    lines += ["", "The independent Boolean oracle uses postfix bit-vector evaluation.",
              "The kernel uses recursive evaluation on single assignments.",
              "Depth <= 2 grammar includes all five ordered binary operators and NOT,",
              "with Boolean constants and three atom names; it is not all Boolean syntax.",
              "The 12-atom boundary and rejection at 13 atoms are tested separately.", "", "Limits:"]
    lines.extend("  " + limit for limit in report["limits"])
    if failures:
        lines += ["", "Failures:"] + ["  %s: %s" % (f["id"], f["message"]) for f in failures]
    lines += ["", "Regeneration: python checks/run_checks.py", ""]
    (CHECKS / "results.txt").write_text("\n".join(lines), encoding="ascii")
    print("\n".join(lines[:30]))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(run())
