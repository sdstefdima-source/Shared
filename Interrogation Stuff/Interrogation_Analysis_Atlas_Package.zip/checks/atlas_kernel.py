"""Bounded, explicit semantic checks for the Interrogation Analysis Atlas.

No natural-language parsing, authentication, psychology, legal classification,
or automatic promotion of reported content into world truth is implemented.
All formulae and labels are supplied by a human annotation process.
"""
from dataclasses import dataclass
from itertools import product
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Optional, Tuple

MAX_ATOMS = 12
OPS = {"not": 1, "and": 2, "or": 2, "implies": 2, "iff": 2, "xor": 2}


class CheckError(ValueError):
    pass


def _label(value):
    return type(value) is str and bool(value.strip())


def _labels(values):
    if isinstance(values, (str, bytes)):
        raise CheckError("A collection of labels cannot be a bare string.")
    try:
        values = tuple(values)
    except TypeError as exc:
        raise CheckError("A label collection must be iterable.") from exc
    if any(not _label(value) for value in values):
        raise CheckError("Labels must be nonempty, non-whitespace strings.")
    return values


def variables(formula: Any) -> set:
    if type(formula) is bool:
        return set()
    if _label(formula):
        return {formula}
    if not isinstance(formula, (list, tuple)) or not formula:
        raise CheckError("Formula must be a Boolean, nonempty atom, or AST.")
    op = formula[0]
    if not _label(op) or op not in OPS or len(formula) != OPS[op] + 1:
        raise CheckError("Unknown operator or wrong arity.")
    found = set()
    for child in formula[1:]:
        found.update(variables(child))
    return found


def freeze_formula(formula: Any):
    """Validate and copy a formula into immutable recursive tuples."""
    variables(formula)
    if type(formula) is bool or isinstance(formula, str):
        return formula
    return tuple([formula[0]] + [freeze_formula(child) for child in formula[1:]])


def evaluate(formula: Any, assignment: Mapping[str, bool]) -> bool:
    if type(formula) is bool:
        return formula
    if isinstance(formula, str):
        if not _label(formula):
            raise CheckError("Invalid atom name.")
        if formula not in assignment or type(assignment[formula]) is not bool:
            raise CheckError("Missing atom or non-Boolean assignment.")
        return assignment[formula]
    variables(formula)
    op = formula[0]
    left = evaluate(formula[1], assignment)
    if op == "not":
        return not left
    right = evaluate(formula[2], assignment)
    if op == "and":
        return left and right
    if op == "or":
        return left or right
    if op == "implies":
        return (not left) or right
    if op == "iff":
        return left == right
    if op == "xor":
        return left != right
    raise CheckError("Unknown operator.")


def valuations(atoms: Iterable[str], cap: int = MAX_ATOMS):
    if type(cap) is not int or cap < 0 or cap > MAX_ATOMS:
        raise CheckError("Cap must be an integer between zero and twelve.")
    names = sorted(set(_labels(atoms)))
    if len(names) > cap:
        raise CheckError("Declared finite atom cap exceeded.")
    for row in product((False, True), repeat=len(names)):
        yield dict(zip(names, row))


@dataclass(frozen=True)
class HardPremise:
    id: str
    formula: Any
    justification: str
    status: str = "explicit_assumption"

    def __post_init__(self):
        if not _label(self.id) or not _label(self.justification):
            raise CheckError("Hard premises need an ID and explicit justification.")
        if not _label(self.status) or self.status not in {"explicit_assumption", "adopted_bridge", "verified_input"}:
            raise CheckError("Unrecognized hard-premise status.")
        object.__setattr__(self, "formula", freeze_formula(self.formula))


def classify(premises: Iterable[HardPremise], query: Any, cap=MAX_ATOMS) -> dict:
    premises = tuple(premises)
    if any(not isinstance(p, HardPremise) for p in premises):
        raise CheckError("Only explicitly declared HardPremise records enter H.")
    if len({p.id for p in premises}) != len(premises):
        raise CheckError("Duplicate premise identifier.")
    names = variables(query)
    for p in premises:
        names.update(variables(p.formula))
    models, yes, no, examined = [], [], [], 0
    for model in valuations(names, cap):
        examined += 1
        if all(evaluate(p.formula, model) for p in premises):
            models.append(model)
            (yes if evaluate(query, model) else no).append(model)
    if not models:
        status = "INCONSISTENT"
    elif not no:
        status = "ENTAILED"
    elif not yes:
        status = "REFUTED"
    else:
        status = "UNDETERMINED"
    return {"status": status, "atoms": sorted(names), "assignments_examined": examined,
            "model_count": len(models), "true_count": len(yes), "false_count": len(no),
            "positive_witness": yes[0] if yes else None,
            "negative_witness": no[0] if no else None,
            "premise_ids": [p.id for p in premises]}


@dataclass(frozen=True)
class Entity:
    id: str
    kind: str

    def __post_init__(self):
        if not _label(self.id) or not _label(self.kind) or self.kind not in {"person", "account", "device", "file", "event", "group", "place"}:
            raise CheckError("Invalid entity identity or type.")


@dataclass(frozen=True)
class Utterance:
    id: str
    original_text: str
    speaker_candidates: Tuple[str, ...]
    event_time: Optional[str]
    recording_time: str
    source_span: str

    def __post_init__(self):
        if not _label(self.id) or type(self.original_text) is not str or not _label(self.recording_time) or not _label(self.source_span):
            raise CheckError("An utterance retains its ID, original string, recording time, and source span.")
        if not isinstance(self.speaker_candidates, tuple) or any(not _label(s) for s in self.speaker_candidates):
            raise CheckError("Speaker alternatives must be an immutable tuple of identity labels.")
        if self.event_time is not None and not _label(self.event_time):
            raise CheckError("An unknown event time is None; a known time has an explicit label.")


@dataclass(frozen=True)
class Scope:
    context: str
    event_time: str
    quantifier: str

    def __post_init__(self):
        if not all(_label(v) for v in (self.context, self.event_time, self.quantifier)):
            raise CheckError("Scope fields are explicit nonempty strings.")


@dataclass(frozen=True)
class Proposition:
    actor: Entity
    predicate: str
    arguments: Tuple[Entity, ...]
    scope: Scope

    def __post_init__(self):
        if not isinstance(self.actor, Entity) or not _label(self.predicate) or not isinstance(self.scope, Scope):
            raise CheckError("Proposition contains invalid typed fields.")
        if not isinstance(self.arguments, tuple) or any(not isinstance(a, Entity) for a in self.arguments):
            raise CheckError("Arguments must be an immutable tuple of typed entities.")


SPEECH_ACTS = {"ASSERT", "DENY", "ASK", "PRESUPPOSE", "ASSUME", "ACCEPT_FOR_DISCUSSION",
               "BELIEVE", "ATTRIBUTE_KNOWLEDGE", "ASSENT", "CORRECT"}
MODALITIES = {"CERTAIN", "POSSIBLE", "PROBABLE", "CONDITIONAL", "UNKNOWN"}


@dataclass(frozen=True)
class Claim:
    id: str
    proposition: Proposition
    utterer: Entity
    introducer: Entity
    speech_act: str
    modality: str
    utterance_order: int
    source_spans: Tuple[str, ...]
    qualifications: Tuple[str, ...] = ()
    dependencies: Tuple[str, ...] = ()
    version: int = 1

    def __post_init__(self):
        if not _label(self.id) or not isinstance(self.proposition, Proposition):
            raise CheckError("Invalid claim identity or proposition.")
        if not isinstance(self.utterer, Entity) or not isinstance(self.introducer, Entity):
            raise CheckError("Claim speakers must be typed entities.")
        if self.utterer.kind != "person" or self.introducer.kind != "person":
            raise CheckError("Claim speakers require person identities.")
        if not _label(self.speech_act) or self.speech_act not in SPEECH_ACTS or not _label(self.modality) or self.modality not in MODALITIES:
            raise CheckError("Unrecognized speech act or modality.")
        if type(self.utterance_order) is not int or self.utterance_order < 0 or type(self.version) is not int or self.version < 1:
            raise CheckError("Invalid order or version.")
        for values in (self.source_spans, self.qualifications, self.dependencies):
            if not isinstance(values, tuple) or any(not _label(s) for s in values):
                raise CheckError("Claim sequences must be tuples of nonempty strings.")
        if not self.source_spans:
            raise CheckError("Claim requires a source span.")


class EvidenceLedger:
    __slots__ = ("__records",)

    def __init__(self):
        self.__records = {}

    @property
    def records(self):
        """Expose a read-only view; all supported writes pass through add()."""
        return MappingProxyType(self.__records)

    def add(self, claim: Claim):
        if not isinstance(claim, Claim):
            raise CheckError("Evidence ledger accepts typed Claim records.")
        if claim.id in self.__records and self.__records[claim.id] != claim:
            raise CheckError("Immutable claim identifier reused with different content.")
        self.__records[claim.id] = claim

    def world_query(self, query, hard_premises=()):
        # Speech facts do not contribute embedded formulae to H.
        return classify(hard_premises, query)


def support_state(positive: Iterable[str], negative: Iterable[str]) -> dict:
    positive, negative = sorted(set(_labels(positive))), sorted(set(_labels(negative)))
    status = {(False, False): "NEITHER", (True, False): "POSITIVE_ONLY",
              (False, True): "NEGATIVE_ONLY", (True, True): "BOTH"}[(bool(positive), bool(negative))]
    return {"status": status, "positive": positive, "negative": negative}


def transition_guard(old: Claim, new: Claim) -> list:
    """Check a purported meaning-preserving paraphrase; return all change flags.

    A change is review-required, not necessarily false. This conservative guard
    does not infer that similar predicates, account names, or pronouns co-refer.
    """
    if not isinstance(old, Claim) or not isinstance(new, Claim):
        raise CheckError("Transition guard requires typed Claim records.")
    checks = {
        "ACTOR_CHANGE": old.proposition.actor != new.proposition.actor,
        "PREDICATE_CHANGE": old.proposition.predicate != new.proposition.predicate,
        "ARGUMENT_CHANGE": old.proposition.arguments != new.proposition.arguments,
        "CONTEXT_CHANGE": old.proposition.scope.context != new.proposition.scope.context,
        "EVENT_TIME_CHANGE": old.proposition.scope.event_time != new.proposition.scope.event_time,
        "QUANTIFIER_CHANGE": old.proposition.scope.quantifier != new.proposition.scope.quantifier,
        "SPEECH_ACT_CHANGE": old.speech_act != new.speech_act,
        "MODALITY_CHANGE": old.modality != new.modality,
        "QUALIFICATION_CHANGE": old.qualifications != new.qualifications,
        "UTTERER_CHANGE": old.utterer != new.utterer,
        "INTRODUCER_CHANGE": old.introducer != new.introducer,
        "SOURCE_LINEAGE_LOSS": not set(old.source_spans).issubset(new.source_spans),
        "DEPENDENCY_LOSS": not set(old.dependencies).issubset(new.dependencies),
    }
    return [name for name, changed in checks.items() if changed]


@dataclass(frozen=True)
class Question:
    id: str
    asker: str
    addressee: str
    order: int
    slots: Tuple[str, ...]
    presuppositions: Tuple[str, ...] = ()

    def __post_init__(self):
        if not all(_label(s) for s in (self.id, self.asker, self.addressee)):
            raise CheckError("Question identities require explicit strings.")
        if type(self.order) is not int or self.order < 0:
            raise CheckError("Question order must be a nonnegative integer.")
        for values in (self.slots, self.presuppositions):
            if not isinstance(values, tuple) or any(not _label(s) for s in values):
                raise CheckError("Question scopes require immutable tuples of proposition IDs.")


@dataclass(frozen=True)
class Answer:
    id: str
    speaker: str
    order: int
    target: Optional[str]
    agreed_slots: Tuple[str, ...]
    explicit_all_slots: bool = False

    def __post_init__(self):
        if not all(_label(s) for s in (self.id, self.speaker)):
            raise CheckError("Answer identities require explicit strings.")
        if type(self.order) is not int or self.order < 0:
            raise CheckError("Answer order must be a nonnegative integer.")
        if self.target is not None and not _label(self.target):
            raise CheckError("An unresolved answer target is None.")
        if not isinstance(self.agreed_slots, tuple) or any(not _label(s) for s in self.agreed_slots):
            raise CheckError("Answer scopes require immutable tuples of proposition IDs.")
        if type(self.explicit_all_slots) is not bool:
            raise CheckError("The all-slots flag requires explicit Boolean annotation.")


def answer_guard(question: Question, answer: Answer) -> list:
    if not isinstance(question, Question) or not isinstance(answer, Answer):
        raise CheckError("Answer guard requires typed Question and Answer records.")
    flags = []
    if answer.order <= question.order:
        flags.append("ANSWER_NOT_AFTER_QUESTION")
    if answer.target != question.id:
        flags.append("UNRESOLVED_OR_WRONG_ATTACHMENT")
    if answer.speaker != question.addressee:
        flags.append("WRONG_RESPONDENT")
    if not question.slots or len(set(question.slots)) != len(question.slots):
        flags.append("INVALID_QUESTION_SLOTS")
    if len(set(answer.agreed_slots)) != len(answer.agreed_slots):
        flags.append("DUPLICATE_ANSWER_SLOT")
    if any(slot not in question.slots for slot in answer.agreed_slots):
        flags.append("ANSWER_OUTSIDE_SLOTS")
    if not answer.agreed_slots:
        flags.append("NO_EXPLICIT_COMMITMENT")
    if len(answer.agreed_slots) > 1 and not answer.explicit_all_slots:
        flags.append("COMPOUND_SCOPE_UNRESOLVED")
    if answer.explicit_all_slots and set(answer.agreed_slots) != set(question.slots):
        flags.append("ALL_SLOTS_MARKER_MISMATCH")
    return flags


def question_commitments(question, answer):
    flags = answer_guard(question, answer)
    if flags:
        raise CheckError(",".join(flags))
    # Presuppositions are deliberately excluded; commitments remain speech-level.
    return {"level": "reported_assent", "respondent": answer.speaker,
            "propositions": list(answer.agreed_slots), "question": question.id,
            "answer": answer.id, "independent_origin": False}


@dataclass(frozen=True)
class QuantityKey:
    actor: str
    activity: str
    material: str
    context: str
    period: str
    unit: str
    denominator: str

    def __post_init__(self):
        if any(not _label(getattr(self, field)) for field in self.__dataclass_fields__):
            raise CheckError("Quantity keys require all seven explicit nonempty strings.")


def quantity_guard(a: QuantityKey, b: QuantityKey) -> list:
    if not isinstance(a, QuantityKey) or not isinstance(b, QuantityKey):
        raise CheckError("Quantity matching requires typed QuantityKey records.")
    return [field.upper() + "_MISMATCH" for field in a.__dataclass_fields__ if getattr(a, field) != getattr(b, field)]


def bounded_rate(numerator, denominator, numerator_key, denominator_key):
    flags = quantity_guard(numerator_key, denominator_key)
    if flags:
        raise CheckError(",".join(flags))
    if type(numerator) is not int or type(denominator) is not int or denominator <= 0 or not 0 <= numerator <= denominator:
        raise CheckError("Rate requires integer event counts with 0 <= n <= d and d > 0.")
    return numerator / denominator


def discharge(background, local_assumption, conclusion):
    """Deduction-theorem check with a nonempty local-model guard.

    Classical logic permits vacuous discharge from impossible antecedents. This
    reporting guard explicitly refuses to present that as evidential support.
    """
    background = tuple(background)
    local = HardPremise("__local_assumption__", local_assumption, "Explicit local branch.")
    proof = classify(background + (local,), conclusion)
    if proof["status"] == "INCONSISTENT":
        return {"accepted": False, "reason": "INCONSISTENT_LOCAL_BRANCH", "local": proof}
    if proof["status"] != "ENTAILED":
        return {"accepted": False, "reason": "CONCLUSION_NOT_DERIVED", "local": proof}
    result = classify(background, ["implies", local_assumption, conclusion])
    return {"accepted": result["status"] == "ENTAILED", "reason": "CONDITIONAL_ONLY",
            "discharged_formula": ["implies", local_assumption, conclusion],
            "unconditional": classify(background, conclusion)["status"], "certificate": result}


def lineage_audit(nodes: Mapping[str, dict], target: str) -> dict:
    """Require all dependency paths to ground in source roots; reject cycles."""
    issues, visiting, memo = [], set(), {}

    def invalid_schema(message):
        return {"valid": False, "issues": [message], "origin_roots": [], "distinct_origin_count": 0}

    if not isinstance(nodes, Mapping):
        return invalid_schema("INVALID_GRAPH_MAPPING")
    if not _label(target) or any(not _label(name) for name in nodes):
        return invalid_schema("INVALID_NODE_ID")

    def walk(name):
        if name in memo:
            return memo[name]
        if name not in nodes:
            issues.append("MISSING:" + name)
            return set()
        if name in visiting:
            issues.append("CYCLE:" + name)
            return set()
        node = nodes[name]
        if not isinstance(node, Mapping):
            issues.append("INVALID_NODE_MAPPING:" + name)
            return set()
        if any(not _label(key) or key not in {"source", "origin", "dependencies"} for key in node):
            issues.append("UNKNOWN_NODE_FIELD:" + name)
            return set()
        if type(node.get("source", False)) is not bool:
            issues.append("INVALID_SOURCE_FLAG:" + name)
            return set()
        deps = node.get("dependencies", [])
        if not isinstance(deps, (list, tuple)) or any(not _label(dep) for dep in deps):
            issues.append("INVALID_DEPENDENCIES:" + name)
            return set()
        if "origin" in node and not _label(node["origin"]):
            issues.append("INVALID_ORIGIN:" + name)
            return set()
        if "origin" in node and not node.get("source", False):
            issues.append("ORIGIN_ON_DERIVED_NODE:" + name)
            return set()
        deps = tuple(deps)
        visiting.add(name)
        roots = set()
        if node.get("source", False):
            if deps:
                issues.append("SOURCE_WITH_DEPENDENCIES:" + name)
            if not node.get("origin"):
                issues.append("ROOT_WITHOUT_ORIGIN:" + name)
            else:
                roots.add(node["origin"])
        elif not deps:
            issues.append("UNGROUNDED:" + name)
        for dep in deps:
            roots.update(walk(dep))
        visiting.remove(name)
        memo[name] = roots
        return roots

    roots = walk(target)
    return {"valid": not issues, "issues": sorted(set(issues)), "origin_roots": sorted(roots),
            "distinct_origin_count": len(roots)}


def independence_guard(nodes, left, right):
    a, b = lineage_audit(nodes, left), lineage_audit(nodes, right)
    overlap = sorted(set(a["origin_roots"]) & set(b["origin_roots"]))
    if not a["valid"] or not b["valid"]:
        status = "INVALID_LINEAGE"
    elif overlap:
        status = "SHARED_ORIGIN"
    else:
        status = "DISJOINT_RECORDED_ORIGINS"
    # Disjoint recorded ancestry is necessary here, never proof of statistical independence.
    return {"status": status, "overlap": overlap,
            "statistical_independence_established": False}


def freeze_model(model):
    if not isinstance(model, Mapping):
        raise CheckError("Model rows must be mappings.")
    if any(not _label(k) or type(v) is not bool for k, v in model.items()):
        raise CheckError("Model rows require string atoms and Boolean values.")
    return tuple(sorted(model.items()))


def model_set(rows):
    rows = list(rows)
    if any(not isinstance(row, Mapping) for row in rows):
        raise CheckError("Model rows must be mappings.")
    if rows and any(set(row) != set(rows[0]) for row in rows):
        raise CheckError("A model family requires a fixed declared vocabulary.")
    return {freeze_model(row) for row in rows}


def split_partition(parent_rows, focal):
    variables(focal)
    parent_rows = list(parent_rows)
    model_set(parent_rows)
    positive, negative = [], []
    for row in parent_rows:
        (positive if evaluate(focal, row) else negative).append(row)
    return positive, negative


def partition_audit(parent_rows, child_rows):
    parent, children = model_set(parent_rows), [model_set(c) for c in child_rows]
    union = set().union(*children) if children else set()
    overlap = set()
    for i, child in enumerate(children):
        for other in children[i + 1:]:
            overlap.update(child & other)
    missing, extra = parent - union, union - parent
    return {"valid": not missing and not extra and not overlap, "parent_count": len(parent),
            "child_counts": [len(c) for c in children], "missing_count": len(missing),
            "extra_count": len(extra), "overlap_count": len(overlap),
            "missing_witness": dict(sorted(missing)[0]) if missing else None,
            "extra_witness": dict(sorted(extra)[0]) if extra else None,
            "overlap_witness": dict(sorted(overlap)[0]) if overlap else None}


def reconstruction_audit(old_rows, new_rows, old_atoms):
    atoms = tuple(sorted(set(_labels(old_atoms))))
    old_rows, new_rows = list(old_rows), list(new_rows)
    model_set(new_rows)  # Check uniform new vocabulary before projecting it away.
    if any(set(row) != set(atoms) for row in old_rows):
        raise CheckError("Old model rows must have exactly the declared old vocabulary.")
    if any(not set(atoms).issubset(row) for row in new_rows):
        raise CheckError("Extension erased an old atom.")
    old = model_set(old_rows)
    projected = model_set({a: row[a] for a in atoms} for row in new_rows)
    lost, invented = old - projected, projected - old
    return {"conservative": not lost and not invented, "old_count": len(old),
            "projection_count": len(projected), "lost_count": len(lost),
            "invented_count": len(invented),
            "lost_witness": dict(sorted(lost)[0]) if lost else None,
            "invented_witness": dict(sorted(invented)[0]) if invented else None}
