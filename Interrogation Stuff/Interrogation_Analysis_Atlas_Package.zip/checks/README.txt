INTERROGATION ANALYSIS ATLAS: EXECUTABLE CHECKS

Run from the extracted package directory:

    python checks/run_checks.py

Python 3.10 or later is required. The implementation uses only the standard
library. No network request or third-party package is required. The runner
resolves fixture paths relative to its own file, so the current working
directory need not be the package directory. A nonzero exit code means failure.
The script writes checks/results.json and checks/results.txt deterministically.

FILES

atlas_kernel.py is a small semantic kernel and a collection of conservative
annotation guards. run_checks.py executes the checks. ../tests/scenarios.json
contains 91 distinct human-annotated synthetic scenarios. The optional
../tests/build_fixtures.py reproduces that JSON from explicit fixture definitions;
the normal check command does not need to run the builder.

WORLD SEMANTICS

Formula syntax is a Boolean constant, an atom string, or an AST such as
["and", "p", ["not", "q"]]. Available operators are not, and, or, implies,
iff, xor. Operators have fixed arity. The maximum declared vocabulary is twelve
atoms, including atoms present only in a query. Every permitted valuation is
enumerated. HardPremise records require an ID, a formula, and an explicit
justification label. Formula trees are copied into immutable tuples. The label
records the analyst's adoption; it does not authenticate the premise.

classify(H, q) reports ENTAILED, REFUTED, UNDETERMINED, or INCONSISTENT. Empty
model families always produce INCONSISTENT. An unconstrained zero-atom family
has one model, the empty assignment. Countermodel and witness fields accompany
nonempty positive and negative extensions. Query atoms enlarge the enumerated
vocabulary; they are not silently assumed false.

The support_state function separately reports NEITHER, POSITIVE_ONLY,
NEGATIVE_ONLY, or BOTH from explicit positive and negative source IDs. These
are support records. The code does not impose a four-valued truth-functional
logic on them and does not confuse BOTH with inconsistent hard premises.

SPEECH, IDENTITY, AND SCOPES

Utterance preserves original strings, unresolved speaker alternatives, recording
time, event-time labels, and source spans. Entity, Scope, Proposition, and Claim
are immutable typed records. The EvidenceLedger holds Claim objects. Its public
records view is read-only; supported writes pass through add. Embedded
claim content never automatically enters the world-premise set. An explicit
HardPremise remains necessary for every adopted world assertion or bridge.

transition_guard compares a proposed meaning-preserving paraphrase with its
source record. It reports changes to actor, predicate, arguments, context,
event time, quantifier, speech act, modality, qualifications, utterer, introducer,
source lineage, and dependencies. A flag means that a separate justification
is required. The flag does not declare that a changed proposition is false.
Equivalent paraphrases require an explicitly justified semantic interface;
the kernel does not infer synonymy, co-reference, or rich modal entailment.

Question and Answer records require an explicit target link, a respondent,
event ordering, and proposition slots. A compound answer must be annotated
with its actual scope. question_commitments issues a reported-assent record;
it does not endorse background presuppositions, infer independent origin,
or turn agreement into truth. The kernel validates supplied linkage, not
spoken language or nonverbal behavior.

The QuantityKey adapter deliberately uses a strict matched-event frame with
seven coordinates: actor, activity, material, context, period, counting unit,
and denominator population. bounded_rate supports an integer numerator that
counts a subset of the same declared event population. Other useful rates,
such as events per person-year, need a separate dimensional adapter. Conversion
between frequencies, probabilities, estimates, counts, and limits is not
automatic. The current rate check is descriptive arithmetic, not a likelihood
model or uncertainty estimate.

HYPOTHESES AND PROVENANCE

discharge checks whether H together with a local assumption supports a
conclusion. An accepted result is the conditional under H; unconditional status
is reported separately. Inconsistent local branches are rejected as evidential
support even though classical material implication would allow a vacuous
conditional. The reserved local ID cannot collide with an existing premise ID.

lineage_audit validates the graph mapping and reachable node schemas, then
checks every dependency path of a target. Source flags must be actual Booleans;
dependency collections must be explicit lists or tuples of valid string IDs.
Unknown schema fields are rejected rather than ignored. A dependency cycle,
missing node, derived node without parents, unnamed source root, or source
root also marked as dependent makes the record invalid. Provenance roots are
deduplicated by their origin labels. The graph does not authenticate those
labels. Disjoint recorded ancestry never proves statistical independence.
Cycles remain invalid even when an external source also feeds the cycle.

PARTITIONS AND EXTENSIONS

split_partition separates explicit model rows according to P and NOT P.
partition_audit checks disjointness, coverage, and absence of invented rows.
Missing, extra, and overlapping assignments receive witnesses. The empty set
can have a mathematically valid partition; this never changes the world-query
rule that an empty admissible family is INCONSISTENT.

reconstruction_audit projects refined rows onto the old vocabulary and tests
exact equality with the old family. Missing old models indicate restriction;
new old-vocabulary models indicate invention. A conservative extension may
double the number of full assignments while retaining every old conclusion.
Projection equality is checked only for the explicit finite rows supplied.

CHECK FAMILIES AND COUNTING

1. Ninety-one synthetic scenarios have one stable ID each. Expected results
   are stored in JSON. Valid controls accompany invalid transformations.
2. Eighty-five named boundary and integration checks cover immutable records,
   the zero-atom and twelve-atom boundaries, rejected thirteen-atom inputs,
   hard-premise separation, explicit assent, matched counts, graph grounding,
   joint constraints, and model restrictions.
3. Thirty metamorphic transformations use six seed cases. They test premise
   order, premise repetition, bijective renaming, unconstrained extension,
   and double negation. They are counted separately from distinct scenarios.
4. The recursive Boolean evaluator is compared with an independent postfix
   bit-vector implementation on all 91,265 distinct ordered ASTs of depth at
   most two over leaves False, True, p, q, r and the six declared operators.
   Eight valuations per formula yield 730,120 formula-assignment comparisons.
   This exact grammar is bounded; it is not all possible Boolean formulae.
5. All 256 subsets of the eight three-atom assignments are compared with six
   atomic or negated-atomic queries: 1,536 world-status classifications. Their
   positive, negative, and total model counts are checked independently.

These counts are different units. Adding them into one large "accuracy" score
would be misleading. Results are regression and finite semantic checks, not
empirical evidence of accuracy on real interrogation transcripts.

RESIDUAL LIMITS

There is no automatic diarization, transcription, identity resolution,
predicate extraction, legal admissibility decision, credibility assessment,
guilt classifier, memory diagnosis, causal identification, or probability
estimator. Rich temporal, modal, quantified, and causal meanings are documented
in the atlas; this executable kernel validates explicit labels and bounded
Boolean abstractions. Only the stated invariant families are tested. Natural
language annotation and evidentiary adoption still require review.

IMPLEMENTATION REVIEW NOTE

The first executed suite passed all original 91 scenarios and 40 boundary
checks. A subsequent invariant review found that a frozen HardPremise wrapper
could still refer to a caller-owned mutable list AST. The implementation was
strengthened by copying formulae to immutable recursive tuples. Additional
record validation and nine checks were added for this and related boundaries,
including fixed-vocabulary validation before finite partitioning or projection.
These were review-discovered weaknesses rather than failures in the original
test set. A later independent software audit found additional gaps: speaker
reassignment was not flagged, several string fields accepted mutable values,
malformed provenance schemas could pass, and a public dictionary bypassed the
ledger write guard. Direct formula/model boundaries also needed validation.
The auditor's initial targeted probes recorded fourteen failures and one grouped
semantic control passing. A new local I50 regression separately reproduced the
missing utterer-change flag before repair. The defects were corrected and
thirty-six additional focused checks were added. The final results files record
the executed suite after those changes. These public-API safeguards are not a
security boundary against code deliberately modifying Python internals.
