"""Check the delivered document files against their source and build record."""
from pathlib import Path
import hashlib
import json
import re
import sys
import pdfplumber

ROOT=Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def compact(text):
    return re.sub(r'\s+','',text)

def run():
    checks=[]
    def check(name, condition, detail):
        checks.append({'name':name,'passed':bool(condition),'detail':detail})
    build=json.loads((ROOT/'build_metadata.json').read_text(encoding='ascii'))
    manuscript=(ROOT/'manuscript.txt').read_text(encoding='ascii')
    check('source_is_ascii',all(ord(c)<128 for c in manuscript),len(manuscript))
    pronouns=re.findall(r'\b(?:you|your|yours|yourself|yourselves)\b',manuscript,re.I)
    check('no_second_person_pronouns',not pronouns,pronouns)
    for i in range(1,31):
        name=f'ch{i:02d}.txt'
        text=(ROOT/name).read_text(encoding='ascii')
        actual=re.findall(r'^EXAMPLE (\d\d\.[ABC])\b',text,re.M)
        expected=[f'{i:02d}.{c}' for c in 'ABC']
        check(name+'_three_examples',actual==expected,actual)
        check(name+'_substantive_length',len(text.split())>=1100,len(text.split()))
    for c in 'abcde':
        text=(ROOT/f'appendix_{c}.txt').read_text(encoding='ascii')
        actual=re.findall(r'^EXAMPLE ([A-E]\.[ABC])\b',text,re.M)
        check(f'appendix_{c}_three_examples',actual==[f'{c.upper()}.{x}' for x in 'ABC'],actual)
    for name,expected in build['source_hashes'].items():
        check('source_unchanged_'+name,sha(ROOT/name)==expected,expected)
    for name,expected in build['files'].items():
        check('build_artifact_hash_'+name,sha(ROOT/name)==expected['sha256'],expected['sha256'])
    pdf=ROOT/'Interrogation_Analysis_Atlas.pdf'
    pages=[]
    stray=[]
    with pdfplumber.open(pdf) as doc:
        for i,page in enumerate(doc.pages,1):
            area=page.crop((51,52,page.width-51,page.height-47))
            pages.append(area.extract_text(x_tolerance=2,y_tolerance=3) or '')
            for char in page.chars:
                if 51<=char['top']<page.height-46 and (char['x0']<51 or char['x1']>page.width-51):
                    stray.append([i,char['text']])
    check('pdf_body_source_match',compact('\n'.join(pages))==compact(manuscript),
          'Exact character order after removing whitespace; headers and footers excluded.')
    check('body_horizontal_bounds',not stray,stray)
    check('pdf_page_count',len(pages)==build['pages'],len(pages))
    text=(ROOT/'Interrogation_Analysis_Atlas_ASCII.txt').read_text(encoding='ascii')
    text_pages=text.split('\f')
    stripped=[re.sub(r'^\s*PAGE \d+ OF \d+\s*','',p) for p in text_pages]
    check('ascii_page_count',len(text_pages)==len(pages),len(text_pages))
    check('ascii_pdf_pagewise_match',all(compact(a)==compact(b) for a,b in zip(stripped,pages))
          and len(stripped)==len(pages),'Every corresponding page compared.')
    check('no_blank_pdf_pages',all(p.strip() for p in pages),len(pages))
    results=json.loads((ROOT/'checks/results.json').read_text(encoding='ascii'))
    check('semantic_results_passed',results['passed'] and not results['failures'],
          'Reads actual semantic result file; this is not an independent rerun.')
    report={'passed':all(c['passed'] for c in checks),'checks':checks,
            'check_count':len(checks),'pages':len(pages),
            'words_including_contents':len(manuscript.split()),
            'worked_examples':105,
            'limits':['Text extraction and bounds checks supplement visual review; they do not alone prove layout quality.',
                      'ASCII bytes and matching editions do not validate historical claims or natural-language annotation.',
                      'Checksums detect accidental changes under SHA-256 assumptions; they do not authenticate evidence.']}
    (ROOT/'artifact_integrity.json').write_text(json.dumps(report,indent=2)+'\n',encoding='ascii')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
    if not report['passed']:
        for c in checks:
            if not c['passed']:print('FAIL:',c)
        return 1
    return 0

if __name__=='__main__':
    sys.exit(run())
