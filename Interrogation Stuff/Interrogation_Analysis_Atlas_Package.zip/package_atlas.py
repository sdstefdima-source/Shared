"""Package the verified snapshot and check each archive member byte-for-byte."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import zipfile

ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'Interrogation_Analysis_Atlas_Package.zip'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    artifact=json.loads((ROOT/'artifact_integrity.json').read_text(encoding='ascii'))
    semantic=json.loads((ROOT/'checks/results.json').read_text(encoding='ascii'))
    computation=json.loads((ROOT/'computation_manifest.json').read_text(encoding='ascii'))
    assert artifact['passed'] and semantic['passed'] and computation['run']['status']=='completed'
    probes=json.loads((ROOT/'audits/software_probe_results.json').read_text(encoding='ascii'))
    assert probes['passed']
    assert probes['kernel_sha256']==sha((ROOT/'checks/atlas_kernel.py').read_bytes())
    assert probes['runner_sha256']==sha((ROOT/'checks/run_checks.py').read_bytes())
    suites=semantic['suites']
    summary=f'''INTERROGATION ANALYSIS ATLAS: FINAL VERIFICATION SUMMARY

DELIVERABLE

{artifact['pages']} PDF pages and the same {artifact['pages']} page sections in the ASCII edition.
{artifact['words_including_contents']:,} manuscript words including contents.
30 chapters, 5 appendices, and 105 worked examples: 3 per chapter or appendix.
The source text uses ASCII; no decorative ASCII diagrams are included.

EXECUTED SEMANTIC CHECKS: PASS

Distinct annotated scenarios: {semantic['scenario_passed']}/{semantic['scenario_count']}.
Named integration and boundary checks: {suites['boundary_integration']['named_checks']}.
Metamorphic transformations: {suites['metamorphic']['transformations_checked']}.
Independent formula-assignment comparisons: {suites['exhaustive_evaluation']['formula_assignment_comparisons']:,}.
Distinct ordered Boolean ASTs in that comparison: {suites['exhaustive_evaluation']['formula_count']:,}.
Every three-atom model family: {suites['exhaustive_classification']['finite_model_families']} families.
Query classifications over those families: {suites['exhaustive_classification']['query_classifications']:,}.
Independent targeted audit probes: {probes['passed_count']}/{probes['probe_count']}.

The oracle family contains all ASTs of depth at most two with leaves
False, True, p, q, r; unary NOT; and ordered AND, OR, implication,
equivalence, and XOR. It is exhaustive within that grammar and depth bound.
The reference evaluator supports at most 12 distinct atoms; the separate
boundary checks enumerate 12 and reject 13. These counts have different units
and are not an empirical accuracy measure.

EXECUTED ARTIFACT CHECKS: PASS

{artifact['check_count']} checks cover ASCII, chapter lengths, three examples per
component, source/build hashes, PDF extraction, page correspondence, and bounds.
The PDF body and canonical manuscript match after removing whitespace.
Every ASCII page matches the corresponding extracted PDF page.
All pages were rendered; contact sheets and selected full pages were inspected.
Layout review findings and limits appear in audits/artifact_review.txt.

INDEPENDENT REVIEW AND REPAIRS

Formal, foundations, interpretation, software, and specification-coverage notes
appear in audits/. Review found and repaired gaps in scope, source attribution,
well-founded derivations, temporal identity, conditional reasoning, mutable
inputs, and speaker-change detection. Historical software probe failures remain
in software_probe_results_initial.json, explicitly distinguished from the final
passing software_probe_results.json. Initial defects are not hidden or recast
as successful executions.

PROVENANCE

computation_manifest.json records the command, Python version, finite bounds,
start time, runtime, exit status, unchanged input hashes, and output hashes.
The final recorded run took {computation['run']['runtime_seconds']:.3f} seconds
and returned {computation['run']['exit_status']}. The computation-audit manifest
validator accepted this record; that acceptance is structural, not a proof of
the mathematical interpretation. Package checksums are in SHA256_MANIFEST.json.
python package_integrity.py checks the distributed snapshot before regeneration.

WHAT IS ESTABLISHED

The listed fixtures and finite families behave as recorded; the two document
editions contain matching text; the package exposes its source, tests, and limits.
Elementary manuscript propositions have stated assumptions and written proofs.
Independent review does not amount to proof-assistant certification.

WHAT IS NOT ESTABLISHED

No real interrogation is automatically interpreted or validated. The package
does not authenticate a recording, identify actual speakers, infer private
intentions, determine guilt, decide legal admissibility, or supply empirical
psychological accuracy. Rich modal, temporal, quantified, causal, probabilistic,
and revision components are specified for human analysis but only the documented
finite subset is executable. A general framework still needs domain-specific
evidence and explicitly justified bridges. Passing tests do not prove all future
program executions correct or all historical claims true.
'''
    (ROOT/'VERIFICATION_SUMMARY.txt').write_text(summary,encoding='ascii')
    versions={name:importlib.metadata.version(name) for name in ['reportlab','pdfplumber','pypdfium2','Pillow']}
    (ROOT/'requirements_document.txt').write_text('\n'.join(f'{name}=={version}' for name,version in versions.items())+'\n',encoding='ascii')
    (ROOT/'document_environment.json').write_text(json.dumps(versions,indent=2)+'\n',encoding='ascii')
    excluded={'SHA256_MANIFEST.json','archive_verification.json','extraction_debug.txt'}
    paths=[]
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(ROOT)
        if any(part in {'rendered','__pycache__'} for part in relative.parts):continue
        if path.suffix=='.zip' or path.name in excluded:continue
        paths.append(path)
    manifest={'algorithm':'SHA-256','scope':'Every delivered member except this manifest and the containing archive.',
        'limits':'Digest checks do not establish source authenticity or historical truth.',
        'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths]}
    manifest_path=ROOT/'SHA256_MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='ascii')
    paths.append(manifest_path)
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in paths:z.write(path,path.relative_to(ROOT).as_posix())
    checked=0
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None, 'CRC failure'
        assert len(z.namelist())==len(set(z.namelist()))==len(paths)
        for path in paths:
            name=path.relative_to(ROOT).as_posix()
            assert z.read(name)==path.read_bytes(),f'Archive bytes differ: {name}'
            checked+=1
    result={'passed':True,'archive':ARCHIVE.name,'members_verified':checked,
        'hashed_members':len(manifest['files']),'archive_bytes':ARCHIVE.stat().st_size,
        'archive_sha256':sha(ARCHIVE.read_bytes()),'CRC_pass':True,
        'scope':'Every archived member compared byte-for-byte with its source file.'}
    (ROOT/'archive_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='ascii')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
