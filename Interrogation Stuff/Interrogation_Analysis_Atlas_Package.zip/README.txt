INTERROGATION ANALYSIS ATLAS
Package guide and reproducibility instructions
Version 1.0

PURPOSE

This package contains a general mathematical scaffold for analyzing interviews,
interrogations, administrative calls, testimony, and other conversations. The
linked logic-block construct tracks statements, assumptions, persons, scope,
time, source lineage, competing interpretations, and justified conclusions.
The accompanying Python kernel implements a bounded part of that specification.

The manuscript distinguishes recorded speech from historical truth. Its worked
exchanges are invented examples. A passing check establishes the declared
behavior on explicit inputs; it does not establish a person's honesty, intent,
guilt, diagnosis, or the legal status of a conversation.

MAIN READING FILES

Interrogation_Analysis_Atlas.pdf
    Formatted reading edition with navigation bookmarks.

Interrogation_Analysis_Atlas_ASCII.txt
    ASCII reading edition with page markers and form-feed separators. Page
    correspondence follows the PDF build. No decorative ASCII drawings are used.

manuscript.txt
    Canonical, unpaginated manuscript assembled from the source text files.
    The PDF body is checked against this text after whitespace normalization.

front.txt, ch01.txt through ch30.txt, appendix_a.txt through appendix_e.txt,
references.txt
    Editable source components. The build also generates a contents section.
    Changes belong in these source components, followed by a rebuild. Editing
    only a generated reading edition will be overwritten by the next build.

checks/README.txt
    Detailed executable contract, accepted formula syntax, check families,
    input bounds, and residual limits.

audits/specification_coverage.txt
    A reviewable map separating implemented behavior from manually specified
    analysis and unimplemented extensions. This distinction applies even when
    a concept is explained fully in the manuscript.

READING ROUTES

Chapters 01-06 define the records, language, evidence, models, and proof duties.
Chapters 07-12 address speech acts, presupposition, answers, modality, time,
and paraphrase. Chapters 13-18 construct the linked atlas, joint constraints,
refinement, inconsistency handling, and finite checking procedures.
Chapters 19-24 address source independence, memory claims, quantities,
causation, decision models, and revision. Chapters 25-30 give the operational
workflow, reporting rules, and three extended invented case studies.

Appendix A collects notation; B collects inference rule cards; C collects
formal results and obligations; D provides annotation forms; E states the
verification and reproducibility contract. The references distinguish the
requested architecture from independent research sources.

SEMANTIC CHECKS: PYTHON STANDARD LIBRARY ONLY

Before regenerating files, verify the distributed snapshot with:

    python package_integrity.py

SHA256_MANIFEST.json lists the archive members, sizes, and SHA-256 digests.
It excludes itself and the containing ZIP. An intentional rebuild can change
PDF metadata and recorded timings, so snapshot hash checking precedes rebuilding.
The manifest detects changes under the hash assumptions; it does not authenticate
the publisher. VERIFICATION_SUMMARY.txt provides the final counts and boundaries.

Extract the archive to a writable directory. From that directory, run:

    python checks/run_checks.py

For a run that also records timing, software versions, and before/after input
hashes in computation_manifest.json, use:

    python run_verification.py

Independent audit probes can be rerun with:

    python audits/software_probes.py

Python 3.10 or later is required. On Windows, an installation using the Python
launcher can run the equivalent command:

    py -3 checks/run_checks.py

The runner resolves paths relative to its own location. An absolute path to the
script also works from another working directory. No third-party package or
network request is needed for these semantic checks. The process returns zero
on success and nonzero on failure. It regenerates:

    checks/results.txt
    checks/results.json

Those result files provide the actual executed counts and failures. Distinct
synthetic scenarios, boundary checks, metamorphic transformations, evaluator
comparisons, and finite-family classifications have different counting units.
They must not be combined into an empirical accuracy percentage.

The kernel is checks/atlas_kernel.py. The runner is checks/run_checks.py.
Explicit human-annotated fixtures are stored in tests/scenarios.json.
The optional fixture builder can regenerate that file:

    python tests/build_fixtures.py

Ordinary verification does not require rerunning the fixture builder. Changed
fixtures are new inputs and require review of their expected outcomes. A
manually changed expected result is not itself a repair of a failing rule.

BUILD AND INSPECT THE DOCUMENT EDITIONS

The document tools have separate dependencies. Installation into a suitable
Python environment can use:

    python -m pip install reportlab pdfplumber pypdfium2 Pillow

An offline installation can use equivalent preinstalled packages or locally
available package wheels. Dependency installation is not part of the semantic
test command. The build and render commands themselves use local files.

Rebuild the editions with:

    python build_document.py

To rebuild and generate page images and contact sheets for visual inspection:

    python build_document.py --render

Optional layout arguments are --font-size and --leading. The defaults define
the supplied layout; changing them can change pagination while preserving the
manuscript. ReportLab creates the PDF, pdfplumber extracts its body for content
comparison, and pypdfium2 with Pillow supplies page rendering. Rendered images
are written to rendered/. The render directory is reproducible review output.

The build writes build_metadata.json with actual pagination, content-match
results, layout parameters, and hashes for the generated editions. Content
comparison removes whitespace differences; it is not a proof that every visual
layout choice is satisfactory. Visual inspection remains a separate review.

Run the artifact checker with:

    python artifact_checks.py

The checker writes artifact_integrity.json and returns a nonzero status when
its checks fail. It compares source and build hashes, example markers, edition
contents, pagination, and layout bounds. Its check of semantic results reads
the existing result file; it does not independently rerun the semantic suite.
The actual shipped verification reports govern file counts, page counts,
checked markers, and package integrity. No fixed count in this guide should
substitute for those records. A changed source, code file, or build invalidates
earlier hashes and requires affected checks and the manifest to be regenerated.

CHECK SCOPE

The reference kernel exhaustively enumerates accepted Boolean inputs within
its declared atom cap. It keeps explicitly adopted hard premises separate
from attributed speech records, validates selected typed transitions, checks
answer order and slots, compares quantity frames, audits source ancestry,
and checks finite partitions and projections. Countermodels make unsupported
entailments inspectable. Valid controls accompany deliberately invalid inputs.

The broader atlas specifies richer temporal, modal, quantified, causal,
probabilistic, and revision structures. Those structures are not all executable
in the reference kernel. Ordinary-language annotation, source authentication,
speaker identification, interpretation of pauses, and domain rules require
separate review. The coverage map identifies the boundary component by component.

RESULT INTERPRETATION

ENTAILED and REFUTED concern all models satisfying the adopted hard premises.
UNDETERMINED has retained models supporting both signs. INCONSISTENT means no
retained model; it is never permission to certify every conclusion. Evidence
support states are separately recorded and are not a four-valued truth logic.

Checksums bind reports to bytes. They do not certify factual truth or source
authenticity. A readable PDF, a successful regression run, and a sound formal
argument answer different verification questions. The package preserves those
distinctions so further analysis can extend the framework without inheriting
unjustified certainty.
