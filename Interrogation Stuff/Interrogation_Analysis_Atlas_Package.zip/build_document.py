"""Build the two matching editions. Run from any working directory.

Dependencies: reportlab, pdfplumber, pypdfium2, Pillow.
This build does not change chapter sources or semantic test results.
"""
from pathlib import Path
from html import escape
import argparse
import hashlib
import json
import re
import textwrap
import time

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, PageBreak
import pdfplumber

ROOT = Path(__file__).resolve().parent
PDF = ROOT / 'Interrogation_Analysis_Atlas.pdf'
TXT = ROOT / 'Interrogation_Analysis_Atlas_ASCII.txt'
WIDTH, HEIGHT = A4
LEFT, RIGHT, TOP, BOTTOM = 52, 52, 54, 49


def compact(value):
    return re.sub(r'\s+', '', value)


def sources():
    names = ['front.txt'] + [f'ch{i:02d}.txt' for i in range(1,31)]
    names += [f'appendix_{c}.txt' for c in 'abcde'] + ['references.txt']
    return [(name, (ROOT/name).read_text(encoding='ascii').strip()) for name in names]


class AtlasDoc(BaseDocTemplate):
    def afterFlowable(self, flowable):
        if getattr(flowable, 'atlas_heading', False):
            title = flowable.getPlainText()
            key = 'sec-' + str(len(self.section_pages))
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(title, key, level=0, closed=False)
            self.section_pages.append({'heading': title, 'page': self.page})


def page(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(colors.HexColor('#526273'))
    canvas.setFont('Helvetica', 8)
    canvas.drawString(LEFT, HEIGHT-32, 'INTERROGATION ANALYSIS ATLAS')
    canvas.drawRightString(WIDTH-RIGHT, HEIGHT-32, 'FORMAL SPECIFICATION | VERSION 1.0')
    canvas.setStrokeColor(colors.HexColor('#BFC8D1'))
    canvas.setLineWidth(.4)
    canvas.line(LEFT, HEIGHT-39, WIDTH-RIGHT, HEIGHT-39)
    canvas.setFont('Helvetica', 8)
    canvas.drawString(LEFT, 29, 'Claims, context, evidence, and inference')
    canvas.drawRightString(WIDTH-RIGHT, 29, str(doc.page))
    canvas.restoreState()


def is_heading(block):
    return (len(block) < 150 and '\n' not in block and
            (bool(re.match(r'^(?:\d+|[A-E])\.\d+\s', block)) or
             block.isupper() or block.startswith('EXAMPLE ')))


def build(font_size=11.5, leading=15.0):
    started = time.time()
    entries = sources()
    contents = 'CONTENTS\n\n' + '\n\n'.join(
        text.splitlines()[0] for name,text in entries if name != 'front.txt')
    entries.insert(1, ('contents', contents))
    canonical = '\n\n'.join(text for _,text in entries) + '\n'
    canonical.encode('ascii')
    (ROOT/'manuscript.txt').write_text(canonical, encoding='ascii', newline='\n')
    body = ParagraphStyle('Body', fontName='Times-Roman', fontSize=font_size,
        leading=leading, spaceAfter=7, alignment=TA_LEFT,
        allowWidows=0, allowOrphans=0, splitLongWords=1)
    heading = ParagraphStyle('Heading', parent=body, fontName='Helvetica-Bold',
        fontSize=16, leading=20, textColor=colors.HexColor('#183449'),
        spaceAfter=17, keepWithNext=True)
    sub = ParagraphStyle('Sub', parent=body, fontName='Helvetica-Bold',
        fontSize=10.8, leading=14, textColor=colors.HexColor('#183449'),
        spaceBefore=7, spaceAfter=7, keepWithNext=True)
    example = ParagraphStyle('Example', parent=sub, fontSize=10,
        textColor=colors.HexColor('#305969'))
    toc = ParagraphStyle('Contents', parent=body, fontName='Helvetica',
        fontSize=9.6, leading=13, spaceAfter=4)
    doc = AtlasDoc(str(PDF), pagesize=A4, leftMargin=LEFT, rightMargin=RIGHT,
        topMargin=TOP, bottomMargin=BOTTOM, title='Interrogation Analysis Atlas',
        author='OpenAI', subject='Typed logic blocks, interrogation analysis, and bounded verification',
        pageCompression=1)
    doc.section_pages = []
    frame = Frame(LEFT, BOTTOM, WIDTH-LEFT-RIGHT, HEIGHT-TOP-BOTTOM,
                  leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates(PageTemplate(id='atlas', frames=frame, onPage=page))
    story = []
    for entry_no,(name,text) in enumerate(entries):
        if entry_no:
            story.append(PageBreak())
        blocks = re.split(r'\n\s*\n', text)
        for i, block in enumerate(blocks):
            flat = ' '.join(line.strip() for line in block.splitlines())
            selected = body
            if i == 0:
                selected = heading
            elif name == 'contents':
                selected = toc
            elif is_heading(block):
                selected = example if block.startswith('EXAMPLE ') else sub
            marked = escape(flat)
            lines = [line.strip() for line in block.splitlines()]
            preserve_lines = (len(lines)>1 and
                (all(re.match(r'^[UT]\d\d\s', line) for line in lines)
                 or all(line.endswith(':') for line in lines)
                 or bool(re.match(r'^[a-z_]+:', lines[0]))))
            if preserve_lines:
                marked = '<br/>'.join(escape(line) for line in lines)
            if selected is body:
                marked = re.sub(r'^(DEFINITION|PROPOSITION|LEMMA|OBLIGATION|THEOREM|RULE|COROLLARY|COUNTERMODEL)([^.]*\.)',
                    r'<b>\1\2</b>', marked)
            paragraph = Paragraph(marked, selected)
            if i == 0:
                paragraph.atlas_heading = True
            story.append(paragraph)
    doc.build(story)
    pages = []
    outside = []
    with pdfplumber.open(PDF) as document:
        for i,p in enumerate(document.pages,1):
            area = p.crop((LEFT-1, TOP-2, WIDTH-RIGHT+1, HEIGHT-BOTTOM+2))
            bodytext = area.extract_text(x_tolerance=2, y_tolerance=3) or ''
            bodytext.encode('ascii')
            pages.append(bodytext)
            for char in p.chars:
                # Headers/footers deliberately lie outside the body frame.
                if TOP-3 <= char['top'] < HEIGHT-BOTTOM+3:
                    if char['x0'] < LEFT-1 or char['x1'] > WIDTH-RIGHT+1:
                        outside.append({'page':i,'text':char['text'],'x0':char['x0'],'x1':char['x1']})
    extracted = '\n\n'.join(pages)
    same = compact(extracted) == compact(canonical)
    if not same:
        (ROOT/'extraction_debug.txt').write_text(extracted,encoding='ascii')
        import difflib
        a,b=compact(canonical),compact(extracted)
        for index,(x,y) in enumerate(zip(a,b)):
            if x != y:
                raise AssertionError(f'PDF content mismatch at {index}: {a[index-70:index+120]!r} != {b[index-70:index+120]!r}')
        raise AssertionError(f'PDF content lengths differ: {len(a)}, {len(b)}')
    if outside:
        raise AssertionError(f'Text outside horizontal frame: {outside[:5]}')
    paginated = '\n\f\n'.join(
        f'PAGE {i:03d} OF {len(pages):03d}\n\n{text}\n'
        for i,text in enumerate(pages,1))
    TXT.write_text(paginated,encoding='ascii',newline='\n')
    metadata = {
        'pages':len(pages), 'words':len(canonical.split()),
        'chapter_count':30, 'chapter_examples':90,
        'appendix_examples':len(re.findall(r'^EXAMPLE [A-E]\.[ABC]', canonical,re.M)),
        'ascii':True,'whitespace_insensitive_pdf_source_match':same,
        'out_of_frame_body_characters':len(outside),
        'body_font_size':font_size,'body_leading':leading,
        'section_pages':doc.section_pages,
        'build_seconds':round(time.time()-started,3),
        'source_hashes':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                         for name,_ in sources()},
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                 for p in [PDF,TXT,ROOT/'manuscript.txt']}}
    (ROOT/'build_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='ascii')
    print(json.dumps({k:v for k,v in metadata.items() if k not in ['files','section_pages']},indent=2))


def render():
    import pypdfium2 as pdfium
    from PIL import Image, ImageDraw
    target = ROOT/'rendered'
    target.mkdir(exist_ok=True)
    pdf = pdfium.PdfDocument(str(PDF))
    thumbs=[]
    for i in range(len(pdf)):
        bitmap=pdf[i].render(scale=1.25)
        img=bitmap.to_pil().convert('RGB')
        img.save(target/f'page_{i+1:03d}.png')
        thumb=img.copy()
        thumb.thumbnail((238,337))
        card=Image.new('RGB',(258,365),'#e3e7eb')
        card.paste(thumb,((258-thumb.width)//2,8))
        ImageDraw.Draw(card).text((10,347),f'Page {i+1}',fill='black')
        thumbs.append(card)
        bitmap.close()
        pdf[i].close()
    for start in range(0,len(thumbs),16):
        subset=thumbs[start:start+16]
        sheet=Image.new('RGB',(258*4,365*4),'white')
        for offset,img in enumerate(subset):
            sheet.paste(img,((offset%4)*258,(offset//4)*365))
        sheet.save(target/f'contact_{start//16+1:02d}.png')
    pdf.close()
    print(f'Rendered {len(thumbs)} pages and {(len(thumbs)+15)//16} contact sheets.')


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--font-size',type=float,default=11.5)
    parser.add_argument('--leading',type=float,default=15.0)
    parser.add_argument('--render',action='store_true')
    args=parser.parse_args()
    build(args.font_size,args.leading)
    if args.render:
        render()
