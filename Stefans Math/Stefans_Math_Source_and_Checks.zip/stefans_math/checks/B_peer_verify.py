"""Independent exact recomputation of selected load-bearing A/G/Z examples.
Not an audit by replaying the author suites. Read B_peer_review.md for proofs.
"""
from fractions import Fraction as Q
from itertools import product
from math import gcd,isqrt
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2]
counts={};examples={}
def check(family,condition):
    assert condition,family
    counts[family]=counts.get(family,0)+1

# A modular examples, generated independently by ordinary residue enumeration.
check('A_examples',[x for x in range(14) if (6*x-8)%14==0]==[6,13])
check('A_examples',[x for x in range(101) if x%12==5 and x%18==11]==[29,65])
check('A_examples',[x for x in range(20,81) if x%12==1 and x%8==5]==[37,61])
check('A_order96',len({pow(5,j,97) for j in range(96)})==96 and pow(5,77,97)==23)
check('A_examples',pow(23,3,97)==42 and pow(23,32,97)==61)
check('A_examples',pow(5,3,97)==28 and pow(5,32,97)==35 and pow(5,48,97)==96)
check('A_examples',[x for x in range(96) if pow(5,x,97)==23]==[77])
check('A_examples',[(x,y) for x in range(18) for y in range(18) if (x+y-16)%18==0 and (x+4*y-13)%18==0]==[(5,11),(11,5),(17,17)])
for r in range(1,9):
    check('A_doubling_strengthened_induction',pow(2,2*3**(r-1),3**(r+1))==1+3**r)
check('A_examples',pow(2,137,729)==158)
# Recover addresses from brute exponent tables, no digit formula.
examples['A_u158_addresses']=[next(n for n in range(2*3**(k-1)) if pow(2,n,3**k)==158%3**k) for k in range(1,7)]
check('A_examples',examples['A_u158_addresses']==[1,5,11,29,137,137])
# Minimal exceptional-regime counterexample: k=1 has a trivial exponent domain.
examples['A_k1_singular_bijection']={'p':3,'k':1,'P':1,'base_mod3':1,'A':0,'domain_size':1,'target_size':1,'bijective':True}
check('A_exception',len({pow(1,x,3) for x in range(1)})==1)

# Polynomial CRT maps: direct reduction and powering in a 128-element binary ring.
f1=(1<<3)|(1<<1)|1;f2=(1<<4)|(1<<1)|1
F=(1<<7)|(1<<5)|(1<<3)|(1<<2)|1
p1=(1<<5)|(1<<2)|(1<<1);p2=p1^1
def pmul_raw(a,b):
    out=0
    while b:
        if b&1:out^=a
        a<<=1;b>>=1
    return out
def rem(a,m):
    while a and a.bit_length()>=m.bit_length():a^=m<<(a.bit_length()-m.bit_length())
    return a
def pmul(a,b):return rem(pmul_raw(a,b),F)
def ppow(a,n):
    out=1
    for _ in range(n):out=pmul(out,a)
    return out
check('A_polynomial_CRT',pmul_raw(f1,f2)==F)
check('A_polynomial_CRT',(rem(p1,f1),rem(p1,f2),rem(p2,f1),rem(p2,f2))==(1,0,0,1))
image=set()
for z in range(128):
    e=pmul(p1,ppow(z,3))^pmul(p2,ppow(z,7))
    d=pmul(p1,ppow(e,5))^pmul(p2,ppow(e,13))
    check('A_polynomial_CRT',d==z);image.add(e)
check('A_polynomial_CRT',len(image)==128)

# Row lattice example: recompute span transport, determinant, Gram-Schmidt,
# nearest-plane coefficients, exact point, and all bounded observation scalars.
B=[[10201,0,0],[0,10201,0],[101,1010,1]]
U=[[-1,-10,101],[0,0,1],[0,-1,10]]
R=[[0,0,101],[101,1010,1],[1010,-101,10]]
def matmul(a,b):return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def det3(m):return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0])
check('A_lattice',matmul(U,B)==R and det3(U)==-1)
stars=[];mus=[]
for row in R:
    residual=list(map(Q,row));mm=[]
    for star in stars:
        mu=Q(dot(row,star),dot(star,star));mm.append(mu)
        residual=[x-mu*y for x,y in zip(residual,star)]
    stars.append(residual);mus.append(mm)
check('A_lattice',stars==[[0,0,101],[101,1010,0],[1010,-101,0]])
T=[3838,6666,0];cc=[0]*3;centers=[]
for j in (2,1,0):
    center=Q(dot(T,stars[j]),dot(stars[j],stars[j]))-sum(Q(cc[i])*mus[i][j] for i in range(j+1,3))
    cc[j]=(center.numerator*2+center.denominator)//(2*center.denominator)
    centers.append(str(center))
check('A_lattice',cc==[0,7,3] and centers==['314/101','698/101','-37/101'])
point=matmul([cc],R)[0];original=matmul([cc],U)[0]
check('A_lattice',point==[3737,6767,37] and original==[0,-3,37])
check('A_lattice',sum((a-b)**2 for a,b in zip(point,T))==21771 and 101**2*2+50**2==22902)
ctr=lambda a:(a+50)%101-50
feasible=[x for x in range(101) if abs(ctr(x-38))<=1 and abs(ctr(10*x-66))<=1]
check('A_lattice',feasible==[37])
boxed=[]
for beta,z1,z2 in product(range(-50,51),range(-10,11),range(-10,11)):
    v=[101*(101*z1+beta),101*(101*z2+10*beta),beta]
    if abs(v[0]-T[0])<=101 and abs(v[1]-T[1])<=101:boxed.append(v)
check('A_lattice',boxed==[point])
examples['A_lattice']={'centers':centers,'c':cc,'point':point,'original_coefficients':original,'feasible_scalars':feasible,'boxed_points':boxed}
# Endpoint formula against direct rational inequalities over an independent grid.
for P,Qden,C,E in product(range(-5,6),range(1,5),range(6),range(1,5)):
    J=isqrt(C*Qden**2//E)
    lo=-(-(P-J)//Qden);hi=(P+J)//Qden
    given=list(range(lo,hi+1))
    oracle=[z for z in range(-15,16) if (Q(z)-Q(P,Qden))**2<=Q(C,E)]
    check('A_exact_endpoints',given==oracle)

# G coordinates, Gram obstruction, incidence, diffusion, and curvature digits.
lambda_point=[Q(5,12),Q(1,4),Q(1,3)]
check('G_affine',sum(lambda_point)==1 and dot(lambda_point,[1,5,7])==4)
check('G_affine',Q(2*3,2)*Q(1+5+7,3)==13)
G=[[Q(1) if i==j else Q(-161,200) for j in range(3)] for i in range(3)]
check('G_Gram_obstruction',matmul(G,[[1],[1],[1]])==[[Q(-61,100)]]*3)
check('G_Gram_obstruction',all(1+1>Q(19,10) for _ in range(3)))
d0=[[-1,1,0],[0,-1,1],[1,0,-1]];d1=[[1,1,1]]
check('G_incidence',matmul(d1,d0)==[[0,0,0]])
L=matmul([list(c) for c in zip(*d0)],d0)
check('G_diffusion',L==[[2,-1,-1],[-1,2,-1],[-1,-1,2]])
check('G_diffusion',matmul(L,[[-4],[-1],[5]])==[[-12],[-3],[15]])
for h,factor in ((Q(1,2),Q(1,4)),(Q(1),Q(4))):check('G_Euler',(1-3*h)**2==factor)
target=Q(5,3);acc=Q();digits=[];rems=[]
for j in range(6):
    a=Q(1,2**(j+3));n=(target-acc)//a;acc+=n*a;digits.append(n);rems.append(str(target-acc))
    check('G_dyadic_angle',0<=target-acc<a and acc==a*(target//a))
check('G_dyadic_angle',digits==[13,0,1,0,1,0] and rems[-2:]==['1/384','1/384'])
examples['G_curvature_ratchet']={'digits':digits,'remainders_in_pi_units':rems}

# Z exact integer examples, including the uniqueness-certificate counterexample.
local9=[x for x in range(9) if (x**3-x)%9==0];local5=[x for x in range(5) if (x**3-x)%5==0]
classes=[x for x in range(45) if x%9 in local9 and x%5 in local5]
check('Z_CRT',local9==[0,1,8] and local5==[0,1,4] and classes==[0,1,9,10,19,26,35,36,44])
check('Z_factorization',101*103==10403 and 102**2-10403==1 and 2**2+4*10403==204**2)
check('Z_phase',77%10==7 and 10403%100==3)
check('Z_altitude',Q(60*(36325-31450),21)==Q(97500,7))
examples['Z_singleton_not_unique']={'original_solution_set':[-1,0,1],'singleton_sound_output':[1],'represents_exactly_one_member_of_S':True,'unique_original_solution':False}
paths=[ROOT/'stefans_math'/'chapters'/f for f in ('A_exact_arithmetic.md','G_discrete_geometry.md','Z_integrated_practice.md')]
result={'base':'SM-2026-10-13-A','python':sys.version,'command':'python3 stefans_math/checks/B_peer_verify.py','status':'FINITE exact recomputations passed; two manuscript-boundary issues reported separately','counts':counts,'examples':examples,'reviewed_file_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'limitations':['Universal proofs were reviewed as written rather than certified by this finite script.','No aviation source revalidation.','No theorem prover.']}
(ROOT/'stefans_math'/'checks'/'B_peer_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':counts,'examples':examples},indent=2))
