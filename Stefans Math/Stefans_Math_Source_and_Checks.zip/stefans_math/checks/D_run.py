#!/usr/bin/env python3
"""Run the two bounded D checks with actual before/after execution provenance."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[2]
area=root/'stefans_math/checks'
declared=['stefans_math/checks/D_results.json','stefans_math/checks/D_modem_results.json']
paths=['stefans_math/checks/D_run.py','stefans_math/checks/D_verify.py','stefans_math/checks/D_modem_check.js','stefans_math/EDITORIAL_CONTRACT.txt','project_sources/01-Math_Work_Exact_Operational_Formalization_ASCII.txt','project_sources/02-Project_Mathematics_Audited_ASCII.txt','project_sources/04-Solvers_Certified_Operationalization_ASCII.txt']
for name in ['Dual_Funnel_Projection_Theorem.pdf','Quaternion_Padic_LockIn_Algorithm_ASCII.txt','airplane_epicycles.html','fourier_six_lab.html','doubling_vortex_mathematics_extracted.txt']:
 p='stefans_math/supplemental/'+name
 if (root/p).exists():paths.append(p)
sha=lambda p:hashlib.sha256((root/p).read_bytes()).hexdigest()
before={p:sha(p) for p in paths}
started=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
commands=[[sys.executable,'stefans_math/checks/D_verify.py'],['node','stefans_math/checks/D_modem_check.js']]
logs=[];exit_status=0
for command in commands:
 process=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=45)
 logs.append(json.dumps(command)+'\n'+process.stdout+process.stderr)
 if process.returncode:
  exit_status=process.returncode;break
duration=time.perf_counter()-clock
after={p:sha(p) for p in paths}
log='stefans_math/checks/D_execution.log';(root/log).write_text('\n'.join(logs))
status='completed' if exit_status==0 else 'failed'
if status=='completed' and before!=after:status='inputs-changed'
outputs=[{'path':log,'sha256':sha(log),'kind':'log'}]
for p in declared:
 if (root/p).exists():outputs.append({'path':p,'sha256':sha(p),'kind':'result'})
manifest={
 'schema_version':2,'claim_id':'D-FINITE-SM-2026-10-13-A',
 'repository':{'commit':'unavailable: supplied-source compilation without git repository','dirty':True},
 'command':[sys.executable,'stefans_math/checks/D_run.py'],
 'environment':{'software':[{'name':'Python','version':platform.python_version()},{'name':'Node','version':subprocess.check_output(['node','--version'],text=True).strip()}],'hardware':platform.machine()},
 'mathematics':{'assertion_tested':'Exact finite Fourier, Mobius, chain, product, projection, quaternion, conic-coordinate and flag identities; approximate waveform/probe reconstruction; actual Fourier Six core constellation and packet checks.','coefficient_domain':'Z, Q, exact Q[i]/Q[omega]/Q[tau], exact permutations, separately labelled IEEE binary64.','conventions':'SM-2026-10-13-A; negative forward DFT sign; 1/N inverse; Hamilton scalar-first active rotation; tolerance 1e-10 for stated float checks.','inputs':[{'path':p,'sha256':before[p]} for p in paths],'bounds':{'DFT4_vectors':625,'Mobius_n_max':256,'anchored_chain_vectors':343,'character_integer_range':[-60,60],'projection_vectors':125,'quaternion_vectors':125,'product_increment_vectors':625,'circle_points':6,'fractional_linear_points':46,'half_radius_points':50,'icosahedral_flags_and_group_elements':120,'paired_probe_samples':256,'six_tone_samples':192,'airplane_coefficients':2048,'airplane_reference_points':1024,'constellation_cases':2040,'packet_cases':6},'non_claims':['Finite computations do not establish universal theorems.','No interval-certified floating calculation or browser UI test.','No physical communication capacity, global nonlinear convergence or chaotic-attractor claim.']},
 'randomness':{'used':False,'generator':'Deterministic enumeration and fixed deterministic bit pattern; no random draw.','seed':None},
 'run':{'started_at':started,'runtime_seconds':duration,'exit_status':exit_status,'status':status,'argv_sequence':commands,'resource_limits':{'memory_bytes':None,'cpu_seconds':None,'max_cores':None,'max_threads':None},'per_process_wall_timeout_seconds':45},
 'input_artifacts':[{'path':p,'sha256':before[p],'sha256_after':after[p]} for p in paths],
 'execution_artifacts':paths,'declared_results':declared,'outputs':outputs,
 'checks':['Exact rational/ring round trips and separate invariants.','Exact icosahedral incidence and complete generated flag group.','Actual extracted modem core without source bits passed to decoder.','Waveform and probe comparisons against independent definitions.'],
 'result':'Implementation and finite assertions verified in the declared ranges.' if status=='completed' else 'Execution failed or inputs changed; review logs.',
 'residual_risks':['Python/Node arithmetic and runtime implementations trusted.','No proof assistant or interval enclosure for binary64 experiments.','CPU/memory/thread caps not enforced; each small process has a 45-second wall timeout.']}
(area/'D_execution_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':status,'runtime_seconds':duration,'exit_status':exit_status}))
raise SystemExit(exit_status)
