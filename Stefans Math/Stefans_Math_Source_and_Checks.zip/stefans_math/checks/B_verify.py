"""Family B exact bounded checks. Base SM-2026-10-13-A.
Run: python3 stefans_math/checks/B_verify.py
All arithmetic is integers or Fraction. No historical test count is reused.
"""
from fractions import Fraction
from itertools import product
from math import factorial, gcd
from pathlib import Path
import hashlib, json, platform, sys, time
BASE = Path(__file__).resolve().parents[1]
START = time.perf_counter()
counts = {}
def count(family):
    counts[family] = counts.get(family, 0) + 1

def vp(a, p):
    if not a: return 10**9
    v = 0
    while a % p == 0:
        a //= p; v += 1
    return v

def value(c, x):
    a,b,d,e=c
    return ((a*x+b)*x+d)*x+e

def derivative(c,x):
    a,b,d,e=c
    return 3*a*x*x+2*b*x+d

def roots(c,p,k):
    rr = [r for r in range(p) if value(c,r)%p==0]
    for j in range(1,k):
        m=p**j; new=[]
        for r in rr:
            q=value(c,r)//m % p; slope=derivative(c,r)%p
            ds=[(-q*pow(slope,-1,p))%p] if slope else (range(p) if not q else [])
            new.extend(r+m*d for d in ds)
        rr=new
    return sorted(rr)

def fractional_mod(q,m):
    return q.numerator*pow(q.denominator,-1,m)%m

def log_mod(u,p,k):
    assert (u-1)%p==0 and (p!=2 or (u-1)%4==0)
    # Long Fraction sum is independent of the finite modular term evaluator.
    return fractional_mod(sum((Fraction((-1)**(n+1)*(u-1)**n,n) for n in range(1,2*k)),Fraction()),p**k)

def exp_mod(y,p,k):
    assert y%p==0 and (p!=2 or y%4==0)
    return fractional_mod(sum((Fraction(y**n,factorial(n)) for n in range(2*k)),Fraction()),p**k)

def divided_term(t,n,d,p,k):
    e=vp(d,p); pe=p**e; m=p**k
    top=pow(t,n,m*pe)
    assert top%pe==0
    return top//pe*pow(d//pe,-1,m)%m

def finite_log(u,p,k):
    return sum((-1)**(n+1)*divided_term(u-1,n,n,p,k) for n in range(1,2*k))%p**k

def finite_exp(y,p,k):
    return (1+sum(divided_term(y,n,factorial(n),p,k) for n in range(1,2*k)))%p**k

# Entire coefficient cube, including identically zero reductions and singular seeds.
for c in product((-1,1),range(-2,3),range(-2,3),range(-2,3)):
    for p in (2,3,5,7):
        for k in (1,2,3):
            expected=[x for x in range(p**k) if value(c,x)%p**k==0]
            assert roots(c,p,k)==expected,(c,p,k)
            count('complete_prime_power_root_sets')

for p in (2,3,5):
    for k in (2,3,4):
        m=p**k; depth=2 if p==2 else 1
        us=list(range(1,m,p**depth)); ys=list(range(0,m,p**depth))
        for u in us:
            l=finite_log(u,p,k)
            assert l==log_mod(u,p,k)
            assert finite_exp(l,p,k)==u
            assert log_mod(u+m,p,k)==l
            count('log_fraction_oracle_inverse_precision')
        for y in ys:
            e=finite_exp(y,p,k)
            assert e==exp_mod(y,p,k)
            assert finite_log(e,p,k)==y
            count('exp_fraction_oracle_inverse')
        for u,v in product(us,repeat=2):
            assert finite_log(u*v%m,p,k)==(finite_log(u,p,k)+finite_log(v,p,k))%m
            count('log_product')

for k in range(1,8):
    m=3**k; period=2*3**(k-1)
    for n in range(period):
        u=pow(2,n,m); eps=0 if u%3==1 else 1
        if k==1: got=eps
        else:
            w=u*pow(2**eps,-1,m)%m
            t=(finite_log(w,3,k)//3)*pow(finite_log(4,3,k)//3,-1,period//2)%(period//2)
            got=eps+2*t
        assert got==n
        count('base_two_ternary_exponent_recovery')

for k in range(1,6):
    m=3**k; input_m=3*m
    cubes={pow(x,3,input_m):x for x in range(input_m) if x%3}
    for c in range(input_m):
        if c%3==0: continue
        sign=1 if c%3==1 else -1
        l=finite_log(sign*c,3,k+1)
        assert (l%9==0)==(c in cubes)
        if l%9==0:
            x=sign*finite_exp(l//3,3,k)%m
            assert (x**3-c)%input_m==0
        count('ternary_unit_cube_extraction_or_rejection')

# Independent fiber oracle for unit-derivative Newton blocks.
for c in product((-1,1),range(-2,3),range(-2,3),range(-2,3)):
    for p in (2,3,5):
        for k in (1,2):
            m=p**k; M=m*m
            for r in roots(c,p,k):
                if derivative(c,r)%p==0:continue
                rn=(r-value(c,r)*pow(derivative(c,r),-1,M))%M
                oracle=[r+m*t for t in range(m) if value(c,r+m*t)%M==0]
                assert oracle==[rn]
                count('unit_newton_complete_fibers')

# All binary parity branches for 3^x modulo 16, including unattainable units.
for target in range(1,16,2):
    got=[]
    for eps in (0,1):
        residual=target*pow(3,-eps,16)%16
        if residual%4!=1:continue
        a=finite_log(9,2,4)//4;b=finite_log(residual,2,4)//4
        for z in range(4):
            if (a*z-b)%4==0:got.append(eps+2*z)
    oracle=[x for x in range(8) if pow(3,x,16)==target]
    assert sorted(got)==oracle
    count('binary_parity_complete_fibers')
assert [x for x in range(8) if pow(3,x,16)==11]==[3,7]

# Doubling sign/log translation at every unit at each named finite level.
for k in range(2,7):
    m=3**k;P=m//3;ell=finite_log(-2,3,k)
    assert ell%3==0 and ell%9!=0
    def psi(u):
        eps=0 if u%3==1 else 1
        ellu=finite_log((-1)**eps*u,3,k)
        tau=ellu//3*pow(ell//3,-1,P)%P
        return eps,tau
    for u in range(m):
        if u%3==0:continue
        eps,tau=psi(u);ee,tt=psi(2*u%m)
        assert (ee,tt)==((eps+1)%2,(tau+1)%P)
        assert (-1)**eps*finite_exp(ell*tau,3,k)%m==u
        count('doubling_sign_translation')
assert finite_log(-2,3,5)==24 and finite_exp(24,3,5)==241

# Degree-two ring: alpha^2=-1. Independent brute table and residual digit algorithm.
def add(u,v,m):return ((u[0]+v[0])%m,(u[1]+v[1])%m)
def mul(u,v,m):return ((u[0]*v[0]-u[1]*v[1])%m,(u[0]*v[1]+u[1]*v[0])%m)
def inverse(u,m):
    q=pow((u[0]*u[0]+u[1]*u[1])%m,-1,m)
    return (u[0]*q%m,-u[1]*q%m)
def power(u,n,m):
    if n<0:return power(inverse(u,m),-n,m)
    out=(1,0)
    while n:
        if n&1:out=mul(out,u,m)
        u=mul(u,u,m);n//=2
    return out

def ring_log(u,k):
    m=3**k; c=((u[0]-1)//3,u[1]//3);out=(0,0)
    for n in range(1,2*k):
        e=vp(n,3); coeff=pow(3,n-1-e,m//3)*pow(n//3**e,-1,m//3)%(m//3)
        t=power(c,n,m//3)
        out=add(out,((-1)**(n+1)*coeff*t[0],(-1)**(n+1)*coeff*t[1]),m//3)
    return out

ring_examples={}
for k in (2,3,4):
    m=3**k; P=m//3; g1=(4,0);g2=(1,3); seen={}
    for x,y in product(range(P),repeat=2):
        h=mul(power(g1,x,m),power(g2,y,m),m)
        assert h not in seen
        seen[h]=(x,y)
        xx=yy=0
        trace=[]
        for j in range(k-1):
            r=mul(h,mul(power(g1,-xx,m),power(g2,-yy,m),m),m)
            d1=((r[0]-1)//3**(j+1))%3;d2=(r[1]//3**(j+1))%3
            xx+=3**j*d1;yy+=3**j*d2
            trace.append({'residual':r,'digits':[d1,d2],'x':[xx,yy]})
        assert (xx,yy)==(x,y)
        C1,C2,b=ring_log(g1,k),ring_log(g2,k),ring_log(h,k)
        assert ((C1[0]*x+C2[0]*y)%P,(C1[1]*x+C2[1]*y)%P)==b
        count('coupled_ring_exponents_complete')
        if (x,y)==(5,7):ring_examples[k]={'target':h,'trace':trace,'C_columns':[C1,C2],'b':b}
    assert len(seen)==P*P

# Polynomial state audit by explicit bounded candidate sets, then direct roots.
c=(1,-37,3,-111); D=set(range(-112,113));C=set(D);M=1;trace=[{'M':1,'count':len(C)}]
for p,k in [(3,1),(3,2),(5,1),(3,3),(5,2)]:
    rr=roots(c,p,k);M=M*(p**k)//gcd(M,p**k)
    Cnew={x for x in C if x%p**k in rr}
    assert Cnew<=C and {37}<=Cnew
    C=Cnew;trace.append({'p':p,'k':k,'M':M,'local_roots':rr,'count':len(C),'candidates':sorted(C) if len(C)<=5 else None})
    count('main_ratchet_stages')
assert [t['count'] for t in trace]==[225,150,25,5,2,1]
assert sorted(x for x in C if value(c,x)==0)==[37]
mixed=[x for x in range(-10,11) if (x**3-x)%5==0 and (x**3-x)%7==0]
assert mixed==[-6,-1,0,1,6]
assert [x for x in mixed if x**3-x==0]==[-1,0,1]
# Strong-Hensel normalization identity and its strict valuation premise.
c=(1,0,0,-10);r=4;p=3;sder=vp(derivative(c,r),p)
assert sder==1 and vp(value(c,r),p)==3 and 3>2*sder
for z in range(-10,11):
    lhs=Fraction(value(c,r+p**(sder+1)*z),p**(2*sder+1))
    a,b,cc,d=c
    rhs=Fraction(value(c,r),p**(2*sder+1))+Fraction(derivative(c,r),p**sder)*z+p*(3*a*r+b)*z*z+p**(sder+2)*a*z**3
    assert lhs==rhs
    count('strong_hensel_rescaling_identity')


for k in range(1,9):
    rr=roots((1,-6,12,-8),3,k)
    assert len(rr)==3**(k-(k+2)//3)
    assert all((r-2)%3**((k+2)//3)==0 for r in rr)
    count('singular_cube_branch_formula')

# Rational monic scaling against independent rational-root theorem enumeration.
def divisors(n):return [d for d in range(1,abs(n)+1) if n%d==0]
for c in product((-2,-1,1,2),range(-2,3),range(-2,3),range(-2,3)):
    a,b,cc,d=c;scaled=(1,b,a*cc,a*a*d);B=1+max(abs(t) for t in scaled[1:])
    got={Fraction(y,a) for y in range(-B,B+1) if value(scaled,y)==0}
    if d==0:
        possibilities={Fraction(n,v) for n in range(-B,B+1) for v in divisors(a)}
    else:
        possibilities={Fraction(s*n,v) for n in divisors(d) for v in divisors(a) for s in (-1,1)}
    expected={x for x in possibilities if value(c,x)==0}
    assert got==expected
    count('complete_rational_monic_scaling')

# Height reconstruction and strictness boundary.
rr=[Fraction(u,v) for u in range(-5,6) for v in range(1,8) if gcd(u,v)==gcd(v,101)==1 and (u-44*v)%101==0]
assert rr==[Fraction(5,7)]
assert 0%5==5%5 # width equal to modulus need not isolate endpoints.
examples={
'valuation_precision':{'x':75,'p':3,'k':5,'residue':75,'valuation':1,'unit':25,'unit_modulus':81},
'cube_log':{'log343_mod2187':finite_log(343,3,7),'quotient_mod729':finite_log(343,3,7)//3,'exp_mod729':finite_exp(222,3,6)},
'exponent173':[{'k':k,'u':pow(2,173,3**k),'period':2*3**(k-1),'residue':173%(2*3**(k-1))} for k in range(1,8)],
'coupled_ring':ring_examples,'main_ratchet':trace,
'simple_cubic':[{'k':k,'roots':roots((1,0,0,-2),5,k)} for k in range(1,7)],
'rational_roots':['-1','1/2','2'],'mixed_crt_false_survivors':[-6,-1,0,1,6],
'height_reconstruction':['5/7'],
}
inputs={str(p.relative_to(BASE.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((BASE.parent/'project_sources').glob('*.txt')) if p.name.startswith(('01-','03-','04-','05-'))}
supplement=BASE/'supplemental'/'doubling_vortex_mathematics_extracted.txt'
inputs[str(supplement.relative_to(BASE.parent))]=hashlib.sha256(supplement.read_bytes()).hexdigest()

result={'base':'SM-2026-10-13-A','verdict':'FINITE: exact assertions passed within stated bounds','python':sys.version,'platform':platform.platform(),'command':'python3 stefans_math/checks/B_verify.py','runtime_seconds':time.perf_counter()-START,'arithmetic':'Python integers and fractions.Fraction; no floating mathematical comparisons','bounds':{'cubics':'a in {-1,1}; b,c,d in [-2,2]; p in {2,3,5,7}; k=1,2,3','log_exp':'p=2,3,5; k=2,3,4; p=2 restricted to 1+4Z and 4Z','dlog':'all exponent classes at 3^k, k=1..7','unit_cubes':'all unit residues modulo 3^(k+1), k=1..5','ring':'alpha^2=-1; all exponent pairs modulo 3^(k-1), k=2,3,4','rational':'a in {-2,-1,1,2}; b,c,d in [-2,2]', 'newton':'same cubic family as root sets; p=2,3,5; k=1,2; every unit-derivative parent; oracle enumerates every p^k child block', 'binary_parity':'all eight odd targets modulo 16; all exponent residues modulo 8', 'doubling_translation':'every unit modulo 3^k; k=2..6', 'strong_hensel':'X^3-10, p=3, r=4; normalization identity for Z=-10..10' },'counts':counts,'total_assertion_cases':sum(counts.values()),'examples':examples,'input_sha256':inputs,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'non_claims':['No proof-assistant certificate.','No universal implementation verification.','No historical count rerun.','No real/complex root completeness claim.']}
(BASE/'checks'/'B_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':counts,'total':sum(counts.values()),'seconds':result['runtime_seconds'],'examples':examples},indent=2))
