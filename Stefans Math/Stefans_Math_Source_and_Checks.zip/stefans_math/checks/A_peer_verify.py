#!/usr/bin/env python3
"""Fresh scoped family-B check; derives operations from raw chapter equations."""
from pathlib import Path
from math import factorial,gcd
from fractions import Fraction
from itertools import product
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]
C={}
def ck(name,assertion):
    if not assertion:raise AssertionError(name)
    C[name]=C.get(name,0)+1
def residue(fr,m):
    fr=Fraction(fr);return fr.numerator*pow(fr.denominator,-1,m)%m
def logmod(u,p,k):
    z=u-1;return sum(residue(Fraction((-1)**(n+1)*z**n,n),p**k) for n in range(1,2*k))%p**k
def expmod(y,p,k):return sum(residue(Fraction(y**n,factorial(n)),p**k) for n in range(2*k))%p**k
def rootslift(a,b,c,d,p,k):
    f=lambda x:a*x**3+b*x*x+c*x+d
    deriv=lambda x:3*a*x*x+2*b*x+c
    roots=[x for x in range(p) if f(x)%p==0];m=p
    for level in range(1,k):
        new=[]
        for r in roots:
            quotient=f(r)//m
            for digit in range(p):
                if (quotient+deriv(r)*digit)%p==0:new.append(r+m*digit)
        roots=new;m*=p
    return roots

def run():
    ck('B_E2_log',logmod(343,3,7)==666)
    ck('B_E2_exp',expmod(222,3,6)==7)
    ck('B_E2_finite_cube_aliases',[x for x in range(729) if (x**3-343)%729==0]==[7,250,493])
    ck('B_E1_product_precision',all(((75+243*u)*(75+243*v)-75*75)%729==0 for u,v in product(range(7),repeat=2)))
    ck('B_binary_log',logmod(9,2,4)//4%4==2)
    for p in [2,3,5,7]:
      for k in range(2,5):
        depth=2 if p==2 else 1;m=p**k
        for z in range(0,m,p**depth):
            u=1+z
            ell=logmod(u,p,k)
            ck('B_finite_safe_chart',expmod(ell,p,k)==u%m)
    for p in [3,5,7]:
      for k in range(1,5):
        m=p**k
        for u in range(1,m):
          if u%p==0:continue
          omega=pow(u,p**(k-1),m)
          ck('B_teichmuller_scalar_formula',pow(omega,p-1,m)==1 and omega%p==u%p)
    for a,b,c,d in product([-1,1],range(-2,3),range(-2,3),range(-2,3)):
      for p in [2,3,5]:
       for k in range(1,5):
        m=p**k;direct=[x for x in range(m) if (a*x**3+b*x*x+c*x+d)%m==0]
        ck('B_complete_cubic_lifts',sorted(rootslift(a,b,c,d,p,k))==direct)
    ck('B_E6_numeric_lifts',all((r**3-2)%5**k==0 for k,r in enumerate([3,3,53,303,2178,5303],start=1)))
    for k in range(1,9):
        roots=[r for r in range(3**k) if (r-2)**3%3**k==0]
        pred=[r for r in range(3**k) if (r-2)%3**((k+2)//3)==0]
        ck('B_singular_count_and_set',roots==pred and len(roots)==3**(k-(k+2)//3))
    # Full exact arithmetic check of rational scaling, including negative a.
    for a,b,c,d in product([-2,-1,1,2],range(-1,2),range(-1,2),range(-1,2)):
      for u,v in product(range(-8,9),range(1,5)):
        x=Fraction(u,v);y=a*x
        f=a*x**3+b*x*x+c*x+d;g=y**3+b*y*y+a*c*y+a*a*d
        ck('B_scaling_identity',g==a*a*f)
        if f==0:ck('B_rational_root_maps_integer',y.denominator==1)
    f=lambda x:x**3-37*x*x+3*x-111
    D=range(-112,113);steps=[(1,0),(3,None),(9,1),(45,37),(135,37),(675,37)]
    counts=[]
    for m,r in steps:
      counts.append(sum(1 for x in D if f(x)%m==0) if r is None else sum(1 for x in D if (x-r)%m==0))
    ck('B_E7_candidate_counts',counts==[225,150,25,5,2,1])
    ck('B_E7_factorization',all(f(x)==(x-37)*(x*x+3) for x in D))
    # Independent strong-Hensel normalization polynomial identity.
    for a,b,c,d,r,s,z in product([-1,1],range(-1,2),range(-1,2),range(-1,2),range(-2,3),range(3),range(-2,3)):
      p=3;f0=a*r**3+b*r*r+c*r+d;fp=3*a*r*r+2*b*r+c
      if fp%p**s or f0%p**(2*s+1):continue
      X=r+p**(s+1)*z
      left=Fraction(a*X**3+b*X*X+c*X+d,p**(2*s+1))
      right=Fraction(f0,p**(2*s+1))+Fraction(fp,p**s)*z+p*(3*a*r+b)*z*z+p**(s+2)*a*z**3
      ck('B_strong_hensel_normalization',left==right)
    chapter=ROOT/'chapters/B_padic_cubic.md'
    result={'base':'SM-2026-10-13-A','reviewed':'B_padic_cubic.md','chapter_sha256':hashlib.sha256(chapter.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'verdict':'all stated finite assertions passed','counts':C,'total_assertions':sum(C.values()),'scope':'Exact examples, full cubic lifts at specified small coefficients/precisions, safe finite log/exp, scalar torsion extraction, rational scaling, strong-Hensel normalization.','non_claims':['Finite checks do not prove universal claims.','No B verification code was imported.','No lattice or symbolic radical implementation is claimed.']}
    out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'checks/A_peer_results.json'
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':run()
