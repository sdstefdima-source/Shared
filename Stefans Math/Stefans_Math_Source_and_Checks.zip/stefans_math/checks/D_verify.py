#!/usr/bin/env python3
"""SM-2026-10-13-A: exact bounded identities and numerical spectral checks.

All universal claims are proved in the chapter. These checks audit examples
and implementations only; floats are explicitly separated from Fractions.
Run from the workspace root: python3 stefans_math/checks/D_verify.py
"""
from fractions import Fraction as F
from itertools import product
from itertools import combinations
from pathlib import Path
import cmath
import hashlib
import json
import math
import platform
import re
import time

BASE = Path(__file__).resolve().parents[1]
START = time.perf_counter()
CHECKS = []

def record(name, kind, count, description, **details):
    CHECKS.append(dict(name=name, arithmetic=kind, cases=count,
                       finite_assertion=description, outcome="pass", **details))

def plus(a,b): return (a[0]+b[0], a[1]+b[1])
def gmul(a,b): return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])
def omul(a,b):
    # Q[w]/(w^2+w+1), encoded as a+b*w.
    return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]-a[1]*b[1])
def normg(a): return a[0]*a[0]+a[1]*a[1]
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def qmul(a,b):
    s,t=a[0],b[0]; v,w=a[1:],b[1:]; c=cross(v,w)
    return (s*t-dot(v,w),*(s*w[j]+t*v[j]+c[j] for j in range(3)))
def qconj(a): return (a[0],*(-x for x in a[1:]))

# Exact three-state character orthogonality.
omega=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(-1))]
for u in range(-60,61):
    value=(F(0),F(0))
    for j in range(3): value=plus(value,omega[(j*u)%3])
    assert value==((F(3),F(0)) if u%3==0 else (F(0),F(0)))
record("D_character_3", "exact Q[omega]",121,"Three-state character indicator for every integer u from -60 through 60.")

# Exact DFT for N=4; all 625 integer input vectors.
i_power=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1))]
for vec in product(range(-2,3),repeat=4):
    coeff=[]
    for k in range(4):
        val=(F(0),F(0))
        for n,x in enumerate(vec): val=plus(val,gmul((F(x),F(0)),i_power[(-k*n)%4]))
        coeff.append(val)
    recovered=[]
    for n in range(4):
        val=(F(0),F(0))
        for k,c in enumerate(coeff): val=plus(val,gmul(c,i_power[(k*n)%4]))
        recovered.append((val[0]/4,val[1]/4))
    assert recovered==[(F(x),F(0)) for x in vec]
    assert sum(x*x for x in vec)==sum(normg(c) for c in coeff)/4
record("D_DFT4", "exact Q[i]",625,"DFT inverse and Parseval on all {-2,-1,0,1,2}^4.")

def divisors(n): return [d for d in range(1,n+1) if n%d==0]
def mu(n):
    out=1; d=2
    while d*d<=n:
        if n%d==0:
            n//=d; out=-out
            if n%d==0:return 0
        d+=1
    return -out if n>1 else out
sequence={n:F(n*n-3*n+2,n+1) for n in range(1,257)}
cumulative={n:sum(sequence[d] for d in divisors(n)) for n in sequence}
for n in sequence:
    assert sum(mu(d) for d in divisors(n))==int(n==1)
    assert sum(mu(d)*cumulative[n//d] for d in divisors(n))==sequence[n]
    # The coefficient of each original monomial after inversion.
    for k in divisors(n):
        val=sum(mu(d) for d in divisors(n) if (n//d)%k==0)
        assert val==int(k==n)
record("D_Mobius", "exact rational/integer",256,"Divisor inversion of specified rational sequence and coefficient cancellation for every n<=256.")
for vec in product(range(-3,4),repeat=3):
    cum=[sum(vec[:n+1]) for n in range(3)]
    inv=[cum[0],cum[1]-cum[0],cum[2]-cum[1]]
    assert inv==list(vec)
record("D_chain", "exact integer",343,"Anchored cumulative/chain inverse on every {-3,...,3}^3.")

# Exact projection onto normal complement of (1,1,1).
P=[[F(int(j==k))-F(1,3) for k in range(3)] for j in range(3)]
for j in range(3):
    for k in range(3): assert sum(P[j][l]*P[l][k] for l in range(3))==P[j][k]
columns=[tuple(P[j][k] for j in range(3)) for k in range(3)]
assert tuple(sum(v[j] for v in columns) for j in range(3))==(0,0,0)
for j in range(3):
    assert dot(columns[j],columns[j])==F(2,3)
    for k in range(3):
        if j!=k:assert dot(columns[j],columns[k])==F(-1,3)
for vec in product(range(-2,3),repeat=3):
    projected=tuple(dot(row,vec) for row in P)
    projected_shift=tuple(dot(row,[v+3 for v in vec]) for row in P)
    assert projected==projected_shift
record("D_projection_120", "exact rational",125,"Rank-two cubic-lattice projection: kernel, idempotence, equal norms and cos(120 degrees)=-1/2.")

# Quaternion rotations with a rational unit quaternion.
q=(F(3,5),F(4,5),F(0),F(0))
qbar=(q[0],-q[1],-q[2],-q[3])
for v in product(range(-2,3),repeat=3):
    pure=(F(0),*map(F,v)); out=qmul(qmul(q,pure),qbar)
    assert out[0]==0 and sum(x*x for x in out)==sum(x*x for x in pure)
    assert qmul(qmul(qbar,out),q)==pure
record("D_quaternion", "exact rational",125,"Quaternion conjugation preserves 125 vector norms and inverts with conjugate.")
assert qmul((0,1,0,0),(0,0,1,0))==(0,0,0,1)
assert qmul((0,0,1,0),(0,1,0,0))==(0,0,0,-1)

# Exact circular samples detect trace ambiguity; coefficient identities.
circle=[(F(1),F(0)),(F(0),F(1)),(F(-1),F(0)),(F(0),F(-1)),(F(3,5),F(4,5)),(F(-3,5),F(4,5))]
J0=F(5); gradient=(F(2),F(-1)); H=((F(4),F(2)),(F(2),F(6)))
def quadratic(v,center=J0,h=H,g=gradient):return center+dot(g,v)+sum(v[j]*h[j][k]*v[k] for j in range(2) for k in range(2))/2
for point in circle:
    shifted=((F(7),F(2)),(F(2),F(9)))
    assert quadratic(point)==quadratic(point,J0-F(3,2),shifted)
record("D_circle_trace", "exact rational",6,"Quadratics H and H+3I, J0 and J0-3/2 coincide on all six specified unit-circle points.")

# Exact finite product-difference and conic transformations.
cases=0
for u,z,a,b in product(range(-2,3),repeat=4):
    assert (u+a)*(z+b)-u*z==u*b+z*a+a*b
    cases+=1
record("D_product_increment", "exact integer",cases,"Finite product cross term on {-2,...,2}^4.")
for x in [F(n,5) for n in range(5,51)]:
    z=1-1/x
    g=x*x*x-x-1
    h=z*z*z-4*z*z+5*z-1
    assert h==(1-z)**3*g
record("D_Mobius_coordinate", "exact rational",46,"Fractional-linear cubic transform h(z)=(1-z)^3*g(1/(1-z)) at x=n/5, n=5,...,50.")
for radius in [F(n,7) for n in range(1,51)]:
    a=c=radius/2
    assert a==c and a+c==radius
record("D_dual_funnel_radius", "exact rational",50,"P3-P4 half-radius identity at 50 positive rational enclosing radii.")

# Exact icosahedral incidence, with tau^2=tau+1 in Q[tau].
def tmul(a,b):return (a[0]*b[0]+a[1]*b[1],a[0]*b[1]+a[1]*b[0]+a[1]*b[1])
vertices=[]
for a,b in product([-1,1],repeat=2):
    vertices.extend([((0,0),(a,0),(0,b)),((a,0),(0,b),(0,0)),((0,b),(0,0),(a,0))])
def squared_distance(v,w):
    ans=(0,0)
    for x,y in zip(v,w):
        delta=(x[0]-y[0],x[1]-y[1]); ans=plus(ans,tmul(delta,delta))
    return ans
edges=[e for e in combinations(range(12),2) if squared_distance(vertices[e[0]],vertices[e[1]])==(4,0)]
edge_set=set(edges)
faces=[f for f in combinations(range(12),3) if all(tuple(e) in edge_set for e in combinations(f,2))]
flags=[(v,e,f) for f in faces for e in combinations(f,2) for v in e]
assert len(edges)==30 and len(faces)==20 and len(flags)==120
index={flag:n for n,flag in enumerate(flags)}
generators=[]
for operation in range(3):
    perm=[]
    for v,e,f in flags:
        if operation==0:
            vv=next(w for w in e if w!=v); new=(vv,e,f)
        elif operation==1:
            ee=next(ee for ee in combinations(f,2) if v in ee and ee!=e); new=(v,ee,f)
        else:
            ff=next(ff for ff in faces if set(e)<=set(ff) and ff!=f); new=(v,e,ff)
        perm.append(index[new])
    generators.append(tuple(perm))
identity=tuple(range(120))
def compose(a,b):return tuple(a[b[j]] for j in range(len(b)))
def ppow(a,n):
    ans=identity
    for _ in range(n):ans=compose(a,ans)
    return ans
for generator in generators:assert ppow(generator,2)==identity
assert ppow(compose(generators[0],generators[1]),3)==identity
assert ppow(compose(generators[1],generators[2]),5)==identity
assert ppow(compose(generators[0],generators[2]),2)==identity
seen={identity}; todo=[identity]
while todo:
    state=todo.pop()
    for generator in generators:
        child=compose(generator,state)
        if child not in seen: seen.add(child); todo.append(child)
assert len(seen)==120
def porder(a):
    ans=a; n=1
    while ans!=identity:ans=compose(a,ans);n+=1
    return n
orders=sorted({porder(a) for a in seen}); assert orders==[1,2,3,5,6,10]
assert {a[0] for a in seen}==set(range(120))
record("D_icosahedral_flags", "exact Q[tau] and permutations",120,"Icosahedral V=12,E=30,F=20; 120 flags, Coxeter relations, 120 generated permutations and simply transitive flag action.",element_orders=orders,coordinates="(0,+/-1,+/-tau) and cyclic permutations, tau^2=tau+1",not_cyclic=True)

# Float harmonic probing: all results are tolerance-bounded numerical evidence.
N=256; bins=[1,7,23]; amplitudes=[.1,.2,.15]; grad=[2.,-3.,4.]; HH=[[4.,1.,2.],[1.,5.,-1.],[2.,-1.,6.]]
def J3(d):return 10.+dot(grad,d)+sum(d[j]*HH[j][k]*d[k] for j in range(3) for k in range(3))/2
hat=[0.]*3; diagonal=[0.]*3
for n in range(N):
    cs=[math.cos(2*math.pi*b*n/N) for b in bins]
    ds=[amplitudes[j]*cs[j] for j in range(3)]
    yp=J3(ds); ym=J3([-x for x in ds]); diff=yp-ym; even=(yp+ym)/2-J3([0,0,0])
    for j in range(3):
        hat[j]+=diff*cs[j]/(N*amplitudes[j])
        diagonal[j]+=8*even*math.cos(4*math.pi*bins[j]*n/N)/(N*amplitudes[j]**2)
error=max(max(abs(a-b) for a,b in zip(hat,grad)),max(abs(diagonal[j]-HH[j][j]) for j in range(3)))
assert error<1e-10
record("D_paired_probe", "binary64 approximate",N,"Paired gradient and diagonal Hessian recovery for specified mixed quadratic.",tolerance=1e-10,max_error=error,gradient=hat,diagonal=diagonal)

N=192; kbins=[4,5,6,7,8,9]; coeff=[complex(1,2),complex(-2,.5),complex(.25,-1),complex(3,-2),complex(-.75,.125),complex(.375,-.625)]
x=[math.sqrt(2)*sum((c*cmath.exp(2j*math.pi*k*n/N)).real for c,k in zip(coeff,kbins)) for n in range(N)]
recovered=[math.sqrt(2)/N*sum(x[n]*cmath.exp(-2j*math.pi*k*n/N) for n in range(N)) for k in kbins]
energy=sum(v*v for v in x)/N; expected=sum(abs(c)**2 for c in coeff)
error=max(abs(a-b) for a,b in zip(coeff,recovered)); assert error<1e-10 and abs(energy-expected)<1e-10
record("D_six_tone", "binary64 approximate",6,"Six coefficient recovery and Parseval on one specified 192-sample block.",tolerance=1e-10,max_error=error,energy=energy,expected_energy=expected)

# Inspect all embedded airplane coefficient/reference data without executing UI.
airplane=BASE/"supplemental/airplane_epicycles.html"
if airplane.exists():
    source=airplane.read_text()
    coeffs=json.loads(re.search(r"const C=(\[.*?\]);",source,re.S).group(1))
    reference=json.loads(re.search(r"const REF=(\[.*?\]);",source,re.S).group(1))
    allpoint=[complex(*p) for p in reference]; NN=len(reference)
    signed={r[0] for r in coeffs}; assert len(signed)==len(coeffs)
    worst=0.; folded={}
    for k,re_part,im_part,mag in coeffs:
        assert abs(abs(complex(re_part,im_part))-mag)<1e-12
        direct=sum(p*cmath.exp(-2j*math.pi*k*n/NN) for n,p in enumerate(allpoint))/NN
        worst=max(worst,abs(direct-complex(re_part,im_part)))
        folded[k%NN]=folded.get(k%NN,0j)+complex(re_part,im_part)
    # It may be a truncated continuous representation rather than full DFT.
    tail=sum(abs(complex(r[1],r[2])) for r in coeffs[129:])
    reconstruction=[]
    for n in range(NN):
        val=sum(complex(r[1],r[2])*cmath.exp(2j*math.pi*r[0]*n/NN) for r in coeffs)
        reconstruction.append(abs(val-allpoint[n]))
    folded_error=max(abs(sum(p*cmath.exp(-2j*math.pi*k*n/NN) for n,p in enumerate(allpoint))/NN-folded[k]) for k in folded)
    assert folded_error<1e-10 and max(reconstruction)<1e-10
    record("D_airplane_data", "binary64 approximate",len(coeffs),"Embedded magnitudes, frequency-folded DFT coefficients and full reference-point reconstruction checked.",coefficient_count=len(coeffs),reference_points=NN,distinct_frequency_bins=len(folded),max_unfolded_coefficient_disagreement=worst,max_folded_coefficient_disagreement=folded_error,max_point_disagreement=max(reconstruction),tail_l1_after_129=tail,tolerance=1e-10,browser_ui_executed=False)

inputs=[Path(__file__),BASE/"EDITORIAL_CONTRACT.txt",BASE.parent/"project_sources/01-Math_Work_Exact_Operational_Formalization_ASCII.txt",BASE.parent/"project_sources/02-Project_Mathematics_Audited_ASCII.txt",BASE.parent/"project_sources/04-Solvers_Certified_Operationalization_ASCII.txt"]
for name in ["Dual_Funnel_Projection_Theorem.pdf","Quaternion_Padic_LockIn_Algorithm_ASCII.txt","airplane_epicycles.html","fourier_six_lab.html"]:
    p=BASE/"supplemental"/name
    if p.exists():inputs.append(p)
extra=BASE/"supplemental/doubling_vortex_mathematics_extracted.txt"
if extra.exists():inputs.append(extra)
output=dict(base="SM-2026-10-13-A",python=platform.python_version(),platform=platform.platform(),elapsed_seconds=time.perf_counter()-START,
            command="python3 stefans_math/checks/D_verify.py",seed=None,
            input_hashes={str(p.relative_to(BASE.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
            checks=CHECKS,non_claims=["No universal theorem follows from these bounded checks.","No interval-certified floating calculation or browser UI playtest.","No proof of chaotic dynamics, global optimization or performance superiority."])
result=BASE/"checks/D_results.json"
result.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
print(json.dumps(dict(groups=len(CHECKS),outcome="pass",elapsed_seconds=output["elapsed_seconds"],results=str(result)),indent=2))
