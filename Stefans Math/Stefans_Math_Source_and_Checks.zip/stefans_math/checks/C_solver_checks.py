"""Exact bounded mathematical checks for Stefans Math family C.

SM-2026-10-13-A. Standard library only. These checks corroborate named
examples and finite formula families; they do not prove universal solving.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import hashlib
import json
import platform
import sys
import time
from datetime import datetime, timezone


def polynomial(coeffs, x):
    value = 0
    for coefficient in reversed(coeffs):
        value = value * x + coefficient
    return value


def bisect(coeffs, left, right, steps):
    left, right = Q(left), Q(right)
    fl, fr = polynomial(coeffs, left), polynomial(coeffs, right)
    assert fl < 0 < fr
    for _ in range(steps):
        middle = (left + right) / 2
        fm = polynomial(coeffs, middle)
        if fm == 0:
            return middle, middle
        if fm < 0:
            left, fl = middle, fm
        else:
            right, fr = middle, fm
    assert polynomial(coeffs, left) < 0 < polynomial(coeffs, right)
    return left, right


def F_box(c):
    x, y, z = c
    return (x + y*y/10 - Q(7, 5),
            y + z*z/10 - Q(29, 10),
            z + x*x/10 - Q(31, 10))


def T_box(c):
    f = F_box(c)
    return tuple(c[i] - f[i] for i in range(3))


def homogeneous(a, b, c):
    s, q, r = a+b+c, a*b+b*c+c*a, a*b*c
    return s**3-6*s*q+7*r


def ec_add(P, R):
    if P is None: return R
    if R is None: return P
    x1, y1 = P
    x2, y2 = R
    if x1 == x2 and y1 == -y2: return None
    slope = ((3*x1*x1+242*x1+1144)/(2*y1) if P == R
             else (y2-y1)/(x2-x1))
    x3 = slope*slope-121-x1-x2
    y3 = -(slope*(x3-x1)+y1)
    return x3, y3


def run():
    started = datetime.now(timezone.utc).isoformat()
    t0 = time.perf_counter()
    results = {}
    # All points, no randomized seeds or skipped residues.
    grid = range(-5, 21)
    roots = []
    for x, y, z in product(grid, repeat=3):
        if x*x + y == z and x+y+z == 10 and x == y:
            roots.append([x, y, z])
    assert roots == [[-5, -5, 20], [2, 2, 6]]
    results['C_EX2'] = {'points': 26**3, 'integer_box': [-5, 20], 'roots': roots}
    # Numerator equation retains a forbidden root; original guard removes it.
    cleared, original = [], []
    for x in range(-5, 6):
        if x*x - 1 == 3*(x-1):
            cleared.append(x)
        if x != 1 and Q(x*x-1, x-1) == 3:
            original.append([x, 3, x+3])
    assert cleared == [1, 2] and original == [[2, 3, 5]]
    results['C_EX1'] = {'cleared_x': cleared, 'guarded_roots': original}
    rational_roots = []
    counts = (range(-4, 5), range(-8, 9), range(-8, 9))
    for X, Y, Z in product(*counts):
        x, y, z = Q(X, 2), Q(Y, 4), Q(Z, 4)
        if x+y+z == 1 and 2*x+y-z == -1 and x-y+2*z == Q(15, 4):
            rational_roots.append([str(x), str(y), str(z)])
    assert rational_roots == [['1/2', '-3/4', '5/4']]
    results['C_EX3'] = {'points': 9*17*17, 'physical_box': [-2, 2],
                           'denominators': [2, 4, 4], 'roots': rational_roots}
    homogeneous_cases = 0
    for a, b, c in product(range(1, 11), repeat=3):
        den = (a+b)*(b+c)*(a+c)
        lhs = Q(a, b+c)+Q(b, a+c)+Q(c, a+b)
        assert (lhs-4)*den == homogeneous(a, b, c)
        assert homogeneous(a, b, c) % 6 == (a+b+c+a*b*c) % 6
        homogeneous_cases += 1
    disc = 121**2*1144**2-4*1144**3-4*121**3*2704-27*2704**2+18*121*1144*2704
    assert disc == 551183360
    P = (Q(-104), Q(260))
    R = None
    carrier_cases = 0
    carrier_checks = []
    for n in range(1, 9):
        R = ec_add(R, P)
        assert R is not None
        X, Y = R
        assert Y*Y == X**3+121*X*X+1144*X+2704
        assert X != 0
        T = -52/X
        w = (T-1)/2
        pair_sum, pair_diff = (9-T)/2, -Y/(2*X)
        u, v = (pair_sum+pair_diff)/2, (pair_sum-pair_diff)/2
        assert u+v+w == 4 and u*v+u*w+v*w+2*u*v*w == 1
        A, B, C = u*(1+v), v*(1+u), 1-u*v
        assert homogeneous(A, B, C) == 0
        if all(t != 0 for t in (A+B, A+C, B+C)):
            assert A/(B+C) == u and B/(A+C) == v and C/(A+B) == w
        carrier_cases += 1
        carrier_checks.append({'multiple': n, 'curve_equation': True,
                               'ratio_identities': True,
                               'positive_ratios': min(u,v,w)>0})
    results['C_HOMOGENEOUS'] = {'positive_input_identity_cases': homogeneous_cases,
                                'input_bound_per_axis': [1,10],
                                'carrier_multiple_checks': carrier_cases,
                                'carrier_discriminant': disc,
                                'carrier_checks': carrier_checks,
                                'non_claim': 'No full rational-group generation, minimality, or positive-integer completeness.'}
    assert Q(4)**(-1) == Q(1,2)**2
    assert Q(-2)**3 == -8
    results['C_EX10'] = {'positive_power_exact_check': '4^(-1)=(1/2)^2',
                            'odd_root_exact_check': '(-2)^3=-8'}
    # Exact polynomial reconstruction on 2,940 quadratic/node/step instances.
    stencil_cases = 0
    for a, b, c in product(range(-3, 4), repeat=3):
        if a == 0:
            continue
        for base, h in product(range(-2, 3), (Q(1, 2), Q(1))):
            f0, f1, f2 = [a*(base+j*h)**2 + b*(base+j*h) + c for j in range(3)]
            d1, d2 = f1-f0, f2-2*f1+f0
            g, curvature = (d1-d2/2)/h, d2/(h*h)
            assert g == 2*a*base+b and curvature == 2*a
            for n in (-3, -1, 0, 1, 2, 4):
                assert f0+n*d1+Q(n*(n-1), 2)*d2 == a*(base+n*h)**2+b*(base+n*h)+c
            stencil_cases += 1
    assert stencil_cases == 2940
    specific = [2*x*x+3*x-15 for x in (Q(0), Q(1, 10), Q(1, 5))]
    assert specific == [Q(-15), Q(-367, 25), Q(-358, 25)]
    results['C_EX4'] = {'stencil_instances': stencil_cases,
                           'trial_points_per_instance': 6,
                           'quadratic_sample_values': list(map(str, specific))}
    # General Newton global convergence is refuted by this exact cycle.
    newton = lambda x: x - (x**3-2*x+2)/(3*x*x-2)
    x0 = Q(0)
    x1, x2 = newton(x0), newton(newton(x0))
    assert (x0, x1, x2) == (Q(0), Q(1), Q(0))
    results['C_EX5'] = {'cycle': list(map(str, (x0, x1, x2))),
                           'residuals': ['2', '1', '2']}
    U = lambda x: x*(x**3+4)/(2*x**3+2)
    h1, h2 = U(Q(1)), U(U(Q(1)))
    assert h1 == Q(5, 4) and h2 == Q(635, 504)
    r2 = h2**3-2
    assert r2 == -Q(253, 128024064)
    upper = h2-r2/3
    assert h2**3 < 2 < upper**3
    factor_cases = 0
    for s in (Q(j, 7) for j in range(1, 50)):
        u = s*(s**3+2)/(2*s**3+1)
        assert u-1 == (s-1)**3*(s+1)/(2*s**3+1)
        assert u-s == -s*(s**3-1)/(2*s**3+1)
        if s > 1: assert 1 < u < s
        if s < 1: assert s < u < 1
        factor_cases += 1
    results['C_EX6'] = {'halley_steps': list(map(str, (h1, h2))),
                           'residual_after_two': str(r2),
                           'interval': [str(h2), str(upper)],
                           'width': str(upper-h2), 'rational_factor_checks': factor_cases}
    left, right = bisect((-1, -1, 0, 1), 1, 2, 48)
    assert right-left == Q(1, 2**48)
    results['C_REAL_BISECTION'] = {'steps': 48, 'left': str(left),
                                       'right': str(right), 'width': str(right-left)}
    # Peer-review regression: a scalar interval Newton pivot belongs in I.
    # f=x^2-1,I=[1,2]. External pivot0 with f'(I)=[2,4] loses root1.
    bad_N = (Q(1, 4), Q(1, 2))
    assert not bad_N[0] <= 1 <= bad_N[1]
    pivot = Q(3, 2)
    fp = pivot*pivot-1
    good_N = (pivot-fp/2, pivot-fp/4)
    assert good_N == (Q(7, 8), Q(19, 16))
    assert good_N[0] <= 1 <= good_N[1]
    results['C_INTERVAL_PIVOT_GUARD'] = {'outside_pivot': '0',
                                           'unsound_N_without_hull': list(map(str, bad_N)),
                                           'inside_pivot': str(pivot),
                                           'sound_N': list(map(str, good_N))}
    c = (Q(101, 100), Q(201, 100), Q(301, 100))
    radius, q = Q(1, 20), Q(153, 250)
    eta = max(map(abs, F_box(c)))
    assert eta == Q(1601, 100000)
    assert eta+q*radius == Q(4661, 100000) < radius
    assert F_box((Q(1), Q(2), Q(3))) == (0, 0, 0)
    vertices = 0
    for signs in product((-1, 1), repeat=3):
        v = tuple(c[i]+signs[i]*radius for i in range(3))
        tv = T_box(v)
        assert all(c[i]-radius < tv[i] < c[i]+radius for i in range(3))
        vertices += 1
    results['C_EX7'] = {'center': list(map(str, c)), 'radius': str(radius),
                           'contraction_upper': str(q), 'drift': str(eta),
                           'self_map_bound': str(eta+q*radius),
                           'corner_checks': vertices, 'exact_root': [1, 2, 3]}
    # Exact linear least squares: H p = -g and final residual zero.
    H, g, theta = ((2, 1), (1, 5)), (-4, -11), (1, 2)
    assert [sum(H[i][j]*theta[j] for j in range(2)) for i in range(2)] == [4, 11]
    assert theta[0]+2*theta[1] == 5 and theta[0]-theta[1] == -1
    results['C_EX8'] = {'H': H, 'g_at_zero': g, 'minimizer': theta,
                           'residual': [0, 0]}
    # Descent can converge away from a stationary point with summable steps.
    x = Q(1)
    steps = 20
    for k in range(steps):
        alpha = Q(1, 2**(k+2))
        x_next = (1-alpha)*x
        assert x_next*x_next/2 <= x*x/2-Q(1, 2)*alpha*x*x
        x = x_next
    assert x > Q(1, 2)
    results['C_SUMMABLE_DESCENT'] = {'steps': steps, 'iterate': str(x),
                                       'uniform_positive_lower_bound': '1/2'}
    # Proposed fallback violates V nonincrease even after feasible clipping.
    assert Q(1, 2) > 0
    results['C_FALLBACK_COUNTEREXAMPLE'] = {'old': '0', 'trial': '1',
                                             'fallback': '1/2', 'V': 'V(M)=M'}
    # Integrator with adaptive gain, exact decimal/rational semantics.
    y, K = Q(0), Q(11, 10)
    trace = []
    for _ in range(4):
        e = 10-y
        control = min(Q(20), max(Q(-20), K*e))
        yn = y+control
        en = 10-yn
        d = (0 if abs(e) <= Q(1, 50) and abs(en) <= Q(1, 50)
             else -2 if e*en < 0 else 1 if abs(en) < abs(e) else -1)
        K = min(Q(6, 5), max(Q(1, 20), K+Q(d, 10)))
        y = yn
        trace.append([str(y), str(K), str(en)])
    assert trace[:3] == [['11', '9/10', '-1'], ['101/10', '1', '-1/10'], ['10', '11/10', '0']]
    plant_cases = 0
    for gain_num in range(1, 25):
        gain = Q(gain_num, 20)
        for error_num in range(-800, 801):
            error = Q(error_num, 10)
            u = min(Q(20), max(Q(-20), gain*error))
            new = error-u
            if error: assert abs(new) < abs(error)
            else: assert new == 0
            if abs(gain*error) <= 20:
                assert abs(new) <= Q(19, 20)*abs(error)
            plant_cases += 1
    results['C_EX9'] = {'trace_y_gain_error': trace,
                           'plant_transition_checks': plant_cases,
                           'gain_range': ['1/20', '6/5'],
                           'error_range': [-80, 80], 'error_step': '1/10'}
    output = Path(__file__).with_name('C_solver_results.json')
    data = {'base': 'SM-2026-10-13-A', 'status': 'passed',
            'arithmetic': 'Python integers and fractions.Fraction only',
            'examples': results,
            'non_claims': ['No complete V4 showcase implementation was rerun.',
                           'No general all-real/all-complex root solver was tested.',
                           'Finite examples do not establish universal convergence.']}
    output.write_text(json.dumps(data, indent=2)+'\n', encoding='ascii')
    script = Path(__file__).resolve()
    script_relative = script.relative_to(Path.cwd().resolve())
    output_relative = output.resolve().relative_to(Path.cwd().resolve())
    source_paths = [Path('project_sources/04-Solvers_Certified_Operationalization_ASCII.txt'),
                    Path('project_sources/02-Project_Mathematics_Audited_ASCII.txt'),
                    Path('stefans_math/supplemental/Solver_Mathematical_Notes_ASCII.txt')]
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = {'schema_version': 1, 'claim_id': 'C-FINITE-2026-10-13',
                'repository': {'commit': 'unversioned supplied-source compilation', 'dirty': True},
                'command': 'python3 stefans_math/checks/C_solver_checks.py',
                'environment': {'software': [sys.version, platform.platform()],
                                'hardware': platform.machine()},
                'mathematics': {'assertion_tested': 'Named C examples and exhaustive specified formula/transition families agree with exact contracts.',
                                'coefficient_domain': 'Z and Q; no floating decisions',
                                'conventions': 'SM-2026-10-13-A; inclusive boxes; original denominator guards; coefficients ascending.',
                                'inputs': [{'path': str(p), 'sha256': sha(p)} for p in source_paths]+[{'path': str(script_relative), 'sha256': sha(script)}],
                                'bounds': {'three_variable_points': 26**3,
                                           'rational_grid_points': 9*17*17,
                                           'quadratic_stencils': 2940,
                                           'homogeneous_identity_cases': homogeneous_cases,
                                           'carrier_multiples': carrier_cases,
                                           'halley_rationals': 49,
                                           'plant_transitions': plant_cases},
                                'non_claims': data['non_claims']},
                'randomness': {'used': False, 'generator': 'not used', 'seed': None},
                'run': {'started_at': started, 'runtime_seconds': time.perf_counter()-t0, 'exit_status': 0},
                'outputs': [{'path': str(output_relative), 'sha256': sha(output)}],
                'checks': ['Independent exhaustive finite grids; polynomial reconstruction; direct substitution; exact sign brackets; exact contraction constants; plant inequalities.'],
                'result': 'Implementation and finite assertions verified in stated ranges.',
                'residual_risks': ['Version 1 manifest pins checksums but lacks before/after input snapshots.',
                                   'No independent process proof assistant verification.',
                                   'Runtime semantics and exact arithmetic library are trusted.']}
    script.with_name('C_solver_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='ascii')
    print(json.dumps({'status': 'passed', 'quadratic_stencils': stencil_cases,
                      'plant_transitions': plant_cases, 'examples': len(results)}))


if __name__ == '__main__':
    run()
