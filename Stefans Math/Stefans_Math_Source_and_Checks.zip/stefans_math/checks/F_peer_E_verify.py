#!/usr/bin/env python3
"""Fresh derivations/checks for selected E chapter claims; no E implementation imported."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
from itertools import permutations, product
from math import comb, gcd, isqrt, lcm
from pathlib import Path
import hashlib
import json
import time

OUT = Path(__file__).resolve().parent
counts = Counter()
def ck(label,predicate):
    counts[label] += 1
    if not predicate:
        raise AssertionError(label)

def prime(n):
    return n>=2 and all(n%d for d in range(2,isqrt(n)+1))

def finite_alarm_probability(horizon,method):
    alive = [1]
    powers3 = [3**k for k in range(horizon+1)]
    for t in range(1,horizon+1):
        cumulative=[]
        if method != "mixture":
            coefficient=1
            total=0
            for r in range(t+1):
                total+=coefficient
                cumulative.append(total)
                if r<t:
                    coefficient=coefficient*(t-r)//(r+1)
        nxt = [0]*(t+1)
        for k in range(t+1):
            ways = (alive[k] if k<len(alive) else 0)+(alive[k-1] if k else 0)
            if method == "mixture":
                reject = powers3[k]+powers3[t-k] >= 20*(1 << (t+1))
            else:
                j = min(k,t-k)
                reject = 40*cumulative[j] <= (1 << t)
            if not reject:
                nxt[k] = ways
        alive = nxt
    return 1-Fraction(sum(alive),1 << horizon)

def main():
    started=time.perf_counter()
    started_at=datetime.now(timezone.utc).isoformat()
    # Construct the two positive-probability histories directly, for all tested m.
    for memory in range(1,33):
        hidden0=[0,0]
        hidden1=[1,1]
        for _ in range(memory):
            hidden0.append(1-hidden0[-1]); hidden1.append(1-hidden1[-1])
        c0=[a+b for a,b in zip(hidden0,hidden0[1:])]
        c1=[a+b for a,b in zip(hidden1,hidden1[1:])]
        ck("count_memory", c0==[0]+[1]*memory and c1==[2]+[1]*memory)
        ck("count_memory", hidden0[-1] != hidden1[-1])
        ck("count_memory", {hidden0[-1]+0,hidden0[-1]+1} !=
                            {hidden1[-1]+0,hidden1[-1]+1})
    # Full-cycle hash repair: all permutations of five buckets, all unit steps.
    for perm in permutations(range(5)):
        for a,g in product(range(5),range(1,5)):
            ck("permutation_probe", len({perm[(a+t*g)%5] for t in range(5)})==5)
    ck("perturbed_probe",[(t+[0,4,3,2][t%4])%5 for t in range(5)]==[0,0,0,0,4])
    # Augmented walk period; independent deterministic orbit traversal.
    steps=[(-1,0),(0,-1),(0,0),(0,1),(1,0)]
    for rows,cols,length in product(range(1,5),range(1,5),range(1,4)):
        for word in product(steps,repeat=length):
            state=(0,0,0); visits=0
            while True:
                r,c,q=state; dr,dc=word[q]
                state=((r+dr)%rows,(c+dc)%cols,(q+1)%length)
                visits+=1
                if state==(0,0,0):break
                if visits>length*rows*cols:raise AssertionError("orbit did not close")
            ar=sum(a for a,b in word); ac=sum(b for a,b in word)
            ck("walk_period",visits==length*lcm(rows//gcd(rows,ar),cols//gcd(cols,ac)))
    # Exact wheel semantics and prime equality exceptions.
    ps=[2,3,5,7,11]; modulus=2310
    for h in range(1,65):
        expected=1
        for p in ps:expected*=p-1 if h%p==0 else p-2
        actual=sum(all(n%p and (n+h)%p for p in ps) for n in range(modulus))
        ck("wheel_counts",actual==expected)
    for p in [2,3,5,7,11,13]:
        primes=[q for q in range(2,p+1) if prime(q)]
        for n in range(p+1,p*p+1):
            ck("square_shell",prime(n)==all(n%q for q in primes))
    F=lambda n:n*n+n+41
    for p in [q for q in range(2,41) if prime(q)]:
        ck("Euler_root_exclusion",all(F(n)%p for n in range(p)))
    ck("Euler_prime_run",all(prime(F(n)) for n in range(40)))
    ck("Euler_prime_run",F(40)==41**2)
    # Reconstruct the F9 code solely from declared field operations.
    profiles=[]
    for a,b in product(range(3),repeat=2):
        code=[]
        for t in range(3):
            code.extend([2*(a+t)%3,((a+t)**2+b*b)%3])
        profiles.append(((a,b),tuple(code)))
    distinct=set(code for _,code in profiles)
    ck("F9_code",len(distinct)==6)
    distances=[sum(x!=y for x,y in zip(c,d)) for c,d in product(distinct,repeat=2) if c!=d]
    ck("F9_code",min(distances)==3)
    sizes=Counter(code for _,code in profiles)
    ck("F9_code",Counter(sizes.values())=={1:3,2:3})
    # Hard-support omission counterexample to unrepaired E3.2.
    prior={2:Fraction(1,2),5:Fraction(1,2)}
    likelihood={2:Fraction(4,5),5:Fraction(4,5)}
    hard={2}
    weights={x:prior[x]*likelihood[x]*int(x in hard) for x in prior}
    ck("symmetry_hard_support_counterexample",weights[2]!=weights[5])
    # Count differences: exact enumerated source tape versus binomial law.
    for width in range(1,5):
        for lag in range(5):
            n=width+lag
            law=Counter()
            for tape in product(range(2),repeat=n):
                diff=sum(tape[lag:lag+width])-sum(tape[:width])
                law[diff]+=1
            m=min(width,lag)
            for diff in range(-m,m+1):
                ck("overlap_difference_law",Fraction(law[diff],1<<n)==
                   Fraction(comb(2*m,diff+m),1 << (2*m)))
    # Check every finite successor conditional mean of the two-point mixture.
    for t in range(33):
        for k in range(t+1):
            now=Fraction(3**k+3**(t-k),1 << (t+1))
            left=Fraction(3**k+3**(t+1-k),1 << (t+2))
            right=Fraction(3**(k+1)+3**(t-k),1 << (t+2))
            ck("mixture_martingale",(left+right)/2==now)
    crossing={}
    for method in ["mixture","fixed_binomial"]:
        for horizon in [20,512]:
            probability=finite_alarm_probability(horizon,"mixture" if method=="mixture" else "binomial")
            crossing[f"{method}_{horizon}"]=dict(float=float(probability),fraction=str(probability))
            if method=="mixture":ck("sequential_crossing",probability<=Fraction(1,20))
            else:ck("sequential_crossing",probability>Fraction(1,20))
            if method=="mixture" and horizon==512:ck("false_limit",probability>Fraction(1,24))
    ck("duplicated_source_counterexample",Fraction(3**10+1,1 << 11)>20)
    ck("duplicated_source_counterexample",Fraction(3**5+1,1 << 6)<20)
    ck("duplicated_source_counterexample",Fraction(1,16)>Fraction(1,20))
    mask=[int(gcd(F(n),1763)==1) for n in range(1763)]
    ck("mask",sum(mask)==1599)
    for width in [42,43]:
        multiplicities=Counter(tuple(mask[(i+j)%1763] for j in range(width)) for i in range(1763))
        if width==42:
            ck("phase_identification",sum(v==2 for v in multiplicities.values())==5)
            ck("phase_identification",max(multiplicities.values())==2)
        else:ck("phase_identification",len(multiplicities)==1763)
    chapter=OUT.parent/"chapters/E_patterns_statistics.md"
    result=dict(status="PASS",base="SM-2026-10-13-A",counts=dict(counts),total=sum(counts.values()),
                started_at=started_at,
                duration_seconds=time.perf_counter()-started,crossing=crossing,
                chapter_hash=hashlib.sha256(chapter.read_bytes()).hexdigest(),
                verifier_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                note="Fresh targeted peer computation, not a proof assistant or imported E verifier run; unrepaired hard-support counterexample retained as historical diagnosis.")
    (OUT/"F_peer_E_results.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps(dict(status=result["status"],checks=result["total"],seconds=result["duration_seconds"],
                         crossing={k:v['float'] for k,v in crossing.items()}),indent=2))

if __name__=="__main__":main()
