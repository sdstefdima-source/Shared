#!/usr/bin/env python3
"""Independent exact finite checks for chapters G and Z; no external inputs."""
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import hashlib,json,platform,time,datetime
BASE=Path(__file__).resolve().parent
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.perf_counter(); checks=0

def check(condition):
 global checks
 assert condition
 checks+=1

# Barycentric inversion and convex membership, independent explicit triangle map.
for ix in range(-12,25):
 for iy in range(-12,37):
  x,y=Q(ix,6),Q(iy,6)
  l1,l2=x/2,y/3;l0=1-l1-l2
  check(l0+l1+l2==1)
  check(2*l1==x and 3*l2==y)
  check((min(l0,l1,l2)>=0)==(x>=0 and y>=0 and 3*x+2*y<=6))
  check(l0+5*l1+7*l2==1+2*x+2*y)
# Gram counterexample evaluated as quadratic form, not a floating eigenvalue.
G=[[Q(1) if i==j else Q(-161,200) for j in range(3)] for i in range(3)]
check(sum(sum(row) for row in G)==Q(-183,100))
# Incidence/coboundary and energy identities for all bounded integer potentials.
D=[[-1,1,0],[0,-1,1],[1,0,-1]]
L=[[sum(D[k][i]*D[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
check([sum(D[k][j] for k in range(3)) for j in range(3)]==[0,0,0])
for a in range(-5,6):
 for b in range(-5,6):
  for c in range(-5,6):
   f=[a,b,c];df=[sum(row[j]*f[j] for j in range(3)) for row in D]
   lf=[sum(row[j]*f[j] for j in range(3)) for row in L]
   check(sum(df)==0)
   check(sum(f[i]*lf[i] for i in range(3))==sum(x*x for x in df))
   check(sum(lf)==0)
# Gauss-Bonnet checked in units of pi with known triangulated examples.
check(4*(2-Q(3,3))==2*(4-6+4))
check(4*Q(1,2)==2*(4-5+2))
# Dyadic angle coordinates in units of pi: direct floor versus recurrence.
for numerator in range(1,31):
 for denominator in range(1,11):
  target=Q(numerator,denominator);rem=target;acc=Q(0)
  prevlo,prevhi=Q(0),target+1
  for n in range(9):
   unit=Q(1,2**(n+3));digit=rem//unit;acc+=digit*unit;rem-=digit*unit
   check(acc==unit*(target//unit))
   check(0<=rem<unit)
   check(prevlo<=acc<=target<=acc+unit<=prevhi)
   prevlo,prevhi=acc,acc+unit
# Complete bounded cubic reconstruction: independent direct root check.
local9=[r for r in range(9) if (r**3-r)%9==0]
local5=[r for r in range(5) if (r**3-r)%5==0]
classes=[r for r in range(45) if r%9 in local9 and r%5 in local5]
check(classes==[0,1,9,10,19,26,35,36,44])
candidates=[x for x in range(-2,3) if x%45 in classes]
check(candidates==[x for x in range(-2,3) if x**3-x==0]==[-1,0,1])
# Factor pair representation and reciprocal/gap enclosures, entire finite family.
factor_cases=0
for N in range(2,1001):
 for a in range(1,isqrt(N)+1):
  if N%a:continue
  b=N//a;h=b-a;k=a+b;factor_cases+=1
  check(h*h+4*N==k*k and (k-h)%2==0)
  check((k-h)//2==a and (k+h)//2==b)
  for width in range(1,4):
   low=max(1,a-width);high=min(isqrt(N),a+width)
   ylo=(N+high-1)//high;yhi=N//low
   check(ylo<=b<=yhi)
   check(ylo-high<=h<=yhi-low)
# Independently enumerate gap square reconstructions for a bounded family.
for N in range(2,301):
 direct={(a,N//a) for a in range(1,isqrt(N)+1) if N%a==0}
 gaps=set()
 for h in range(N):
  K=isqrt(h*h+4*N)
  if K*K==h*h+4*N and (K-h)%2==0:
   pair=((K-h)//2,(K+h)//2)
   if pair[0]>0:gaps.add(pair)
 check(gaps==direct)
check(102**2-10403==1 and 101*103==10403)
check(10403%100==3)
check(Q(77%10,10)==Q(7,10))
result={
 'status':'pass','assertions':checks,'runtime_seconds':time.perf_counter()-t0,
 'started_at':started,'python':platform.python_version(),
 'domains':'exact integers and Fraction rational arithmetic',
 'scope':{
 'triangle_grid':'ix=-12..24,iy=-12..36; coordinates divided by6',
 'potentials':'all triples in[-5,5]^3',
 'dyadic_angles':'numerator1..30,denominator1..10,levels0..8',
 'factor_pairs':'N=2..1000,all lower factors',
 'gap_roundtrip':'N=2..300,h=0..N-1'},
 'factor_cases':factor_cases,
 'non_claims':['No universal theorem follows from a finite test.',
 'No physical mesh convergence, factorization speedup or global numerical convergence is tested.'],
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
}
(BASE/'GZ_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
