#!/usr/bin/env python3
"""SM-2026-10-13-A: exact finite checks of the F chapter contracts.

Run from the project workspace: python3 stefans_math/checks/F_verify.py
All enumeration bounds are recorded in F_results.json. No random sampling.
The written proofs, not the counts, justify the universal chapter statements.
"""
from __future__ import annotations

import ast
from collections import Counter, deque
from datetime import datetime, timezone
from functools import reduce
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import sys
import time
import types

BASE = "SM-2026-10-13-A"
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
STARTED = datetime.now(timezone.utc).isoformat()
T0 = time.perf_counter()
SUITES = {}
ASSERTIONS = Counter()


def check(suite, condition, detail):
    ASSERTIONS[suite] += 1
    if not condition:
        raise AssertionError(f"{suite}: {detail}")


def nand(a, b):
    return 1 - a*b


def full_adder(a, b, c):
    t = nand(a, b)
    u = nand(a, t)
    v = nand(b, t)
    p = nand(u, v)
    q = nand(p, c)
    r = nand(p, q)
    s = nand(c, q)
    return nand(r, s), nand(t, q)


def ripple(a, b, carry, width):
    result = 0
    for bit in range(width):
        out, carry = full_adder((a >> bit)&1, (b >> bit)&1, carry)
        result |= out << bit
    return result | (carry << width)


def verify_arithmetic():
    suite = "nand_and_integer_arithmetic"
    for a, b, c in itertools.product(range(2), repeat=3):
        s, carry = full_adder(a,b,c)
        check(suite, s+2*carry == a+b+c, (a,b,c))
    pairs = 0
    for width in range(1, 9):
        for a,b,carry in itertools.product(range(1 << width), range(1 << width), range(2)):
            pairs += 1
            check(suite, ripple(a,b,carry,width) == a+b+carry, (width,a,b,carry))
    squares = 0
    for width in range(1, 9):
        for x in range(1 << width):
            xs = [(x >> i)&1 for i in range(width)]
            expanded = sum(bit*(1 << (2*i)) for i,bit in enumerate(xs))
            expanded += sum((xs[i]&xs[j])*(1 << (i+j+1))
                            for i in range(width) for j in range(i+1,width))
            squares += 1
            check(suite, expanded == x*x, (width,x))
    root_cases = 0
    for width in range(1,6):
        for target in range(1 << (2*width)):
            candidates = set(range(1 << width))
            for precision in range(1, 2*width+1):
                modulus = 1 << precision
                refined = {x for x in candidates if (x*x-target)%modulus == 0}
                exact_roots = {x for x in range(1 << width) if x*x == target}
                check(suite, exact_roots <= refined <= candidates,
                      ("root preservation",width,target,precision))
                candidates = refined
            z = math.isqrt(target)
            expected = {z} if z*z == target and z < (1 << width) else set()
            check(suite, candidates == expected, ("root equality",width,target))
            root_cases += 1
    overflow = None
    for width in range(1,9):
        for a,b in itertools.product(range(1, 1 << width), repeat=2):
            exact = a*a+b*b
            wrapped = exact % (1 << (2*width))
            c = math.isqrt(wrapped)
            if c > 0 and c < (1 << width) and c*c == wrapped and c*c != exact:
                overflow = dict(width=width,a=a,b=b,c=c,exact_square_sum=exact,
                                wrapped_square_sum=wrapped)
                break
        if overflow:
            break
    check(suite, overflow is not None, "need concrete overflow alias")
    guarded_triangle_cases = 0
    for width in range(1,6):
        modulus = 1 << (2*width)
        for c in range(1,1 << width):
            for a,b in itertools.product(range(1,c+1),repeat=2):
                residual = a*a+b*b-c*c
                check(suite, (residual%modulus == 0) == (residual == 0),
                      ("largest-side comparison guard",width,a,b,c))
                guarded_triangle_cases += 1
    SUITES[suite] = dict(full_adder_rows=8, ripple_cases=pairs, widths=[1,8],
                         square_cases=squares, root_targets=root_cases,
                         root_widths=[1,5], overflow_counterexample=overflow,
                         largest_side_guard_cases=guarded_triangle_cases,
                         largest_side_guard_widths=[1,5])


def gate(op,a,b,c):
    if op == 0: return (~a)&15
    if op == 1: return a&b
    if op == 2: return a|b
    if op == 3: return a^b
    if op == 4: return (~(a^b))&15
    if op == 5: return a if c else b
    raise ValueError(op)


def bit_gate(op,a,b,c):
    if op == 0: return 1-a
    if op == 1: return a*b
    if op == 2: return a+b-a*b
    if op == 3: return (a+b)%2
    if op == 4: return 1-(a+b)%2
    if op == 5: return c*a+(1-c)*b
    raise ValueError(op)


def xor_all(values):
    return reduce(lambda a,b:a^b, values, 0)


def syndromes(data):
    rx = [xor_all(row) for row in data]
    rs = [sum(row)%16 for row in data]
    cx = [xor_all(data[r][c] for r in range(96)) for c in range(32)]
    cs = [sum(data[r][c] for r in range(96))%16 for c in range(32)]
    corners = [xor_all(rx),sum(rs)%16,xor_all(rs),sum(cx)%16]
    return rx,rs,cx,cs,corners


def verify_table():
    suite = "nibble_table"
    data = [[0]*32 for _ in range(96)]
    addresses = set()
    for op,a,b,c in itertools.product(range(6),range(16),range(16),range(2)):
        row, col = 16*op+a, b+16*c
        idx = row*34+col
        check(suite, idx not in addresses, ("address collision",op,a,b,c))
        addresses.add(idx)
        output = gate(op,a,b,c)
        expected = sum(bit_gate(op,(a>>j)&1,(b>>j)&1,c)*(1<<j) for j in range(4))
        check(suite, output == expected, (op,a,b,c))
        data[row][col] = output
    original = syndromes(data)
    fault_cases = 0
    for row,col in itertools.product(range(96),range(32)):
        old = data[row][col]
        for new in range(16):
            if new == old:
                continue
            data[row][col] = new
            dx_row = xor_all(data[row]) ^ original[0][row]
            dx_col = xor_all(data[r][col] for r in range(96)) ^ original[2][col]
            check(suite, dx_row == dx_col and dx_row != 0, (row,col,old,new))
            check(suite, new^dx_row == old, ("repair",row,col,old,new))
            ds_row = (sum(data[row])-original[1][row])%16
            check(suite, ds_row == (new-old)%16 and ds_row != 0,
                  ("sum check",row,col,old,new))
            fault_cases += 1
        data[row][col] = old
    damaged = [row[:] for row in data]
    coords = [(16,0),(16,16),(17,0),(17,16)]
    for row,col in coords:
        check(suite, damaged[row][col] == 0, ("rectangle source",row,col))
        damaged[row][col] = 8
    check(suite, syndromes(damaged) == original, "four-cell undetected fault")
    check(suite, damaged != data, "fault must actually change table")
    check(suite, data[58][6] == 12 and 58*34+6 == 1978, "XOR example")
    check(suite, data[90][22] == 10 and 90*34+22 == 3082, "IF example")
    SUITES[suite] = dict(data_cells=3072, single_fault_cases=fault_cases,
                         table_shape=[98,34], nibble_count=3332,
                         undetected_four_cell_fault=dict(coordinates=coords,
                                                         old=0,new=8))


def evidence_and(a,b): return (a[0]&b[0],a[1]|b[1])
def evidence_or(a,b): return (a[0]|b[0],a[1]&b[1])
def evidence_neg(a): return (a[1],a[0])


def verify_logic():
    suite = "logic_and_observation"
    four = list(itertools.product(range(2),repeat=2))
    for a,b,c in itertools.product(four,repeat=3):
        check(suite, evidence_neg(evidence_and(a,b)) ==
              evidence_or(evidence_neg(a),evidence_neg(b)), ("De Morgan",a,b))
        check(suite, evidence_and(a,evidence_or(b,c)) ==
              evidence_or(evidence_and(a,b),evidence_and(a,c)),
              ("distributivity",a,b,c))
    p,q = (1,1),(0,0)
    conditional = evidence_or(evidence_neg(p),q)
    check(suite, p[0] == conditional[0] == 1 and q[0] == 0, "MP countermodel")
    rows = {z for z in itertools.product(range(2),repeat=3) if z[2] == z[0]^z[1]}
    for i,j in [(0,1),(0,2),(1,2)]:
        check(suite, {(z[i],z[j]) for z in rows} == set(itertools.product(range(2),repeat=2)),
              ("pairwise projection",i,j))
    check(suite, (1,1,1) not in rows, "spurious global triple")
    check(suite, not any(a!=b and b!=c and a!=c
                        for a,b,c in itertools.product(range(2),repeat=3)),
          "disequality triangle")
    for r,c in [(5,8),(4,8)]:
        all_idx = set()
        for row,col in itertools.product(range(r),range(c)):
            idx = c*row+col
            check(suite, divmod(idx,c) == (row,col), ("index inverse",r,c,row,col))
            all_idx.add(idx)
        check(suite, all_idx == set(range(r*c)), ("index coverage",r,c))
    check(suite, {(i%4,i%8) for i in range(32)} ==
          {(i%4,i%8) for i in range(8)}, "noncoprime residue alias")
    for i in range(20):
        x = 1 if i%2 == 0 else 0
        nxt = 1-x
        check(suite, nxt-(13-x) == -12, ("modulus residual",i))
        for modulus in [2,3,4,6,12]:
            check(suite, (13-x)%modulus == nxt, (i,modulus))
    uniform_countermodels = 0
    for flat in itertools.product(range(2),repeat=4):
        relation = [flat[:2],flat[2:]]
        local = all(any(row) for row in relation)
        uniform = any(all(relation[w][a] for w in range(2)) for a in range(2))
        if local and not uniform:
            uniform_countermodels += 1
    check(suite, uniform_countermodels == 2, "quantifier exchange count")
    SUITES[suite] = dict(four_valued_triples=64, xor_full_profiles=sorted(rows),
                         local_uniform_success_matrices=16,
                         nonuniform_countermodels=uniform_countermodels,
                         modulus_aliases=[2,3,4,6,12])


def closure(seeds,rules):
    current = set(seeds)
    while True:
        nxt = current | {q for body,q in rules if body <= current}
        if nxt == current:
            return current
        current = nxt


def verify_closure_and_maps():
    suite = "grounded_closure_and_fixed_points"
    universe = set(range(3))
    subsets = [set(x for x in universe if mask&(1<<x)) for mask in range(8)]
    edges = list(itertools.product(range(3),repeat=2))
    cases = 0
    for mask in range(512):
        rules = [({a},b) for bit,(a,b) in enumerate(edges) if mask&(1<<bit)]
        for seeds in subsets:
            got = closure(seeds,rules)
            supersets = [candidate for candidate in subsets if seeds <= candidate
                         and all(not body<=candidate or q in candidate for body,q in rules)]
            expected = set.intersection(*supersets)
            check(suite, got == expected, (mask,sorted(seeds)))
            cases += 1
    check(suite, closure(set(),[({0},1),({1},0)]) == set(), "unsupported cycle")
    check(suite, closure({0},[({0},1),({1},0)]) == {0,1}, "seeded cycle")
    check(suite, closure({0},[({0,1},2)]) == {0}, "conjunction guard")
    check(suite, closure({0,1},[({0,1},2)]) == {0,1,2}, "conjunction firing")
    states = list(itertools.product(range(2),repeat=2))
    distribution = Counter()
    monotone_count = 0
    for images in itertools.product(range(4),repeat=4):
        fixes = [i for i in range(4) if images[i] == i]
        distribution[len(fixes)] += 1
        leq = lambda a,b: all(x<=y for x,y in zip(a,b))
        monotone = all(not leq(states[i],states[j]) or
                       leq(states[images[i]],states[images[j]])
                       for i,j in itertools.product(range(4),repeat=2))
        if monotone:
            monotone_count += 1
            for start in [0,3]:
                current = start
                for step in range(5):
                    current = images[current]
                check(suite, images[current] == current, ("extremal fixed point",images,start))
            check(suite, bool(fixes), ("monotone existence",images))
    check(suite, dict(distribution) == {0:81,1:108,2:54,3:12,4:1}, "fixed point counts")
    check(suite, monotone_count == 36, "monotone map count")
    SUITES[suite] = dict(unary_rule_graphs=512, seed_sets=8, closure_cases=cases,
                         conjunctive_named_cases=2, maps_on_four_states=256,
                         fixed_point_distribution=dict(distribution),
                         monotone_maps=monotone_count)


def reachable(graph,start,allowed=None):
    if allowed is not None and start not in allowed:
        return set()
    seen = {start}
    todo = [start]
    while todo:
        here = todo.pop()
        for nxt in graph[here]:
            if (allowed is None or nxt in allowed) and nxt not in seen:
                seen.add(nxt)
                todo.append(nxt)
    return seen


def has_cycle(graph,allowed):
    color = {}
    def visit(node):
        color[node] = 1
        for nxt in graph[node]:
            if nxt not in allowed:
                continue
            if color.get(nxt) == 1:
                return True
            if not color.get(nxt) and visit(nxt):
                return True
        color[node] = 2
        return False
    return any(not color.get(node) and visit(node) for node in allowed)


def least_fixed(f):
    value = set()
    while True:
        nxt = f(value)
        if nxt == value:
            return value
        value = nxt


def greatest_fixed(f,states):
    value = set(states)
    while True:
        nxt = f(value)
        if nxt == value:
            return value
        value = nxt


def verify_temporal():
    suite = "finite_temporal_graphs"
    graphs, cases = 0,0
    for n in range(1,4):
        states = set(range(n))
        successors = [set(i for i in range(n) if mask&(1<<i)) for mask in range(1,1<<n)]
        for row_choices in itertools.product(successors,repeat=n):
            graph = dict(enumerate(row_choices))
            graphs += 1
            pre_some = lambda z: {s for s in states if graph[s]&z}
            pre_all = lambda z: {s for s in states if graph[s] <= z}
            for mask in range(1<<n):
                label = {i for i in states if mask&(1<<i)}
                ef = least_fixed(lambda z:label|pre_some(z))
                af = least_fixed(lambda z:label|pre_all(z))
                ag = greatest_fixed(lambda z:label&pre_all(z),states)
                eg = greatest_fixed(lambda z:label&pre_some(z),states)
                for start in states:
                    all_reached = reachable(graph,start)
                    avoid_reached = reachable(graph,start,states-label)
                    safe_reached = reachable(graph,start,label)
                    check(suite, (start in ef) == bool(all_reached&label), ("EF",graph,label,start))
                    check(suite, (start in af) == (not has_cycle(graph,avoid_reached)),
                          ("AF",graph,label,start))
                    check(suite, (start in ag) == (all_reached <= label), ("AG",graph,label,start))
                    check(suite, (start in eg) == has_cycle(graph,safe_reached), ("EG",graph,label,start))
                cases += 1
    SUITES[suite] = dict(state_sizes=[1,3], serial_directed_graphs=graphs,
                         graph_label_cases=cases, exact_classical_operators=["EF","AF","AG","EG"],
                         independent_oracle="reachability and DFS cycle detection")


def hanoi_neighbors(state):
    tops = {}
    for disk,peg in enumerate(state):
        tops.setdefault(peg,disk)
    for src,disk in tops.items():
        for dst in range(3):
            if dst != src and (dst not in tops or tops[dst] > disk):
                nxt = list(state)
                nxt[disk] = dst
                yield tuple(nxt)


def hanoi_recursive(n,src,dst,aux):
    if n:
        yield from hanoi_recursive(n-1,src,aux,dst)
        yield n-1,dst
        yield from hanoi_recursive(n-1,aux,dst,src)


def verify_hanoi():
    suite = "hanoi_state_graph"
    reports = []
    for n in range(8):
        start = (0,)*n
        target = (2,)*n
        distances = {start:0}
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for nxt in hanoi_neighbors(current):
                if nxt not in distances:
                    distances[nxt] = distances[current]+1
                    queue.append(nxt)
        check(suite, len(distances) == 3**n, ("graph coverage",n))
        check(suite, distances[target] == 2**n-1, ("shortest transfer",n))
        current = start
        path = [current]
        for disk,dst in hanoi_recursive(n,0,2,1):
            nxt = list(current)
            nxt[disk] = dst
            nxt = tuple(nxt)
            check(suite, nxt in set(hanoi_neighbors(current)), ("recursive move",n,current,nxt))
            current = nxt
            path.append(current)
        check(suite, current == target and len(path)-1 == distances[target], ("path optimum",n))
        reports.append(dict(disks=n,graph_states=len(distances),minimum_moves=distances[target]))
        if n == 3:
            check(suite, ["".join(map(str,s)) for s in path] ==
                  ["000","200","210","110","112","012","022","222"], "chapter path")
    SUITES[suite] = dict(disks=[0,7], bfs_and_recursive_comparison=reports)


def verify_original_mechanical():
    suite = "original_mechanical_simulator"
    source = ROOT/"stefans_math/supplemental/Mechanical Logic Computers(2).txt"
    raw = source.read_text()
    # Read the whole available artifact, then extract its explicitly delimited code.
    start = raw.index("# Mechanical Logic Machine Simulator")
    program = raw[start:]
    parsed = ast.parse(program, filename=str(source))
    # Preserve all definitions and constants; skip only original demo executions.
    allowed = (ast.Import,ast.ImportFrom,ast.ClassDef,ast.FunctionDef,ast.Assign,ast.AnnAssign)
    body = [node for node in parsed.body if isinstance(node,allowed)]
    # Top-level demo assignments call functions/instantiate objects; none is needed.
    body = [node for node in body if not isinstance(node,(ast.Assign,ast.AnnAssign))
            or not any(isinstance(desc,ast.Call) for desc in ast.walk(node))]
    module = types.ModuleType("F_original_mechanical")
    module.__file__ = str(source)
    sys.modules[module.__name__] = module
    exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),str(source),"exec"),module.__dict__)
    examples = [
        ("A | ~A", lambda d:1),
        ("A & ~A", lambda d:0),
        ("~((A & B) | C)", lambda d:int(not ((d["A"] and d["B"]) or d["C"]))),
        ("(A -> B) & A -> B", lambda d:1),
        ("A ^ B", lambda d:d["A"]^d["B"]),
        ("A <-> B", lambda d:int(d["A"] == d["B"])),
        ("A -> (B -> C)", lambda d:int((not d["A"]) or (not d["B"]) or d["C"])),
        ("~(A -> B)", lambda d:int(d["A"] and not d["B"])),
        ("~(A ^ B)", lambda d:int(d["A"] == d["B"])),
        ("~(A <-> B)", lambda d:d["A"]^d["B"]),
    ]
    rows = 0
    for formula,oracle in examples:
        report = module.run_machine(formula,trace_enabled=False)
        for assignment,value in report.rows:
            check(suite, value == oracle(assignment), (formula,assignment,value))
            rows += 1
    valid = module.validate_argument(["A -> B","A"],"B",trace_enabled=False)
    invalid = module.validate_argument(["A -> B","B"],"A",trace_enabled=False)
    check(suite, valid.classification == "contradiction", "modus ponens valid")
    check(suite, invalid.seen_one, "affirming consequent countermodel")
    SUITES[suite] = dict(source=str(source.relative_to(ROOT)), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                         executed_original_definitions=True, skipped="only original printing/demo calls",
                         formulas=len(examples),truth_rows=rows,argument_cases=2,
                         output_reference="separate direct Boolean functions")


def verify_ideal_wave_gates():
    suite = "ideal_wave_threshold_gates"
    cases = 0
    for n in range(1,9):
        for bits in itertools.product(range(2),repeat=n):
            signed = [2*b-1 for b in bits]
            and_z = sum(signed)-(n-1)
            or_z = sum(signed)+(n-1)
            check(suite, int(and_z>0) == int(all(bits)), ("AND",bits))
            check(suite, int(or_z>0) == int(any(bits)), ("OR",bits))
            check(suite, abs(and_z)>=1 and abs(or_z)>=1, ("margin",bits))
            cases += 1
    for b in range(2):
        check(suite, int(-(2*b-1)>0) == 1-b, ("NOT",b))
    SUITES[suite] = dict(and_or_input_counts=[1,8],and_or_rows=cases,not_rows=2,
                         arithmetic="exact integers after ideal compensation",
                         not_claimed="no noisy physical-device reliability experiment")


def main():
    if sys.flags.optimize:
        raise RuntimeError("Run without Python optimization for consistent source assertions.")
    for work in [verify_arithmetic,verify_table,verify_logic,verify_closure_and_maps,
                 verify_temporal,verify_hanoi,verify_original_mechanical,verify_ideal_wave_gates]:
        work()
    sources = [
        ROOT/"project_sources/01-Math_Work_Exact_Operational_Formalization_ASCII.txt",
        ROOT/"project_sources/02-Project_Mathematics_Audited_ASCII.txt",
        ROOT/"project_sources/03-Cryptogram_Operational_Formalization_ASCII.txt",
        ROOT/"stefans_math/supplemental/abstract_temporal_framework_ASCII.txt",
        ROOT/"stefans_math/supplemental/Math Compilation/Three_Dimensional_Logic_Array_Monograph_ASCII.txt",
        ROOT/"stefans_math/supplemental/Math Compilation/CH_Choice_Cubical_Logic_Report.txt",
        ROOT/"stefans_math/supplemental/Electronic Logic Computers(2).txt",
        ROOT/"stefans_math/supplemental/Mechanical Logic Computers(2).txt",
        ROOT/"stefans_math/supplemental/logic_block_layout.txt",
        ROOT/"stefans_math/supplemental/logic_block_squaring_rooting_triangles.txt",
        ROOT/"stefans_math/supplemental/Logic Certificates(1).txt",
        ROOT/"stefans_math/supplemental/terminator_logic_verification.txt",
    ]
    hashes = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    report = dict(base=BASE,started_at=STARTED,python=platform.python_version(),
                  duration_seconds=time.perf_counter()-T0,status="PASS",randomness="none",
                  assertions=dict(ASSERTIONS),total_assertions=sum(ASSERTIONS.values()),
                  suites=SUITES,input_sha256=hashes,
                  verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  non_claims=["No finite test is promoted to a universal theorem.",
                              "No forcing theorem, CH independence proof or arbitrary temporal validity decision is run.",
                              "No physical hardware, noisy wave simulation or general parser proof is certified.",
                              "The finite temporal suite covers classical EF/AF/AG/EG, not every four-valued CTL formula."])
    output = OUT/"F_results.json"
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    elapsed = time.perf_counter()-T0
    manifest = dict(schema_version=1,claim_id="F-finite-contracts-"+BASE,
        repository=dict(commit="not a git repository; source hashes pinned",dirty=True),
        command="python3 stefans_math/checks/F_verify.py",
        environment=dict(software=["Python "+platform.python_version()+" standard library"],
                         hardware=platform.machine()+"; "+platform.system()+"; CPU timing not a performance claim"),
        mathematics=dict(assertion_tested="Exact checks of specified finite F-chapter interfaces and counterexamples",
                         coefficient_domain="integers; Boolean pairs; finite sets; unsigned bit words",
                         conventions=BASE+"; bit index 0 is least significant; Hanoi disk0 is smallest; finite temporal graphs serial",
                         inputs=[dict(path=p,sha256=h) for p,h in hashes.items()],
                         bounds=SUITES,non_claims=report["non_claims"]),
        randomness=dict(used=False,generator="none",seed=None),
        run=dict(started_at=STARTED,runtime_seconds=elapsed,exit_status=0),
        outputs=[dict(path=str(output.relative_to(ROOT)),sha256=hashlib.sha256(output.read_bytes()).hexdigest())],
        checks=["NAND outputs compared with integer addition", "Table outputs compared with independent per-bit arithmetic",
                "Unary closure compared with intersection of all closed supersets", "Temporal fixed points compared with DFS/BFS oracle",
                "Hanoi recursion compared with breadth-first exact distances", "Original mechanical source definitions compared with direct Boolean oracle"],
        result="implementation and finite assertions verified within the stated bounds",
        residual_risks=["Self-review of chapter proofs; no proof assistant", "Legacy v1 manifest records source hashes but not live before/after file monitoring",
                        "Original source circuits beyond the named tests remain unverified"])
    (OUT/"F_manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
    print(json.dumps(dict(status="PASS",assertions=report["total_assertions"],seconds=round(elapsed,3),
                         output=str(output.relative_to(ROOT)),suites=SUITES),indent=2))


if __name__ == "__main__":
    main()
