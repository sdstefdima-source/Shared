"""Record the actual bounded family-B execution with before/after input hashes."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, platform, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'stefans_math'/'checks'
files=[ROOT/'stefans_math'/'checks'/'B_verify.py',Path(__file__).resolve()]
files+=sorted(p for p in (ROOT/'project_sources').glob('*.txt') if p.name.startswith(('01-','03-','04-','05-')))
files.append(ROOT/'stefans_math'/'supplemental'/'doubling_vortex_mathematics_extracted.txt')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(ROOT)):sha(p) for p in files}
started=datetime.now(timezone.utc).isoformat();t=time.perf_counter()
argv=[sys.executable,'stefans_math/checks/B_verify.py']
run=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
runtime=time.perf_counter()-t
(OUT/'B_run.log').write_text(run.stdout+run.stderr)
after={str(p.relative_to(ROOT)):sha(p) for p in files}
assert run.returncode==0,run.stderr
assert before==after,'Execution inputs changed during run.'
result=json.loads((OUT/'B_results.json').read_text())
manifest={
'schema_version':2,'claim_id':'SM-2026-10-13-A/B-finite-boundary-checks',
'repository':{'commit':'unavailable: standalone compilation, no git revision','dirty':True},
'command':argv,'environment':{'software':[{'name':'Python','version':platform.python_version()}],'hardware':platform.machine()+'; '+platform.platform()},
'mathematics':{'assertion_tested':'Complete finite cubic root sets, safe log/exp charts, coupled exponent recovery, binary parity families, Newton blocks, ternary exponent/cube coordinates, and rational monic scaling match independent exact oracles.','coefficient_domain':'Python integers, fractions.Fraction; Z/p^k Z and degree-two coefficient ring alpha^2=-1.','conventions':'Base SM-2026-10-13-A; == means congruence; canonical least nonnegative residues; complete distinct root sets; odd-prime principal depth 1 and binary safe depth 2.','inputs':list(before),'bounds':result['bounds'],'non_claims':result['non_claims']},
'randomness':{'used':False,'generator':'none: deterministic exhaustive finite loops','seed':None},
'run':{'started_at':started,'runtime_seconds':runtime,'exit_status':run.returncode,'status':'completed','resource_limits':{'memory_bytes':None,'cpu_seconds':None,'max_cores':None,'max_threads':None},'missing_results':[],'invalid_results':[]},
'input_artifacts':[{'path':p,'sha256':before[p],'sha256_after':after[p]} for p in before],
'execution_artifacts':list(before),'declared_results':['stefans_math/checks/B_results.json'],
'outputs':[{'path':'stefans_math/checks/B_results.json','sha256':sha(OUT/'B_results.json'),'kind':'result'},{'path':'stefans_math/checks/B_run.log','sha256':sha(OUT/'B_run.log'),'kind':'log'}],
'checks':[{'family':name,'case_groups':n,'result':'passed exact independent assertion'} for name,n in result['counts'].items()],
'result':'FINITE: 26,484 exact case groups passed at declared bounds; implementation and finite assertions checked; no universal implementation certificate.',
'residual_risks':['No theorem prover was used.','The ring routes share coefficient multiplication.','General Smith-form construction and ramified extension engines were not executed.','No operating-system resource cap was imposed; declared finite loops completed within the recorded runtime.']}
(OUT/'B_computation_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'exit_status':run.returncode,'total_case_groups':result['total_assertion_cases'],'runtime_seconds':runtime,'inputs_unchanged':before==after},indent=2))
