#!/usr/bin/env python3
"""Fresh exact checks for Stefan's Math family E, SM-2026-10-13-A.

This tests declared finite instances and implementation invariants. It does not
prove prime asymptotics, stochastic assumptions, or universal solver claims.
Standard library only. Run from compilation root:
    python3 stefans_math/checks/E_verify.py
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from math import comb, gcd, lcm, isqrt
from pathlib import Path
import hashlib, json, platform, time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).with_name('E_results.json')
checks = Counter()
results = {}

def check(condition, group):
    checks[group] += 1
    if not condition:
        raise AssertionError(group)

def primes_upto(n):
    return [p for p in range(2, n+1) if all(p%d for d in range(2,isqrt(p)+1))]

def F(n): return n*n+n+41
def tm(n): return (-1)**n.bit_count()

def integer_root(n,k):
    r=0
    while (r+1)**k<=n: r+=1
    return r

def mobius(n):
    sign=1
    for p in primes_upto(n):
        if n%p==0:
            n//=p; sign=-sign
            if n%p==0: return 0
    return sign

def J(x):
    return sum((Fraction(sum(p**e<=x for p in primes_upto(x)),e)
                for e in range(1,x.bit_length())),Fraction())

def rank(matrix):
    a = [[Fraction(x) for x in row] for row in matrix]
    r = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(r,len(a)) if a[i][col]), None)
        if pivot is None: continue
        a[r], a[pivot] = a[pivot], a[r]
        divisor = a[r][col]
        a[r] = [x/divisor for x in a[r]]
        for i in range(len(a)):
            if i != r and a[i][col]:
                factor = a[i][col]
                a[i] = [x-factor*y for x,y in zip(a[i],a[r])]
        r += 1
    return r

def fixedtime_alarm(t,k):
    # Exact symmetric two-sided binomial tail, clipped at one.
    tail = min(2**t, 2*sum(comb(t,j) for j in range(min(k,t-k)+1)))
    return 20*tail <= 2**t

def crossing(horizon, kind):
    alive = {0:1}
    for t in range(1,horizon+1):
        nxt = defaultdict(int)
        for k,count in alive.items():
            for newk in (k,k+1):
                alarm = (fixedtime_alarm(t,newk) if kind=='binomial' else
                         3**newk+3**(t-newk) >= 20*2**(t+1))
                if not alarm: nxt[newk] += count
        alive = nxt
    return Fraction(2**horizon-sum(alive.values()),2**horizon)

def main():
    start = time.monotonic()
    begun = datetime.now(timezone.utc).isoformat()
    # Rolling Hamming identity: independent direct windows, every legal shift.
    for n in range(2,8):
        for x in product((0,1),repeat=n):
            for w in range(1,n):
                for i in range(n-w):
                    for j in range(n-w):
                        old = sum(x[i+r]!=x[j+r] for r in range(w))
                        actual = sum(x[i+1+r]!=x[j+1+r] for r in range(w))
                        check(actual==old-(x[i]!=x[j])+(x[i+w]!=x[j+w]),'rolling_hamming')
    # Hash verification survives complete fingerprint collapse.
    x = [1,2,3,1,2,3,9,9,1,2,3]
    for w in range(1,6):
        windows = [tuple(x[i:i+w]) for i in range(len(x)-w+1)]
        for q in windows + [tuple([0]*w)]:
            indexed = [i for i,v in enumerate(windows) if v==q] # one bucket, exact verifier
            direct = [i for i in range(len(x)-w+1) if tuple(x[i:i+w])==q]
            check(indexed==direct,'forced_hash_collision')
    # Independently enumerate wrapped augmented-state periods.
    walks = 0
    vectors = ((0,0),(0,1),(1,0),(1,-1))
    for rows in range(1,5):
        for cols in range(1,5):
            for length in range(1,4):
                for word in product(vectors,repeat=length):
                    dr,dc = map(sum,zip(*word))
                    predicted = length*lcm(rows//gcd(rows,dr),cols//gcd(cols,dc))
                    state=(0,0,0); seen=set()
                    while state not in seen:
                        seen.add(state); r,c,q=state; a,b=word[q]
                        state=((r+a)%rows,(c+b)%cols,(q+1)%length)
                    check(state==(0,0,0) and len(seen)==predicted,'walk_period')
                    walks += 1
    results['walk_machines'] = walks
    # Supplemental hash counterexamples and repaired permutation coverage.
    perturbation=[0,4,3,2]
    addresses=[(t+perturbation[t%4])%5 for t in range(20)]
    check(addresses[:5]==[0,0,0,0,4] and set(addresses)==set(range(5)),
          'perturbed_probe_coverage_counterexample')
    check([pow(2,j*j,2**16) for j in range(4,8)]==[0,0,0,0],
          'sampled_frequency_alias')
    permutation=[2,4,1,0,3]
    for a in range(5):
        for g in range(1,5):
            check(len(set(permutation[(a+t*g)%5] for t in range(5)))==5,
                  'permutation_probe_repair')
    results['perturbed_probe_first_five']=addresses[:5]
    # Width-two count memory histories force distinct successor laws.
    for memory in range(1,9):
        terminal_sets=[]
        for first_count in (0,2):
            history=(first_count,)+(1,)*memory
            matching=[word for word in product((0,1),repeat=memory+2)
                      if tuple(word[i]+word[i+1] for i in range(memory+1))==history]
            check(bool(matching),'count_memory')
            terminal_sets.append(set(word[-1] for word in matching))
        check(terminal_sets[0]!=terminal_sets[1] and all(len(s)==1 for s in terminal_sets),
              'count_memory')
    # Exact rational rank, independent of the gcd proof.
    for modulus in range(1,11):
        for width in range(1,11):
            a = [[sum((i+r)%modulus==j for r in range(width))
                  for j in range(modulus)] for i in range(modulus)]
            check(rank(a)==modulus-gcd(modulus,width)+1,'window_sum_rank_Q')
    # Pair wheels, explicit finite counts and CRT product.
    ps=[2,3,5,7,11]; wheel=2310
    counts={}
    for h in range(1,65):
        direct=sum(gcd(n*(n+h),wheel)==1 for n in range(wheel))
        expected=1
        for p in ps: expected *= p-1 if h%p==0 else p-2
        check(direct==expected,'prime_pair_wheel')
        if h in (2,4,6,8,12,18,30,32,60,64): counts[h]=direct
    results['prime_pair_wheel_2310']=counts
    # Original square-shell theorem and higher-root necessary bound.
    shellcounts={}
    for p in (2,3,5,7,11):
        ps=primes_upto(p); size=0
        for n in range(p+1,p*p+1):
            exact_prime=all(n%d for d in range(2,isqrt(n)+1))
            survivor=all(n%q for q in ps)
            check(survivor==exact_prime,'square_shell_sieve')
            size+=survivor
            factors=0; remaining=n
            for q in primes_upto(n):
                while remaining%q==0: remaining//=q; factors+=1
            for k in range(2,6):
                if all(n%q for q in ps if q**k<=p*p):
                    check(factors<=k-1,'higher_root_roughness')
        shellcounts[p]=size
    results['square_shell_prime_counts']=shellcounts
    for x in range(2,65):
        inverse=sum((Fraction(mobius(m),m)*J(integer_root(x,m))
                     for m in range(1,x.bit_length())),Fraction())
        check(inverse==len(primes_upto(x)),'finite_prime_power_Mobius_inversion')
    check(J(16)==Fraction(91,12),'finite_prime_power_Mobius_inversion')
    results['J_16']=str(J(16))
    results['Euler_no_root_primes_below_41']={p:[r for r in range(p) if F(r)%p==0]
                                             for p in primes_upto(40)}
    check(all(not r for r in results['Euler_no_root_primes_below_41'].values()),'Euler_prime_run')
    check(all(all(F(n)%d for d in range(2,isqrt(F(n))+1)) for n in range(40)),'Euler_prime_run')
    check(F(40)==41**2 and F(49)==47*53 and
          all(all(n%d for d in range(2,isqrt(n)+1)) for n in (419,421)),
          'Euler_prime_run')
    # Offset root-overlap formula where division is by a unit.
    for p in primes_upto(61):
        if p==2: continue
        for h in range(1,33):
            roots=[n for n in range(p) if F(n)%p==F(n+h)%p==0]
            if h%p:
                predicted=[(-(h+1)*pow(2,-1,p))%p] if (h*h+163)%p==0 else []
                check(roots==predicted,'offset_root_overlap')
    # Product root lifting at 163: direct children, including disappearing level.
    p=163; h=163; roots=[r for r in range(p) if F(r)*F(r+h)%p==0]
    rootcounts=[len(roots)]
    modulus=p
    for k in (2,3):
        nextmod=modulus*p
        roots=[r+t*modulus for r in roots for t in range(p)
               if F(r+t*modulus)*F(r+t*modulus+h)%nextmod==0]
        modulus=nextmod; rootcounts.append(len(roots))
    check(rootcounts==[1,163,0],'dying_product_root_tree')
    results['product_root_counts_p163_h163']=rootcounts
    # Arithmetic mask components and phase identification widths.
    mask=[int(gcd(F(n),1763)==1) for n in range(1763)]
    check(sum(mask)==1599,'mask_components')
    components=[]; i=0
    while i<len(mask):
        if not mask[i]: i+=1; continue
        first=i
        while i<len(mask) and mask[i]: i+=1
        components.append((first,i-1))
    check(len(components)==117 and max(components,key=lambda v:v[1]-v[0])==(862,900),'mask_components')
    check(F(881)==853*911,'composite_survival_peak')
    results['mask_component_lengths']=dict(sorted(Counter(b-a+1 for a,b in components).items()))
    collision_counts={}
    for w in (42,43):
        signatures=Counter(tuple(mask[(n+r)%1763] for r in range(w)) for n in range(1763))
        collision_counts[w]=sum(s>1 for s in signatures.values())
        check(collision_counts[w]==(5 if w==42 else 0) and
              all(s<=2 for s in signatures.values()),'phase_identification')
    results['phase_signature_collision_fibers']=collision_counts
    # Binary carry identity and exact dyadic correlation.
    for n in range(4096):
        for k in range(9):
            a=n//2**k+1; v=0
            while a%2==0: a//=2; v+=1
            check(tm(n)*tm(n+2**k)==-(-1)**v,'binary_carry')
    for m in range(11):
        for k in range(m+1):
            direct=sum(tm(n)*tm(n+2**k) for n in range(2**m))
            exact=-(2**m+2**(k+1)*(-1)**(m-k))//3
            check(direct==exact,'dyadic_correlations')
    # Discrepancy exhaustive full-mask enumeration, all progressions all prefixes.
    discrepancy_counts={}
    for bound in (1,2):
        row=[]
        for n in range(1,13):
            valid=0
            for word in product((-1,1),repeat=n):
                good=True
                for d in range(1,n+1):
                    partial=0
                    for index in range(d-1,n,d):
                        partial += word[index]
                        if abs(partial)>bound: good=False; break
                    if not good: break
                valid += good
            row.append(valid)
        discrepancy_counts[bound]=row
    check(discrepancy_counts[1]==[2,2,4,2,4,2,4,2,4,2,4,0],'discrepancy_enumeration')
    check(discrepancy_counts[2]==[2,4,6,12,18,28,44,88,100,152,240,370],'discrepancy_enumeration')
    results['discrepancy_counts_N1_to12']=discrepancy_counts
    # Independent prime signs: complete 256-element ensemble through N=20.
    ps=primes_upto(20); sums=[]
    for signs in product((-1,1),repeat=len(ps)):
        values=[]
        for n in range(1,21):
            value=1
            for p,sign in zip(ps,signs):
                while n%p==0: n//=p; value*=sign
            values.append(value)
        sums.append(sum(values))
    mean=Fraction(sum(sums),len(sums)); moment=Fraction(sum(s*s for s in sums),len(sums))
    check(mean==4 and moment==42 and moment-mean*mean==26,'prime_sign_moments')
    results['prime_sign_N20_moments']={'mean':str(mean),'second_moment':str(moment),'variance':str(moment-mean*mean)}
    # Completed mod-three character: factor stripping versus base-three digits.
    total=0
    for n in range(1,4097):
        u=n
        while u%3==0: u//=3
        total += 1 if u%3==1 else -1
        digits=[]; u=n
        while u: u,d=divmod(u,3); digits.append(d)
        check(total==digits.count(1),'completed_character_digit_sum')
    # GF(9) invariant records and minimum-distance-one-error orbit code.
    code={}
    for a,b in product(range(3),repeat=2):
        orbit=(a,min(b,(-b)%3))
        word=tuple(v for t in range(3)
                   for v in ((2*(a+t))%3,((a+t)**2+b*b)%3))
        if orbit in code: check(code[orbit]==word,'GF9_symmetry_code')
        code[orbit]=word
    distance=lambda u,v:sum(a!=b for a,b in zip(u,v))
    minimum=min(distance(u,v) for i,u in enumerate(code.values())
                for j,v in enumerate(code.values()) if i!=j)
    check(len(code)==6 and minimum==3,'GF9_symmetry_code')
    records=0
    for orbit,word in code.items():
        corrupted={word}
        for i in range(6):
            for delta in (1,2):
                v=list(word); v[i]=(v[i]+delta)%3; corrupted.add(tuple(v))
        for v in corrupted:
            decoded=min(code,key=lambda q:distance(v,code[q]))
            check(decoded==orbit,'GF9_one_error_decode'); records+=1
    check(records==78,'GF9_one_error_decode')
    results['GF9_orbit_code']={'minimum_distance':minimum,'verified_records':records}
    # Filtering symmetry also requires invariant hard support, independently of
    # invariant prior/dynamics/likelihood. An added bound can break an alias.
    hidden=(2,5)
    for support in (set(),set(hidden)):
        weights={x:int(x in support) for x in hidden}
        check(weights[2]==weights[5],'support_invariant_symmetry')
    bounded_weights={x:int(x<3) for x in hidden}
    check(bounded_weights=={2:1,5:0},'support_breaks_observation_alias')
    # Exact crossing dynamic program, horizon 512. State retains prior alarm.
    sequential={}
    for h in (20,100,256,512):
        a=crossing(h,'binomial'); b=crossing(h,'evidence')
        check(b<=Fraction(1,20),'sequential_crossing')
        sequential[h]={'fixed_time_test_ever_alarm':str(a),'mixture_evidence_ever_alarm':str(b),
                       'test_percent':float(100*a),'evidence_percent':float(100*b)}
    check(Fraction(sequential[512]['mixture_evidence_ever_alarm'])>Fraction(1,24),'false_limit_1_over_24')
    results['sequential_crossings']=sequential
    check(Fraction(3**10+1,2**11)==Fraction(29525,1024)>20,'duplicate_source_counterexample')
    check(Fraction(3**5+1,2**6)==Fraction(61,16)<20,'duplicate_source_counterexample')
    # Bernoulli grid confidence sets, exact rational comparisons, selected 1110 record.
    retained={Fraction(r,100) for r in range(1,100)}; grid={}; k=0
    for t in range(1,257):
        k+=int((t-1)%4<3)
        retained={p for p in retained if 1 < 20*(t+1)*comb(t,k)*p**k*(1-p)**(t-k)}
        if t in (16,64,256): grid[t]=[str(min(retained)),str(max(retained)),len(retained)]
    check(grid=={16:['43/100','19/20',53],64:['29/50','89/100',32],256:['33/50','83/100',18]},'confidence_grid')
    results['confidence_grid_1110']=grid
    results['checks']=dict(checks)
    results['finite_assertions']=sum(checks.values())
    results['base_revision']='SM-2026-10-13-A'
    OUT.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n',encoding='ascii')
    manifest={
        'schema_version':1,'claim_id':'E-FINITE-SM-2026-10-13-A',
        'repository':{'commit':'not a git repository; base SM-2026-10-13-A','dirty':True},
        'command':'python3 stefans_math/checks/E_verify.py',
        'environment':{'software':[platform.python_version()+' Python; standard library'],
                       'hardware':platform.machine()+' '+platform.system()},
        'mathematics':{'assertion_tested':'Declared finite identities, exhaustive pattern/count instances and exact fair-bit crossing probabilities',
                       'coefficient_domain':'integers and rational numbers (fractions.Fraction)',
                       'conventions':'Zero-based tape; positive discrepancy positions; no circular wrap except named cyclic mask',
                       'inputs':[{'path':str(Path(__file__).relative_to(ROOT)),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}],
                       'bounds':{'binary_tapes':'length 2..7','walks':'R,C1..4; step words1..3; four declared displacements',
                                 'matrix_ranks':'M,w1..10 over Q','wheel':'M2310,h1..64','carry':'n0..4095,k0..8',
                                 'discrepancy':'all sign words N1..12, bounds1,2','sequential':'horizons20,100,256,512',
                                 'grid':'99 parameters,256 observations','count_memory':'identical suffix length1..8',
                                 'square_shells':'p2,3,5,7,11; higher roots k2..5','prime_power_counts':'x2..64',
                                 'GF9_code':'all9 hidden states,all78 clean/single-error orbit records',
                                 'completed_character':'n1..4096'},
                       'non_claims':['No prime asymptotic or novelty claim','No real-data stochastic-model validation','No universal complexity gain','No full replay of historic packages']},
        'randomness':{'used':False,'generator':'none','seed':None},
        'run':{'started_at':begun,'runtime_seconds':time.monotonic()-start,'exit_status':0},
        'outputs':[{'path':str(OUT.relative_to(ROOT)),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}],
        'checks':[{'name':group,'assertions':count,'passed':True} for group,count in checks.items()],
        'result':'Finite assertions passed in the stated ranges; fresh exact checks',
        'residual_risks':['Self-review shares project definitions','No OS resource cap; computation is bounded by explicit loops','Legacy version-1 provenance schema']}
    Path(__file__).with_name('E_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='ascii')
    print(json.dumps({'result':'passed','assertions':sum(checks.values()),'runtime_seconds':manifest['run']['runtime_seconds'],
                      'output':str(OUT)},sort_keys=True))

if __name__=='__main__': main()
