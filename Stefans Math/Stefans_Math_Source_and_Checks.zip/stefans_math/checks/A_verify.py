#!/usr/bin/env python3
"""SM-2026-10-13-A. Exact family-A finite checks, standard library only."""
from pathlib import Path
from math import gcd,lcm,isqrt
from fractions import Fraction
from itertools import product
import hashlib,json,platform,time,sys
ROOT=Path(__file__).resolve().parents[1]
COUNTS={}
def check(name,flag):
    if not flag: raise AssertionError(name)
    COUNTS[name]=COUNTS.get(name,0)+1
def crt(a,m,c,n):
    d=gcd(m,n)
    if (c-a)%d:return None
    q=n//d
    k=((c-a)//d*pow(m//d,-1,q))%q if q>1 else 0
    return ((a+m*k)%lcm(m,n),lcm(m,n))
def scalar(a,c,n):
    d=gcd(a,n)
    if c%d:return []
    m=n//d;r=(c//d*pow(a//d,-1,m))%m if m>1 else 0
    return list(range(r,n,m))
def ring_mul(x,y,m):return ((x[0]*y[0]-x[1]*y[1])%m,(x[0]*y[1]+x[1]*y[0])%m)
def ring_pow(x,k,m):
    if k<0:
        den=pow((x[0]*x[0]+x[1]*x[1])%m,-1,m)
        return ring_pow((x[0]*den%m,-x[1]*den%m),-k,m)
    v=(1,0)
    while k:
        if k&1:v=ring_mul(v,x,m)
        x=ring_mul(x,x,m);k//=2
    return v
def lambda3(u,H):
    P=3**(H-1);c=((u[0]-1)//3,u[1]//3);v=(0,0);cj=(1,0)
    for j in range(1,2*H):
        cj=ring_mul(cj,c,P);j0=j;vp=0
        while j0%3==0:j0//=3;vp+=1
        f=(-1 if j%2==0 else 1)*3**(j-1-vp)*pow(j0,-1,P)
        v=((v[0]+f*cj[0])%P,(v[1]+f*cj[1])%P)
    return v
def coupled_recover(h,H):
    m=3**H;x=[0,0];bases=[(4,0),(1,3)]
    for k in range(H-1):
        r=h
        for base,e in zip(bases,x):r=ring_mul(r,ring_pow(base,-e,m),m)
        assert (r[0]-1)%3**(k+1)==0 and r[1]%3**(k+1)==0
        d=((r[0]-1)//3**(k+1)%3,r[1]//3**(k+1)%3)
        x=[x[j]+3**k*d[j] for j in range(2)]
    return tuple(x)
def poly_mul(a,b):
    c=0
    while b:
        if b&1:c^=a
        a<<=1;b>>=1
    return c
def poly_rem(a,m):
    while a.bit_length()>=m.bit_length():a^=m<<(a.bit_length()-m.bit_length())
    return a
def poly_pow(a,k,m):
    v=1
    while k:
        if k&1:v=poly_rem(poly_mul(v,a),m)
        a=poly_rem(poly_mul(a,a),m);k//=2
    return v

def run():
    t=time.monotonic()
    for n in range(1,41):
      for a in range(n):
       for c in range(n):check('linear_congruence',scalar(a,c,n)==[x for x in range(n) if (a*x-c)%n==0])
    for m in range(1,17):
     for n in range(1,17):
      p=lcm(m,n)
      for a in range(m):
       for c in range(n):
        out=crt(a,m,c,n);direct=[x for x in range(p) if x%m==a and x%n==c]
        check('generalized_crt',direct==([] if out is None else [out[0]]))
    g=5;p=97;N=96
    for x in range(N):
      h=pow(g,x,p);rs=[]
      for ell,e in [(2,5),(3,1)]:
        m=ell**e;gamma=pow(g,N//m,p);eta=pow(h,N//m,p);beta=pow(gamma,ell**(e-1),p);s=0
        for j in range(e):
          z=pow(eta*pow(gamma,-s,p)%p,ell**(e-1-j),p)
          ds=[d for d in range(ell) if pow(beta,d,p)==z];check('pohlig_hellman_digit',len(ds)==1)
          s+=ds[0]*ell**j
        rs.append((s,m))
      out=crt(*rs[0],*rs[1]);check('pohlig_hellman_full',out==(x,N))
      for M in range(1,21):
       for a in range(M):
        A=-29;B=67;L=-((a-A)//M);U=(B-a)//M
        b=pow(g,M,p);y=h*pow(g,-a,p)%p;R=N//gcd(N,M)
        residual=[a+M*z for z in range(L,U+1) if pow(b,z,p)==y]
        direct=[z for z in range(A,B+1) if z%M==a and pow(g,z,p)==h]
        check('arbitrary_residue_bounds',residual==direct)
        ts=[z for z in range(R) if pow(b,z,p)==y]
        if ts:
            aliases=[a+M*z for z in range(L,U+1) if (z-ts[0])%R==0]
            check('residual_alias_period',aliases==direct)
        else:check('residual_nonmembership',not direct)
    for H in [2,3,4]:
      m=3**H;P=3**(H-1);units=[(1+3*a,3*b) for a in range(P) for b in range(P)]
      logs={u:lambda3(u,H) for u in units};check('finite_log_bijection',len(set(logs.values()))==len(units))
      for u,v in product(units,repeat=2):
        w=ring_mul(u,v,m);lu,lv=logs[u],logs[v]
        check('finite_log_homomorphism',logs[w]==((lu[0]+lv[0])%P,(lu[1]+lv[1])%P))
      for x,y in product(range(P),repeat=2):
        h=ring_mul(ring_pow((4,0),x,m),ring_pow((1,3),y,m),m)
        check('coupled_digit_recovery',coupled_recover(h,H)==(x,y))
    f1=0b1011;f2=0b10011;F=poly_mul(f1,f2);e1=(1<<5)|(1<<2)|(1<<1);e2=e1^1
    check('polynomial_factorization',F==0b10101101)
    for z in range(128):
      c1,c2=poly_rem(z,f1),poly_rem(z,f2)
      recomb=poly_rem(poly_mul(e1,c1)^poly_mul(e2,c2),F)
      check('polynomial_crt',recomb==z)
      E=poly_rem(poly_mul(e1,poly_pow(z,3,F))^poly_mul(e2,poly_pow(z,7,F)),F)
      D=poly_rem(poly_mul(e1,poly_pow(E,5,F))^poly_mul(e2,poly_pow(E,13,F)),F)
      check('component_permutation_inverse',D==z)
    for q in [3,5,7]:
      H=(q-1)//2
      for t1,t2,a1,a2 in product(range(q),repeat=4):
       for B in range(0,min(2,H+1)):
        direct=[x for x in range(q) if all(abs((t*x-a+H)%q-H)<=B for t,a in [(t1,a1),(t2,a2)])]
        # Enumerate every point of target box before checking lattice membership.
        lattice=[]
        for beta,y1,y2 in product(range(-H,H+1),range(a1-B,a1+B+1),range(a2-B,a2+B+1)):
          if (y1-t1*beta)%q==0 and (y2-t2*beta)%q==0:lattice.append(beta%q)
        check('hnp_box_bijection',sorted(lattice)==direct and len(lattice)==len(set(lattice)))
    B0=[[10201,0,0],[0,10201,0],[101,1010,1]]
    U=[[-1,-10,101],[0,0,1],[0,-1,10]];R=[[0,0,101],[101,1010,1],[1010,-101,10]]
    mm=lambda A,B:[[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
    check('hnp_reduced_basis_transform',mm(U,B0)==R)
    coeff=[0,7,3];v=[sum(coeff[i]*R[i][j] for i in range(3)) for j in range(3)]
    check('hnp_worked_vector',v==[3737,6767,37])
    check('hnp_coefficient_decode',mm([coeff],U)==[[0,-3,37]])
    # Independent rational Gram-Schmidt and actual nearest-plane procedure.
    dot=lambda a,b:sum(x*y for x,y in zip(a,b))
    star=[];norm=[]
    for row in R:
        vstar=list(map(Fraction,row))
        for prev,D in zip(star,norm):
            mu=dot(row,prev)/D
            vstar=[a-mu*b for a,b in zip(vstar,prev)]
        star.append(vstar);norm.append(dot(vstar,vstar))
    residual=list(map(Fraction,[3838,6666,0]));decoded=[0]*3
    for j in range(2,-1,-1):
        h=dot(residual,star[j])/norm[j]+Fraction(1,2)
        c=h.numerator//h.denominator;decoded[j]=c
        residual=[a-c*b for a,b in zip(residual,R[j])]
    check('hnp_actual_nearest_plane',decoded==[0,7,3])
    # Exact branch endpoints versus direct squared rational comparisons.
    for P,Q,C,E in product(range(-8,9),range(1,6),range(31),range(1,6)):
        J=isqrt((C*Q*Q)//E);lo=-((J-P)//Q);hi=(P+J)//Q
        pred=list(range(lo,hi+1));direct=[z for z in range(-20,21) if Fraction((Q*z-P)**2,Q*Q)<=Fraction(C,E)]
        check('exact_lattice_branch_endpoints',pred==direct)
    for k in range(1,8):
        modulus=3**k;visited=set();cycles=[]
        for x in range(modulus):
            if x in visited:continue
            cycle=[];z=x
            while z not in visited:
                visited.add(z);cycle.append(z);z=2*z%modulus
            check('doubling_cycle_closure',z==x);cycles.append(cycle)
        check('doubling_complete_stratification',sorted(map(len,cycles))==[1]+[2*3**r for r in range(k)])
        for u in range(1,modulus):
            if u%3==0:continue
            n=0 if u%3==1 else 1
            for r in range(1,k):
                modnext=3**(r+1);q0=u*pow(pow(2,n,modnext),-1,modnext)%modnext
                digit=(q0-1)//3**r;n+=digit*(2*3**(r-1))
            check('doubling_exponent_inverse',pow(2,n,modulus)==u and 0<=n<2*3**(k-1))
    elems=list(product(range(7),range(3)))
    op=lambda x,y:((x[0]+pow(2,x[1],7)*y[0])%7,(x[1]+y[1])%3)
    def gp(x,n):
        y=(0,0)
        for _ in range(n):y=op(y,x)
        return y
    for x,y,z in product(elems,repeat=3):check('order21_associativity',op(op(x,y),z)==op(x,op(y,z)))
    for x in elems:
        check('order21_inverse_squaring',gp(gp(x,2),11)==x)
        order=next(n for n in range(1,22) if gp(x,n)==(0,0))
        check('order21_element_orders',order in [1,3,7])
    # Explicit failures of unrestricted statements.
    check('binary_layer_counterexample',pow(3,2,8)==1 and (1+4)%8==5)
    check('power_cycle_counterexample',next(k for k in range(1,7) if pow(3,k,7)==1)==6 and 105%6!=0)
    check('cyclotomic_zero_divisor_counterexample',(4*4-1)%15==0 and (4-1)%15!=0 and (4+1)%15!=0)
    check('worked_ring_target',ring_mul(ring_pow((4,0),5,81),ring_pow((1,3),7,81),81)==(25,66))
    check('rational_reconstruction',3==41*5%101 and 2*3*5<101)
    sources={}
    paths=[ROOT.parent/'project_sources'/fn for fn in ['01-Math_Work_Exact_Operational_Formalization_ASCII.txt','03-Cryptogram_Operational_Formalization_ASCII.txt']]
    paths += [ROOT/'supplemental'/'Modular Math Lab'/fn for fn in ['Mathcrack.txt','Mathcrack 2.txt','Mathcrack 3.txt','Hidden_Number_Lattice_Reconstruction_ASCII.txt']]
    paths += [ROOT/'supplemental'/'doubling_vortex_mathematics_extracted.txt']
    for path in paths:
      data=path.read_bytes();sources[str(path.relative_to(ROOT.parent))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    output={'base':'SM-2026-10-13-A','verdict':'all stated finite assertions passed','python':sys.version,'platform':platform.platform(),'command':'python3 stefans_math/checks/A_verify.py','runtime_seconds':round(time.monotonic()-t,6),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_files':sources,'counts':COUNTS,'total_assertions':sum(COUNTS.values()),'non_claims':['Finite ranges do not prove universal theorems.','No cryptographic challenge or timing claim is reproduced.','No random-sampling checks are used.']}
    out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'checks'/'A_results.json';out.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
if __name__=='__main__':run()
