/* Finite checks of the actual local Fourier Six core, without browser UI. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const base=path.resolve(__dirname,'..');
const sourcePath=path.join(base,'supplemental','fourier_six_lab.html');
const source=fs.readFileSync(sourcePath,'utf8');
const core=source.match(/<script>\s*\/\* Fourier Six[\s\S]*?<\/script>/)[0].replace(/^<script>/,'').replace(/<\/script>$/,'');
const context={module:{exports:{}},TextEncoder,TextDecoder,Uint8Array,Float64Array,ArrayBuffer,DataView,Math,Number,Object,Array,Error};
vm.runInNewContext(core,context,{filename:'FourierSixCore',timeout:10000});
const api=context.module.exports;
function assert(condition,msg){if(!condition)throw Error(msg);}
let constellationCases=0,maxProjectionError=0;
for(const b of [2,4,6,8])for(let j=0;j<6;j++)for(let n=0;n<(1<<b);n++){
 const bits=api.numberBits(n,b),point=api.qamMap(bits,b),round=api.qamSlice(point,b);
 assert(Array.from(bits).join('')===Array.from(round).join(''),'QAM round trip');
 const c=api.config({noise:false}),coeff=Array.from({length:6},()=>({re:0,im:0}));coeff[j]=point;
 const samples=api.synth(coeff,c),recover=api.project(samples,0,c);
 for(let k=0;k<6;k++)maxProjectionError=Math.max(maxProjectionError,Math.hypot(coeff[k].re-recover[k].re,coeff[k].im-recover[k].im));
 constellationCases++;
}
assert(maxProjectionError<1e-10,'Fourier projection tolerance');
const bits=Uint8Array.from({length:4096},(_,n)=>(Math.imul(n,1103515245)>>>10)&1);
const results=[];
for(const size of [8,512,513,4096]){
 const input=bits.slice(0,size),r=api.run(input,{noise:false,echo:0,rail:100},2);
 assert(r.rx.complete&&Array.from(input).join('')===Array.from(r.rx.accepted).join(''),'clean packet');
 results.push({name:'clean_'+size,bits:size,accepted:r.rx.accepted.length,complete:r.rx.complete});
}
for(const c of [{echo:.8,delay:18,cp:24},{echo:.8,delay:40,cp:48}]){
 const input=bits.slice(0,512),r=api.run(input,{noise:false,rail:100,...c},2);
 assert(r.rx.complete&&Array.from(input).join('')===Array.from(r.rx.accepted).join(''),'echo compensated packet');
 results.push({name:'echo',...c,accepted:r.rx.accepted.length,complete:r.rx.complete});
}
const gram=api.gram({},false),gramCollision=api.gram({},true);
let gramError=0;for(let j=0;j<12;j++)for(let k=0;k<12;k++)gramError=Math.max(gramError,Math.abs(gram[j][k]-(j===k?1:0)));
assert(gramError<1e-10,'Gram identity');
for(let j=0;j<12;j++)for(let k=0;k<12;k++)assert(Math.abs(gramCollision[j][k]-(j%2===k%2?1:0))<1e-10,'collision repeated columns');
const output={base:'SM-2026-10-13-A',node:process.version,command:'node stefans_math/checks/D_modem_check.js',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),script_sha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),arithmetic:'IEEE binary64; tolerance 1e-10',constellationCases,maxProjectionError,gramError,packetCases:results,browser_ui_executed:false,non_claims:['No physical modem certification or capacity theorem.','No error-free guarantee for arbitrary noisy channels.']};
fs.writeFileSync(path.join(__dirname,'D_modem_results.json'),JSON.stringify(output,null,2)+'\n');
process.stdout.write(JSON.stringify({constellationCases,maxProjectionError,gramError,packet_cases:results.length,outcome:'pass'})+'\n');
