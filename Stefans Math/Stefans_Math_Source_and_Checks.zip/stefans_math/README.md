# Stefans Math - corrected collected reference

Edition 1, 13 October 2026. Project ideas and collected work: Stefan. Mathematical compilation, editing, audit and typesetting: AI-assisted.

The final reference has 98 PDF pages, 23 chapters and approximately 56,000 manuscript words. It consolidates twelve supplied reports and recovered related project records. It contains standardized terminology, proofs with hypotheses, worked examples, answered exercises, a glossary, a consequential correction register and explicit coverage/evidence boundaries.

## Reading

- stefans_math/output/Stefans_Math.pdf is the typeset book with contents and PDF outline.
- stefans_math/output/Stefans_Math_ASCII.txt contains the same manuscript mathematics in plain ASCII.
- stefans_math/output/Stefans_Math_Editable.md is the assembled editable text.
- stefans_math/chapters contains the authoritative individual corrected chapter sources.
- stefans_math/audits contains source-level family audits and fresh cross-reviews.
- project_sources contains unchanged supplied reports.
- stefans_math/supplemental contains recovered historical records, including duplicate versions as returned.
- stefans_math/source_inventory.json records source bytes and duplicate hashes.
- stefans_math/final_review_record.json pins final manuscript hashes and review coverage.
- stefans_math/checks contains executable checks and finite evidence records.

The book's scope is the inspected/recovered corpus. An inaccessible original is not treated as inspected. Standard mathematics retains attribution. FINITE and APPROXIMATE outputs are not universal proofs. OPEN and CONDITIONAL statements remain visibly scoped. The archive preserves original inputs alongside the corrected synthesis.

## Rebuild the book

Run commands from the extracted archive root. Python3 with reportlab and pypdf is required for PDF building:

```text
python3 -m pip install -r stefans_math/requirements.txt
python3 stefans_math/build_book.py
```

The script regenerates PDF, ASCII, editable Markdown and book_build.json. The build contains the cover and contents; the original chapters remain plain ASCII Markdown. Different dependency versions can change page breaks without changing the manuscript.

## Reproduce mathematical checks

The mathematical Python scripts use the standard library, exact integers and fractions, with explicit floating-point checks in family D. Recovered program segments run only in the specific bounded comparison harnesses described in their audits.

```text
python3 stefans_math/checks/A_verify.py
python3 stefans_math/checks/B_verify.py
python3 stefans_math/checks/C_solver_checks.py
python3 stefans_math/checks/D_verify.py
python3 stefans_math/checks/E_verify.py
python3 stefans_math/checks/F_verify.py
python3 stefans_math/checks/GZ_verify.py
```

The original Fourier Six core is checked separately with Node.js:

```text
node stefans_math/checks/D_modem_check.js
```

A D execution wrapper preserves commands, source/output hashes and its exact/numerical distinction:

```text
python3 stefans_math/checks/D_run.py
```

A and B have additional recorded-run and fresh peer-check scripts. Review the matching audit before running a historical harness. The stored manifests identify actual original execution commands and bounds; an original host-specific Python path in a historical manifest need not exist on another computer. The portable commands above use the local Python3/Node environment.

Manifest validation is optional record verification:

```text
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/A_run/manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/B_computation_manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/C_solver_manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/D_execution_manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/E_manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/F_manifest.json --root .
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/GZ_manifest.json --root .
```

Some check scripts regenerate output files. Stored manifests describe the recorded original outputs, so after a new execution timestamps or hashes can change. Regenerate the corresponding manifest through its recording script, or retain a new result separately; a stale-record failure is not a mathematical failure. Version-1 manifests explicitly retain their older provenance limitations. Record validation never substitutes for mathematical interpretation.

## Continuing the work

A new adapter should declare its original domain, observations, retained fiber information, admissibility guards, verifier, and completeness/termination contract. A revised theorem should update its local proof and dependent claims. A new finite test should state its precise family and bounds. The chapter structure, notation dictionary and audit records make these changes traceable.
