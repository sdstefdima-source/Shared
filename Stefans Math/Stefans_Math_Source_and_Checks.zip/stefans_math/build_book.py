#!/usr/bin/env python3
from pathlib import Path
import re,html,textwrap,json,hashlib
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import BaseDocTemplate,PageTemplate,Frame,Paragraph,Spacer,PageBreak,Preformatted,Table,TableStyle,KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
PAGE=A4;W,H=PAGE
MARGIN=39
BODY_SIZE=11.3
LEADING=13.8
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodySM',fontName='Times-Roman',fontSize=BODY_SIZE,leading=LEADING,spaceAfter=5.0,splitLongWords=True,allowWidows=0,allowOrphans=0))
styles.add(ParagraphStyle(name='ChapterSM',fontName='Helvetica-Bold',fontSize=18,leading=21,spaceAfter=14,keepWithNext=True,textColor=colors.HexColor('#143743')))
styles.add(ParagraphStyle(name='TOCTitleSM',parent=styles['ChapterSM']))
styles.add(ParagraphStyle(name='SectionSM',fontName='Helvetica-Bold',fontSize=11.3,leading=13.3,spaceBefore=10,spaceAfter=5,keepWithNext=True,textColor=colors.HexColor('#143743')))
styles.add(ParagraphStyle(name='SubSM',fontName='Helvetica-Bold',fontSize=10.2,leading=12.2,spaceBefore=7,spaceAfter=4,keepWithNext=True))
styles.add(ParagraphStyle(name='CellSM',fontName='Times-Roman',fontSize=8.8,leading=10.2,spaceAfter=0,splitLongWords=True))
styles.add(ParagraphStyle(name='TOCSM',fontName='Times-Roman',fontSize=10.5,leading=13.7,leftIndent=0,firstLineIndent=0,spaceBefore=2,spaceAfter=2))
styles.add(ParagraphStyle(name='CodeSM',fontName='Courier',fontSize=8.1,leading=9.6,spaceBefore=4,spaceAfter=6,backColor=colors.HexColor('#F0F3F3'),borderPadding=6))
styles.add(ParagraphStyle(name='BodyCSM',parent=styles['BodySM'],leading=13.5,spaceAfter=3.8))
styles.add(ParagraphStyle(name='GlossarySM',parent=styles['BodySM'],fontSize=11.1,leading=13.6,spaceAfter=3.0))
styles.add(ParagraphStyle(name='SmallSM',fontName='Times-Roman',fontSize=9.2,leading=11.2))

class BookDoc(BaseDocTemplate):
 def __init__(self,filename,**kw):
  super().__init__(filename,**kw)
  frame=Frame(MARGIN,43,W-2*MARGIN,H-86,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
  self.addPageTemplates([PageTemplate(id='all',frames=[frame],onPage=self.page_art)])
  self.bookmarks=[]
 def page_art(self,c,doc):
  if doc.page==1:return
  c.saveState();c.setStrokeColor(colors.HexColor('#CAD4D6'));c.setLineWidth(.4)
  c.line(MARGIN,H-29,W-MARGIN,H-29)
  c.setFont('Helvetica',7.2);c.setFillColor(colors.HexColor('#46606A'))
  c.drawString(MARGIN,H-23,'STEFANS MATH')
  c.drawRightString(W-MARGIN,H-23,'Corrected collected reference | Edition 1')
  c.line(MARGIN,32,W-MARGIN,32)
  c.drawString(MARGIN,22,'13 October 2026 | Proofs, examples and explicit research boundaries')
  c.drawRightString(W-MARGIN,22,str(doc.page))
  c.restoreState()
 def afterFlowable(self,f):
  if isinstance(f,Paragraph) and f.style.name in ('ChapterSM','SectionSM'):
   label=f.getPlainText();key='h'+hashlib.sha1(label.encode()).hexdigest()[:18]
   self.canv.bookmarkPage(key)
   level=0 if f.style.name=='ChapterSM' else 1
   self.canv.addOutlineEntry(label,key,level=level,closed=True)
   if level==0:self.notify('TOCEntry',(0,label,self.page,key))

def inline(t):
 t=html.escape(t)
 t=re.sub(r'`([^`]+)`',lambda m:'<font name="Courier" size="9">'+m.group(1)+'</font>',t)
 t=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',t)
 # Remove source Markdown links as explicit, readable title and URL.
 t=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1 (\2)',t)
 return t

def ptext(t,style='BodySM',**kw):return Paragraph(inline(t),styles[style],**kw)

def markdown(t,chapter_counter,glossary=False,compact=False):
 lines=t.splitlines();out=[];i=0
 while i<len(lines):
  line=lines[i].rstrip()
  if not line.strip():i+=1;continue
  if line.startswith('```'):
   code=[];i+=1
   while i<len(lines) and not lines[i].startswith('```'):
    for part in textwrap.wrap(lines[i],width=102,replace_whitespace=False,drop_whitespace=False,subsequent_indent='    ') or ['']:code.append(part)
    i+=1
   i+=1
   block=Preformatted('\n'.join(code),styles['CodeSM'],maxLineLength=106)
   if len(code)<15:out.append(KeepTogether([block]))
   else:out.append(block)
   continue
  if line.startswith('# '):
   chapter_counter[0]+=1
   if out or chapter_counter[0]>1:out.append(PageBreak())
   title=re.sub(r'^[CEF][123]\.\s*','',line[2:])
   label=f'{chapter_counter[0]}. {title}'
   out.append(ptext(label,'ChapterSM'));i+=1;continue
  if line.startswith('## '):out.append(ptext(line[3:],'SectionSM'));i+=1;continue
  if line.startswith('### '):out.append(ptext(line[4:],'SubSM'));i+=1;continue
  if line.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    cells=[x.strip() for x in lines[i].strip('|').split('|')]
    if not all(re.fullmatch(r':?-+:?',c or '-') for c in cells):rows.append(cells)
    i+=1
   if not rows:continue
   nc=max(map(len,rows));widths=[(W-2*MARGIN)/nc]*nc
   data=[[ptext(c,'CellSM') for c in row+['']*(nc-len(row))] for row in rows]
   tab=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
   tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E4ECEE')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#BAC9CE')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
   out += [tab,Spacer(1,6)];continue
  if re.match(r'^\s*[-*] ',line):
   out.append(ptext(line.lstrip()[2:],bulletText='-'));i+=1;continue
  para=[line];i+=1
  while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','```','|')) and not re.match(r'^\s*[-*] ',lines[i]):
   para.append(lines[i].strip());i+=1
  text_value=' '.join(para)
  style='GlossarySM' if glossary else ('SmallSM' if re.match(r'^\[?[A-Z]-[RS]\d',text_value) else ('BodyCSM' if compact else 'BodySM'))
  out.append(ptext(text_value,style))
 return out

files=sorted((ROOT/'chapters').glob('*.md'),key=lambda p:(p.name.startswith('ZZ'),p.name))
if len(files)<10:raise RuntimeError('Missing manuscript families')
content='\n\n'.join(p.read_text().strip() for p in files)+'\n'
if not content.isascii():raise RuntimeError('Manuscript contains non-ASCII characters')
front='STEFANS MATH\nCoordinates, Constraints and Reconstruction\nCorrected collected reference - Edition 1 - 13 October 2026\nProject ideas and collected work: Stefan\nMathematical compilation, editing and checking: AI-assisted\n\n'
(OUT/'Stefans_Math_ASCII.txt').write_text(front+content)
(OUT/'Stefans_Math_Editable.md').write_text('# Stefans Math\n\n'+front+content)
story=[]
story.append(Spacer(1,100))
story.append(Paragraph('STEFANS<br/>MATH',ParagraphStyle('Cover',fontName='Helvetica-Bold',fontSize=48,leading=51,textColor=colors.HexColor('#143743'))))
story.append(Spacer(1,23))
story.append(Paragraph('Coordinates, Constraints<br/>and Reconstruction',ParagraphStyle('Subtitle',fontName='Times-Roman',fontSize=22,leading=26,textColor=colors.HexColor('#294D59'))))
story.append(Spacer(1,43))
story.append(ptext('A corrected collection of mathematical ideas, proofs, worked examples, and reusable operational methods.','SmallSM'))
story.append(Spacer(1,35))
story.append(Paragraph('Project ideas and collected work: Stefan<br/>Mathematical compilation, editing and checking: AI-assisted',styles['SmallSM']))
story.append(Spacer(1,20))
story.append(ptext('Edition 1 | 13 October 2026','SmallSM'))
story.append(PageBreak())
story.append(ptext('Contents','TOCTitleSM'))
toc=TableOfContents();toc.levelStyles=[styles['TOCSM']];story.append(toc)
story.append(PageBreak())
cc=[0]
for p in files:story.extend(markdown(p.read_text(),cc,glossary=p.name=='ZZ_glossary.md',compact=p.name=='C_certified_solvers.md'))
pdf=OUT/'Stefans_Math.pdf'
doc=BookDoc(str(pdf),pagesize=PAGE,title='Stefans Math',author='Stefan; AI-assisted compilation',subject='Unified corrected mathematical reference',pageCompression=1)
doc.multiBuild(story)
reader=PdfReader(pdf)
info={'pages':len(reader.pages),'manuscript_words':len(content.split()),'chapters':cc[0],'files':[p.name for p in files],'pdf_bytes':pdf.stat().st_size,'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'ascii_sha256':hashlib.sha256((OUT/'Stefans_Math_ASCII.txt').read_bytes()).hexdigest()}
(OUT/'book_build.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps(info,indent=2))
