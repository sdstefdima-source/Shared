# Fourier Six — Test Report

Recorded 2026-09-17. These are computational and browser tests, not measurements from physical cable hardware.

## Results at a glance

- **25 / 25 core test groups passed**, using v22.16.0.
- **340 / 340 constellation points** passed exhaustive modulation/demodulation checks across 4-, 16-, 64- and 256-QAM.
- **16 / 16 browser interaction checks passed** in Chromium with networking disabled.
- An **independent NumPy FFT / nearest-neighbor QAM / zlib CRC decoder** recovered all 1,024 source bits in its two-packet one-echo test vector.

## Measured numerical checks

| Check | Result |
|---|---:|
| Real basis rank, six distinct tones | 12 |
| Real basis rank, all tones at one frequency | 2 |
| Maximum normalized Gram-matrix error (NumPy) | 6.661e-16 |
| NumPy FFT versus transmitted coefficients | 9.695e-16 V |
| NumPy IFFT versus directly synthesized waveform | 6.439e-15 V |
| IFFT imaginary residue | 2.478e-16 V |
| Maximum Parseval mean-square identity error | 1.110e-15 V² |
| Estimated versus analytic one-echo complex gain | 1.790e-15 |

## Long-stream recovery

The clean 65,536-bit baseline recovered **every bit** across 128 packets. Its waveform contained 774,144 real voltage samples, representing 16.128 seconds at 48 ksample/s. This uses the baseline 16-QAM channel settings, a 24-sample prefix, two training symbols per packet and 512 source-payload bits per packet.

Clean 8,192-bit trials separately succeeded for all four supported QAM orders. Mixed [2,4,6,8,6,4]-bit loading with unequal [1,2,4,8,4,2] power weights also recovered exactly. UTF-8 and non-byte-aligned literal-bit payloads passed.

## Deliberate failure and repair trials

The table below uses the deterministic 8,192-bit test source, not the shorter browser default message. Error counts include the header, allocated payload and CRC, but exclude final OFDM symbol padding.

| Trial | Observed result |
|---|---|
| Echo amplitude 0.7, delay 18, prefix 24 | 0 bit errors |
| Echo amplitude 0.8, delay 40, prefix 24 | 599 bit errors |
| Same echo with prefix extended to 48 | 0 bit errors |
| Reference AWGN SNR 8 dB | 1,246 errors / 9,728 framed bits; 0/16 packets accepted |
| Reference AWGN SNR 32 dB | 0 bit errors |
| 4-bit ADC, ±8 V, six 256-QAM channels | 916 bit errors; 0/16 packets accepted |
| 4-bit ADC, ±4 V, six 16-QAM channels | 0 bit errors |
| Saturation at ±0.75 V | 44,924 clipped samples; 538 bit errors |
| C6 detuned by 75 Hz | 30 bit errors |
| Six tones forced to one frequency | 4,815 bit errors; 0/16 packets accepted |

The low-resolution 16-QAM success is intentional. Coefficients are estimated from a full block of samples; sample precision and coefficient information are not interchangeable quantities. The higher-density 256-QAM case makes the precision failure visible.

A noise-normalization test measured complex coefficient-noise variance 0.0016479328 against the theoretical 0.0016666667, a ratio of 0.98876 over 4,000 independent useful windows. This checks that the simulator does not accidentally manufacture a signal-to-noise improvement by confusing in-band noise and full-Nyquist sample noise.

## Browser verification

The app was exercised at 1,440-pixel desktop width and 390-pixel mobile width. Both had no horizontal document overflow. The tests checked all six presets, the echo repair control, bandwidth/rate scaling, a 4,096-bit source, single-symbol stepping and the real mono PCM WAV export.

For the receiver-only test, the browser exported 48,384 real samples plus public settings, changed the transmitter message, then imported the old samples. The old 4,096-bit stream still decoded exactly. The exported JSON contained no source bits or TX coefficients.

No uncaught browser JavaScript errors were observed. Browser tests used an offline inline-document load because the container's administration policy blocked direct file:// navigation. The mobile test was a Chromium viewport/touch emulation, not a physical phone. Audio playback was not part of the automated pass count; WAV structure was verified separately.

## Scope

These checks establish internal numerical consistency, exact clean recovery for the tested inputs, agreement with an independent implementation and working tested UI paths. They do not certify unknown-channel timing recovery, real cable bandwidth, analog spectral masks, arbitrary noise statistics, production-grade reliability or operation on every browser.

The app assumes packet/symbol timing and modulation settings are known. It has no implemented autonomous synchronization, error-correcting code or retransmission. Its nominal active-bandwidth display is six-bin accounting, not a strict measured occupied bandwidth. CRC is error detection, not authentication.

## Reproduce

```
python build.py
node test_modem.js
python verify_independent.py
python test_browser.py
```

The complete core tests appear below. Machine-readable detail is in `test_results.json`, `independent_results.json` and `browser_results.json`.

1. PASS — CRC-32/ISO-HDLC known check value
2. PASS — Exhaustive QAM round trips and normalized average energy
3. PASS — Whitening is exactly reversible for a non-byte-aligned bit stream
4. PASS — Twelve real basis functions are orthonormal
5. PASS — Direct synthesis and projection preserve arbitrary complex coefficients
6. PASS — All four QAM orders recover 8,192 bits without impairments
7. PASS — Mixed bit loading and unequal positive power scales are invertible
8. PASS — UTF-8 text and partial final packet are reconstructed from waveform
9. PASS — One-bit and odd-length payloads retain exact bit length
10. PASS — Receiver decodes serialized real samples with no original bits or coefficients
11. PASS — Sample-noise normalization gives the configured per-tone SNR
12. PASS — Adequate prefix and training equalization undo a one-echo cable
13. PASS — Too-short prefix breaks recovery; extending it repairs the same echo
14. PASS — Low-SNR run generates errors and CRC rejections
15. PASS — High-SNR baseline succeeds with actual noisy samples
16. PASS — Four-bit ADC damages a dense 256-QAM constellation
17. PASS — Four-bit ADC samples can still recover baseline 16-QAM over a full block
18. PASS — Clipping is counted and introduces frame errors
19. PASS — Channel-6 detuning causes leakage and errors
20. PASS — Single-frequency collision cannot be decoded as six orthogonal channels
21. PASS — Bandwidth, symbol time and raw rate scale consistently
22. PASS — Baseline full-packet rate includes every overhead term
23. PASS — Seeded noisy waveform is reproducible
24. PASS — Full visual-lab limit: 65,536 source bits recover exactly
25. PASS — Malformed payloads and incomplete sample frames are rejected
