# Fourier Six — Epicycle Packet Laboratory

A dependency-free browser experiment that sends a bit stream as six changing complex Fourier coefficients, synthesizes one real voltage waveform, and recovers the packets from that waveform. Created 2026-09-17.

## Start

Open `fourier_six_lab.html` in a JavaScript-capable browser. No installation, internet connection, account, server, external library, microphone access or font download is required by the application. A file preview that displays source code instead of running it is not a browser execution environment; the HTML file must be opened as a webpage.

The clean preset starts with an encoded text message. The complete transmission is calculated immediately. The animation is a slow-motion inspection of those actual computed symbols, not the wall-clock data rate. Pause, step, scrub and visual-speed controls are independent of the physical sample rate.

The current visual version accepts at most 65,536 source bits, or 8 KiB. That is an implementation memory guard, not an information-theoretic limit. More source bits require more packets and more transmission time.

## Six useful experiments

**Clean proof.** Start with six 16-QAM channels. Inspect the epicycles, their horizontal projection, the transmitted voltage, the received coefficients, and the recovered text. Select “4,096 random bits” to test a bit stream rather than text. Every accepted packet must pass its decoded header and CRC checks.

**Scaled bit loading.** This preset assigns 2, 4, 6, 8, 6 and 4 bits to the six channels, with relative power weights 1, 2, 4, 8, 4 and 2. The total is 30 coded bits per data symbol. Gaussian noise is enabled at a reference in-band SNR of 32 dB. Changing a weight reallocates a fixed expected power budget; it does not grant unlimited amplitude.

**Noise floor.** At 8 dB reference SNR, the received constellation clouds overlap the wrong decisions. The packet inspector reports actual bit errors and rejected packets. CRC-approved payloads alone enter the output; missing frames are not silently replaced using the source message.

**Echo trouble and repair.** The preset introduces an echo of amplitude 0.8 after 40 samples, while the prefix contains only 24 samples. Change the prefix to 48 samples with the equalizer enabled. The same noiseless one-echo model then becomes recoverable. The extra protection reduces the useful payload rate because it consumes transmission time.

**Crushed precision.** Six 256-QAM channels are received by a 4-bit ADC with ±8 V rails. This deliberately combines dense constellations and coarse voltage precision. A useful contrast is 16-QAM with a 4-bit ADC and ±4 V rails: the supplied repeatable test still recovers correctly. A coefficient is estimated from the full sample block, so ADC bits per sample are not identical to bits per coefficient.

**Frequency collision.** All six transmitted tones are forced to the same frequency. The receiver still expects its original six distinct frequencies. The transmit signal now spans only two real linear dimensions. Five nominal channels did not become magically recoverable merely because their amplitude scales differ. This switch overrides channel-6 detuning to keep the collision exactly single-frequency.

## The construction

A coefficient is a complex number `c = I + iQ`. Its magnitude is an epicycle's radius; its argument is the initial angle. During a useful symbol, the six circles rotate at six distinct integer-related frequencies. At the next symbol, new bits choose new coefficients.

This is an OFDM-style real-valued multitone modem, not a claim of a new modulation principle. The distinctive part of the experiment is exposing the coefficient geometry, physical projection, packet accounting, power scales and failure modes in one visual instrument.

### Signal convention

```
N = 192 useful samples
k = [4, 5, 6, 7, 8, 9]
Fs = N * delta_f
Tu = 1 / delta_f
w[j] = raw_weight[j] / sum(raw_weight)
c[j] = Vref * sqrt(w[j]) * a[j]

z[n] = sum_j c[j] * exp(i*2*pi*k[j]*n/N)
x[n] = sqrt(2) * real(z[n])
     = sqrt(2) * sum_j (I[j]*cos(...) - Q[j]*sin(...))
```

Here `x` and `c` are measured in volts, `a` is dimensionless, and `Vref = 1 V`. Each square-QAM alphabet has unit mean squared magnitude under uniformly distributed symbols. Therefore the expected useful-symbol mean-square voltage is `Vref^2`. Individual symbols and finite messages need not have exactly that average. The display reports actual waveform RMS and peak separately.

One voltage stream is sufficient because the information lives in its evolution over a block, not in one instantaneous voltage sample. The twelve basis functions are the sine and cosine functions for the six frequencies. Their normalized discrete Gram matrix is the 12-by-12 identity in the ideal case.

The clean receiver computes:

```
c_hat[j] = sqrt(2)/N * sum_n x[n] * exp(-i*2*pi*k[j]*n/N)
```

The factor `sqrt(2)` is part of the chosen voltage normalization. With a conventional inverse DFT containing `1/N`, the equivalent nonzero spectrum entries are:

```
X[k[j]]   = N/sqrt(2) * c[j]
X[N-k[j]] = conjugate(X[k[j]])
```

The negative-frequency entries are determined mirrors, not six additional independently writable channels. DC, Nyquist and all other unused bins are zero. Direct synthesis evaluates only the occupied tones; an independent NumPy IFFT check verifies the same real waveform.

### QAM and coefficient scaling

The available square constellations contain 4, 16, 64 or 256 points, carrying 2, 4, 6 or 8 bits per complex coefficient. Both axes use Gray labels. The normalization is `sqrt(2*(M-1)/3)` for raw odd-integer amplitude levels.

For a power share `w[j]`, the minimum separation of adjacent coefficient points is:

```
dmin[j] = Vref * sqrt(w[j]) * sqrt(6/(M[j]-1))   [volts]
```

More points at fixed power means less separation. More power for one channel leaves less for the others. A larger alphabet changes distinguishability requirements, not the number of orthogonal dimensions.

The six default coefficients jointly select one of `16^6 = 2^24` distinct clean data-symbol waveforms. This is 24 bits per symbol, not 24 bits per voltage sample. Successive packets extend the stream through time.

### Why pure scale stacking is different

Six arbitrary coefficients on the same basis function collapse into a summed coefficient. The corresponding linear map has rank two over the real numbers, not twelve. Their individual arbitrary values cannot be uniquely recovered from that sum.

A carefully designed *finite* superposition alphabet could assign bits to distinct amplitude levels on a single carrier. That is a valid alternative coding design, but the combined constellation would become denser or require a larger amplitude range. It is not six independent Fourier channels and does not evade a precision, power or noise budget.

If each logical channel later contains several independent epicycles, each of those additional independent Fourier coefficients must be counted. Six groups containing `n[j]` tones would use `sum(n[j])` complex coefficients, not merely six.

## Timing and dimensional ledger

At the default settings:

| Quantity | Value |
|---|---:|
| Tone spacing | 250 Hz |
| Tone centers | 1,000; 1,250; 1,500; 1,750; 2,000; 2,250 Hz |
| Sample rate | 48,000 real samples/s |
| Useful block | 192 samples = 4 ms |
| Cyclic prefix | 24 samples = 0.5 ms |
| Total symbol duration | 4.5 ms |
| Data bits per six-tone symbol | 24 |
| Gross data-symbol rate | 5,333.33 bit/s |
| Nominal active allocation | 6 × 250 = 1,500 Hz |
| Full source payload per packet | 512 bits |
| Header + CRC | 64 + 32 = 96 bits |
| Total framed bits | 608 |
| Data symbols per packet | ceil(608/24) = 26 |
| Known training symbols per packet | 2 |
| Total packet duration | 28 × 4.5 ms = 126 ms |
| Full-packet net payload rate | 4,063.49 bit/s |

The 26 data symbols provide 624 slots, so 16 final OFDM padding bits are discarded. A final partly filled payload packet still consumes the full fixed allocation. This explains why a short message's offered payload rate can be below the full-packet value.

For an arbitrary enabled constellation combination:

```
K = sum_j log2(M[j])                              [bits/data symbol]
Ts = (N + Ncp)/Fs                                 [s/symbol]
Rgross = K/Ts                                     [bit/s]
Npacket = 2 + ceil((64 + P + 32)/K)                 [symbols]
Rpayload,full = P/(Npacket*Ts)                     [payload bit/s]
```

The 65,536-bit clean baseline test uses 128 packets, 774,144 real samples and 16.128 seconds of encoded cable time. The calculation itself is not required to execute at that physical rate.

## Bandwidth caveat — important

`Bnominal = 6*delta_f` is six-bin accounting. It is not an exact measured occupied bandwidth, not the whole span from DC to the highest tone, and not a guarantee of no energy outside the allocation. The spectrum display shows ideal useful-window basis sinc magnitudes and receiver DFT estimates. It is not a continuous-stream emission-mask analyzer.

Rectangularly bounded symbols and packet transitions have sidelobes. A hardware link needs an agreed spectral mask, guard space, transmit/reconstruction filters and receiver filtering. There is no analog anti-alias or reconstruction-filter model in this version.

Increasing tone spacing with fixed `N` and prefix ratio scales bandwidth, sample rate and data rate together. Merely oversampling an unchanged waveform would not create new independent coordinates.

The familiar ideal flat-band Gaussian-noise benchmark is `B*log2(1+S/N)`. The GUI deliberately labels it a reference, not the exact capacity of the generated sidelobed waveform or a guarantee of reliable uncoded QAM. It is omitted when Gaussian noise is disabled. Clipping, converter quantization, echo and a finite alphabet remain separate constraints.

## Link and receiver model

The channel applies a causal one-echo filter to the complete transmitted stream:

```
r[n] = x[n] + g*x[n-d] + noise[n]
```

Past samples before the start are zero. The model then clips to the configured receiver rails and optionally quantizes to the ADC's finite levels. Saturation is active even in floating-point mode.

The noise parameter is a reference in-band SNR `rho` based on expected useful transmit voltage power and the nominal active allocation. With one-sided voltage-noise PSD:

```
noise_PSD = Vref^2/(Bnominal*rho)          [V^2/Hz]
sample_noise_variance = noise_PSD*Fs/2   [V^2]
```

This prevents a false benefit from confusing the noise across the full sampled Nyquist bandwidth with noise in the occupied signal dimensions. Equal-power tones have the configured coefficient SNR in the ideal flat channel. Per-channel power reallocation and echo change that relationship.

Two known QPSK training symbols precede every packet. The receiver estimates each complex channel gain by least squares and divides subsequent data coefficients by that estimate. The estimate uses noisy received training samples, not the known simulated echo parameters. Very weak channel gains can magnify noise.

For the one-echo model, a prefix at least as long as the sample delay protects the useful window from preceding-symbol interference. The prefix is a copied tail, not a zero-filled pause. Additional prefix samples cost time.

The C6 frequency-error model restarts the detuned tone at every symbol. It is a useful intercarrier-leakage demonstration, not a full continuously drifting oscillator model.

## Packet format

All multibyte header fields and the stored CRC use big-endian byte order.

```
16 bits: magic 0xF6C3
16 bits: sequence number, starting at zero
16 bits: valid source-payload bit count
 8 bits: mode (1 UTF-8, 2 literal bits, 3 loaded bytes)
 8 bits: version 1
 P bits: fixed payload allocation, unused positions zero-filled
32 bits: CRC-32/ISO-HDLC over header + entire payload allocation
```

The framed bits are whitened by XOR with a reset 16-bit LFSR, initially `0xACE1`. The output is the low state bit; feedback is the XOR of state bits 0, 2, 3 and 5, shifted into bit 15. Whitening is reversible and is **not encryption**. CRC is **not authentication** and cannot detect every possible corruption pattern.

The whitened frame is distributed in channel order into successive symbols. The remaining slots in the last data symbol are zero-padded. The receiver slices the received coefficients, discards those final slots, reverses whitening, validates the decoded header and CRC, and reads the valid bit count from the decoded header.

Known packet/symbol boundaries and public modem parameters are assumptions. Autonomous timing acquisition, synchronization detection, clock recovery, rate negotiation, resampling, real-time continuous oscillator tracking, error-correcting codes and retransmission are not implemented. The training symbols estimate gains; they are not evidence of an implemented synchronization detector.

The receiver never receives the source bits. The original bits are used only by a separate evaluation stage to report bit errors. The receiver-only JSON bench demonstrates this separation: an exported waveform can be decoded after the source text in the transmitter has been replaced.

When a packet fails, its payload is omitted and the assembled output is marked incomplete. An incomplete text output can contain gaps; it must not be treated as a complete reconstructed source. “Save recovered bytes” zero-pads the final byte for non-byte-aligned literal-bit payloads; the exact recovered bit count remains visible in the app.

## Exports and sound

“Export RX sample JSON” writes public configuration and one array of received real voltage samples. It does not include source bits or transmitted coefficients. Importing it uses the independent receiver entry point.

“Export mono WAV” writes the clean TX waveform as peak-scaled 16-bit PCM at the configured sample rate. That export's scale and quantization are not used for the lab's decode statistics. WAV files are not imported by the modem; the sample JSON format preserves its voltage convention and public settings.

“Hear wire” plays at low digital amplitude and limits the preview to four seconds. It is not physical cable transmission, microphone reception or an implemented acoustic modem.

## Source files and verification

`modem.js` is the dependency-free core. `ui.js` and `shell.html` are the editable browser application. `build.py` embeds the scripts into a single file.

```
python build.py
node test_modem.js
python verify_independent.py
python test_browser.py
```

The first command needs Python's standard library. The Node tests use built-in Node modules. Independent verification needs NumPy. Browser tests need Python Playwright and a Chromium executable; the supplied test uses `/usr/bin/chromium`, which may need adjustment elsewhere.

The recorded run passed 25 core test groups and 16 browser interaction checks. Exhaustive QAM mapping covered all 340 points across the four supported alphabets. The independent verifier uses NumPy FFT/IFFT, exhaustive nearest-neighbor QAM decisions and zlib CRC-32, rather than the JavaScript projection/slicer/CRC routines.

The test browser ran with networking disabled and HTML loaded directly into an inline document. Direct `file://` navigation was blocked by the container's browser-administration policy, so direct local-file opening was not the browser-test route. Desktop and 390-pixel mobile layouts were checked in Chromium; no physical Android device or analog cable was tested.

See `TEST_REPORT.md`, `test_results.json`, `independent_results.json` and `browser_results.json` for the measured results. Test vectors are regenerated by the Node suite.

## Background references

Keysight's OFDM documentation explains the conventional Fourier-modulation framework and orthogonality conditions:
https://helpfiles.keysight.com/csg/89600B/Webhelp/Subsystems/wlan-ofdm/content/ofdm_basicprinciplesoverview.htm

MathWorks documents QAM mapping, Gray ordering and average-power normalization:
https://www.mathworks.com/help/comm/ref/qammod.html

MIT 6.451 provides the AWGN-capacity benchmark and signal-space background:
https://ocw.mit.edu/courses/6-451-principles-of-digital-communication-ii-spring-2005/a05a253379aba3efbd400e8b82dde603_midterm03solns.pdf

The parameter choices, packet protocol, browser implementation and reported measurements are specific to this experiment.
