# C independent review of Z6 directional limits

Reviewed: chapters/Z_integrated_practice.md, Z6, lines103-109.
Base: SM-2026-10-13-A.
Primary verdict: proved as written, with the stated domain interpretation.

For f(x,y)=x^2*y/(x^4+y^2), the denominator is positive away from the
origin. At a fixed nonzero direction(a,b), substituting(at,bt) and
canceling t^2 gives a^2*b*t/(a^4*t^2+b^2). If b!=0, its denominator tends
to b^2>0 and the value tends to zero. If b=0, its value is zero. Thus
every fixed straight approach has limit zero. On(t,t^2), numerator and
denominator are t^4 and2*t^4 respectively, giving exactly1/2. The ordinary
multivariate limit therefore does not exist.

The uniform criterion is equivalent to the ordinary epsilon-delta limit.
Interpret its domain restriction as t*v belonging to the original domain.
For a unit vector v and t>0, norm(t*v)=t. Conversely, every nonzero point
x has the unique decomposition t=norm(x),v=x/norm(x). Consequently one
delta controlling every admitted unit direction controls precisely all
admitted punctured-neighborhood points, and conversely. Direction-specific
deltas do not establish this joint quantifier order.

Independent exact Fraction checks passed for20 curved-path values
t=2^(-j),j=1..20, and80 fixed-direction identities. These corroborate the
algebra; the derivations establish the limit claims. No substantive issue
or chapter edit is required. The repaired statement retains the useful
scale/direction representation while exposing its missing uniformity.
