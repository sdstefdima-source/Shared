# F audit: logic, observation, computational structures

Base: SM-2026-10-13-A. Project origin: Stefan. This is a corrective synthesis and self-review with fresh finite checks. No agreement count is used as a mathematical premise. The original supplied and retrieved files were not changed.

Primary verdict: **correct only after stated restrictions**. The chapter's explicit elementary theorems are supplied with proofs under their stated domains. Broad source claims of automatic semantic immunity, physical-wave reliability, universal table integrity, geometric truth selection, unrestricted inverse recovery, and generic computational completeness are not retained.

Deliverables: chapters/F_logic_computation.md; checks/F_verify.py; checks/F_results.json; checks/F_manifest.json. The three chapters contain 7,000-plus substantive words, natural-language explanations, worked examples, algorithm contracts, proofs and answer-bearing exercises. The final assembly owns global numbering and pagination.

## Authoritative artifacts and actual inspected scope

The twelve source reports are compilation snapshots, not original proof-assistant certificates. Their titles do not transfer evidence status. Relevant F statements were rebuilt from definitions. Raw supplemental records make several computational projects substantive rather than conversation-only sketches.

| Artifact | Scope read and role |
| --- | --- |
| supplied01, Math_Work_Exact_Operational_Formalization_ASCII.txt | Part I typed kernel and composition, Part IV temporal provenance, Part VII S.6 contextual NAND/Hanoi statement, Appendix B.4 and final composition. Arithmetic chapters provide interfaces, rather than becoming F's independent proof leaves. |
| supplied02, Project_Mathematics_Audited_ASCII.txt | Entire section structure inventoried; close reading of opening/common kernel, inverse identification sections on fibers/anchors, differencing, chain inversion, boundaries, categorical typing, modular evidence, independent-review fiber/gcd sections, formula appendix and final composition. Analytic/controller and harmonic/conic material is assigned C/D at team level; F does not claim an independent full re-audit of those sections. |
| supplied03, Cryptogram_Operational_Formalization_ASCII.txt | Common domain F2-F8 on typed preimages, branch completeness, information accounting, state transitions and composition. |
| abstract_temporal_framework_ASCII.txt | Semantic core, four-valued definitions/folds, syntax, quantifiers, sign compilation, scope, evidence closure, provenance, nonvacuity, causal cycles/interventions, fixed-point verification, strategies, abstraction and final acceptance contract. Historical 590,388-assertion claim is treated as an archived report, not a fresh result. |
| Math Compilation/Three_Dimensional_Logic_Array_Monograph_ASCII.txt | Source audit, typed object, 3D role/layout contracts, axes and center, complete hyperedges, two-query truth status, atomization, orthogonal reconstruction, projection/permutation limitations, compression/propagation, CH and choice specialization. Later richer-language material overlaps the independently inspected abstract temporal source. |
| Math Compilation/CH_Choice_Cubical_Logic_Report.txt | Finite profiles, kernel, current/future scope, choice/witness dependence and imported-source boundary. The claimed forcing histories are not reverified in this F pass. |
| logic_block_layout.txt | Layout, address map, all six operations, scalar IF, XOR/mod16 side checks, code generator and subsequent prose claims. Repeated copies have one source ancestry. |
| logic_block_squaring_rooting_triangles.txt | Arithmetic formalization, full adder, square expansion, root filters, primitive/triangle conditions, integer trace and fixed-point/cosine proposals. |
| Mechanical Logic Computers(2).txt | Prose pipeline and executable source: parser, node tapes, NNF, gate tape/cams, evaluator/classification, argument checker, limits and demonstrations. All code was parsed; original definitions were executed in a fresh module with demo printing skipped. |
| Electronic Logic Computers(2).txt | Prose pipeline and load-bearing code: bit/phase encoding, transport/compensation, threshold gate weights and biases, noise, oracle rejection, channel doubling, margin estimate and modal equalization. No full stochastic notebook rerun or physical-device test was performed. |
| Logic Certificates(1).txt | Typed interpretation, essence/accident proposals, controller/barrier condition, coherence certificate and temporal-modal claims. Psychological immunity language and Isabelle-like display are not accepted as proved implementation. |
| terminator_logic_verification.txt | Complete finite Boolean model and support-algebra report; clauses are modeling assumptions, not physical laws. F reconstructs the minimal cycle, route and scope examples. Historical aggregate counts are not reused as this run's evidence. |

The source file named supplied01 explicitly stated that no substantive historical NAND/Hanoi/backend artifact existed in its own inspected corpus. The later retrieved logic block and mechanical/electronic source records change the available coverage. They are now described as actual sources. The nine-NAND adder and full state-graph Hanoi demonstration remain transparent editorial standard examples; no missing original twelve-NAND circuit or proprietary Hanoi algorithm is invented.

## Claim cards and decisive repairs

| F claim | Exact hypotheses and conclusion | Verdict and decisive evidence |
| --- | --- | --- |
| Exact decoder | O:D->Y; Q(O(x))=x for every x in D | PROVED iff O is injective; proof uses equal inputs to decoder and inverse on actual image. No computability/efficiency inference. |
| Transform information | T acts on already observed Y | PROVED original fibers are contained in transformed fibers; no deterministic transform splits an original alias. |
| Linear anchor recovery | Consistent observations over a field on the full coordinate vector space | PROVED iff common kernel is zero. Restricted domains can have uniqueness without full rank; composite-ring invertibility needs separate unit analysis. |
| Difference boundary | Unanchored D versus anchored cumulative inverse M | RESTRICTED source wording: ker(D)=constants, but M(c,...,c)=(c,0,...,0). Distinct source/target maps are retained. |
| Modulus discovery | Exact known recurrence and canonical states | RESTRICTED gcd gives compatible divisors. f(x)=13-x and data 1,0,... admit m=2,3,4,6,12. Spectral coherence does not resolve aliases. |
| Exact composition | Forward coverage and backward correctness at every typed relation | PROVED by witness composition. One-way inclusion cannot establish completeness or global optimum. |
| Logic array orthogonality | Nonempty classical model family; finite interpreted generator list | PROVED disjoint signature atomization with reconstruction. Permutation/layout alone does not change intersections; semantic dimension need not be three. |
| Pairwise completeness | Store projections of R=P XOR Q | REFUTED: all pairwise combinations occur while 111 fails. Hyperedge or equivalent relation must remain. |
| CH adapter | Declared three-profile kernel and accessibility relation | FINITE semantic consequences are correct relative to that declaration. Set-theoretic realization and CH-independence theorems are imported, not certified by the table. |
| Four-valued detachment | Positive designation; conditional defined as neg(P) OR Q | REFUTED unrestricted modus ponens at P=(1,1),Q=(0,0). Explicit Boolean support-preservation rules repair detachment. |
| Witness exchange | Constant two-object domain and two contexts | REFUTED forall-context exists-witness -> exists-witness forall-context. Diagonal success matrices give two concrete countermodels. |
| Grounded closure | Finite signed atom set and finite-premise positive rules | PROVED least rule-closed superset; no unseeded support from P->Q->P. Empty-body rules are declared axioms, not self-generated evidence. |
| Temporal inevitability | Finite serial graph and classical goal labels | PROVED least AF and EF fixed-point characterizations. s self-loop plus optional goal refutes AG EF -> AF. Fairness/deadlock conventions remain separate. |
| Causal cycle | Boolean simultaneous equations versus update iteration | RESTRICTED: x=y,y=x has two solutions, F(x,y)=(y,x) oscillates at 01, least unseeded evidence closure is empty. None implies the others. |
| Nibble IF type | Archived control cbit belongs to {0,1} | RESTRICTED: a nibble mask needs gate composition or a new table. A scalar selector is not a mask selector. |
| Mechanical IF name | Source cam IF has table 1,1,0,1 | Naming corrected to IMP for implication; IF retained for controlled selection. Same word did not name the same operation. |
| Single-fault correction | One changed data cell; all stored side checks trusted | PROVED XOR syndrome identifies its row/column and repairs the value. Corrupted checks or multiple faults need another contract. |
| General table integrity | XOR and mod16 checks alone | REFUTED four 0->8 changes at rows16,17 columns0,16 preserve all side and corner values. No claim of universal corruption detection. |
| Lane universality | Four isolated lanes plus scalar operations | RESTRICTED needs extraction/shifts/routing for cross-bit dependence. Gate functional completeness applies when interconnections are available. |
| Addition and square | Declared unsigned widths; NAND gate equations | PROVED ripple invariant and self-convolution. Exact addition has one extra carry bit; square cross terms cannot be removed. |
| Triangle arithmetic | Each side W-bit; bare wrapped sum versus guarded equality | RESTRICTED sum can need 2W+1. Bare W=3 check admits 4^2+7^2==1^2 modulo64. Independently checking c>=a,b also repairs the equality certificate by a residual magnitude bound. |
| Wave reliability | Ideal compensated signed inputs; specified detector | PROVED ideal gates and margin1; bounded additive error <1 preserves output. Gaussian/noisy/physical guarantees are not implied. |
| Oracle-assisted acceptance | Source compares attempted output with exact logical oracle | RESTRICTED accepted correctness follows from definition; independent hardware success probability does not. |
| Hanoi | Three pegs, full-tower endpoints, legal moves | PROVED 2^n-1 via matching upper/lower recursion. Shortest path visits eight states for n=3, not all27. Cached five-level planning does not reduce executed moves. |

## Dependency and obligation record

The original-domain observation definitions lead to fibers. Injectivity or surviving-fiber descriptions license recovery. Safe necessary predicates license pruning. Coverage plus backward correctness licenses exact composition. Every final answer returns to its original predicate or a stated equivalent verifier.

The logic layer has a separate chain: typed formula and context -> specified semantics -> exact semantic translation or finite model -> complete search or justified fixed-point calculation -> scoped certificate with nonempty premises and retained provenance. A report about a fact is not the fact itself. A logically valid consequence of assumptions does not authenticate those assumptions.

The computational layer uses a declared finite encoding -> bit/gate semantics -> width/address/fault contract -> exact finite witness checks. The source's circuit simulator and its acceptance oracle share a specification; this is a legitimate reference comparison and not a second physical observation source. Physical implementations require calibration and error contracts beyond the finite logic.

Obligations passed: symbol/type normalization, relevant base cases, zero/empty cases, quantifier order, domain boundaries, exact arithmetic, original-domain verification, count versus semantic-enclosure distinction, source ancestry and explicit result types. Conditional obligations: imported forcing realizations, factual accuracy of external reports, physical transducer/noise assumptions. Not addressed: arbitrary higher-order validity, proof-assistant encoding, general parser proof, arbitrary stochastic notebook performance, a hardware realization, or a globally optimal lookahead policy for every Hanoi state.

## Fresh computation contract and result

Command: `python3 stefans_math/checks/F_verify.py`, run without Python optimization. Python standard library only; no random sampling. Output F_results.json and v1 evidence manifest F_manifest.json pin the available source hashes and verifier digest. Runtime is a local execution measurement, not a speed theorem.

The mathematical finite surrogate tests the following explicitly enumerated families:

| Suite | Exact range and independent comparison |
| --- | --- |
| NAND arithmetic | All8 full-adder rows; all174,760 pairs/carries at widths1..8; compare gate output to integer sum. |
| Squaring/root filters | All510 unsigned inputs at widths1..8; square expansion compared with integer multiplication. All1,364 targets at root widths1..5, keeping branches at every precision, compared with math.isqrt and exact equality. |
| Triangle guard | All positive a,b<=c at widths1..5; guarded modular equality compared with integer residual equality. Bare overflow witness recorded separately. |
| Nibble table | All3,072 data entries compared with independent per-bit arithmetic; all46,080 single-cell substitutions checked and repaired; four-cell undetected fault explicitly reproduced. |
| Logic/observation | All64 four-valued triples for the selected algebraic laws; all16 two-context/two-action success relations; exact XOR projection, noncoprime indexing and recurrence aliases. |
| Grounded closure | All512 directed unary-rule graphs on three atoms times all8 seed sets =4,096 cases; compare iteration with intersection of every closed superset. Two conjunctive rules are named examples, not exhaustive hypergraph coverage. |
| Fixed-point maps | All256 maps on four two-bit states; counts81,108,54,12,1 for0..4 fixed points; all36 monotone maps checked from extremal starts. |
| Temporal graphs | All353 serial directed graphs at sizes1..3 and all2,782 graph/goal-label combinations. EF/AF/AG/EG fixed points compared with separate BFS/DFS reachability and cycle tests. Classical labels only; full four-valued CTL not claimed. |
| Hanoi | All reachable states from a full source tower at n=0..7; BFS distances compared with legal recursive paths. Maximum enumerated graph has2,187 states, and n=7 transfer distance127. |
| Original mechanical code | Original definitions executed;10 formula cases/44 truth rows compared with independent direct Boolean functions; modus-ponens and affirming-consequent argument queries checked. Full parser correctness not inferred. |
| Ideal wave gates | All510 input words for AND/OR arities1..8 plus two NOT rows, using exact integer detector values after stipulated ideal compensation. Noise notebook not rerun. |

The current result file is the authority for the total assertion count and runtime. Assertion totals measure implemented work, not independent proofs. The v1 manifest validator passes with its advertised legacy provenance limitations; those limitations are retained. After adding the independent largest-side comparison check, the verifier was rerun rather than using the old counts.

## Primary literature checks and limits

Checked 2026-10-13 through primary-source opens:

- Todd J. Green, Grigoris Karvounarakis and Val Tannen, Provenance Semirings, PODS2007, sections3-4. Author-hosted full text: https://www.cs.ucdavis.edu/~green/papers/pods07.pdf . Extracted implication: joint annotation use and alternative derivations use distinct semiring operations; provenance polynomial multiplicity is not automatic statistical independence. F uses only this lineage plus its own root-set definition.
- Alfred Tarski, A lattice-theoretical fixpoint theorem and its applications, Pacific Journal of Mathematics5(2),1955, Theorem1, pages286-287. Original journal text: https://msp.org/pjm/1955/5-2/pjm-v5-n2-p11-p.pdf . Complete lattice and increasing self-map hypotheses were checked. F supplies elementary finite proofs and does not derive arbitrary-start convergence from Tarski.
- Rajeev Alur, Thomas A. Henzinger and Orna Kupferman, Alternating-Time Temporal Logic, JACM49(5),2002, section3.2. Author-hosted text: https://www.cis.upenn.edu/~alur/Jacm02.pdf . The existential strategy/universal outcome semantics and history-dependent strategy definitions were inspected; F's finite success-matrix argument is separately proved.

The four-valued algebra's Dunn-Belnap attribution is standard lineage; all adopted operations are defined and proved here. The CH source's constructibility, Cohen iteration, preservation and independence leaves were not freshly authenticated by F. They remain explicit imported assumptions for the finite application, and are unnecessary for its abstract Boolean truth-table correctness. No novelty search was performed; standard inverse, Boolean, automata and Hanoi mathematics is not attributed as Stefan's new theorem. Stefan's organizing constructions and applications are distinguished from those standard tools.

## Strongest safe conclusion and reusable next work

The compiled F material supplies a useful exact toolkit: identify what observations leave ambiguous, select anchors that remove the actual ambiguity, retain full relation scopes in logic arrays, preserve witness dependencies, derive evidence only from grounded sources, calculate finite temporal guarantees, and implement arithmetic with explicit bit/width/table contracts. These modules compose under their checked interfaces. They do not jointly become a universal solver, a language-immunity guarantee, an infinite set-theory oracle or an independently verified physical machine.

Reusable extensions include a proof-assistant encoding of the signed syntax and translation, a standalone certificate checker for the array adapter, a physically specified transducer model with measured bounded-error contracts, and an implementation benchmark for the original LUT. Each has a concrete missing artifact and proof obligation. Additional assertions alone would not fill those gaps.
