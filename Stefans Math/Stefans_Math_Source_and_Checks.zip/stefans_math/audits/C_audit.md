# C audit: certified equation solving and numerical control

Base: SM-2026-10-13-A. Manuscript: chapters/C_certified_solvers.md.
Primary verdict: correct only after a stated restriction.

The useful project construction is an architecture of guarded equations,
domain-specific candidate enclosures, numerical proposals, and independent
verification. Universal global Newton convergence, stationary-point-to-root
inference, grid-to-all-rational completeness, and unconstrained controller
guarantees are refuted. The revised chapters contain self-contained corrected
arguments and explicitly scoped software dependencies. Source titles such as
"audited" and "certified" were not treated as proof evidence.

## Sources and actual coverage

- project_sources/04-Solvers_Certified_Operationalization_ASCII.txt: all
  2574 physical lines inspected, including the full exact reference program,
  source inventories, bibliography, and final compositional argument.
- project_sources/02-Project_Mathematics_Audited_ASCII.txt: relevant solver and
  analytic portions inspected: 146-229 (quadratic reconstruction/error),
  662-877 (quadratic control, tensor rank, shooting), 997-1238 (roots,
  finite differences, rotations, quadratic inversion), and 1757-1906
  (finite increments, derivative limits, dual numbers). Other mathematical
  families belong to their assigned agents; no full-read claim for source02.
- stefans_math/supplemental/Solver_Mathematical_Notes_ASCII.txt: all 2120
  lines inspected. This is the current V4 solver-note contract, with a
  finite rational-grid route, approximate real route, and optional exact
  algebraic backend. Its current capabilities supersede older integer-only
  impressions. The complete V4 source package was not rerun by this agent.
- stefans_math/supplemental/Number Pattern Finder/math.txt: inspected
  mathematical introduction 1-260, exact carrier description 390-435,
  group/coefficient search 430-690, Vieta move 758-805, coverage/ranking
  946-982, and exact carrier/group implementation 1470-1648. This is partial
  mathematical coverage, not a complete executable audit of its 3243 lines.
- math(3).txt, math(4).txt, mathsave.txt: introductions inspected and contents
  hashed for revision/dedup checking. Their full algorithms were not audited.

The raw SHA256 values of the homogeneous puzzle revisions are:

```text
Number Pattern Finder/math.txt
c1bc57d67627ec378a92cc57e1a7eeb00ba41b2f90a12c0255e642a787ea6252
math(3).txt
26d4e867085f5416e5a3d8dab3617889b9188df11834b79e1c60f754b3df4f84
math(4).txt
8eacb9db44a28c2645ee4cf15e23330690530a75e91147b0015c147ad7edf8a5
mathsave.txt
e670054c479a76b0b75754eacf148bb196664a676f2b6496aeded908c750edc1
```

After selecting the code beginning at '# Google Colab script:', removing
trailing whitespace per line, and normalizing newlines, math.txt and
math(4).txt share the code hash
43c69de1b3e416343529bc2953eef3b895c0864663d6f06dd1e7f123d2c4d4e0.
Their distinct whole-file hashes therefore reflect front matter/formatting.
math(3).txt and mathsave.txt remain distinct normalized code revisions.
Duplicate material is one evidentiary origin, not independent corroboration.

## Claim cards and decisive corrections

| Claim or inference | Verdict | Decisive evidence and corrected form |
| --- | --- | --- |
| Rational numerator normalization alone preserves an equation globally | RESTRICTED | Original denominator guards remain required. (x^2-1)/(x-1)=2 has no root although its cleared numerator vanishes at x=1. |
| Exact decimal coefficients choose a rational unknown domain | REFUTED | 2*x=1 needs x=1/2; integer and half-grid domains differ. |
| Complete finite rational grid solving means all rational solving | REFUTED | x*y=1 has rational points with unbounded denominators. The completeness contract is the declared finite grid. |
| Three unknowns and three rows ensure a finite unique set | REFUTED | Dependent rows leave families, while singular real and complex dimensions may differ. Rank and domain determine the answer type. |
| Degree above four prevents an exact answer | REFUTED | Algebraic root objects and the verified univariate parameter contract represent t^5-t-1 without radicals. |
| Positive complex dimension implies infinitely many real solutions | REFUTED | x^2+y^2=0,z=0 has only the origin over R and complex curve components. |
| Every local quadratic interpolation is an exact nonlinear solve | RESTRICTED | Exact for degree<=2; C^3 interpolation has a cubic nodal remainder over the full extrapolation interval. |
| The numerical source samples for 2*x^2+3*x-15 are correct | REFUTED | At 0,.1,.2 values are -15,-14.68,-14.32, yielding curvature4 rather than source38. |
| Shrinking perturbations indefinitely improves derivatives | REFUTED | Truncation shrinks as h^2 but bounded value error is amplified by 1/h or 1/h^2. |
| Opposite endpoint signs always prove a root | RESTRICTED | Continuity and no intervening pole are necessary; 1/x across zero refutes the unrestricted statement. |
| Newton converges from every start | REFUTED | x^3-2*x+2 has exact cycle0->1->0. Local simple-root theorem is proved under derivative bounds. |
| Fixed damping preserves quadratic convergence | RESTRICTED | e_new=(1-alpha_d)e+O(e^2); generic fixed alpha_d<1 gives linear leading error. |
| A small residual establishes a nearby root | REFUTED | 10^-12*(x-1) passes a raw10^-9 tolerance at x=0. Existence plus derivative/inverse control are needed. |
| Halley's cube update converges for all real starts | RESTRICTED | N>0,x>0 gives a proved global monotone theorem. Zero is a spurious fixed point; other domains are not covered. |
| The quoted cube Pade start matches the second-order term | REFUTED | Correct form is (1+2e/3)/(1+e/3), with exact cubic residual given in C2.4. |
| Stationarity of squared residual proves a root | REFUTED | x^2+1 at0 is a positive global minimum; (x^2+1)(x-3) has a positive strict local minimum despite a root elsewhere. |
| Positive damping proves nonlinear descent/root existence | RESTRICTED | It makes the local normal matrix positive definite. Original evaluation and root certificates are separate. |
| Monotone Armijo values ensure a stationary limit | REFUTED | J=x^2/2, alpha_k=2^(-k-2) gives strict acceptable descent with x_k>=1/2 from1. |
| Probe amplitude annealing restores quadratic Newton rate automatically | RESTRICTED | Matrix error must be O(root error), residual error O(error^2), with controlled solve and damping errors. |
| Clipping plus a smaller fallback preserves every acceptance gate | REFUTED | Allowed[0,1], old0,V(M)=M, fallback1/2 violates nonincrease. All branches need the same gate. |
| Bounded increments ensure controller boundedness | REFUTED | M_k=k*delta. A bounded allowed set or coercive invariant is additional. |
| Convergent scalar energy guarantees convergent state | REFUTED | M_k=(-1)^k,V=M^2 has constant energy. |
| Controller adaptation proves generic plant stability | RESTRICTED | The stated saturated scalar integrator has an explicit gain-envelope theorem; no generic plant conclusion follows. |
| Positive real homogeneous-controller output certifies an integer intersection | REFUTED | a=b=1 gives c=(7+sqrt65)/2, a positive irrational slice root and no rational slice solution. |
| P and -P form two independent elliptic search axes | REFUTED | Integer combinations reduce to (c1-c2)P. |
| Smallest discovered coefficient tuple proves smallest integer triple | RESTRICTED | Complete group generators/cosets plus height/coverage bounds are required. The source's final qualified discovered-best claim is retained. |
| Three named channels must have distinct values | REFUTED generally; RESTRICTED here | The equal-channel slice has discriminant65, ruling out equal positive rational channels for this specific equation. |

## Internal dependency graph

Original expression semantics -> guarded normalization -> finite coordinate
bijection or exact algebraic representation -> original verifier -> witnessed
answer. Numerical evaluation -> local model -> proposed correction -> original
domain/residual check -> independent real root certificate when available.
Controller/observer proposal -> immutable acceptance gate -> committed valid
controller. Each direction is proved under its local hypotheses; numerical
non-discovery never enters as a solution-exclusion premise.

C-TH1 and C-TH2 prove the compiler and finite-grid interfaces. C-TH3 proves
the conditional univariate reconstruction contract. C-TH4 proves exact
quadratic interpolation. C-TH5 and C-TH6 prove the restricted Newton and
positive cube Halley results. C-TH7 proves a self-mapping contraction box
certificate, including its own Cauchy convergence/uniqueness argument.
C-TH8 proves controlled-commit validity by induction. Ordinary field
arithmetic, elementary calculus theorems, real completeness, and the
fundamental theorem of algebra remain standard background prerequisites,
rather than being reproved from foundational axioms.

## Primary sources checked this turn

1. SymPy 1.14.0, Solvers, official documentation, polynomial system section
   lines1324-1423 in retrieval. Verified strict incomplete radical handling,
   triangular algebraic extensions, and exact root-object examples.
   https://docs.sympy.org/latest/modules/solvers/solvers.html
2. SymPy 1.14.0, Solveset, official documentation, lines334-381 and
   1131-1249 in retrieval. Verified unresolved-set interface, parameter
   examples, and distinct real/complex solving routes.
   https://docs.sympy.org/latest/modules/solvers/solveset.html
3. NIST DLMF3.8, lines115-125 in retrieval. Verified Newton's local
   simple-root quadratic versus multiple-root linear distinction.
   https://dlmf.nist.gov/3.8
4. GNU Octave Interval Package official Root Finding documentation,
   Section3.4.1, retrieval lines8-16. Verified interval Newton enclosure
   intersection versus point Newton proposal semantics.
   https://octave.sourceforge.io/interval/package_doc/Root-Finding.html
5. Boyd and Vandenberghe, Convex Optimization, author-hosted book,
   Algorithm9.2, printed464-466/PDF477-479. Verified descent-direction
   backtracking, its termination reasoning, and domain requirement.
   https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf

All checked2026-10-13. These sources authenticate method/software contracts.
No external theorem is imported to assert universal convergence or novel
combined-solver correctness. Each source is paraphrased in the chapter well
below its retrieval word budget. A separate attempted obsolete SymPy
polysys.html URL failed and was replaced by the actual official section.

Browser retrieval references, for coordinator reopening if needed:
turn7view0/turn15view3 (SymPy Solvers), turn14view1/turn15view0 (Solveset),
turn7view3/turn8view3 (DLMF), turn7view1/turn8view4 (Octave),
turn7view2/turn8view2 (Boyd book). The book and official documents are the
source evidence; retrieval snippets were not used as stand-alone proofs.

## Executed finite evidence

Command: python3 stefans_math/checks/C_solver_checks.py
Output: stefans_math/checks/C_solver_results.json
Manifest: stefans_math/checks/C_solver_manifest.json
Arithmetic: arbitrary integers and fractions.Fraction; no floating decisions.
Randomness: none. Runtime approximately0.36seconds on this host.

- Complete17576-point integer scan of C-EX2, roots(-5,-5,20),(2,2,6).
- Complete2601-point rational scan of C-EX3, root(1/2,-3/4,5/4).
- Guarded-versus-cleared C-EX1 branches and exact rational power checks.
- 2940 quadratic/node/spacing cases, each with six trial coordinates.
- 49 exact rational Halley factor/monotonicity checks and C-EX6 endpoints.
- 48 exact rational bisections with width2^-48 and exact endpoint signs.
- Exact C-EX7 drift, infinity matrix bound, inward radius bound, and8 corners.
- Direct linear residual/normal equations for C-EX8.
- 20 exact Armijo-compatible summable steps, all bounded away from zero.
- Corrected adaptive-gain trace and38424 exact plant transitions:
  gains j/20,j=1..24; errors k/10,k=-800..800.
- 1000 homogeneous-cubic/rational-equation identity checks on[1,10]^3,
  including mod6 identity; eight exact multiples of the stated carrier point,
  checking curve equation, ratio relations, and rational cubic reconstruction.
- Carrier cubic discriminant551183360, nonzero. No full rational group
  generation, giant positive minimum, or coefficient-lattice completeness
  theorem was claimed or tested.

All assertions passed. The current skill manifest validator was run as
python3 stefans_math/checks/validate_manifest.py stefans_math/checks/C_solver_manifest.json
--root . and accepted the evidence record. Its explicit legacy-version1
qualification is retained: this manifest does not mechanically enforce
before/after input snapshots or resource limits, although it includes input,
script, and output SHA256 values. Mathematical interpretation requires the
separate proofs. No completed V4 package execution or speed benchmark is
claimed by this new check run.

## Editorial self-review and remaining coverage

The chapter has three unified substantive chapters, approximately7650 words,
ten numbered worked examples, six exercises with answers, explicit claims,
and practical contracts. ASCII validation passed; no second-person pronouns
are present. Routine self-review corrected an interval/identity-matrix symbol
collision by writing Id, and separated the original domain D from the
positive damping matrix W. These are presentation repairs within this edit;
the source reports remain unchanged.

Independent family peer review by the spectral/geometry agent identified
a missing scalar interval-Newton pivot guard. The chapter was corrected to
require c in I, or a derivative enclosure over the enlarged hull if the pivot
lies outside. Its explicit counterexample was f=x^2-1,I=[1,2],c=0: the
unrestricted formula gives N=[1/4,1/2] and loses root1. This is a substantive
restriction, not a typographical repair. The initial C mathematical review
was a self-review, not independently proved by agent identity. Open
implementation work includes a production outward-
rounded real backend, singular-root handling, certified global box coverage,
arbitrary nonlinear families, and broader primitive/complex branch support.
The book explains these as future adapters rather than current hidden
guarantees. CRT and p-adic lifting remain in familiesA/B; detailed harmonic
derivative extraction and geometry remain in familyD/coordinator synthesis.
