# Independent family-B peer review of A, G, and Z

Base SM-2026-10-13-A. Review date 2026-10-13. Reviewer: family B, reviewing owner files without editing them. The raw chapter statements and derivations were read before running the separate numerical recomputation. This is a mathematical review of the displayed claims, not endorsement from the owners' test totals. The finite checks use a new script and elementary oracles; no owner test implementation was imported.

Reviewed files: chapters/A_exact_arithmetic.md, chapters/G_discrete_geometry.md, chapters/Z_integrated_practice.md. Current reviewed byte hashes are in checks/B_peer_results.json. The owner corrected the two substantive findings during this pass; the original failed formulations and counterexamples are retained below.

## Primary verdicts

- A: **correct only after the stated restriction** k>=2 on the coupled first-layer recovery/necessity statement. That restriction is now present in A11. The remaining reviewed arithmetic, coefficient-ring, polynomial CRT, and bounded-lattice implications are correct under their stated domains.
- G: **proved as written** for the limited coordinate, Gram-realization, incidence, positive-metric energy, finite diffusion, and manifold angle-deficit claims. The chapter does not claim continuum convergence, mesh realization from arbitrary angle lists, or a physical-gravity theorem.
- Z: **correct only after the stated restriction** that uniqueness concerns a sound complete output, equivalently S={x}. Z1 now states that requirement explicitly. Its pruning, finite CRT example, factor-gap coordinates, exact phase distinction, and sparse-observation formulas are correct under their displayed model assumptions.

## Substantive finding B-PR1: first-layer necessity has a precision-one exception

The original A11 setup omitted k>=2, then asserted that singular A cannot yield a bijection and used exponent difference p^(k-2)*v. At k=1, the declared exponent modulus is P=p^0=1 and U_1={1} in R_1. Both domain and target are trivial. The map is bijective for every matrix, including A=0. Moreover p^(k-2)*v is not an integral exponent vector. This is an actual counterexample to the unrestricted necessity paragraph, not a test-range concern.

Smallest example: p=3, degree one, k=1, g=1 modulo 3, tangent coefficient c=0, A=[0]. The map from Z/1Z to {1} is bijective although A is singular. Restricting the theorem and its necessity argument to k>=2 repairs the statement; k=1 is the separate trivial principal-group regime. The owner inserted "At precision k>=2" before the coupled setup, and the corrected theorem's first/last-layer proof then applies.

## Substantive finding B-PR2: singleton output is not uniqueness of the original problem

The original Z1 certificate line read: "Uniqueness certificate: output represents exactly one member of S." That describes a singleton sound output, but does not establish |S|=1 unless completeness is also required. The chapter's own example makes the distinction decisive: for x^3-x=0 in [-2,2], S={-1,0,1}. Output {1} represents exactly one member of S while the original equation has three solutions.

The cheapest repair is to require a sound complete output representing S={x}, or an existence certificate together with an exclusion certificate for every other admissible solution. Z1 now says "Uniqueness certificate: sound complete output represents S={x}." Its exercise Z-E2 and the common solver contract then agree. The pruning induction itself was correct before this edit; the failure concerned the separate uniqueness certificate definition.

## Independent arithmetic reconstruction

All displayed core A numerical examples were re-evaluated directly. Nonunit cancellation gives residues 6,13 modulo 14. Overlapping CRT in [0,100] gives 29,65. The arbitrary-modulus residual example gives x=37,61. The order-96 target has original exponent 77; the projection constants 28,42,96,35,61 agree. The singular modulus-18 system has exactly (5,11),(11,5),(17,17). The strengthened ternary step 2^(2*3^(r-1))==1+3^r modulo 3^(r+1) was checked at r=1..8 and independently follows by cubing the preceding expression: omitted terms have depth at least r+2. The addresses for observed unit 158 are 1,5,11,29,137,137.

The polynomial CRT example was rebuilt as a binary-polynomial quotient from its displayed factors. Their product, two projectors, component reductions, and all 128 values of D(E(z)) agree. This explicitly includes zero and zero divisors. The inverse exponent conventions on nonzero field components and the separate fixed-zero check are correct. A15 correctly distinguishes map-cycle length from group-element order; the six-cycle under exponent multiplication by three modulo seven is valid even though six does not divide the unit-group exponent 105.

The coupled ring example matches the independently generated B ring calculation. At modulus 81 the target is (25,66), residuals are (10,45) then identity, and the logarithmic columns are (16,0),(15,25) with target (23,13) modulo 27. The singular comparison at modulus 27 has a depth-two second direction and the asserted aliases. Its exclusion for alpha coefficients not divisible by nine is valid after multiplication by the first scalar base, which cannot create an alpha direction.

## The lattice example was rederived from its rows

The row identity R=U*B0 and det(U)=-1 hold exactly. Rational Gram-Schmidt of the displayed R gives orthogonal rows (0,0,101), (101,1010,0), and (1010,-101,0). Independently recomputed nearest-plane centers are 314/101, 698/101, and -37/101. Their selected coefficients (0,7,3) give point (3737,6767,37) and original coordinates (0,-3,37). The squared target displacement is 21771 and the containing radius squared is 22902.

Direct scalar enumeration gives only x=37. A separate finite lattice-row enumeration over beta=-50..50 and both wrap coordinates -10..10 gives exactly the one boxed point; the wrap range covers the possible bound-generated wraps in this example. This verifies the last-coordinate interpretation without assuming that the final reduced basis coefficient is the secret. The universal A-P9 proof is valid because centered beta and bounded errors give a unique wrap vector, and the converse recovers those errors from every boxed lattice point.

The A20 exact endpoint formula was challenged on 1,056 rational-center/radius tuples against direct rational inequalities. It agrees, including zero remaining radius and negative centers. Its general proof is sound: Qz-P is integral, so a rational squared upper bound is equivalent to an integer square bound after floor and isqrt. Keeping the original search radius is correctly required for complete feasible-output enumeration.

The signature lattice obstruction also survives direct algebra: q times the secret row minus the listed multiples of the q^2 diagonal rows produces a marker-zero vector of length Bq. A marker-one secret vector with positive nonces is strictly longer. Thus neither basis-row search nor a shortest-vector promise alone proves secret recovery. This is a substantive and correct restriction on the proposed solver, not an unnecessary generic warning.

## Geometry and integrated practice

G's barycentric values and affine integral agree exactly. Its tetrahedron counterexample has Gram diagonal 1 and off-diagonal -161/200; multiplication by (1,1,1) gives eigenvalue -61/100, so realization is impossible despite strict face inequalities. The Gram equivalence is correct: a realized nondegenerate simplex gives B^T B positive definite; a positive-definite candidate admits a realizing factorization. Positive semidefiniteness can produce a degenerate object and does not satisfy the nondegenerate claim.

The oriented triangle incidence product d1*d0 is zero. Its identity-metric Laplacian has diagonal 2 and off-diagonal -1, acting by eigenvalue 3 on mean-zero vectors. The stated continuous decay and Euler stability interval follow. For h=1/2 the squared deviation multiplier is 1/4; for h=1 it is 4. G's weighted adjoint orientation and nonnegative energy identity are correct in the positive-definite cochain inner products.

The angle-deficit sum is derived with the required manifold boundary identities 3F=2E_int+E_b and E_b=V_b. The tetrahedral sphere and square disk values agree. The dyadic approximation of 5pi/3 gives counts 13,0,1,0,1,0 and remainders pi/24,pi/24,pi/96,pi/96,pi/384,pi/384. Its precision increase and unchanged approximants are consistent. The chapter correctly treats this as arithmetic angle approximation rather than automatic mesh realization.

Z's nine classes modulo 45 are exactly {0,1,9,10,19,26,35,36,44}; bound [-2,2] leaves -1,0,1. The Fermat and gap example for 10403 gives 101*103, center 102, and square 204^2. Its signed phase example for 77 modulo 10 is correct. Exact harmonic intensity one with M>=2 implies z=1 by the equality case for an average of unit vectors; M=1 is correctly excluded as uninformative.

The added sparse-observation section was reviewed mathematically without revalidating its aviation data sources. The altitude average is exactly 97500/7 feet per minute. The chord-to-radius relation and retained arc choice are correct for the stated nonzero angle below 2pi. The distinction between norm of average force and average force norm follows from the triangle inequality. No instantaneous peak or accident-cause conclusion is supplied by those identities.

## Remaining narrow wording recommendations

These do not invalidate the proved examples. In A14's affine power-map extension on all field elements, state k_i as a positive integer explicitly, because negative exponents are undefined at zero. The preceding worked positive powers already meet this guard. In Z3, state 0<L<=U explicitly before using N/L and N/U; the positive-factor interval is intended, but this prevents a parser from accepting L=0. Neither recommendation requires a new theorem or algorithm.

## Evidence files and limits

Reproduction command: python3 stefans_math/checks/B_peer_verify.py. Result: checks/B_peer_results.json. The exact script checks its own finite assertions, and the review above evaluates the universal arguments directly. No theorem prover was used. The owner files were not edited by family B; changes were returned to their owners. The two substantive findings are repaired in the current snapshots. No further substantive error was found in the reviewed scope.
