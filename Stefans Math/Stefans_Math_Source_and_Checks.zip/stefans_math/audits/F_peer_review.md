# F fresh peer review of E patterns and statistics

Base SM-2026-10-13-A. Reviewed artifact: chapters/E_patterns_statistics.md. The review reconstructed selected claims from their definitions before inspecting E's verification implementation. No E chapter or source artifact was edited by F. The finding was sent to the owning agent, who corrected the chapter and its dependent checks.

Primary verdict: **correct only after a stated hypothesis repair**, now incorporated for the selected reviewed claims. There is no remaining material gap in the selected claim set after that correction. This is a targeted peer review, not an independent audit of every imported external theorem or every historic source report.

## Decisive finding: hard-support symmetry was missing

The earlier E3.2 contract asserted equal filtered weights from prior invariance, transition commutation and likelihood invariance alone. Its own E3.1 filtering equation also multiplies by a hard candidate-support indicator. That indicator can break the symmetry even when all the listed conditions hold.

Small exact counterexample: hidden states are {2,5}; sigma exchanges them; prior weights are 1/2 each; dynamics are the identity; the observed modulo-three symbol has likelihood4/5 in both states. All listed observational/evolutionary conditions agree. Add the independently certified bound x<3, so C={2}. The next unnormalized weights are2/5 and0. They are not equal.

This is not a hypothetical warning about noise. It is a direct failed implication in the written filtering equation. The strongest repaired statement requires sigma to be a permutation, pointwise prior invariance, sigma(C_t)=C_t, transition equivariance K(sigma(u),sigma(x))=K(u,x), and likelihood invariance. Adaptive chosen actions must preserve each of those relevant interfaces as well.

The owning E agent incorporated these hypotheses and the counterexample. F then reread the revised E3.2. Reindexing the predecessor sum by the permutation gives the same sum for x and sigma(x), and the invariant hard-support indicators agree. Induction proves the repaired equality. If an action is chosen only from indistinguishable observation histories, its law agrees between aliases; conditional preservation under that chosen action then continues the induction. The hard bound in the counterexample is correctly described as an additional distinguishing constraint rather than forbidden information.

## Independent derivations of load-bearing claims

| Selected claim | Fresh reconstruction and verdict |
| --- | --- |
| Width-two count process has no finite Markov order | Start hidden words00 and11, then append alternating bits so each next observed adjacent count is1. Any m-long suffix of ones is identical, but the latest hidden bits stay opposite. Next-count support is{0,1} versus{1,2}; each finite history has positive fair-bit probability. This proves the arbitrary-m obstruction. The finite belief update u->0,1-u,1 for new counts0,1,2 follows by conditioning a fresh fair bit. PROVED under the stated iid input. |
| A known tape index is not a fresh bit | Conditional on earlier revelation its next repeated reading is deterministic. Removing it from a current window does not remove it from the full information filtration. The explicit revealed-index cache is an appropriate state repair. PASSED. |
| Augmented wrapped walk period | Returning the phase requires a multiple of L. Each L-step block translates by the same displacement, whose order is lcm(R/gcd(R,a),C/gcd(C,b)). Their product is the exact augmented period. Cell-only return can occur earlier. PASSED. |
| Hash perturbation loses full-cycle coverage | Period-four offsets(0,4,3,2) with m5,g1 give addresses0,0,0,0,4 at the first five steps. This independently refutes the original full-cycle claim. A permutation after a unit-stride residue traversal restores coverage exactly. PASSED. |
| High sampled frequencies alias | 2^(j^2) is divisible by2^16 for j>=4. Its phase at integer lattice points contributes only the fixed phase offset, so no added sampled oscillation appears. PASSED. |
| Pair wheel factors | At a prime p, forbidden n residues0 and-h coincide iff p divides h. Counts p-1 or p-2 multiply by CRT over a complete period. This is exact finite counting, with prime-equality exceptions retained separately. PASSED. |
| Square-shell primality | A composite n<=p^2 has a prime divisor<=sqrt(n)<=p. A prime n>p has no such divisor. The shell lower bound is essential to exclude the small prime-equality cases from the blanket filter. PASSED. |
| Higher-root roughness | If every prime factor exceeds X^(1/k), a product of k factors exceeds X. This gives at most k-1 factors, not primality or a converse. PASSED. |
| Euler quadratic prime run | Independent reduction finds no root at any prime below41. The values for n0..39 are below41^2, so a composite would contradict that exclusion. n40 gives41^2. PASSED. |
| Shift overlap and product roots | Under odd p not dividing h, subtracting the two F equations gives the unique candidate n=-(h+1)/2, and substitution gives the h^2+163 condition. At p=h=163, the displayed valuation identity makes each factor valuation1 and their product valuation2, explaining roots at levels1,2 and none at3. PASSED. |
| Complete cyclic window sums over Q | C_w(n+1)-C_w(n)=x(n+w)-x(n). A kernel tape is gcd(M,w)-periodic and has one zero-sum condition on that period. Characteristic0 makes w/d nonzero. The stated dimension d-1 follows, and characteristic caveat is explicit. PASSED. |
| F9 invariant code | Direct field coordinates give Tr=2a,N=a^2+b^2. The six conjugacy orbits produce six distinct six-symbol codewords with minimum distance3. Correcting one arbitrary symbol identifies an orbit; it cannot split a two-member conjugacy orbit. PASSED. |
| Overlapping window difference law | Shared physical bits cancel. The remaining m fresh positive bits minus m fresh negative bits have distribution Binomial(2m,1/2)-m. This agrees with the range[-m,m] and variance m/2. PASSED. |
| Anytime mixture guarantee | Each predictable factor has conditional mean1 under a genuinely fresh fair bit. Finite stopped expectation and the threshold lower bound give crossing probability<=alpha; monotone events extend the bound to all finite horizons. No independence among alternative betting strategies is required for a fixed mixture, but fresh-target conditional calibration is required. PASSED. |
| Duplicated-data failure | Five equal original fair bits occur with probability1/16, exceeding5%. Treating their duplicates as ten independent observations produces capital29525/1024>20, whereas five sources give61/16. This single event is a decisive failure of the false guarantee. PASSED. |
| Bernoulli confidence inversion | Integrating q^k(1-q)^(t-k) over q in[0,1] gives1/((t+1)binom(t,k)). Dividing by a fixed true Bernoulli(p) likelihood gives the stated likelihood-ratio martingale. Threshold inversion controls exclusion of the one true p, and a finite grid does not cover off-grid p. PASSED. |

The count-memory proof has a universal construction; its finite test does not supply the universal quantifier. The same distinction holds for the permutation, CRT and martingale proofs. The specific phase-identification width, mask counts and crossing probabilities are finite results requiring their declared enumerations rather than a general theorem about all masks or all tests.

## Fresh finite computation

Files: checks/F_peer_E_verify.py and checks/F_peer_E_results.json. The program imports no E implementation and uses only the Python standard library. It reconstructs its own arithmetic, transitions, field profiles and integer path-count dynamic programs. It passed6,048 checked assertions; the current JSON records the actual run start and duration. The recorded hashes pin the chapter revision and peer verifier read by that run.

Exact bounds:

- Count-memory constructions at m1..32; all120 permutations of five buckets with every start and unit stride; wrapped grids1..4 in both dimensions and step words of length1..3 over five signed/stay steps.
- Complete pair-wheel counts at gaps1..64; square shells for p2,3,5,7,11,13; all residue roots at primes below41; Euler values n0..40.
- All nine F9 coordinate states, all six resulting orbit codewords and their pairwise distances; fair-tape overlap laws at widths1..4 and lags0..4.
- Mixture conditional-mean equations at every t0..32 and k0..t. Independent integer alive-path dynamic programs through horizons20 and512 for mixture monitoring and repeated fixed-time binomial tests.
- All1,763 mask phases at cyclic widths42 and43. Width42 has exactly five double fibers and no larger fiber; width43 gives1,763 distinct words.
- The exact hard-support symmetry counterexample is retained as evidence of the formerly missing premise, even after the chapter is repaired.

The independently reproduced crossing probabilities are0.018918991088867188 and0.04166675910417392 for the mixture at horizons20 and512, versus0.10661697387695312 and0.3577969973717913 for repeated fixed-time binomial checking. Exact fractions are in the JSON. The mixture's512-step probability is strictly greater than1/24 and no more than1/20. This reproduces the specific finite counterexample to the proposed1/24 limit; it does not establish the eventual limit.

## Coverage limits and final status

The published Erdos discrepancy theorem and time-uniform inference papers remain external leaves checked by E's source workflow; F did not independently authenticate every publication/version. The directly stated finite martingale argument was rebuilt here and is sufficient for the local threshold guarantee. No generic pattern predictor, prime asymptotic or arbitrary hash-performance theorem was inferred from these checks.

The corrected chapter preserves the appropriate distinctions between descriptive matches, exact arithmetic filters, statistical evidence and unobserved aliases. Its symmetry hypothesis now accounts for every factor in the actual filtering equation. Remaining unimplemented work is already identified as such, rather than being silently certified by the peer's agreement.
