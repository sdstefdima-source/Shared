# Family A audit - SM-2026-10-13-A

Primary verdict: correct only after the explicit domain, order, precision, field-characteristic, fiber, and complete-search restrictions stated in the replacement chapters. The manuscript gives self-contained proofs of its principal arithmetic claims. Standard Smith-form existence and Galois-ring terminology retain named external source dependencies. Historical cryptographic recovery and runtime claims are not upgraded to newly reproduced results.

## Reviewed sources and boundaries

The source-byte inventory is in checks/A_run/results.json and the validated version-2 computation manifest. The two large supplied reports were scanned throughout for topics, assertions, formulas, examples, external dependencies, and historical evidence labels. Detailed mathematical reconstruction focused on the family-A sections listed below; scanning the entire documents is not a claim that every incidental sentence in other families was independently proved here.

- Supplied source 01, Math_Work_Exact_Operational_Formalization_ASCII.txt: Part I definitions and composition; all Part II cyclic-group/CRT/digit/collision/epoch material; all Part III local-ring/principal-unit/logarithm/modular-matrix material; Part V bounded-signature embedding; Part VI bounded observations, target lattices, and exact search; Part VII finite-algebra and order-21 sections; formula, source, and final-composition appendices. Cubic, optimization, Fourier, and temporal sections were surveyed for connections and referred to their owning families.
- Supplied source 03, Cryptogram_Operational_Formalization_ASCII.txt: F1-F8 common contract; M1-M12 exact modular reconstruction; H1-H7 hidden-number material; V02-V03, V08-V10 residue shells, primitive-root lifting, sign/logarithm, and coupled monomial systems; transform atlas and embedded exact lattice implementation; all inventories and evidence statements. Cipher diagnostics, sieve, cubic, and geometry passages were surveyed and assigned to other families.
- Supplemental Modular Math Lab/Mathcrack.txt: complete arithmetic carrier/pullback specification, torsion/orbit extension, and cyclotomic continuation. Original claims were checked rather than inheriting later report titles.
- Supplemental Modular Math Lab/Mathcrack 2.txt: quotient-series explanation, order-21 operation, odd-order roots, power maps, crypto interpretation, polycyclic sketches, and operational summary. Its Feit-Thompson assertion is standard but not needed as a chapter dependency; no proof of that deep theorem is claimed here.
- Supplemental Modular Math Lab/Mathcrack 3.txt: full first plain-formula version, with repeated LaTex version scanned and compared by structure. Detailed sections: polynomial quotient, repeated factors, selectors, local/global powers, hidden-coordinate conjugation, all explicit toy values, cycle/order distinction, cyclotomic/Frobenius interpretation, solvable-series claim, and audit schema.
- Supplemental Hidden_Number_Lattice_Reconstruction_ASCII.txt: complete box-equivalence proof and the q=101 array/basis/decoder example read in detail, with its completeness/separation/interface sections surveyed against the chapter's independently reconstructed contract.
- Supplemental doubling_vortex_mathematics_extracted.txt: complete arithmetic types, full ambient graph, valuation/period proofs, reduction tree, sign-plus-log chart, finite/infinite distinction, and exact logarithm cutoff. Its independent geometric state spaces were left to the geometry family.

No direct historical challenge executable or positive ECDSA test fixture was present in these records. The historical success narratives are retained only as source-reported examples. Their absence does not affect the exact signing identity, which has a short proof and a directly checked standard source.

## Decisive corrections and their mathematical consequences

A-C1. Exact scalar order is essential. The input must use ord(g)=N, not merely g^N=1. A false order can invalidate the promised modulus of a projected exponent. Exact-order certification uses every distinct prime in a complete factorization; subgroup membership is a separate premise. Counterexample: C2 times C2 has elements killed by two outside the selected cyclic subgroup.

A-C2. Nonzero does not imply invertible. The linear congruence a*x==b modulo M must reduce by gcd(a,M), checking divisibility and changing the modulus. The displayed 6x==8 modulo14 has two canonical solutions; ordinary division with a claimed unique answer loses one.

A-C3. Compatible CRT modulus is lcm, not the product when factors overlap. The 12/18 example has true period36, not216. This correction preserves both bounded candidates29 and65.

A-C4. External residue M does not need to divide the group order, but residual order is then N/gcd(N,M), not N/M. The order12, modulus8, bounded example retains two aliases37 and61 with original period24. This distinction is especially relevant for external binary suffix information in odd-order groups.

A-C5. Bounds must remain exact and attached to original variables. A lattice or Smith coordinate change can skew the region. Congruence uniqueness is not integer uniqueness unless aliases are removed by an explicit interval. Rational reconstruction needs height and denominator conditions; 2AB<M proves uniqueness, not existence.

A-C6. A projection identifies only a fiber. A quotient result alone cannot be silently decoded as a full object, and maps into divisor/subgroup carriers are not automatically total on Z. The manuscript uses original-domain predicates and explicit coordinate maps instead.

A-C7. The fixed intersection operator is already idempotent. Iterating a static Phi(X)=X intersect E reaches its fixed point in one application. A useful operational iteration requires newly received information or state-dependent recomputation of proved constraints.

A-C8. Prime-power group digits are valid, standard Pohlig-Hellman mathematics. The repair is attribution and preservation of the actual prime-order leaf difficulty. A smooth address does not independently determine a coprime hard address. The finite F97 calculation and every scalar class were rechecked.

A-C9. Algebraic collision-state transport is valid; old walk continuation is a separate dynamical assertion. Epoch and coefficients must remain attached. Exact element equality, not hash equality alone, authenticates a collision relation.

A-C10. Principal-unit digit recovery does not need an irreducible defining polynomial, only the stated monic commutative free coefficient algebra and odd prime. Irreducibility is needed for field residue/Galois-ring terminology. This expands the useful constructive theorem while keeping the structural vocabulary accurate.

A-C11. The square first-layer rank criterion is necessary and sufficient on the full exponent domain for k>=2. A fresh peer review detected that the first draft had not written this precision guard explicitly. At k=1, P=1 and both domain and principal-unit target are trivial, so the unique map is bijective even for a zero first-layer matrix. The guard and trivial branch were added before manuscript freeze. Singular systems need all fibers. The kernel vector p^(k-2)*v directly witnesses noninjectivity; ordinary rational full rank does not suffice over a residue ring.

A-C12. Dividing log(u) by p loses one absolute precision digit. Nonunit denominators in the series are canceled before their unit parts are inverted. A safe tail cutoff is proved termwise; the first zero term is not a valid stopping test.

A-C13. The binary leading-term formula differs. Modulo8, 3^2=1 rather than5. Binary parity branches or a chart restricted to1+4O repair the method. Full 3-adic units likewise require a sign coordinate: exp(log(-2))=-2, not2.

A-C14. Nonunits belong to valuation strata, not multiplicative groups. The doubling graph modulo9 is exactly one fixed zero, one two-cycle, and one six-cycle. Modulo3^k, the complete layer counts sum to3^k. A digital-root display must not count0 and9 as distinct residues.

A-C15. Power-map orbit length differs from the group-element order. The r->3r map modulo7 has period6; that6 does not divide group exponent105 in the toy product. Correct cycle comparison uses ord_(N/gcd(N,r))(k).

A-C16. Cyclotomic zero sets cannot be joined as if the ring were an integral domain. Modulo15, Phi1(4)=3 and Phi2(4)=5 are nonzero while their product vanishes. Primitive-order identification also needs characteristic coprime to the index. A power image is different from a root-of-unity kernel.

A-C17. Linear conjugation of a reversible function stays reversible, but the coordinate map need not be a ring automorphism. Frobenius in mixed characteristic is not raw pth powering. Z/9Z supplies the immediate counterexample2^3=8 while its degree-one Frobenius lift is identity.

A-C18. Quotient-series inversion requires an inverse on every conditional coset fiber. The Z/4Z map fixing even residues and collapsing1,3 has invertible parity quotient and invertible even-subgroup restriction, yet no full inverse. A group homomorphism or verified fiber inverses can supply the missing implication.

A-C19. The HNP box/lattice map is a genuine bijection with centered scalar coordinate and errors strictly below half a period. Sphere membership is an enclosure rather than the whole observation condition. Basis reduction changes coordinates, not the solution set; the scalar is an original coefficient or point coordinate, not a last reduced coefficient.

A-C20. Exact marker-bearing ECDSA lattice membership does not imply shortest-vector or basis-row recovery. The same embedding always contains the shorter marker-zero vector(0,...,0,Bq,0). A universal recovery conclusion needs a separate slice/CVP/decoding theorem. Low-s normalization changes effective nonce sign, so a small original nonce need not remain small in the displayed signing equation.

A-C21. A shortest group equation ax=y is not a difficult cryptographic equation by default. In the explicit order21 semidirect product, the quotient-first multiplication equation is directly invertible in its public coordinates. No element has order21. Reversible roots and unknown-base logarithms remain distinct tasks.

## Proof dependencies and obligations

| Manuscript claims | Required leaf | Audit result |
|---|---|---|
| A-P1,A-P2,A-P3 | Integer divisibility, Bezout inverses, determinant bound | Passed; explicit complete proofs |
| A-P4,A-P5 | Exact cyclic order and given prime factors | Passed under declared inputs; constructive digit proof |
| A-P6 | Public free coefficients, odd p, invertible square first layer | Passed; constructive all-target proof and final-layer necessity |
| A-P7 | Integer Smith form plus unimodular orientation | External existence checked; internal modular fibers and count passed |
| A-P8 | Polynomial Bezout and coprime factors | Passed; both local selectors and global reconstruction |
| A-P9 | Centered scalar interval, error widths<q/2 | Passed; both directions and unique witness proved |
| A-P10 | Full coefficient traversal in a containing sphere | Passed as algorithm contract; exact endpoint arithmetic tested |
| A-P11 | Odd/even valuation law and unit count | Passed; binomial proof and complete finite layer tests |
| Historical signature runs | Complete challenge inputs and executed solver | Not addressed as reproduction; no universal inference |

The proofs are self-reviewed derivations. Agreement with supplied audit reports or a finite test is not labeled an independent universal proof. The original-operation checks are computationally independent of the specific recovery formulas wherever practical.

## Literature checks conducted on 13 October 2026

A-R1: author-hosted original Pohlig-Hellman PDF, Sections III-IV, authenticated and extracted. Its prime-field operation model was distinguished from the general cyclic-group proof supplied locally.

A-R2: official HAC Chapter3 PDF, Algorithm3.63 and Facts3.62/3.65, authenticated and extracted. Given factorization is retained in the cost statement; randomized-rho timing requires its random-function model.

A-R3: original Numdam archival Raghavendran paper, Section3.9 Theorem9, printed page215 onward, authenticated and extracted. Source parameters GR(p^(nr),p^n) map to residue degree f=r and precision k=n. Only the odd-prime part is used for structural context.

A-R4: author-hosted Stanley manuscript, Theorem2.1(4), authenticated and extracted. The existence of Smith form over a principal ideal ring includes Z. The manuscript convention is D=UCW, x=Wz, avoiding reversed column transforms.

A-R5: Boneh author publication page authenticated, including title, authors, venue, year, and historical HNP formulation. An attempted guessed PDF URL failed. No full-paper theorem is cited as a uniform recovery guarantee, so the attribution remains properly scoped.

A-R6: official SEC1 version2.0 PDF authenticated through body/header and Sections4.1.3-4.1.4. Search extraction called the file version1.9 in metadata, while the document body and stated edition are version2.0. The signing equation and hash-conversion premise were checked in the actual document.

A-R7: Conrad author notes authenticated, Theorems8.5/8.13 extracted. Exact inverse domains are valuation>1/(p-1), giving pZ_p for odd p and4Z_2 in the binary scalar case. The coefficient-algebra transfer is explained by the chapter's commutative formal-series and convergence argument.

Durable URLs and complete bibliographic identifiers are in the chapter. Standard results are not presented as original Stefan discoveries. Stefan's contribution is the common operational organization of these methods and applications.

## Exact finite computation

Command: python3 stefans_math/checks/A_verify.py. The sealed version-2 run records its actual argv with an explicit result destination, Python version, source hashes before/after, output hashes, UTC start, runtime, exit status, and enforced caps. Manifest: checks/A_run/manifest.json. Validator returned "valid evidence record; mathematical interpretation requires review."

The execution completed successfully with all 651,719 assertions passing. Full counts are in checks/A_results.json and checks/A_run/results.json. No randomness or sampling was used. The major input families are:

- 22,140 complete scalar congruences for M=1..40, all a,b residues, checked against direct residue enumeration.
- 18,496 generalized CRT instances for both moduli1..16, all residue pairs, checked against direct enumeration over the lcm period.
- Every96 scalar in F97's base-five cyclic group, including576 digit tests and96 full Pohlig-Hellman reconstructions.
- 20,160 arbitrary external-residue/bound instances: all96 targets, M1..20, all residues, integer interval[-29,67]. The residual equations, aliases, and nonmembership branches were checked against direct original powers.
- 538,083 ordered principal-unit pair checks for log-product addition at k=2,3,4, plus819 complete coupled digit recoveries. Ring multiplication was the independent original-operation oracle.
- All128 polynomial quotient elements for CRT reconstruction and reversible component powers; binary polynomial arithmetic implements the original ring definition.
- 6,214 full two-observation HNP families for q=3,5,7 and widths0,1 under the strict half-period condition. Complete box-point enumeration was compared with complete scalar enumeration.
- Actual rational Gram-Schmidt/nearest-plane decoding of the q101 example, including original coefficient transport.
- 13,175 exact lattice branch-endpoint comparisons over the declared rational centers/allowances, checked with squared Fraction inequalities.
- Complete doubling graphs for k1..7, plus2,186 unit exponent inverses, all original residues rather than samples.
- All9,261 associativity triples of the order21 semidirect product, and all21 inverse-square and actual element-order checks.

Universal correctness remains a proof obligation. The finite suite audits the formulas and examples at these stated bounds; it does not certify large cryptographic recovery, historical performance, arbitrary machine-integer implementations, or inaccessible project conversations.

## Self-review and remaining scope

The chapter was proofread in ASCII with its shared notation and labels. No second-person pronouns occur. It has three chapter-level units and twelve substantial worked examples, together with answered exercises. No speculative security claim remains in its theorem statements. General high-dimensional lattice or singular-family enumeration can remain expensive; the manuscript gives exact output meaning without an unproved runtime guarantee.

Cross-family notices sent to the coordinator: a completed-square congruence may add roots when4a is noninvertible; arbitrary repeated-step state machines are not automatically cyclic group translations. Their full polynomial/dynamical treatment belongs to the corresponding chapter owners.
