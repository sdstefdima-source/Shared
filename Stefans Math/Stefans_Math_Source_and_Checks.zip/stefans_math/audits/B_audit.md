# Family B audit - p-adic coordinates, coupled exponents, and cubic reconstruction

Base: SM-2026-10-13-A. Audit date: 2026-10-13. Scope owner: family B.
Chapter source: chapters/B_padic_cubic.md. Original supplied reports unchanged.

## Normalized target and primary verdict

Target claim: for an integer cubic f with nonzero leading coefficient, a finite certified integer interval D, complete local root enumeration, complete prime-power child enumeration, compatible CRT joins, and final exact substitution of every remaining bounded candidate, the returned set equals {x in D:f(x)=0}. Rational mode applies the proved monic scaling and returns exactly all rational roots after deriving its complete bound. Resource exhaustion remains unresolved.

Primary verdict: **proved as written** for this normalized bounded integer/rational contract. The contract deliberately does not claim all real/complex roots, global logarithmic linearization, a generic discrete-logarithm attack, or proof-assistant certification. Those broader claims would be different statements, and some are explicitly refuted below.

Dependencies: coefficient-derived bound or declared interval -> complete local seed roots -> integral polynomial difference identity -> all next digits -> compatible congruence intersections -> exact bounded fibers -> final substitution. Rational mode adds the monic-root integrality lemma. Optional valuation, Newton, logarithm, and projective transforms have separate guards and are not required for the complete finite core.

## Source scope actually consulted

- 05-Cubic_Ratchet_Formalization_ASCII.txt: entire 2,516-line report, including all 28 sections, analytic precision modules, reference implementation, historical validation description, reference guide, and final composition argument. The embedded reference code was inspected. The historical packaged verify.py was not supplied independently here and its 96,949-case total is not relabeled as a fresh run.
- 01-Math_Work_Exact_Operational_Formalization_ASCII.txt: Parts III and IV, lines 425-880; local-ring theorem, coefficient layers, coupled exponent proof, series precision, singular modular system, worked degree-two ring, binary branches, Frobenius distinction, cubic interfaces. Also relevant formula and reference pointers inspected via search.
- 03-Cryptogram_Operational_Formalization_ASCII.txt: M6-M8, M12, C1-C15 and worked/audit boundaries, concentrating on valuation strata, free coefficient algebras, full modular families, rational uniqueness, affine/projective charts, and nonlinear cubic coupling. Its statements about earlier package reruns remain source-reported observations.
- 04-Solvers_Certified_Operationalization_ASCII.txt: sections 2.6-2.7, lines 370-430; separation of real spectral logarithms and principal-unit logarithms, all Hensel cases, and bounded CRT completion. Finite-group sections were used only as notation consistency pointers.
- supplemental/doubling_vortex_mathematics_extracted.txt: sections 6-7 and 9, source-access boundary, exact sign-plus-logarithm coordinate, finite logarithm residues, and rational scale orbit. Its three inaccessible original Zenodo PDFs were not claimed to have been inspected. The chapter preserves that boundary.

## Claim cards and decisive corrections

| ID | Claim or proposed inference | Verdict | Correction or decisive evidence |
|---|---|---|---|
| B-C1 | A residue modulo p^k determines an ordinary integer | Correct only with a stated restriction | Retain x=r+p^k*t; bounds or additional observations must constrain t. |
| B-C2 | Extracting p^t leaves the original k unit digits | Refuted | 75 modulo 243 gives unit 25 modulo 81, not modulo 243. Division consumes t digits. |
| B-C3 | Valuation makes all arithmetic linear | Refuted | v_3(75)=v_3(6)=1 but v_3(75+6)=4. Multiplicative valuations add; sums need cancellation. |
| B-C4 | A unique smallest polynomial term valuation can cancel to zero | Refuted | Divide by the minimum power and reduce modulo p; exactly one nonzero residue remains. |
| B-C5 | Logarithms turn a general cubic sum into a linear equation | Refuted | Only multiplicative principal-unit relations have the additive product law. The explicit cubic remainder and Cardano product coupling remain. |
| B-C6 | The logarithm converging on 1+2Z_2 is an invertible chart | Refuted | log_2(-1)=log_2(1)=0. Use 1+4Z_2 and retain scalar sign or coefficient parity branches. |
| B-C7 | One binary sign bit handles every unramified coefficient ring | Correct only with a stated restriction | A sign normalizes scalar Q_2 units. For residue degree d>1, U1/U2 has d directions; retain every parity vector. |
| B-C8 | Monicity alone makes an arbitrary coefficient quotient a Galois ring | Correct only with a stated restriction | Irreducibility modulo p is required for the unramified/Galois-ring interpretation. The odd-prime principal-unit digit theorem itself needs only the commutative free coefficient algebra. |
| B-C9 | Singular Hensel parents can be solved by inverse derivative | Refuted | Derivative residue zero gives all or no next digits. X^3-3 dies modulo 9; (X-2)^3 branches. |
| B-C10 | Raw root counts must decrease during a ratchet | Refuted | (X-2)^3 has counts 1,3,9,9,27,81,81,243. The represented ordinary candidate enclosure is nested. |
| B-C11 | Tangent precision can be increased without checking its remainder | Refuted | X^3+X^2-80 at center 1, displacement 3, has linear part -63 and remainder 63. Modulo 27 a tangent-only filter deletes root 4. |
| B-C12 | A strong Hensel seed gives uniqueness throughout its original residue class | Correct only with a stated restriction | With s=v_p(f'(r)) and v_p(f(r))>2s, uniqueness is in v_p(alpha-r)>s. Finite congruence roots can still have aliases. |
| B-C13 | Repeated prime-power observations multiply independent moduli | Refuted | Joining p^k and p^(k+1) gives lcm p^(k+1), not p^(2k+1). |
| B-C14 | M greater than interval width proves a unique root overall | Refuted | X^3-X in [-10,10] has five survivors modulo 35; final substitution gives three actual roots. Uniqueness is per class. |
| B-C15 | M equal to interval width suffices for per-class uniqueness | Refuted | Both 0 and 5 belong to class 0 modulo 5 in [0,5]. The inequality is strict. |
| B-C16 | A p-adic root is automatically rational | Refuted | X^3-2 has a simple root in Z_5 and no rational root. |
| B-C17 | A modular rational residue establishes existence | Correct only with a stated restriction | M>2AB proves at most one reduced candidate in the stated height box; existence requires a witness and denominator invertibility. |
| B-C18 | Independent cube-root choices reconstruct a depressed cubic | Refuted | For Y^3-3Y-2, u=1 and v=rho have correct cube sum but wrong product, so u+v fails. Keep uv=1. |
| B-C19 | A degree drop under a fractional coordinate removes a root | Refuted | X(X-1)(X-2), X=1/Y, becomes quadratic 1-3Y+2Y^2; X=0 moved to Y=infinity. |
| B-C20 | Doubling is a multiplicative-group automorphism | Refuted | u->2u moves identity 1 to 2. It is translation by 2, conjugate to sign flip plus additive translation. |
| B-C21 | Every finite doubling cycle implies a periodic nonzero Z_3 orbit | Refuted | Every finite unit quotient cycles, but (2^n-1)u=0 forces u=0 in Z_3. |

Several supplied current reports already contain these restrictions. The synthesis preserves and operationalizes them rather than attributing every correction to a new error found in the supplied final documents.

## Obligation matrix

| Obligation | Status | Evidence boundary |
|---|---|---|
| Root bound for integer cubic | Passed | Leading-term domination proof, including zero lower coefficients and negative a. |
| Rational monic scaling | Passed | Exact identity and elementary coprime-denominator proof; 500 fresh complete comparisons. |
| Complete next digit at p=2,3 | Passed | Integral cubic identity; no factorial inverse; direct finite root oracle. |
| Singular all/no alternatives | Passed | Complete digit rule plus repeated-root and dead-branch counterexamples. |
| Unit Newton block | Passed | Residual cancellation proof; 968 fresh complete parent-fiber comparisons. |
| Strong Hensel guard and ball | Passed | Explicit normalized polynomial; primary theorem checked; finite identity check supplementary. |
| Odd-prime log/exp inverse domain | Passed | Term valuation and formal composition proof; primary source exact domains checked. |
| Binary log/exp domain | Passed | Depth-two restriction; source torsion counterexample; fresh inverse and product comparisons. |
| Safe modular division | Passed | Numerator computed at k+e digits before exact cancellation. |
| Ternary unit cubes | Passed | Image of multiplication by 3 on 3Z_3; extra input digit retained; fresh complete image comparison. |
| Coupled square exponent recovery | Passed | Layer proof and first-nonzero-digit kernel proof; all exponent pairs for k=2,3,4. |
| Singular modular family | Passed with named structural input | Integer Smith decomposition exists by classical theorem; diagonal congruence families proved internally. General Smith backend is not implemented in B_verify.py. |
| Binary parity reconstruction | Passed | Exhaustive first-layer branches plus safe logarithm; all eight odd targets modulo 16 checked. |
| Exponent order of 2 at 3^k | Passed | Binomial valuation proof and full finite cycles through k=7. |
| Doubling sign/translation map | Passed | Sign split and principal-unit chart; every finite unit at k=2..6 checked. |
| Global CRT compatibility | Passed | Residual congruence proof and explicit class tests; broad CRT exhaustive implementation audit belongs to family A. |
| Bound-pruned completion | Passed | Strict spacing argument and final substitution; exact 225-element trace reproduced. |
| General real/complex root algorithm | Out of scope | Need algebraic-number output or rigorous real/complex isolation; local integer core supplies neither automatically. |
| General ramified analytic engine | Out of scope | Fractional valuation scales and extension-field guards are identified, not implemented. |
| Efficiency against industrial solvers | Not addressed | No benchmark or asymptotic speedup imported from operation counts. |
| Full proof-assistant certification | Not addressed | No Lean/Isabelle run; formalization references do not certify this chapter. |

## Primary sources rechecked

Checked 2026-10-13 using the authenticated author or archive URLs. These source files were not copied into this family's disjoint write scope; the URLs and exact result locators provide provenance. Source authentication, statement extraction, and project applicability were all checked for the listed dependencies.

1. Keith Conrad, Hensel's Lemma, author-hosted 25-page PDF. Theorem 2.1 gives f(a)==0 modulo p with derivative nonzero; Theorem 4.1 gives |f(a)|_p<|f'(a)|_p^2 and uniqueness within |alpha-a|_p<|f'(a)|_p. Valuation translation is h>2s and v_p(alpha-a)>s. The source permits integral coefficients and the binary prime. https://kconrad.math.uconn.edu/blurbs/gradnumthy/hensel.pdf
2. Keith Conrad, Infinite Series in p-adic Fields, author-hosted 42-page PDF, Theorems 8.5,8.7,8.13. The isometric inverse disc has v_p(y)>1/(p-1); integral Q_p inputs give pZ_p for odd p and 4Z_2 at p=2. The source explicitly explains log(-1)=0. The chapter retains the narrower inverse chart rather than confusing it with the wider convergence domain. https://kconrad.math.uconn.edu/blurbs/gradnumthy/infseriespadic.pdf
3. R. Raghavendran, Finite Associative Rings, Compositio Mathematica 21(2), 1969, 195-229, original Numdam archive PDF. Theorem 9, printed p.215, describes the odd-prime principal group as d cyclic factors of order p^(k-1). Its n,r correspond to k,d. The chapter's coefficient proof establishes the constructive matrix criterion directly and does not rely on unread algorithm details in the structural theorem. https://www.numdam.org/item/CM_1969__21_2_195_0.pdf
4. Richard P. Stanley, Smith Normal Form in Combinatorics, author manuscript dated 18 April 2016, Theorem 2.1(4). Integer matrices have Smith form; U,V are chosen unimodular. The diagonal divisibility and solution count are derived internally. https://math.mit.edu/~rstan/papers/snf_survey.pdf
5. NIST DLMF, Section 1.11(iii), cubic equations, equations 1.11.12-1.11.15. The affine depressed-cubic coefficients and retained product choice match after accounting for the reference's scaled radical A,B. This is supporting attribution; the cubic sum/product identities are rederived. https://dlmf.nist.gov/1.11

No novelty search or new-theorem claim was made. Hensel lifting, principal-unit logarithms, CRT, Smith form, rational reconstruction, and the cubic resolvent are established mathematics. Stefan's organizing contribution is the use of a common reconstruction workflow and compatible numerical coordinates. The chapter presents that organization as a usable synthesis.

## Fresh exact computation record

Command from project root:

```text
python3 stefans_math/checks/B_verify.py
```

The concrete execution is also recorded by B_record_run.py in the version-2 B_computation_manifest.json. The shipped mathbox validator accepted it with --root /workspace/scratch/e552861014e9; all pinned execution inputs remained unchanged and declared output hashes matched. Validation checks the evidence record, not its mathematical interpretation.

Arithmetic: Python arbitrary-precision integers and fractions.Fraction. No floating mathematical comparison. Runtime and software version are recorded in checks/B_results.json. The manifest records the script digest and input digests, including the supplemental doubling extraction. A runtime is an observed duration, not a benchmark.

| Family | Case groups | Exact independent check |
|---|---:|---|
| Complete prime-power cubic roots | 3,000 | 250 cubics, p=2,3,5,7, k=1,2,3; every residue directly enumerated. |
| Log Fraction oracle, inverse, precision | 201 | Every safe input at p=2,3,5 and k=2,3,4; separate modular-term and rational-sum evaluation. |
| Exp Fraction oracle and inverse | 201 | Every safe additive input at the same precision. |
| Log products | 17,115 | Every ordered principal-unit pair at the stated primes/precisions. |
| Ternary exponent recovery | 2,186 | Every exponent residue modulo 2*3^(k-1), k=1..7. |
| Ternary cube extraction/rejection | 726 | Every unit input modulo 3^(k+1), k=1..5; independent complete cubing image. |
| Unit Newton complete fibers | 968 | Every applicable parent of the 250 cubics at p=2,3,5, k=1,2; every block child directly evaluated. |
| Binary parity families | 8 | All odd targets modulo 16, all exponent residues modulo 8. |
| Doubling sign/translation | 726 | Every unit modulo 3^k, k=2..6; inverse coordinate and translated step. |
| Coupled ring exponent pairs | 819 | All pairs modulo 3^(k-1), k=2,3,4; residual digit recovery, distinct-image table, and logarithmic matrix. |
| Main cubic refinement trace | 5 | Explicit candidate sets inside [-112,112], containment, true-root retention, published counts. |
| Strong Hensel rescaling identity | 21 | X^3-10, p=3, r=4, integer Z=-10..10; exact rational identity. |
| Singular cube branch counts | 8 | Complete root lists through 3^8 and exact divisibility characterization. |
| Rational monic scaling | 500 | Full coefficient family a in {-2,-1,1,2}, b,c,d in [-2,2]; independent rational-root candidate theorem. |
| Total | 26,484 | Case groups as defined by the script, not a count of universal theorems. |

The script also checks the mixed-CRT nonroot survivors and the rational height witness, without including them as inflated additional counted groups. No prior 96,949-case or million-case total was imported. The current checks are deliberately smaller, exact, reproducible, and targeted at exceptional domains.

Residual limitations: the two ring routes share coefficient multiplication; finite checks are not proof of all inputs; no exhaustive test of arbitrary Smith decompositions, ramified extensions, or projective charts was performed; timing is not an efficiency theorem. The mathematical proofs and the finite computation serve distinct evidence roles.

## Final mathematical proofreading

Entire family-B chapter self-reviewed for local definitions, ASCII congruence syntax, type distinctions, exceptional prime guards, precision formulas, and reference orientation. A repeated stage/index j in the coupled residual formula was replaced by stage ell and product index j. The Smith diagonal symbol was renamed J to avoid competing with original domain D. No source files were altered. ASCII-only and absence of second-person pronouns checked mechanically.

The source core's strongest safe result survives: complete bounded numerical reconstruction can find exact integer/rational answers without a symbolic cubic formula, while its genuinely linear steps remain local, filtered, or multiplicative. Additional real/complex output and general multi-variable algebra require further solver contracts, which are not supplied by p-adic digits alone.
