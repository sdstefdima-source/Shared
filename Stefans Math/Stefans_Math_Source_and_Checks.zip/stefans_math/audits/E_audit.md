# E audit: patterns, arithmetic regularity and statistical evidence

Base revision: SM-2026-10-13-A. Primary verdict: correct only after a stated restriction. The compilation retains functioning exact constructions and conditional statistical procedures, while restricting interpretation to the domain, observation map, evidence law and finite range actually justified. Historical assertion totals are not accepted as proof or represented as current executions.

## Sources inspected

The seven supplied files 06-12 were read in full, totaling 19,965 source words. Overlap was unified rather than concatenated.

| Source | Sections used | Resulting chapter coverage |
|---|---|---|
| 06 Two Window Mathematical Investigation | 1-10, references | E1 moving heads and memory; E2 offsets/product roots; E3 partitions, overlap and evidence |
| 07 Statistical Algebra State Machines | common interface; noisy reconstruction; field symmetry/coding; bounded paths; sequential evidence | E3 filtering, symmetry, survival conditioning, confidence sets |
| 08 Arithmetic Connections Integrated | quadratic norms/offsets, digit products/block summaries, reconstruction and entropy distinctions | E2 split norms and arithmetic masks; E3 support versus concentration |
| 09 Primes Offsets Padic Machines | all thematic sections | E2 wheels, digit carries, completed characters, root-tree interpretation |
| 10 Erdos Primes Parity Quadratic | 1-11 | E2 progression coupling, finite search, prime-sign moments and theorem boundary |
| 11 Construct Pattern Finder v2 | all sections | E1 walks, verified rolling hashes, patch symmetries and indexing contracts |
| 12 Construct Pattern Finder | all sections | E1 constructs and representations; E3 version spaces, active probes and tolerance |

Additional original files were inspected by relevant construction, not treated as newly certified sources: Math Prime Numbers.txt; Math Prime Numbers(1).txt, including primorial generator, split norm, square-root closure and bulk sieve; fractal database hashing.txt, initial construction, probe design, invariants and prototype; Number Pattern Finder/Mathproject.txt and Mathproject Notes.txt, square-shell theorem, roots-of-unity projector, higher-root filter, prime-power/Mobius counting, zeta truncation; Factorization and Symetry in Numbers.txt, phase kernel, aggregates, precomputation, best-first/fallback; MH SECURE/ai_statistics_logic_investigation_chat.txt, dependence, confidence, source blending and validation passages. The two resonator notes and two primorial files largely repeat their own constructions. No claim that every retrieved historical discussion was exhaustively audited is made.

## Dependency and obligation checks

Exact constructs reduce to complete typed comparisons. Translation indexing reduces to telescoping. Wrapped walk period reduces to translation order in a finite product group. Prime-wheel counts reduce to forbidden residue cardinalities and CRT. Square-shell primality reduces to the least-prime-divisor bound. Higher-root roughness reduces to a strict product bound. Product-root termination reduces to the explicit valuation-one identity. Discrepancy search reduces to checking every newly completed progression prefix. Statistical evidence reduces to a declared conditional input law, a verified martingale identity and its threshold argument. The general infinite discrepancy theorem has an external source leaf; no custom proof is claimed.

| Obligation | Audit status | Decisive check |
|---|---|---|
| Raw equality, translation and affine matching distinct | passed | Constant-source and scale-zero cases kept explicit |
| Boundary-only rolling update | correct under common one-step movement | Every short binary tape comparison independently checked |
| Count-state Markov memory | refuted without additional state | Width-two count-one words have different successor laws; arbitrarily long suffix argument |
| Coordinate revisit and phase | passed after retaining augmented state | right,right,stay on 1-by-2 grid |
| Full-cycle perturbed probing | refuted as originally inferred | Period-four offsets on five buckets visit only two buckets in first five probes |
| Sampled frequency complexity | refuted for the declared high modes | 2^(j^2)==0 modulo 2^16 for j>=4 |
| Shell as finite field | ill-typed original wording repaired | Shell is an interval subset of integers, not a field |
| Prime versus rough survivor | passed after restriction | 77 survives cube-root filter at X=121; fails prime test |
| Field invariant alias and code | passed | Six orbits; minimum distance three; all 78 clean/single-error records |
| Product root versus common root | passed after distinction | 41*41*43 zero modulo 41^2 despite nonzero factors |
| Statistical independence | conditional on exact source model | Copies do not multiply likelihood; overlapping sums share source indices |
| Sequential false-alarm claim | passed under stated conditional fair law | Direct mean-one proof; exact crossing DP; duplicated-source counterexample |

## Decisive corrections and strongest safe statements

E-C01. Counts, equal sums, ranks, residues and valuations are observation maps with different fibers. The corresponding relations cannot be promoted into equality of original data. Translation of integer windows is exactly indexed by equal difference words plus an offset witness. Numerical affine matching remains APPROXIMATE and records support, tolerance and degeneracy.

E-C02. A current count word need not be a Markov state. The ordered window or a sufficient belief state is required; shared-tape revisits additionally retain index history. The infinite-order observed-count statement has a direct proof, while fresh finite enumeration checks identical suffix lengths one through eight.

E-C03. A nonzero coprime linear probe stride guarantees a permutation only for the linear orbit. Arbitrary perturbation can collapse it. A proved outer bucket permutation repairs coverage. Period-N perturbations with gcd(N*g,m)=1 give m*N-step coverage, not m-step coverage. A capped search needs overflow handling and cannot infer a miss from an incomplete traversal without its insertion invariant.

E-C04. Finite trigonometric sums are smooth; lattice aliasing can make arbitrarily high displayed frequencies constant. Different deterministic phase salts do not prove independence, uniform occupancy, security or superior performance. The compilation treats this layer as a candidate generator with explicit baseline comparisons. Final integer lookup tables require preserved construction semantics or saved values to avoid quantization changes.

E-C05. Primorial endpoints require k>=1 in the declared W=210 family. The literal W^n-1 factorization excludes that family, not all nonlinear center rules. The scheme tests a subfamily of twin candidates. Its split quadratic algebra is a product of fields. Zero residues are kept separately from discrete logarithm coordinates. Small-prime survival remains an enclosure until the complete square-root test finishes.

E-C06. The roots-of-unity projector proof uses a geometric sum. For composite d and noncoprime n, the phases can repeat rather than form d distinct roots. The identity remains correct. The square shell is a finite set. Higher-root survivors have at most k-1 prime factors counted with multiplicity; that bound is one-way. Finite zeta-zero truncations do not replace the exact arithmetic decision without an independently certified error bound.

E-C07. Euler-polynomial initial primes have a finite elementary divisibility/size proof. Raw masks omit equality cases and retain composites. Common, union and product roots differ over residue rings. At p=h=163, product-root counts one,163,zero are exactly verified by compatible child enumeration, with general termination supplied by the explicit valuation identity.

E-C08. Arithmetic drift, entropy and discrepancy are distinct quantities. A finite sign generator can have an unbounded running sum. Completely multiplicative prime-sign ensembles differ from independent integer signs. The exact N=20 moments are mean four, second moment 42 and variance 26; the general infinite discrepancy result is attributed to Tao.

E-C09. Repetition of symmetry-invariant observations cannot separate aliases when prior, transitions, likelihoods and every applied hard support set preserve the symmetry; it can improve orbit evidence and error protection. Independent peer review by family F identified the initially omitted hard-support hypothesis. The chapter was repaired: exchanging candidates2 and5 preserves their modulo-three reports, but the independent bound x<3 separates them. Adaptive action updates must preserve the same hard-support invariance. Fresh direct checks now cover both invariant and separating support cases. Confidence sets, posterior probabilities and hard support have different semantics. A 99-point parameter grid supplies membership coverage only for a true grid parameter under its sampling model.

E-C10. Exact local p-values do not calibrate a selected search or timeline. A conditional mean-one evidence process supports an anytime threshold, and a fixed mixture preserves validity even with shared observations. A retrospective maximum has no automatic preservation. Duplicating five source bits gives an explicit 6.25% counterexample to an incorrectly imported 5% bound.

Factorization-specific findings were sent to the coordinator: the complete phase precomputation already evaluates every candidate remainder; early best-first return certifies some factor rather than the largest factor below sqrt(n); expected-speed claims need an input distribution or benchmark; the descending scan is trial division regardless of its label; budget exhaustion is inconclusive until fallback completes; the source's demo wrapper provides fallback but its named dyadic function alone does not.

## Primary source checks

E-R1: Yeh et al., journal author PDF, DOI 10.1007/s10618-017-0519-9. Source authentication and definitions 2-7 inspected. It uses z-normalized Euclidean windows, whereas the compilation defines Hamming matching and proves its own update. No metric-transfer guarantee is imported.

E-R2: Tao, Discrete Analysis 2016:1, arXiv:1509.05363v6. Exact primary PDF inspected at Corollary 1.2 and raw/completed-character examples. Every infinite sequence taking only +/-1 has unbounded homogeneous-progression discrepancy. Zeros in raw characters fail the hypothesis. A restricted custom family does not replace the general theorem.

E-R3: Howard et al., arXiv:1808.03204v8, primary HTML. The initial PDF request failed; the same exact version's HTML supplied Lemma 1, equation 2.11 and proof section 6.1. Nonnegative supermartingale with initial value one yields threshold-a ever-crossing probability at most 1/a. The compilation proves its special discrete-bit application directly.

E-R4: Howard et al., arXiv:1810.08240v9, primary PDF. Method-of-mixtures/inversion passages and beta-binomial context inspected. Application to the specific Bernoulli likelihood ratio is derived explicitly, including one common alternative parameter across the whole record and finite-grid coverage semantics.

The Aho-Corasick historical paper request failed with a gateway error. Its detailed external complexity theorem is not used. The dictionary description is operational context, with correctness requested by direct match-set comparison. Broader Cobham, Mauduit-Rivat, Liouville asymptotics, number-field class-number proofs and zeta explicit-formula analytic hypotheses are not load-bearing results in these chapters. No novelty search was performed.

## Fresh computation contract

Command: python3 stefans_math/checks/E_verify.py . Arithmetic: integers and fractions.Fraction; no random sampling. Complete tested families and bounds are recorded in E_manifest.json. E_results.json preserves exact fractions and explanatory decimal displays. The script regenerates both output and version-1 provenance manifest; timestamps and runtime may differ while scientific fields remain unchanged.

Fresh results passed 60,182 assertions in about nine seconds after final editorial review. Coverage includes every binary tape of length 2..7 for the diagonal update; 1,344 wrapped step-word machines; exact rational matrix ranks at M,w=1..10; wheel offsets 1..64; count-memory suffixes 1..8; square shells p=2,3,5,7,11 and higher roots k=2..5; finite Mobius inversion x=2..64; dying product roots to 163^3; 1763-mask components and identifying widths42/43; binary carries n=0..4095,k=0..8; all discrepancy sign words through N=12 at bounds one/two; complete256-element prime-sign ensemble through N=20; completed-character prefix identities through4096; every GF9 orbit code and78 error records; symmetry support cases; exact sequential crossing probabilities through512; and99-point confidence-grid updates through256.

The tests have independent representations where useful: direct comparison versus boundary updates, enumerated permutation walks versus gcd/lcm formula, rational row reduction versus kernel-dimension formula, direct residue enumeration versus CRT product, direct sign-word constraints versus historical prefix-search counts, explicit prime-factor choices versus moment formula, exact DP versus the martingale upper bound. Assertion counts are workloads, not independent pieces of mathematical evidence.

Independent family D review reconstructed the GF9 code from all nine field-coordinate pairs: its fifteen unordered codeword distances consist of three distance-three pairs and twelve distance-five pairs, confirming the minimum-three argument. It also reconstructed the rational cyclic-window kernel proof and requested explicit positive integer M,w in the local theorem statement; the statement now carries that guard. Width zero is deliberately outside the theorem and finite checks. Independent family F review supplied the substantive missing hard-support invariance in E3.2, now corrected as recorded above. These reviews strengthen the documented derivations; actor count is not an independent proof certificate.

Residual limits: self-review shares definitions with the compiled prose; no external proof assistant is run; no OS resource cap is imposed; the manifest uses the supported legacy version-1 schema. Old JavaScript programs, browser screenshots and large benchmarks from source-report packages were not automatically available as executable inputs and were not rerun here. The new checks intentionally cover representative mechanisms and stated finite claims, not every historical output. The chapters distinguish self-contained proofs, finite computations, approximate displays and declared stochastic assumptions.
