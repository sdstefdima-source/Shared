# C independent review of D spectral and geometric chapters

Base: SM-2026-10-13-A.
Reviewed artifact: chapters/D_spectral_geometry.md, all556 lines as supplied.
Primary verdict: proved as written, for the internally proved mathematical
claims under their explicit model hypotheses. Recorded finite measurements
retain their finite/approximate grade. This review does not upgrade external
source authentication or historic software execution claims.

## Review method and scope

The reviewer read the complete manuscript and freshly derived the load-bearing
formulas from the objects defined there. The author's audit verdict and its
verification implementation were not used to infer correctness. An inline
independent Python computation corroborated the harmonic example, exact
icosahedral action, projection/rotation distinction, and conic intercept.
Exact algebraic calculations used Q[tau]/(tau^2-tau-1); numerical harmonic
sampling was separately labeled binary64 with4096 coherent samples.

The evidence is an independent derivation and a different small computation,
not a claim that agent agreement establishes truth. No complete external
source-paper check or recovered modem/airplane runtime execution was repeated
here. Those provenance obligations remain with D's own source/check records
and coordinator inspection.

## Reconstructed critical implications

1. D-P1: omega=(-1+i*sqrt3)/2 has omega^3=1 and1+omega+omega^2=0.
   The real-linear kernel of(a,b,c)->a+b*omega+c*omega^2 is the span of
   (1,1,1). The inverse of a+b*omega and the norm a^2-ab+b^2 follow by
   solving Cartesian coordinates. A120-degree display does not have three
   independent planar directions.
2. D-P2: substituting the forward DFT into the inverse leaves the finite
   character sum, which selects the matching index. The same calculation
   gives Parseval. Cosine bins k and N-k coincide, and DC/Nyquist sine
   columns vanish. The stated sample-versus-continuous distinction passes.
3. D-P3: finite synthesis truncation is bounded by the sum of omitted
   coefficient magnitudes. Largest-magnitude retention minimizes sampled
   squared error only for independently represented bins; folding the
   2048 coefficients into1024 observational bins correctly handles aliasing.
4. D-P4: real synthesis creates c_j/sqrt2 at positive bin and its conjugate
   at the negative bin. Multiplication by sqrt2/N and the DFT character
   identity therefore recovers c_j. Its real Gram matrix is N*Id. The
   example coefficient energy is1563/64, independently summed. Packet
   arithmetic also checks:608bits require26 data symbols;28total symbols
   last126ms and deliver512/.126=4063.49payloadbits/s. Physical bandwidth,
   sender authentication, and noisy channel identification are not implied.
5. D-P5: expanding(1/2)d^T H d gives diagonal amplitude a_j^2 H_jj/4
   and mixed sum/difference amplitude a_j a_k H_jk/2. The L=2average
   normalization gives factors4 and2 exactly as stated. The base-B design
   proof passes for B>=5: any highest nonzero digit exceeds the maximum
   lower contribution with coefficient magnitudes at most4.
6. D-P6: paired subtraction cancels every even quadratic term. The
   normalized fundamental correlation therefore requires only independent
   nonexceptional carrier columns. The cubic bias3a^2/4 remains and
   Richardson cancels that example. Third-derivative and noise bounds
   correctly retain1/a_j amplification. The circle trace ambiguity is
   exactly H->H+cId,J0->J0-c*r^2/2.
7. D-P7-D-P9: finite product increments retain ab; dual-number coefficient
   extraction is a different ring. Divisor inversion cancellation is
   finite and exact. Repeated derivatives of x^-k give(-1)^m(k)_m x^-k-m;
   the imaginary projection sign and worked example pass. The phase
   logarithmic derivative includes the real path tangent and excludes
   zeros. The reciprocal exponential zeros and simple-root condition pass.
8. D-P10: substituting y=m*x+b+epsilon cancels the x^2 and x terms exactly
   when A+Bm+Cm^2=0 and b=-(D+Em)/(B+2Cm). Its rationalized small quadratic
   root is O(1/x) for a simple direction. A repeated projective direction
   does not guarantee an affine asymptote. The hyperbola example's
   intercept4/3 and decay bound3/(x-1) were freshly reconstructed.
9. D-P11-D-P14: Hamilton multiplication yields a real-linear orthogonal
   conjugation action, Rodrigues' formula, and x-axis90-degree map
   (x,y,z)->(x,-z,y). The plane normals are orthogonal while corresponding
   vectors have dot product exp(-2*kappa*t)*cos(w*t)^2. Top projection of
   the rotated mouth collapses to a segment. Therefore the original
   circular-mouth theorem is not inherited. Its radius equations a=c,
   a+c=R do force R/2; the stated two-arc divider, length, curvature and
   equal-area involution pass. The linear spirals contract every initial
   separation at exp(-kappa*t), excluding the claimed chaos in this model.
10. D-F1 and D19: exact coordinates generate30edges,20faces,120flags.
    Adjacent-flag involutions generate120permutations, with product orders
    3,5,2. The exact action's element orders are1,2,3,5,6,10, so no element
    has order120. The separately defined C24xC5 simultaneous register has
    first return120. Euler subdivision gives10*f^2+2, hence144002 at120.

## Independent finite execution

An inline standard-library script rebuilt the objects rather than importing
D's verifier. It returned:

```text
Harmonic D-E5 recovered:
[-7.000000000000006, 0.9999999999999972,
 3.9999999999997815, 3.000000000000003,
 0.9999999999999497]
Maximum absolute coefficient error:2.184918912462308e-13.

Icosahedron:12vertices,30edges,20faces,120flags.
Generated permutation group:120elements.
Element orders:[1,2,3,5,6,10].
Adjacent-generator product orders:[3,5,2].

Hyperbola slope/intercept:2/3,4/3.
Substituted constant residual:-36.
Orthogonal-plane vector dot product independently matched cos^2.
```

The computation is a finite cross-check. The main implementation and durable
reproduction scripts remain D's own D_verify files. No new user-facing
performance or measurement claims arise from this execution.

## Clarifications sent to the author

No material formula correction was required. One optional precision was
communicated: adjacent-flag toggling permutations constitute the regular
monodromy/right action abstractly isomorphic to the full H3 symmetry group.
An individual global toggle is not one fixed Euclidean rotation applied to
every flag in the same ambient frame. The existing prose largely describes
the abstract structure, so this is a terminology clarification rather than
a refutation of its120-state result.

The familyC manuscript received a reciprocal independent review. Its
interval-Newton pivot restriction was missing and has been corrected in
C2.5, with an exact counterexample and regression check. That correction is
recorded in C_audit.md and does not change the successful D review above.
