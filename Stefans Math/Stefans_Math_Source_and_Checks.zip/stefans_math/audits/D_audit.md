# Family D audit - SM-2026-10-13-A

Primary verdict: correct only after stated restrictions. The resulting chapter
contains self-contained proofs of finite Fourier inversion, quadratic harmonic
recovery, paired quadratic gradients, chain/divisor inversion, derivative and
phase identities, conic asymptote branches, quaternion rotations, and the
source circular half-radius theorem. The orthogonal-funnel variant is a
separate geometric model. No chaotic-attractor, universal solver, historical
transmission, or novelty claim is established.

## Coverage and source identity

The entire supplied 02 report was scanned for topic/claim structure, headings,
equations, cross-references, and repeated audit appendices. Full mathematical
reading focused on its own spectral, geometric, inverse and calculus sections,
with unrelated arithmetic, probabilistic and optimizer sections assigned to
other compilation families. This is a full-file structural inspection and a
domain-focused content audit, not a claim to reprove every theorem in all
5,196 lines independently.

- project_sources/02-Project_Mathematics_Audited_ASCII.txt: 339,188 bytes,
  45,695 whitespace words. Consulted common inverse-map kernel; oscillatory
  chapter lines 230-996; rotation and convergence counterexamples 1101-1133;
  integer-channel caution 1239-1288; conics 1290-1395; inverse/anchor/chain
  sections 1445-1582; calculus, divisor and phase sections 1757-2356; related
  implementation/coverage/audit appendices at 2357-3387, 3727-3808,
  4183-4322, 4554-4728, 4805-4865; final formula/composition appendix.
- project_sources/01-Math_Work_Exact_Operational_Formalization_ASCII.txt:
  Fourier-coordinate chapter 1687-1811, with its channel compensation and
  finite-algebra boundary; related source and formula references.
- project_sources/04-Solvers_Certified_Operationalization_ASCII.txt:
  Chapters 4 and 5, especially harmonic rank/aliasing, circular probes,
  projection/log-polar metric, and transformed-root correspondence. Simplex,
  DEC and curvature synthesis belongs to the coordinator's G chapter.
- supplemental/Quaternion_Padic_LockIn_Algorithm_ASCII.txt: entire 629-line
  version 3 report read, including exact bounded grid, original syntax and
  guards, arithmetic charts, quaternion state, paired probes, completeness,
  separate approximate real track, and evaluation-cost comparison. Historical
  solver implementation/package assertions are not newly executed by D.
- supplemental/Dual_Funnel_Projection_Theorem.pdf: full seven-sheet PDF,
  cover and pages 1-6, author Griff Gurwell, October 2026. Extracted to
  checks/D_dual_funnel_extract.txt using pdftotext -layout. Source attribution
  is explicit; its elementary circle proof is independently reconstructed.
- supplemental/airplane_epicycles.html: entire program inspected, all embedded
  coefficients and reference points parsed, draw-loop synthesis checked.
- supplemental/fourier_six_lab.html: signal/packet core, UI calculation and
  educational explanations inspected. Core extracted and actually executed
  in a local Node VM; browser interface and audio paths not executed.
- supplemental/doubling_vortex_mathematics_extracted.txt: embedding section 3,
  icosahedral/flag/route/register/subdivision sections 10-12, and references.
  Its arithmetic tower is owned by A and B. No unavailable Zenodo manuscript
  is inferred from the historical report's source-access claim.

Every source byte hash relevant to the mathematical check run appears in
checks/D_results.json. Original files were not edited.

## Decisive correction register

| Label | Source claim or risk | Verdict and corrected implication |
|---|---|---|
| D-C1 | 120-degree vectors are three independent orthogonal axes or binary digits. | Refuted. Pairwise cosine is -1/2 and 1+omega+omega^2=0. Two real basis coordinates or a three-coefficient record with an anchor are legitimate. |
| D-C2 | Complete periods imply every sampled cosine channel is independent. | Restricted. k and N-k are cosine aliases; DC/Nyquist norms differ. Full finite DFT is invertible on C^N, while a selected real design requires rank and alias checks. |
| D-C3 | One real instantaneous value contains twelve independently recoverable real values. | Refuted as instantaneous inference. A 192-sample time block has rank twelve for the six distinct complex bins. |
| D-C4 | Distinct carrier frequencies isolate every nonlinear derivative. | Refuted. J=theta_1^2/2, bins 1 and 2 gives false g_2=a_1^2/(4a_2). Quadratic dictionaries require mixing separation. |
| D-C5 | Paired probing makes every smooth derivative exact. | Restricted. It cancels quadratic even terms but retains cubic bias. For J=x^3 at zero, paired g_hat=3a^2/4. |
| D-C6 | Phase itself is a gradient component for a memoryless objective. | Conditional calibration. J(theta0+a cos t) is even in t, with zero sine quadrature. atan2 carries quadrant information; phase at zero amplitude is undefined. |
| D-C7 | One circular scan determines a full plane Hessian. | Refuted without a center or second radius. H+cI and J0-c r^2/2 give identical circle samples. |
| D-C8 | Derivatives, finite increments and anchored chain inverses have the same kernel. | Refuted. Finite product changes include ab. Ordinary adjacent differences lose an offset; anchored chain inversion is bijective. |
| D-C9 | Mobius divisor reconstruction supplies an additional spectral mask. | Refuted. T^-1 T=I coefficientwise; mu(4)=0 does not remove the fourth output monomial. A real filter must insert a new operator. |
| D-C10 | A sine node deletes a full complex derivative mode. | Refuted. k=3,m=2,r=2,theta=pi/5 gives derivative -3/8 with zero imaginary part. |
| D-C11 | Modulus and argument have unrestricted holomorphic derivatives. | Ill-typed. Real path derivatives with a tangent factor and nonzero signal repair the claim. |
| D-C12 | Projective infinity direction proves an affine line tail. | Refuted. y^2=x has horizontal infinity direction and divergent horizontal distance. A simple exact-conic direction gives the repaired line theorem. |
| D-C13 | Log-polar straightening preserves Euclidean lengths after dropping the scale factor. | Refuted. ds^2=e^(2v)(du^2+dv^2) at reference radius one. Radial length 1->2 is one, while raw coordinate difference is log2. |
| D-C14 | Quaternion coordinate storage decouples equations or establishes solver completeness. | Refuted. Pure quaternion extraction is a bijective record; coupled residuals remain coupled. Exhaustive retained-grid verification supplies bounded completeness. |
| D-C15 | Arbitrary real rotations/rounding preserve integer divisibility. | Refuted. Arithmetic invariants belong to integer combinations or proven homomorphisms; a real control orientation is not an integer-module certificate. |
| D-C16 | Mirror conjugacy alone forces the Taijitu/S partition. | Restricted. The half-radius theorem follows from four additional circular projection assumptions. |
| D-C17 | A 90-degree x rotation preserves the two-circle top projection. | Refuted. An xy circle rotated into xz projects to a segment; P1 fails. Perpendicular planes do not imply perpendicular corresponding position vectors. |
| D-C18 | Opposite-winding or orthogonal contracting spirals demonstrate a strange attractor. | Refuted for the source linear contraction. All pair separations decay as e^(-kappa t); largest rate -kappa and equilibrium limit. A nonlinear autonomous model remains absent. |
| D-C19 | n equal-phase labels are a periodic full contracting orbit. | Restricted to angular quotient/register. Radius decreases after n steps. |
| D-C20 | 120 flags, 120 routes, 120 symmetry elements and a cyclic 120-step register are one object. | Refuted. Cardinality does not identify group actions. H3 finite flag action has no element order120; a separate C24 x C5 register does. |
| D-C21 | Icosahedral f=120 subdivision has 144000 vertices, or closure alone selects f120. | Corrected to 144002 vertices. Closure only says 120 divides f under an explicit phase update; minimality is a separate condition. |
| D-C22 | Negation is an embedding-independent geometric half-turn. | Refuted. Residue-clock negation is conjugation; unit-orbit negation is a half-turn; label-permutation negation is not scalar -I. |
| D-C23 | Airplane's 2048 stored coefficients can individually be read from its 1024 reference samples. | Refuted. Frequencies fold modulo1024. Folded coefficient sums and full reference synthesis pass, while individual unfurled comparison legitimately aliases. |

## Proof dependencies and obligation outcomes

Finite complex character cancellation -> Fourier inverse, energy and rank.
Declared real signal symmetry -> positive/negative conjugate relation.
Exact quadratic + coherent nonaliased dictionary -> coefficient recovery.
Paired exact quadratic + fundamental Gram -> exact gradient.
Third/fifth derivative bounds + response error -> controlled approximation.
Independent center/radius observation -> missing circular trace.
Finite product identity + differentiability -> derivative limit.
Anchored cumulative definition -> triangular inverse; ordinary differences
require a boundary anchor instead.
Prime-subset Mobius cancellation -> divisor inverse and no additional mask.
Compact distance from zero + factorial bound -> fixed-order convergence.
Nonzero analytic signal + real path -> logarithmic phase rate.
Pole-free invertible coordinate map -> original/transformed root equivalence.
Exact conic + simple infinity direction -> actual small-error line branch.
Unit Hamilton quaternion + declared convention -> orthogonal rotation.
P1-P4 circle assumptions -> R/2 mouths, divider and equal areas.
Explicit linear contracting flow -> negative separation exponent and point
attractor; fixed rotations preserve that conclusion.
Icosahedral incidence -> finite flag action; separate register definition
supplies the actual cyclic120 model.

Passed: all displayed self-contained identities under their stated domains.
Failed: unrestricted claims in the correction register.
Conditional: transformed optimization success beyond coefficient recovery,
historical source software assertions, unprovided nonlinear chaos model,
physical communication performance and unavailable original aircraft contour.
Out of scope: universal continuous inversion, global nonlinear convergence,
all historical claims, cryptographic security, or novelty.

## Primary source checks

Checked on 13 October 2026 through primary official or author-hosted pages:

- MathWorks R2026b Discrete Fourier Transform: negative forward sign and
  1/N inverse factor, zero-based translation. No continuous inverse inferred.
- Stanford Research Systems About Lock-In Amplifiers pp1-2: multiplier,
  low-pass and quadrature mechanism; project cosine/sine sign translation.
- NIST DLMF v1.2.8 (15 September 2026), Sections27.5 and1.9: exact arithmetic
  inversion formulas and complex analytic/polar conventions.
- NASA/JPL NAIF CSPICE Rotation: scalar-first Hamilton product, unit
  axis/half-angle construction, conjugation and composition order.
- David Vogan Tufts slides corrected26 January2019, pp9-12 and21-22:
  flags, adjacent generators, free/transitive regular action and H3 order120.
  Independent exact-coordinate enumeration verifies the chapter finite model.

Publisher retrieval of Lorenz1963 failed on one route; an author manuscript
copy was located but no Lorenz result is needed or cited in the chapter.
The contraction refutation is derived directly from the actual source flow.
No theorem is promoted from a search snippet, title, or historical audit claim.

## Reproducible finite runs

Commands from workspace root:

```text
python3 stefans_math/checks/D_verify.py
node stefans_math/checks/D_modem_check.js
```

D_verify.py uses only Python standard library, fractions, exact coefficient
rings, exact permutations, and separately labelled floating experiments.
Its 14 groups pass:

- 121 exact three-state character indicators, u=-60,...,60.
- 625 exact N=4 DFT inverse/Parseval vectors in {-2,...,2}^4.
- Divisor inversion/cancellation for n=1,...,256 on the declared rational tape.
- 343 exact anchored chain triples in {-3,...,3}^3.
- 125 exact projected vectors and the rank-two 120-degree axis calculation.
- 125 exact rational unit-quaternion norm/inverse vectors.
- Six explicit rational circle points reproducing the trace ambiguity.
- 625 exact finite product-increment quadruples.
- 46 rational cubic fractional-linear coordinate identities.
- 50 rational half-radius circle instances, supplementary to the proof.
- Exact 12-vertex/30-edge/20-face incidence and all120 flag-action elements;
  relations, simple transitivity and element orders1,2,3,5,6,10 checked.
- 256 sampled paired gradient/Hessian measurements on a declared mixed
  quadratic, maximum discrepancy below5e-14, tolerance1e-10.
- Six recovered coefficients in one192-sample block, maximum discrepancy
  below1.8e-15 and energy24.421875.
- All2048 airplane magnitudes/frequencies, 1024 folded bins and reference
  points, folded coefficient discrepancy below3.7e-14; reconstructed point
  discrepancy below5.1e-15; stored tail l1 after129 terms0.07254724.

D_modem_check.js runs the actual recovered core, with original payload never
supplied to decode. All2040 supported single-point/bin constellation cases,
ordinary/collision Gram assertions and six payload cases pass. Payload lengths
8,512,513,4096 exercise clean packets; two echo cases use delay18/prefix24 and
delay40/prefix48. Projection maximum error is1.6946818973100074e-15; Gram maximum
error8.881784197001252e-16; tolerance1e-10. No browser UI run is claimed.

JSON records contain exact commands, versions, arithmetic domains, source
hashes, range descriptions, tolerances and nonclaims. They are available as
checks/D_results.json and checks/D_modem_results.json. A bounded regeneration
wrapper D_run.py executed both checks in 3.14 seconds, recorded before/after
input hashes and actual argv in checks/D_execution_manifest.json (schema2),
and retained checks/D_execution.log. The existing computation-audit validator
passed with --root . . No CPU/memory caps were needed or claimed; each small
process had a45-second wall timeout. The coordinator owns final persistence;
subagent files are not independently uploaded.

## Final editorial check

Chapter text: approximately 8,220 whitespace words before coordinator edits, three main
chapters, fifteen substantial numbered worked examples, six exercises with
answers, five primary external references plus the supplied Gurwell source.
Plain ASCII Markdown; no second-person prose. Relevant original speculations
are repaired or given explicit residual gaps rather than silently omitted.
No original standalone solver or HTML is modified by this compilation family.
