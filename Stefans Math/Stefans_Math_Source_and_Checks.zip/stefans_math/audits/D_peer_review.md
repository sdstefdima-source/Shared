# Independent family D review of C and selected E statements

Base: SM-2026-10-13-A. Review date: 13 October 2026.

Primary C verdict: correct only after a stated restriction; the restriction
has now been incorporated and reread. No remaining load-bearing mathematical
gap was found in the complete 482-line C_certified_solvers.md chapter.
This is an independent fresh derivation and read of the actual chapter, not
an endorsement inherited from the source report's title or its test counts.

## C review target and coverage

Full chapter C1-C3 read. Main obligations reviewed from definitions:

1. Rational-expression normalization preserves value and every guard on the
   original domain; denominator clearing is equivalent only there.
2. Grid coordinate map is bijective; sound retention plus definitive checking
   of every survivor gives exactly the finite grid solution set.
3. Optional exact algebraic scope is correctly separated from finite grids,
   Gaussian-rational coefficients, radicals, real branches, transcendental
   equations and positive-dimensional families. Source-described software
   behavior is explicitly not a fresh full-package execution.
4. Rational univariate representation needs both arrows, polynomial gcd
   denominator conditions and original guards. Polynomial root isolation
   does not require a radical expression.
5. Ratio puzzle clearing, homogeneous polynomial, ratio identities and
   elliptic carrier are correctly typed and restricted to admitted charts.
6. Finite-difference interpolation, derivative error and noise amplification,
   bracket existence/uniqueness, Newton locality and specialized Halley
   positivity/convergence all pass fresh derivation.
7. Multivariate closed-box contraction checks its derivative norm over the
   whole convex box, maps the box into itself, and requires invertible B to
   identify fixed points with roots. Local uniqueness is not global coverage.
8. Least-squares stationarity is not silently promoted to a root. Quadratic
   positivity/compatibility, damping, model error, trust-region sufficiency,
   inexact Newton rates and gates all retain their separate conditions.
9. The saturated-integrator theorem is correctly attached to its stated plant
   and gain envelope, with the large-error nonuniform contraction retained.

## Concrete defect and repair

Initial scalar interval-Newton statement omitted pivot membership. It claimed
every root in I lies in N=c-f(c)/f'(I) without stating c in I. The segment from
an external pivot to a root need not stay within the derivative enclosure.

Decisive exact counterexample:

```text
f(x)=x^2-1; I=[1,2]; f'(I)=[2,4]; c=0.
True admitted root: alpha=1.
N=0-(-1)/[2,4]=[1/4,1/2].
I intersect N is empty despite the true root in I.
```

The owner added c in I, explained segment containment, and stated that an
external pivot requires a derivative enclosure over the enlarged hull.
The corrected paragraph was reread. This is sufficient: the mean-value
point between c and alpha belongs to I, so its derivative is represented
in f'(I) and the retained root lies in N.

## Fresh evidence and derivations

The reviewer did not run C_solver_checks.py because its main routine writes
the owner's outputs. Independent standard-library rational calculations
were executed directly without importing the author's functions:

- Original ratio residual equals
  (s^3-6*s*q+7*r)/((a+b)*(a+c)*(b+c)) on all1000 triples
  a,b,c in {1,...,10}. This bounded check corroborates the algebraic derivation.
- Exact carrier witnesses (X,Y)=(-8,28),(-8,-28),(-4,0) satisfy the curve.
  Their reconstructed ratios are respectively (3/2,-1/4,11/4),
  (-1/4,3/2,11/4),(-1,-1,6), and satisfy both invariant equations.
  They are algebraic chart witnesses, not positive puzzle solutions.
- A symbolic manual reduction sets T=-52/X and obtains
  uv=(-X-40-208/X)/16 and
  w(u+v)=(-2704/X^2-520/X-9)/4.
  Then T*uv+w(u+v)=1 exactly. This independently proves the
  uv+uw+vw+2uvw relation using the curve equation.
- Published exact real-bracket endpoints were substituted directly into
  f=x^3-x-1: signs are negative/positive and width is exactly2^-48.
- Coupled contraction example independently gives eta=1601/100000,
  q=153/250 and eta+q*r=4661/100000<1/20. The root(1,2,3) and
  all eight corner images are independently checked. The derivative norm,
  rather than the corners alone, supplies the full interior theorem.
- Halley635/504 residual and interval follow directly from exact rational
  cubing; local Newton cycle0->1->0 is independently substituted.
- The positive nonroot strict minimum has f'=0 and
  J''=8*sqrt(6)-16/3>0 by direct differentiation. This confirms that the
  nonroot stationarity warning is backed by a genuine strict minimum.
- The trust-region certificate expands to the two nonnegative terms given
  in C. The gradient-error descent bound and inexact matrix/residual error
  decomposition also reconstruct correctly from their definitions.

These checks do not establish general software parsing correctness, all-root
coverage of an optional package, or an elliptic rational-group generating
set. The chapter explicitly avoids those conclusions. No physical plant or
general optimizer stability is inferred from the scalar envelope example.

## Selected E peer review

E3.2 GF9 and E3.3 cyclic-window theorem were freshly reconstructed from their
objects. GF9=F3[u]/(u^2+1), with u^2=-1, gives Frobenius conjugation
a+b*u -> a-b*u, trace2a and norm a^2+b^2. Integer translation gives
Tr(z+t)=Tr(z)+2t and N(z+t)=N(z)+tTr(z)+t^2.
Nine elements give six conjugacy orbits. Independent direct construction of
the six interleaved trace/norm codewords found pair-distance histogram
distance3: three pairs; distance5: twelve pairs. Thus minimum distance3
and single-symbol correction to the orbit are correct. The unresolved
conjugate sign is not recovered by redundant invariant measurements.

For positive integers M,w, the cyclic-window kernel proof is correct over Q.
Zero window sums force x(n+w)=x(n), hence gcd(M,w)-periodicity. Each window
has w/gcd(M,w) copies of its period block, whose sum must vanish. This gives
gcd(M,w)-1 independent rational kernel coordinates, and invertibility exactly
when the gcd is one.

The original E3-P1 paragraph did not explicitly state positive M,w locally.
At w=0, the operator is zero and kernel dimension is M rather than M-1.
The script already tests positive M,w. The missing statement guard was sent
to the owner and coordinator for insertion. No change to the positive-width
proof or GF9 code is needed.

## Source and independence limits

The direct chapter read, hand derivations and rational checks were independent
of C's and E's test implementations. Several reviewers can still share model
errors; agreement is not itself a theorem. External software documentation
was not reauthenticated in this pass; its described scope remains the owning
family's separately checked dependency. The self-contained mathematical
contracts above do not depend on an unexecuted application claiming general
scope. No owner chapter or check output was edited by D.
