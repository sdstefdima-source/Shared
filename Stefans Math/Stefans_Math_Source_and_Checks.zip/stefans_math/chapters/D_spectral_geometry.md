# Fourier coordinates, rotating channels, and measured derivatives

Stefan's recurring use of clocks, waves, and rotating components has a precise common basis: a complicated record can become easier to inspect after its components are expressed in a suitable basis. A rotating vector provides two real coordinates; a family of distinct harmonics provides several distinguishable coordinates over an observation interval. Orthogonality then supplies a decoder. These ideas support waveform transmission, geometric drawing, modular filters, and derivative measurements. The object being decoded must be specified separately in every application.

The standard mathematics here is complex arithmetic, finite Fourier analysis, and linear measurement. Stefan's organizing proposal is to use these representations as cooperating instruments inside a numerical reconstruction process. The usefulness lies in selecting channels that expose constraints or coefficients, attaching their inversion conditions, and checking reconstructed values against the original observations. The chapters retain that practical architecture while repairing claims that rotations or phases automatically create information.

## D1. Complex coordinates and the exact meaning of 120 degrees

A complex number z=x+i*y packages two real numbers. Its conjugate is conj(z)=x-i*y, and |z|^2=z*conj(z)=x^2+y^2. For z!=0, polar form is z=r*exp(i*theta), where r=|z|>0 and theta is specified modulo 2*pi. Euler's identity exp(i*theta)=cos(theta)+i*sin(theta) converts multiplication by a unit complex number into a planar rotation. Multiplication by a general nonzero complex number combines rotation with uniform scaling. The zero record has no direction, so its phase is undefined.

PROVED D-P1. Let omega=exp(2*pi*i/3). Then

```text
omega^3=1; omega!=1; omega^2+omega+1=0.
omega=-1/2+i*sqrt(3)/2.
omega^2=conj(omega)=-1/2-i*sqrt(3)/2.
1+omega+omega^2=0.
```

The factorization u^3-1=(u-1)(u^2+u+1) proves the polynomial identity because omega is a nontrivial cube root of one. Alternatively, summing the displayed real and imaginary coordinates gives zero directly. The three vectors point 120 degrees apart. They are not three orthogonal directions: the dot product of any two distinct unit vectors is -1/2. Their sum-zero relation also makes them linearly dependent over the real numbers.

This distinction explains the useful two-coordinate interpretation of a three-direction drawing. Any two of 1, omega, omega^2 are a real basis of the plane, and the third equals minus their sum. Three coefficients therefore need one constraint or one extra observation before they can be recovered from their complex sum. The word binary in such a construction can refer to choosing two independent directions. It does not establish binary arithmetic, independent bits, or a third orthogonal axis.

Worked example D-E1. Take z=2+3*omega. Cartesian form is 1/2+(3*sqrt(3)/2)*i, and |z|^2=7. More generally,

```text
|a+b*omega|^2=a^2-a*b+b^2, for real a,b.
Re(a+b*omega)=a-b/2; Im(a+b*omega)=sqrt(3)*b/2.
b=2*Im(z)/sqrt(3); a=Re(z)+Im(z)/sqrt(3).
```

The inverse follows by solving these two real equations. In contrast, if three unrestricted coefficients are used, then (a,b,c) and (a+t,b+t,c+t) have the same value a+b*omega+c*omega^2. A third scalar anchor, such as a+b+c, removes this particular ambiguity. A 120-degree display is therefore useful for constrained three-channel data, triangular lattices, or residue classes modulo three, with its one-dimensional kernel kept explicit.

## D2. Finite Fourier inversion and aliasing

Fix an integer N>=1 and zeta=exp(2*pi*i/N). A sample vector x=(x_0,...,x_(N-1)) has the finite Fourier coordinates

```text
X_k=sum_(n=0)^(N-1) x_n*zeta^(-k*n), 0<=k<N.
x_n=(1/N)*sum_(k=0)^(N-1) X_k*zeta^(k*n).
```

PROVED D-P2. These maps are inverses on C^N. The load-bearing identity is

```text
sum_(k=0)^(N-1) zeta^(k*u) = N if u == 0 (mod N), otherwise 0.
```

If zeta^u=1, every summand equals one. Otherwise the finite geometric sum is (1-(zeta^u)^N)/(1-zeta^u)=0. Substitute the definition of X into the inverse and interchange the two finite sums. The coefficient of x_m becomes the character sum for u=n-m divided by N. Only m=n survives. The normalized Fourier matrix is consequently unitary, and the same calculation gives

```text
sum_n |x_n|^2=(1/N)*sum_k |X_k|^2.
```

This is Parseval's identity in the present normalization. A different choice of normalization can place sqrt(N) factors in both maps; changing conventions is harmless when both directions change consistently.

Worked example D-E2. For N=4 and x=(1,2,3,4), the relevant roots are 1,i,-1,-i. Direct calculation gives X=(10,-2+2i,-2,-2-2i). The first inverse sample is [10+(-2+2i)-2+(-2-2i)]/4=1. At n=1, multiplication by (1,i,-1,-i) gives 8/4=2. The remaining samples return 3 and 4. The input energy is 30, while the sum of squared coefficient magnitudes is 100+8+4+8=120; division by four again gives 30. This example is checked with exact rational complex arithmetic, rather than rounded trigonometric values.

The same character sum expresses modular membership:

```text
delta_N(u)=(1/N)*sum_k zeta^(k*u).
delta_N(u)=1 exactly when N divides u, and otherwise 0.
```

It can replace an integer congruence test with an exact finite phase identity. It does not make a dense sum cheap merely because the answer is zero or one. Efficiency needs sparse structure, reusable transforms, or another independently proved reduction. For exact computation, algebraic roots of unity or direct residue tests avoid treating a tiny floating residual as an exact zero.

Sampling identifies frequencies modulo N: exp(2*pi*i*(k+N)*n/N)=exp(2*pi*i*k*n/N). A physical frequency and another frequency shifted by the sample rate can therefore produce identical sampled phases. With real cosine channels, k and N-k also give identical columns. Sine channels distinguish orientation except at DC and, for even N, the Nyquist bin, where the sampled sine is identically zero. Those exceptional cosine columns have squared norm N; an ordinary nonexceptional cosine has squared norm N/2.

A complete sample vector has an exact finite inverse. Reconstruction of an arbitrary continuous signal from that vector requires an additional bandlimit or finite-model assumption. Infinitely many continuous curves agree at the same finite sample points. Calling the finite inverse a universal continuous inverse would change the problem's domain without providing observations that distinguish those curves.

## D3. Epicycles as geometric synthesis

Let a closed parameterized planar curve be represented by complex coordinates z(t), with t running from zero to 2*pi. A finite trigonometric representation has the form

```text
z_K(t)=sum_(k in K) c_k*exp(i*k*t).
c_k=radius_k*exp(i*initial_phase_k).
```

Each term is a vector rotating at signed angular rate k. Placing the start of each vector at the end of its predecessor produces the familiar epicycle picture. The endpoint is their sum, so vector order changes the intermediate chain but not the final point. The k=0 term is a translation of the entire drawing. Positive and negative k rotate in opposite directions. A planar curve is generally a complex-valued signal; its coefficients need not have the conjugate symmetry imposed on a real voltage signal.

For N sampled boundary points z_n, coefficients c_k=X_k/N and the inverse finite transform recover those points exactly. Between samples the chosen trigonometric polynomial supplies an interpolation. The interpolation depends on the chosen frequency representatives and the parameterization of the boundary. Uniform time samples, uniform arc-length samples, and a parameterization that dwells near a corner produce different coefficients even when the visible outline is similar.

PROVED D-P3. For any finite complete coefficient list and retained subset K,

```text
|z(t)-z_K(t)| <= sum_(k not in K) |c_k|, for every real t.
```

The triangle inequality proves the bound because every exponential has modulus one. On a sample grid, orthogonality also gives the mean squared omitted error as the sum of omitted squared coefficient magnitudes when the bins are distinct modulo N. A largest-magnitude-first display minimizes that discrete squared error among subsets of the same size. It need not minimize maximum geometric deviation, preserve a sharp corner, or maintain the ordering of self-intersections. Those are different objectives.

Worked example D-E3. The four sampled points (1,i,-1,-i) form one counterclockwise circular mode: c_1=1 and every other coefficient is zero. A constant displacement 2-i adds c_0=2-i. An ellipse z(t)=3*cos(t)+i*sin(t) becomes 2*exp(i*t)+exp(-i*t). Two counter-rotating vectors of radii two and one reproduce it exactly. At t=0 their sum is 3; at t=pi/2 it is i. Removing the radius-one term leaves a circle and has maximum error exactly one, matching the omitted-coefficient bound.

The recovered airplane demonstration contains 2,048 stored coefficients but only 1,024 stored reference points. An independent check reconstructs every reference point from the complete list with maximum binary64 discrepancy about 5.1e-15. Individual coefficients must not be compared directly with the 1,024-point DFT: coefficients whose frequencies agree modulo 1,024 fold into the same observed bin. Comparing the folded sums gives maximum discrepancy below 3.7e-14. The reference samples alone therefore do not identify 2,048 independently writable frequency coordinates.

At its default 129 retained terms, the sum of stored omitted magnitudes is approximately 0.07255 in normalized drawing units. This is a uniform bound relative to the complete stored trigonometric representation. It is not an authenticated bound relative to an unavailable original aircraft photograph or an independently defined continuous contour. The result still gives a concrete, useful demonstration of progressive geometric approximation, with reproducible error accounting instead of a visual claim that every added circle is exact new information.

## D4. Six complex channels in one real waveform

A signal block can preserve twelve real coordinates although each instantaneous voltage is one real number. The block supplies many observations at known times. Set N=192, choose distinct positive bins k_j=4,5,6,7,8,9, and let c_j=I_j+i*Q_j. Define

```text
x_n=sqrt(2)*Re(sum_(j=1)^6 c_j*exp(2*pi*i*k_j*n/N)).
c_hat_j=(sqrt(2)/N)*sum_(n=0)^(N-1)
                 x_n*exp(-2*pi*i*k_j*n/N).
```

PROVED D-P4. In the ideal mathematical model c_hat_j=c_j. Expanding the real part creates a positive term c_j/sqrt(2) and a negative term conj(c_j)/sqrt(2). During decoding, frequency differences k_l-k_j vanish modulo N only when l=j; sums k_l+k_j never vanish modulo N. Character orthogonality removes every other term. The decoder factor sqrt(2) then restores c_j.

An equivalent real synthesis matrix has columns sqrt(2)*cos(2*pi*k_j*n/N) and -sqrt(2)*sin(2*pi*k_j*n/N). Its Gram matrix is N times the 12-by-12 identity. This proves rank twelve, gives the left inverse A^T/N, and supplies the energy identity

```text
(1/N)*sum_n x_n^2=sum_j |c_j|^2.
```

The conjugate negative-frequency coefficients are determined by real-valuedness, so they are not six additional independently assigned channels. If all six tones share one frequency, the waveform depends only on sum_j c_j; its real-linear rank drops from twelve to two. Increasing a numerical coefficient's precision does not remove that kernel.

Worked example D-E4. Assign c=(1+2i,-2+i/2,1/4-i,3-2i,-3/4+i/8,3/8-5i/8). Their squared magnitudes sum to 1563/64=24.421875. The 192 synthesized samples have that same mean squared voltage, and all six coefficients are recovered. A direct binary64 implementation gives coefficient errors below 1.8e-15. The proof establishes the exact identity; this finite run checks the normalization and code path.

To turn coefficients into bits, choose a finite constellation. Six independent 16-point complex constellations provide 16^6=2^24 distinct symbol choices, or 24 bits per data symbol. Higher constellation order reduces nearest-point separation at fixed power. For square M-QAM normalized to mean squared magnitude one, adjacent complex points are separated by sqrt(6/(M-1)); channel power weight w_j and voltage scale V_ref multiply this by V_ref*sqrt(w_j).

In the supplied packet model the sample rate is 48,000 samples per second. A 192-sample useful interval lasts 4 ms; a copied 24-sample prefix adds 0.5 ms. Twenty-four bits per 4.5-ms data symbol give approximately 5,333.33 gross bit/s. A 512-bit payload plus a 64-bit header and 32-bit checksum requires ceiling(608/24)=26 data symbols. Two training symbols bring the packet to 28 symbols, lasting 126 ms and carrying approximately 4,063.49 payload bit/s.

For a single echo r_n=x_n+g*x_(n-d), a prefix of at least d samples turns the useful-window operation into circular convolution when the specified packet timing and finite memory assumptions hold. Fourier coordinates then give R_k=H_k*X_k with H_k=1+g*exp(-2*pi*i*k*d/N). This follows by shifting the DFT summation index. A nonzero H_k can be inverted; a small H_k amplifies measurement error. Training estimates those gains. Unknown timing, clipping, drift, and insufficient prefixes remain separate measurement problems.

The actual recovered modem core was tested on all 340 supported QAM points in each of six bins, giving 2,040 projection checks. Six clean or compensated-echo packet cases also recovered their payloads. These are software checks of the finite model. The nominal allocation 6*250=1,500 Hz is a bin-allocation count; rectangular time windows have sidelobes, so it is not a strict occupied-bandwidth certificate. Checksums detect many corruptions and do not authenticate the sender. The model is useful for teaching signal dimensions, power allocation, and reversible data transport with explicit assumptions.

## D5. Harmonic probing of an unknown local quadratic

The same orthogonality can recover derivatives when an objective is evaluated along known displacements. Fix a real base point theta_0 and an exact local quadratic

```text
J(theta_0+d)=J0+g^T*d+(1/2)*d^T*H*d, H=H^T.
d_j(t)=a_j*cos(w_j*t+phi_j), a_j>0.
```

Substitution gives linear channels at w_j, diagonal-curvature channels at 2*w_j, and mixed-curvature channels at w_j+w_k and |w_j-w_k|. Specifically,

```text
C0=J0+sum_j a_j^2*H_jj/4.
linear cosine amplitude:       a_j*g_j.
diagonal doubled amplitude:    a_j^2*H_jj/4.
mixed sum/difference amplitude:a_j*a_k*H_jk/2.
```

These factors follow from cos(alpha)^2=(1+cos(2*alpha))/2 and cos(alpha)*cos(beta)=[cos(alpha+beta)+cos(alpha-beta)]/2. They also follow by multiplying positive and negative exponential terms. Both derivations retain the half in the quadratic definition; its omission would double curvature estimates.

Let avg denote averaging over complete common periods, and define L(w,phi;y)=2*avg[y*cos(w*t+phi)]. If every labelled first- and second-order frequency is nonzero and distinct, PROVED D-P5 gives

```text
g_j=L(w_j,phi_j;y)/a_j.
H_jj=4*L(2*w_j,2*phi_j;y)/a_j^2.
H_jk=2*L(w_j+w_k,phi_j+phi_k;y)/(a_j*a_k).
```

Orthogonality selects the displayed amplitudes, after which these rescalings recover the coefficients. Difference channels give redundant estimates when their signed frequency and phase are handled consistently. For uniformly sampled coherent data, modular aliasing must also be excluded. More than twice the highest output bin is a simple sufficient sampling condition.

Worked example D-E5. Take H=[[4,1],[1,3]], theta_0=(0,0), and J(theta)=(1/2)*(theta-(2,-1))^T*H*(theta-(2,-1)). Then J0=15/2 and g=(-7,1). Amplitudes (1/10,1/5) and bins (1,4) give

```text
y(t)=377/50-(7/10)*cos(t)+(1/5)*cos(4t)
     +(1/100)*cos(2t)+(3/100)*cos(8t)
     +(1/100)*cos(3t)+(1/100)*cos(5t).
```

The six nonzero bins are distinct. Decoding returns g=(-7,1), H_11=4, H_22=3, and H_12=1. Since det(H)=11 and H_11>0, H is positive definite. Solving H*p=-g gives p=(2,-1), and direct evaluation of the original objective gives zero. Thus this exact quadratic supports an exact recovered coefficient model and an exact minimizer. The polynomial degree, domain, positivity, and original substitution establish the result; a spiral drawing supplies none of those conditions.

Distinct carriers alone are insufficient. With J=(1/2)*theta_1^2, bins (1,2), and amplitudes a_1,a_2, the doubled first-coordinate harmonic falls on the second carrier. Its false second-gradient estimate is a_1^2/(4*a_2), although the true gradient is zero. Common-period averaging and longer windows cannot separate identical frequencies generated by different causes.

One sufficient all-dimension design is w_j=B^(j-1) with integer B>=5. Equality of two different labelled quadratic frequencies would give sum_j z_j*B^(j-1)=0 with |z_j|<=4. At the largest nonzero index h, the leading term has magnitude at least B^(h-1), whereas all lower terms have combined magnitude at most 4*(B^(h-1)-1)/(B-1), which is smaller. This contradiction proves separation. The design requires exponentially increasing bandwidth; practical schedules should be checked against the actual channel list.

## D6. Paired probes, circular probes, and finite-amplitude error

Paired evaluations improve the gradient contract. For displacements d_n at coherent sample times, set deltaJ_n=J(theta_0+d_n)-J(theta_0-d_n). On every quadratic this equals 2*g^T*d_n, because constant and even terms cancel. If the cosine carrier columns have Gram matrix (N/2)*I,

```text
g_hat_j=(1/(N*a_j))*sum_n deltaJ_n*cos(2*pi*b_j*n/N)=g_j.
```

PROVED D-P6 follows by substitution and discrete orthogonality. It needs distinct, nonexceptional fundamental bins, rather than complete separation of all quadratic mixing channels. Curvature recovery still needs the stronger separation condition. In particular, paired bins (1,2,3) can recover the exact quadratic gradient although their doubled curvature channels collide with mixed products.

For a smooth nonquadratic objective, pairing cancels even powers but retains cubic and higher odd terms. If the third derivative's trilinear operator norm is bounded by B_3 on the full probe neighborhood and rho^2=sum_j a_j^2, Taylor's remainder gives |g_hat_j-g_j|<=B_3*rho^3/(3*a_j). With comparable amplitudes a, this is O(a^2). Error of magnitude at most sigma in each response adds the conservative term 2*sigma/a_j. Shrinking amplitudes reduces the first contribution while increasing the second.

A scalar cubic J(x)=x^3 illustrates the bias without any measurement noise. At x=0, a*cos(t) produces a^3*(3*cos(t)+cos(3t))/4. The decoded first derivative is 3*a^2/4, although J'(0)=0. Pairing retains that odd contribution. At a=1/10 the false value is 3/400; at a/2 it is 3/1600. The Richardson combination [4*g_hat(a/2)-g_hat(a)]/3 cancels it exactly for this cubic. A general O(a^4) claim needs sufficient regularity and a bound on the remaining fifth-order terms. Disagreement between two amplitudes is a useful diagnostic but not itself a certified remainder bound.

Circular probing uses d=r*(u*cos(phi)+v*sin(phi)) for orthonormal plane directions u,v. For an exact quadratic,

```text
J_circle=C0+A1*cos(phi)+B1*sin(phi)+A2*cos(2phi)+B2*sin(2phi).
A1=r*g_1; B1=r*g_2.
A2=r^2*(h_11-h_22)/4; B2=r^2*h_12/2.
C0=J0+r^2*(h_11+h_22)/4.
```

Worked example D-E6. Set r=1, J0=5, g=(2,-1), and H=[[4,2],[2,6]]. The circle coefficients are C0=15/2, A1=2, B1=-1, A2=-1/2, B2=1. The mixed coefficient returns h_12=2. A separate center measurement J0=5 returns trace(H)=10, and trace together with h_11-h_22=-2 gives diagonal entries four and six.

Without center data, replacing H by H+3*I and J0 by 7/2 leaves every unit-circle value unchanged. More generally, H+c*I and J0-c*r^2/2 give the same scan. This is an exact unresolved fiber, not poor numerical resolution. Measuring a second radius also removes it. The first-harmonic minimum gives the negative-gradient direction; the complete circular objective can have a different minimum because its curvature harmonics also contribute.

Phase decoding has its own convention. For y=A*cos(w*t+phi), A>0, define I=2*avg(y*cos(w*t)) and Q=2*avg(y*sin(w*t)). Then I=A*cos(phi), Q=-A*sin(phi), so A=sqrt(I^2+Q^2) and phi=atan2(-Q,I) modulo 2*pi. Principal arcsine or a single arctangent ratio loses quadrant information. A memoryless objective J(theta_0+a*cos(t)) is even in t and has no sine quadrature. Its first-harmonic phase is normally zero or pi, determined by the sign of its amplitude. A generic proportionality between phase lag and derivative requires a separately calibrated dynamic plant.

The resulting instrument contract is concrete: declare the observation model, keep every probe in its defined neighborhood, check rank or frequency separation, record amplitude and noise bounds, reconstruct coefficients, and pass a proposal to an original-problem verifier. Fourier recovery identifies the admitted coefficient model. The optimization chapter supplies the separate conditions under which its proposed step decreases the actual objective or solves an equation.

# Inverse transforms, derivative coordinates, and geometry at infinity

The mathematical word inverse names a map that undoes a particular forward map. A derivative, a cumulative transform, an arithmetic divisor transform, and a fractional-linear coordinate change have different domains and different inverse conditions. Standardizing those distinctions turns several repeated project speculations into a useful collection of reconstruction methods. It also prevents an apparent analogy between two diagrams from silently replacing an algebraic identity.

## D7. Finite increments and linear coefficient extraction

For y=u*z, independent finite increments a,b give

```text
Delta y=(u+a)*(z+b)-u*z=u*b+z*a+a*b.
```

The product a*b is part of the exact finite change. At u=z=a=b=1, the output changes from one to four, a change of three. The first-order terms alone give two. If u and z depend differentiably on a real parameter t, divide their exact increment identity by a nonzero step h. The remaining cross term is [Delta_h u/h]*Delta_h z. Differentiability makes the first factor bounded near zero and the second tend to zero. Taking the limit gives (u*z)'=u*z'+z*u'. No value is assigned to an undefined quotient 0/0.

For f(x)=x^2, [f(x+h)-f(x)]/h=2*x+h whenever h!=0. The reduced expression has a continuous extension to h=0, with value 2*x. The derivative is that limit, while the exact finite change is 2*x*h+h^2. At x=0 the derivative is zero and the finite change remains h^2. Comparing h^2 to an allegedly nonzero first-order term would fail at precisely that legitimate point.

A related exact coefficient device uses dual numbers a+b*epsilon with epsilon^2=0. Their multiplication is

```text
(a+b*epsilon)*(c+d*epsilon)=a*c+(a*d+b*c)*epsilon.
```

PROVED D-P7. For a polynomial f over a characteristic-zero field,

```text
f(x+h*epsilon)=f(x)+h*f'(x)*epsilon.
```

For a monomial, the binomial theorem leaves only the constant term and the term containing one epsilon. Linearity then gives the polynomial formula. This is an exact identity in a different ring, not an equality that deletes h^2 from ordinary real arithmetic. Propagating value-and-derivative pairs through specified differentiable primitives gives forward automatic differentiation. General branch choices, non-smooth operations, and divisions still need their own rules.

Worked example D-E7. For f(x)=x^3-2*x+1 at x=2, substitute 2+epsilon. The cubic becomes 8+12*epsilon, the linear term becomes -4-2*epsilon, and the constant is one. The result is 5+10*epsilon, recording f(2)=5 and f'(2)=10. With an ordinary finite step h=1/10, the exact change is 1+6/100+1/1000=1.061, rather than the first-order prediction one. Both computations are correct because they answer different typed questions.

## D8. Difference kernels, anchors, and chain inversion

For x=(x_0,...,x_n), let d_t=x_t-x_(t-1), 1<=t<=n. Two sequences with the same differences differ by a constant. Subtracting their difference equations shows equal successive discrepancies, and induction makes the discrepancy constant at every index. Thus the difference observation has a one-dimensional kernel. An independently observed anchor x_0=b gives

```text
x_t=b+sum_(k=1)^t d_k.
```

The sum telescopes, proving both reconstruction and its uniqueness after anchoring. A terminal anchor works as well: b=x_n-sum_k d_k. Declaring b=0 chooses a representative; measuring b identifies a missing datum. A complex record can store that anchor on an imaginary axis, but cannot discover it from unchanged differences.

Worked example D-E8. Differences (3,4,5) have cumulative displacements (3,7,12). A terminal measurement x_3=20 gives x_0=8 and the full sequence (8,11,15,20). The carrier z_t=(x_t-x_0)+i*x_0 is reversible through x_t=Re(z_t)+Im(z_t). The final carrier 12+8i records displacement and anchor separately. Removing the imaginary coordinate leaves every translated sequence observationally equivalent.

The anchored cumulative transform is a different map. For u=(u_0,...,u_n), define Y_t=sum_(k=0)^t u_k. Its inverse is u_0=Y_0 and u_t=Y_t-Y_(t-1) for t>=1. Both round trips telescope. Its matrix is lower triangular with ones on the diagonal, so its determinant is one and its kernel is zero. A constant cumulative sequence (c,c,...,c) decodes to (c,0,...,0), not to zero.

This inverse is the incidence-algebra Mobius inverse on a finite ordered chain. The conventional boundary Y_(-1)=0 makes the difference formula uniform, but it does not supply a new physical observation. Omitting Y_0 or omitting an external physical offset defines a different observation map and changes the kernel. The distinction is essential whenever initial-state recovery is discussed.

For a differentiable function on a connected interval, derivative observations similarly determine the function up to a constant; an initial value supplies an integral reconstruction. Once dynamics are imposed, the admissible family can be smaller. If x'=a*x with known a!=0, an observed derivative identifies x=x'/a; if x'=0, it does not. Identifiability concerns the observation map restricted to the declared dynamics, not a slogan about all derivatives losing the same information.

## D9. Arithmetic Mobius inversion and genuine filters

The arithmetic Mobius function is mu(1)=1, mu(n)=0 if n contains a squared prime factor, and mu(n)=(-1)^s for a product of s distinct primes. For n>1, square-free divisors correspond to subsets of its distinct prime factors, giving sum_(d|n) mu(d)=(1-1)^s=0. For n=1 the sum is one.

PROVED D-P8. If A(n)=sum_(d|n) a(d), then

```text
a(n)=sum_(d|n) mu(d)*A(n/d).
```

Substitute A and collect the coefficient of a(k). It is zero unless k divides n, and in that case it equals sum_(d|(n/k)) mu(d). The preceding cancellation leaves only k=n. Every sum is finite, so no convergence hypothesis enters. On indices 1,...,L, the forward divisor matrix is triangular with diagonal one and the Mobius formula supplies its inverse. This proves both possible round trips.

Worked example D-E9. Let a(n)=n. Then A(1)=1, A(2)=3, A(3)=4, and A(6)=12. Reconstruction at six gives 12-4-3+1=6. For a(n)=x^(-n), the same formula gives

```text
(x^-1+x^-2+x^-3+x^-6)-(x^-1+x^-3)
 -(x^-1+x^-2)+x^-1=x^-6.
```

The intermediate representation includes lower powers that cancel. The fact mu(4)=0 does not erase the fourth output mode: the inverse still reconstructs x^-4. Applying a transform and its exact inverse is a representation change, not a newly created spectral mask.

A genuine modified filter can be defined by inserting an operator B between transform T and inverse U=T^-1, giving a_new=U*B*T*a. If B=I, this is exactly a. If B deletes selected transformed coordinates, then the kernel and reconstruction error of U*B*T must be analyzed. The filter can be useful, but it receives a new definition and cannot inherit the original round-trip certificate. The same principle applies to truncated Fourier synthesis, derivative channels, and partial geometric observations.

Chain incidence inversion and arithmetic divisor inversion are related as inverses of cumulative incidence operators on different partially ordered sets. Their index relations differ: one sums over earlier chain positions, the other over divisors. Fractional-linear Mobius coordinates are a third use of the name and are unrelated to the integer weights mu(n). Standard notation should identify which map is intended before any inverse is used.

## D10. Reciprocal exponentials, repeated derivatives, and phase paths

Consider E(t)=exp(t)-1=sum_(n>=1) t^n/n!, and F(x)=E(1/x) for nonzero complex x. E is entire in t. F is holomorphic away from zero and has an essential singularity at zero: its Laurent series contains infinitely many nonzero negative-power coefficients. A coordinate reciprocal does not transport entirety through its excluded point.

Mobius inversion can rewrite every x^-n inside F as a finite divisor expression. It reconstructs the same F. To justify manipulating the resulting infinite triple sum, fix a compact set with |x|>=delta>0 and derivative order m>=0. Put Q=max(1,delta^-1). There are at most n^2 divisor pairs, every contributing power k is at most n, and its m-th derivative is bounded by (n+m)^m*delta^-m*Q^n. Consequently the entire n-th contribution is bounded by

```text
n^2*(n+m)^m*delta^-m*Q^n/n!.
```

The ratio of successive bounds tends to zero. Their sum therefore converges, yielding absolute locally uniform convergence for each fixed derivative order. Termwise differentiation is justified on a compact neighborhood avoiding zero, either through the derivative-series bound and integration or the holomorphic Cauchy formula. This is not a uniform statement over all orders m and all radii.

For integers k>=1 and m>=0, with the empty product (k)_0=1,

```text
(k)_m=k*(k+1)*...*(k+m-1).
D_x^m(x^-k)=(-1)^m*(k)_m*x^(-k-m).
```

Induction proves this: one more derivative multiplies by -(k+m) and increases the negative exponent by one. At fixed m, (k)_m is a degree-m polynomial in k. At fixed k and growing m, its growth is factorial in m. Describing both regimes as the same damping process hides their different magnitudes. With x=r*exp(i*theta), the derivative modulus is (k)_m*r^(-k-m), independent of theta, while

```text
Im(D_x^m x^-k)=(-1)^(m+1)*(k)_m*r^(-k-m)*sin((k+m)*theta).
```

Worked example D-E10. For k=3,m=2,r=2, the derivative is (3/8)*exp(-5i*theta). At theta=pi/10 its imaginary part is -3/8. At theta=pi/5 the derivative is -3/8, with imaginary part zero. The mode survives; only one observation coordinate vanishes. One angle also changes all harmonic gains together. The gains sin(theta) and sin(2*theta) cannot both equal one, since sin(theta)=1 forces sin(2*theta)=0.

Phase rates must be differentiated along a real path. Let x=x(s) be C^1, with x!=0 and F(x)!=0. Write F(x(s))=R(s)*exp(i*phi(s)) locally, R>0. Differentiate and divide by F to obtain

```text
(log R)'=Re[(F'/F)(x(s))*x'(s)].
phi'=Im[(F'/F)(x(s))*x'(s)].
F'/F=-exp(1/x)/[x^2*(exp(1/x)-1)].
```

These are PROVED D-P9 under the stated path and nonzero conditions. Writing F=U+i*V gives the independent real formula phi'=(U*V'-V*U')/(U^2+V^2). A nonconstant real modulus is not a holomorphic function of a complex variable; using its supposed complex derivative is ill-typed. The tangent x'(s) cannot be omitted when the observation path changes.

For the simpler signal G(x)=x, the path x(s)=exp(i*s) gives (G'/G)*x'=i and phase rate one. A horizontal path x(s)=s+i gives Im[1/(s+i)]=-1/(s^2+1), a different rate. The quotient G'/G is the same analytic expression, but the paths and phases differ.

For F=exp(1/x)-1, the zeros are x=1/(2*pi*i*j), j any nonzero integer. Taking modulus in exp(1/x)=1 forces Re(1/x)=0, and the sine/cosine equations force Im(1/x)=2*pi*j; these conditions are also sufficient. Each zero is simple because F'=-1/x^2 there. The logarithmic derivative is undefined at these zeros and amplifies uncertainty near them. Phase can be chosen continuously along an admitted path, but a single-valued global logarithm cannot cover loops around those simple zeros.

## D11. Fractional-linear coordinates and their poles

A fractional-linear coordinate map has the form

```text
y=T(x)=(a*x+b)/(c*x+d), a*d-b*c!=0.
x=(d*y-b)/(a-c*y).
```

The forward and inverse denominators must be nonzero on their declared charts. Cross multiplication derives the inverse, and substitution proves the round trip. The derivative is (a*d-b*c)/(c*x+d)^2 where defined. The determinant condition prevents the map from collapsing to a constant. On a chosen real interval avoiding its pole, it is monotone and provides a legitimate coordinate adapter.

Worked example D-E11. Let g(x)=x^3-x-1 on [1,2], and choose z=1-1/x. Then z ranges bijectively over [0,1/2], with x=1/(1-z). Multiplication by the nonzero factor (1-z)^3 gives

```text
h(z)=z^3-4*z^2+5*z-1=(1-z)^3*g(1/(1-z)).
```

Expanding 1-(1-z)^2-(1-z)^3 proves the polynomial identity. An admitted root of h maps to a root of g and conversely. The pole z=1 is outside the transformed interval. The substitution reorganizes the cubic; it does not make its additive terms linear. An interval or exact original-equation verifier remains the final certificate.

Multiplying a rational equation by a denominator without retaining its exclusions is a different operation. For (x-1)/(x-1)=1, the cleared polynomial is zero but x=1 remains excluded from the original domain. A coordinate adapter therefore stores its forward map, inverse map, guards, and correspondence of solution sets together.

## D12. Projective directions and affine asymptotes

An exact conic F(x,y)=A*x^2+B*x*y+C*y^2+D*x+E*y+F0 has homogeneous form

```text
Fh(X,Y,Z)=A*X^2+B*X*Y+C*Y^2+D*X*Z+E*Y*Z+F0*Z^2.
Fh(X,Y,Z)=Z^2*F(X/Z,Y/Z), Z!=0.
```

The identity follows by substitution. Nonzero common scaling preserves its zero set and multiplies its value by the square of the scale. It does not selectively suppress terms involving Z. Infinity is examined after projective normalization when affine coordinates escape, not by multiplying every coordinate by the same factor.

At Z=0, finite candidate slopes m=Y/X satisfy A+B*m+C*m^2=0. For a nonzero quadratic block, B^2-4*A*C distinguishes two real directions, one repeated real direction, or no real direction. A direction is not yet an affine line asymptote. For y^2=x, the infinity equation Y^2=0 gives horizontal direction, but y=+/-sqrt(x) moves arbitrarily far from every horizontal line. For y^2+1=0, a real projective point at infinity coexists with no real affine points at all.

PROVED D-P10. For a simple finite direction m, set k=B+2*C*m!=0 and b=-(D+E*m)/k. Substitute y=m*x+b+epsilon. The exact remaining equation is

```text
C*epsilon^2+(k*x+2*C*b+E)*epsilon+R0=0.
R0=C*b^2+E*b+F0.
```

If C=0, its small solution is -R0/(k*x+E). If C!=0, for sufficiently large |x| its discriminant is positive and the small solution is

```text
epsilon=-2*R0/[H+sgn(H)*sqrt(H^2-4*C*R0)],
H=k*x+2*C*b+E.
```

The denominator is asymptotic to 2*k*x, proving epsilon=O(1/x) and y=m*x+b+O(1/x). This establishes an actual branch and its line under an exact conic hypothesis. At k=0 the direction is repeated and the intercept division is unavailable; it does not mean the asymptote is vertical. Vertical directions require a separate slope chart.

Worked example D-E12. The upper hyperbola branch y=2+2*sqrt(1+(x-1)^2/9) has line y=(2/3)*x+4/3 as x tends positively to infinity. Put t=x-1>0. Its exact line error is

```text
epsilon=(2/3)*(sqrt(t^2+9)-t)
       =6/(sqrt(t^2+9)+t), 0<epsilon<=3/t.
```

At x=10, t=9 and the error is 6/(sqrt(90)+9), approximately 0.3246; the bound is 1/3. Rationalization proves the decay without a fitted extrapolation. Conversely, y=x+sqrt(x) has y/x tending to one but y-x diverging. A relative direction limit cannot be promoted to bounded absolute distance from a line.

A conic fitted to finitely many points yields a model-conditional prediction. Its coefficient vector needs a nonzero normalization, because unconstrained algebraic-residual minimization chooses the zero polynomial. Rank, singular-value separation, and the distinction between algebraic residual and perpendicular distance control stability. Adding a multiple of product_i(x-x_i)^2 leaves every sampled value unchanged while altering the distant tail. No finite fit alone proves an arbitrary unknown function's asymptote.

# Projections, quaternion rotations, and the dual-funnel boundary

Geometry becomes a solver component when its coordinates, metric, and state evolution are explicitly connected to the original problem. Three-dimensional orientation is a legitimate use of quaternions. Log-polar coordinates organize scale changes. Orthographic views expose selected components. None of these operations automatically preserves every metric, supplies missing constraints, or changes a contracting trajectory into a chaotic attractor. The following constructions give useful exact forms while retaining those distinctions.

## D13. Projection kernels and 120-degree lattice pictures

For a unit normal n in R^3, orthographic projection onto its perpendicular plane is P=I-n*n^T. Direct multiplication gives P^2=P and P*n=0. If v=v_perp+alpha*n, its image is v_perp. Thus an entire line of spatial points has the same image. Projection preserves lengths only for displacements already in the plane; in general |P*v|<=|v|.

Worked example D-E13. Choose n=(1,1,1)/sqrt(3). The projected coordinate axes are

```text
p1=(2,-1,-1)/3; p2=(-1,2,-1)/3; p3=(-1,-1,2)/3.
p1+p2+p3=0.
|p_j|^2=2/3; p_j dot p_k=-1/3 for j!=k.
```

Their mutual cosine is (-1/3)/(2/3)=-1/2, so the originally perpendicular axes appear 120 degrees apart. This explains a triangular lattice projection through an exact metric calculation. It does not make the projected axes orthogonal. The points (0,0,0) and (3,3,3) both project to zero. Recovering depth needs another observation or a justified constraint selecting one point from each line.

For an orthonormal complete basis u_1,...,u_d, sum_j u_j*u_j^T=I and |x|^2=sum_j(u_j^T*x)^2. An incomplete family gives a projection and an inequality. These identities distinguish complete coordinate recovery from a useful lower-dimensional view. Multiple projections can jointly become injective: stacked observation matrices recover x exactly when their common kernel is zero. A second camera or a known plane can supply depth; repainting the first projection cannot.

Diagram meaning also depends on embedding. On residue-clock coordinates iota(x)=exp(2*pi*i*x/9), arithmetic negation x->-x becomes conjugation, a reflection. A regular nine-gon has no diametrically opposite vertex pair. On unit-orbit coordinates eta(2^j mod 9)=exp(2*pi*i*j/6), doubling becomes a 60-degree rotation and negation becomes a half-turn, because 2^3 == -1 (mod 9). These are representations of different labelled structures. In the six-dimensional permutation representation, the third iterate sends basis vector e_x to e_(-x); it is not the scalar matrix -I. A geometric assertion must name its embedding before identifying reflection, label negation, and coefficient negation.

## D14. Log-polar scale coordinates retain a metric

For r>0, use u=theta modulo 2*pi and v=log(r/r_ref). The punctured plane is identified with S^1 times R, with inverse r=r_ref*exp(v). Uniform dilation r->lambda*r becomes v->v+log(lambda). A logarithmic spiral r=r0*exp(b*theta) becomes a straight relation v=b*theta+log(r0/r_ref) on an unwrapped angular coordinate. When b!=0, each turn changes v by 2*pi*b, so it is not a single-valued graph over theta modulo 2*pi.

The Euclidean metric and area become

```text
ds^2=r_ref^2*exp(2*v)*(dv^2+du^2).
dArea=r_ref^2*exp(2*v)*du*dv.
```

Substitute dr=r*dv into dr^2+r^2*dtheta^2 to prove the first identity; the Cartesian inverse's Jacobian proves the second. Dropping the factor exp(2*v) changes length and geodesic optimization. Conformal coordinates preserve angles locally, not arbitrary distances or curvature values.

For a concrete distance comparison, take r_ref=1 and a radial move from r=1 to r=2 at fixed angle. Its Euclidean length is one. Its coordinate difference is log(2), approximately 0.6931. Integrating the transformed metric gives integral_0^log(2) exp(v) dv=1; treating the coordinates as an ordinary Euclidean plane gives the wrong length. The coordinate map is useful precisely because the metric is carried along with it.

Discrete scale invariance has an equally precise form. If lambda>1 and f(lambda*r)=lambda^a*f(r), put P(t)=lambda^(-a*t)*f(lambda^t). Substitution gives P(t+1)=P(t), so f(r)=r^a*P(log_lambda(r)). A periodic factor may be Fourier-expanded when its regularity supports that expansion. Its fundamental angular log-frequency is 2*pi/log(lambda), not log(lambda). For lambda=2 and P(t)=cos(2*pi*t), equal-phase radii repeat by factors of two. This prescribed spatial scaling law is not automatically a temporal oscillation or an orbital stability theorem.

## D15. Quaternion packages and actual rotations

Hamilton quaternions have the form q=s+x*i+y*j+z*k, with i^2=j^2=k^2=i*j*k=-1. In scalar-vector notation q=(s,v), multiplication is

```text
(s,v)*(t,w)=(s*t-v dot w, s*w+t*v+v cross w).
conj(q)=(s,-v); q*conj(q)=s^2+|v|^2.
```

Their multiplication is noncommutative: i*j=k while j*i=-k. A pure quaternion (0,v) is a reversible record of three real coordinates. It is not generally a unit quaternion and should not be normalized if the magnitude of those coordinates matters. Extracting its components before evaluating ordinary equations preserves their intended real arithmetic. Replacing real variables by i,j,k inside a polynomial changes the multiplication law and changes the problem.

For a unit quaternion q, define a rotation by v' as the vector part of q*(0,v)*conj(q). PROVED D-P11 states that it preserves |v| and has inverse conjugation by conj(q). Norm multiplicativity follows from conjugating products in reverse order and using q*conj(q)=|q|^2; the unit factors leave the pure quaternion's norm unchanged. Direct expansion shows its scalar part remains zero. Thus the map is real-linear and orthogonal.

For a unit axis a and angle alpha, q=cos(alpha/2)+a*sin(alpha/2). Expansion gives Rodrigues' formula

```text
v'=cos(alpha)*v+(1-cos(alpha))*(a dot v)*a
                    +sin(alpha)*(a cross v).
```

The component parallel to a is fixed; perpendicular components rotate through alpha. The half-angle is required because conjugation applies q on both sides. Quaternions q and -q give the same rotation. Composition order remains significant: q2*q1 represents the rotation by q1 followed by q2 in this active-vector convention. Frame-coordinate conventions can reverse signs or order, so a code adapter must declare them.

Worked example D-E14. A positive 90-degree rotation about the x-axis uses q=(1+i)/sqrt(2). It sends (x,y,z) to (x,-z,y), hence e_y to e_z and e_z to -e_y. The normal e_z of the xy-plane becomes -e_y, so the plane becomes the xz-plane. The inverse is the negative 90-degree x rotation. A separate rational quaternion q=(3/5,4/5,0,0) gives an exact algebraic test of norm preservation without approximating sqrt(2); all 125 integer vectors in {-2,...,2}^3 were rotated and inverted exactly.

In the recovered three-variable solver, q=k_x*i+k_y*j+k_z*k stores chart coordinates X_i=r_i+M*k_i and physical coordinates theta_i=X_i/D_i. Its actual loss is evaluated on those extracted real components. The chain rule gives dJ/dk_i=(M/D_i)*dJ/dtheta_i; applying that factor twice would corrupt a gradient. Paired lock-in estimates proposals inside this chart. Quaternion multiplication is unnecessary for that storage-and-probing task, and a real vector implements the same updates.

The useful division of work is operational: residue methods produce sound retained lattice charts; continuous probing proposes promising nearby points; exact original-equation checks validate snapped points; exhaustive checking of all retained finite candidates supplies completeness. The quaternion package does not prove global numerical convergence or completeness. It provides clean three-axis bookkeeping and, when conjugation is actually used, a verified spatial rotation.

## D16. Mirror-conjugate contracting flows

The supplemental Dual-Funnel Projection Theorem is a document by Griff Gurwell, dated October 2026. Its elementary geometric theorem is separate from Stefan's later proposal to orient one spiral orthogonally to the other. The source's domain assumptions must be retained when its result is reused.

Let kappa>0 and w>0. The two complex flows are

```text
z_plus(t)=z0*exp((-kappa+i*w)*t).
z_minus(t)=z0*exp((-kappa-i*w)*t).
```

Orientation reflection M(z)=conj(z) satisfies M*Phi_plus(t)*M=Phi_minus(t). Conjugating exp((-kappa+i*w)*t) reverses the imaginary exponent and preserves the real one. Both flows contract in radius as r0*exp(-kappa*t), while their angles advance in opposite directions. This is PROVED D-P12. Replacing t by -t instead causes expansion, so mirror reversal and time reversal are different operations.

On unwrapped polar coordinates, log(r/r0)=-kappa*t and theta=theta0+/-w*t. Eliminating t gives a logarithmic spiral. A three-dimensional funnel interpretation requires an additional axial coordinate, surface definition, or vector field. The complex flow alone specifies a planar trajectory. Appending height h(t) produces a spatial curve, but its height law is an added modeling choice.

A known-target discrete spiral z_(n+1)=z_star+rho*exp(i*alpha)*(z_n-z_star), 0<rho<1, has error e_n=rho^n*exp(i*n*alpha)*e_0 and converges to z_star. The proof is direct iteration. It illustrates convergence only because z_star is already supplied. Rotating a projected answer can change that answer: the map z_new=(z+i)/2 converges to i, even if the intended constant consistency projection returns one. A contraction proves approach to its own fixed point; a separate fixed-point correspondence must identify that point with the original solution.

## D17. The half-radius projection theorem and the 90-degree change

The source projection class imposes four conditions. Two projected mouth circles have equal radius a; their centers are opposite points (0,c) and (0,-c); both circles pass through the origin; and they are internally tangent to an outer circle of radius R at opposite poles. Here R>0 and c>0 describe the nondegenerate construction.

PROVED D-P13. The common-origin condition gives a=c. Internal tangency gives a+c=R. Solving these two equations yields a=c=R/2. Conversely these values satisfy both conditions. The mouth circles are therefore

```text
x^2+(y-R/2)^2=R^2/4.
x^2+(y+R/2)^2=R^2/4.
```

Alternating inward semicircles produce the bicircular S-divider, with the two reflection-related orientation choices. Each arc has radius R/2 and length pi*R/2, so the full divider length is pi*R. Its curvature magnitude on either arc is 2/R. A half-turn exchanges the two complementary regions and preserves area; their areas are therefore equal, each pi*R^2/2. These conclusions are forced by the circular projection assumptions, not by mirror conjugacy alone.

Worked example D-E15. For R=10, the mouth radius and center displacement are both five. The divider length is 10*pi, approximately 31.416, and each complementary area is 50*pi, approximately 157.080. No secondary nested radius follows from the two equations. Choosing smaller copies is a recursion rule requiring its own scale and nonintersection conditions.

A 90-degree x-axis rotation creates a legitimate orthogonal-plane model, but changes the projection hypothesis. Consider

```text
gamma_1(t)=exp(-kappa*t)*(cos(w*t),sin(w*t),0).
gamma_2(t)=exp(-kappa*t)*(cos(w*t),0,sin(w*t)).
```

The second curve is the positive 90-degree x rotation of the first. Their planes have perpendicular normals e_z and -e_y. Their position vectors are not generally perpendicular: their dot product is exp(-2*kappa*t)*cos(w*t)^2. Perpendicular planes intersect along the x-axis, so orthogonal planes do not imply orthogonal corresponding points or tangent vectors.

Top-down orthographic projection discards z. A circular mouth in the xy-plane projects to a circle. After a 90-degree x rotation it lies in the xz-plane and projects to a line segment. More generally, a circular mouth tilted by angle beta has projected semiaxes a and a*|cos(beta)|. At beta=pi/2 the second semiaxis vanishes. Thus the rotated pair fails the original congruent-circle condition. The half-radius S-partition theorem cannot be transferred unchanged to this orthogonal-funnel view.

The useful repaired objects are explicit: the original mirror pair retains its exact planar bicircular theorem under its mouth assumptions; the rotated pair is a three-dimensional orthogonal-plane spiral model, with a different projection and no inherited S-divider guarantee. Quaternion conjugation provides the rotation certificate. Any proposed new projection theorem must start from its changed mouth geometry rather than from the familiar appearance of the original diagram.

## D18. Contracting spirals are not evidence of chaos

The displayed flows have an attracting equilibrium at the origin. For any two initial states z0,z1, their separation at time t is exp(-kappa*t)*|z0-z1|. It decreases exponentially. The largest linear Lyapunov rate is therefore -kappa. Every trajectory tends to zero. For independent products of these flows, the Euclidean separation of the combined state also contracts at that rate. A fixed spatial rotation preserves these facts because it preserves distances.

PROVED D-P14 therefore refutes a chaotic-attractor interpretation for this particular linear contraction model. Crossing projected traces, two apparent lobes, opposite winding, or a rotated plane does not establish recurrent chaotic dynamics. A point equilibrium is an attractor, but the adjective strange requires a different dynamical claim.

An actual investigation of a proposed strange attractor needs an autonomous map or vector field, an admissible state domain, a bounded invariant or trapping region, and a definition of the claimed recurrent set. Lyapunov calculations must be tied to that model and checked for step-size and trajectory-length dependence. A positive finite-time numerical exponent would be approximate evidence, not a theorem by itself. The present source supplies neither a nonlinear coupling law nor such evidence. The corrected orthogonal construction remains useful as an orientation test, a contraction visualization, and a controlled geometric seed.

Equal-phase sampling also needs a quotient distinction. Sampling theta in increments 2*pi/n gives angular labels in C_n. Reflection sends the phase generator to its inverse, yielding the usual dihedral completion of order 2*n. The full contracting state does not return after n samples because its radius has decreased. C_n describes the angular quotient or a separately defined phase register. It is not the complete state group of a contracting flow.

## D19. Icosahedral flags, routes, and a separate 120-state register

The recovered doubling-vortex report introduces an icosahedral model as an additional geometric state space. Twelve spherical sites are a new premise; they are not forced by the six units modulo nine. A regular icosahedron can be defined by vertices proportional to

```text
(0,+/-1,+/-tau), (+/-1,+/-tau,0), (+/-tau,0,+/-1),
tau=(1+sqrt(5))/2, tau^2=tau+1.
```

In these unnormalized coordinates, nearest neighbors have squared separation four. There are twelve vertices, thirty edges, and twenty triangular faces. Each vertex has five neighbors, so the edge count is 12*5/2=30; each edge belongs to two triangles, so the face count is 2*30/3=20. A flag is an incident vertex-edge-face triple. Every triangle has three edges and each edge two endpoints, giving 20*3*2=120 flags.

Changing just the vertex, edge, or face of a flag gives involutions r0,r1,r2. Moving around a triangular face gives (r0*r1)^3=1; moving around a five-face vertex gives (r1*r2)^5=1; the independent endpoint and face changes at a fixed edge commute, giving (r0*r2)^2=1. These global adjacent-flag toggles form the monodromy action, isomorphic to the full symmetry group's opposite regular action. A toggle need not be one fixed spatial isometry on every flag. This is the standard H3 Coxeter flag structure. Vogan's primary slides identify the corresponding icosahedral symmetry group of order 120. The accompanying exact enumeration constructs these 120 flags from the coordinates, generates exactly 120 permutations, and checks the relations.

FINITE D-F1. That specific finite action has element orders 1,2,3,5,6,10. In particular it is not cyclic and has no element of order 120. Merely arranging its flags in a list of length 120 creates an indexing cycle; it does not create an order-120 rigid spatial rotation.

Another 120-element set consists of all directed non-antipodal routes between the twelve vertices: each start has ten eligible destinations. It includes both adjacent and more distant vertex pairs, so it is not the thirty-edge nearest-neighbor graph. Its equal cardinality does not make it the same symmetry action as the flag set. A traversal ordering of routes is a routing rule, with its own state and transition contracts.

A genuine cyclic 120-state register can be specified as C_24 times C_5 with simultaneous update (a,b)->(a+1,b+1). Its first return occurs when both 24 and five divide the step count, hence at lcm(24,5)=120. This is a proof about explicitly supplied registers. Their counts do not follow from the icosahedral flags or the 3-adic unit tower.

For class-I icosahedral subdivision frequency f, the face count is 20*f^2, the edge count is 30*f^2, and the vertex count is 10*f^2+2 by Euler's sphere identity. At f=120, the vertex count is 144,002, not 144,000. The latter equals the count minus the Euler characteristic two. If a separately chosen phase generator g has order 120 and one cell advances phase by g, endpoint closure says 120 divides f. Only an additional first-return requirement selects f=120 rather than a larger multiple. These exact models make arithmetic, geometry, and synchronization usable together while keeping their additional coupling assumptions visible.

## D20. Practical contracts and exercises

The spectral-and-geometric component accepts a domain D, an observation map O, a coordinate map T where genuinely invertible, and a verifier V. A finite Fourier block supplies a matrix and a rank certificate. A discarded projection supplies a kernel and the anchors needed for recovery. An oscillatory probe supplies frequencies, amplitude, domain guards, and coefficient error bounds. A quaternion supplies an orientation convention and an inverse. A fitted curve supplies a model assumption and a residual metric. The output remains a coefficient record, geometric reconstruction, certified correspondence, or numerical proposal according to that contract.

These components serve concrete tasks: drawing compressed outlines; transmitting finite constellations over measured waveforms; estimating derivatives of costly experimental responses; checking whether boundary data identify a state; moving an algebraic search to a better interval; separating projective direction from actual tail distance; and testing a three-dimensional orientation before asserting properties of its projection. Their shared advantage is structured access to information already present in the model, together with transparent accounting for information lost.

Exercise D-X1. A record a+b*omega+c*omega^2 equals zero and its anchor is a+b+c=9. Determine all real coefficients. Answer: the complex equation has kernel (t,t,t), so the anchor gives a=b=c=3. Without the anchor there is an entire line of solutions.

Exercise D-X2. On an eight-sample grid, compare cosine bins one and seven, and decide whether two unrestricted amplitudes are identifiable. Answer: cos(2*pi*7*n/8)=cos(2*pi*n/8), so only their sum is observed. Adding a sine channel with a declared sign convention changes the design; relabelling the two cosine columns does not.

Exercise D-X3. A unit-circle scan has C0=9, A2=1, B2=-2 and an independently measured center J0=6. Recover its plane Hessian. Answer: trace=4*(9-6)=12, difference=4, and mixed entry=2*(-2)=-4. Thus H=[[8,-4],[-4,4]]. Omitting J0 leaves the trace free.

Exercise D-X4. A cumulative array is (7,7,7). Compare its anchored chain inverse with ordinary adjacent differences. Answer: the inverse is (7,0,0), while adjacent differences are (0,0). Their domains have different dimensions and their kernels differ.

Exercise D-X5. Rotate a circle of radius three in the xy-plane through 60 degrees about x, then project top-down. Answer: its image is an ellipse with semiaxes three and 3*cos(60 degrees)=3/2. A 90-degree tilt produces a segment. The circular-mouth projection theorem requires renewed hypotheses after either tilt.

Exercise D-X6. A phase has 120-state generator g, but each spatial cell advances by g^8. Find the first closure frequency. Answer: 120/gcd(120,8)=15. A group order does not determine the physical update step.

The local check scripts separate exact rational identities from binary64 experiments. They preserve input hashes, tested ranges, and regeneration commands. Original source titles containing audited or certified are not substitutes for those checks. The chapter proofs establish the stated general implications; the recorded finite runs verify selected formulas, data, and implementations within their declared scope.

## D21. Primary references and dependency boundaries

D-R1. MathWorks, Discrete Fourier Transform, R2026b, inspected 13 October 2026. The documented transform signs and inverse factor are translated to zero-based indexing here. URL: https://www.mathworks.com/help/signal/ug/discrete-fourier-transform.html . The chapter gives its own finite character proof and does not infer a continuous reconstruction theorem from the finite inverse.

D-R2. Stanford Research Systems, About Lock-In Amplifiers, Application Note 3, pages 1-2, inspected 13 October 2026. This primary manufacturer source explains reference multiplication, averaging, and quadrature. URL: https://www.thinksrs.com/downloads/pdfs/applicationnotes/AboutLIAs.pdf . Its sine-reference convention is translated explicitly; it supplies no universal optimization theorem.

D-R3. NIST Digital Library of Mathematical Functions, version 1.2.8, released 15 September 2026, Sections 27.5 and 1.9, inspected 13 October 2026. Formulas 27.5.2-3 identify arithmetic Mobius inversion; Section 1.9 supplies complex polar and analytic conventions. URLs: https://dlmf.nist.gov/27.5 and https://dlmf.nist.gov/1.9 . Self-contained finite cancellation and pathwise phase derivations appear above.

D-R4. NASA/JPL NAIF, CSPICE Required Reading: Rotation, quaternion and composition sections, inspected 13 October 2026. The scalar-first Hamilton convention, conjugation, and composition order match the declared active-vector convention. URL: https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/rotation.html . A pure coordinate package and a unit orientation quaternion remain distinct objects.

D-R5. David Vogan, Regular polyhedra and Coxeter groups, Tufts lecture 25 January 2019, corrected version 26 January 2019, slides 9-12 and 21-22, inspected 13 October 2026. Flags, adjacent-flag generators, and the H3 icosahedral group of order 120 are the checked source scope. URL: https://math.mit.edu/~dav/regpolyTUFTSHO2.pdf . The exact finite action is also independently enumerated in D_verify.py.

D-R6. Griff Gurwell, The Dual-Funnel Projection Theorem, October 2026, supplied local PDF, full seven-sheet document including cover read. This is source material provided for review, rather than an independently peer-reviewed dynamical theorem. Its elementary P1-P4 radius calculation is reconstructed above. Its circular projection result does not supply a strange-attractor theorem or the changed projection of an orthogonal funnel.
