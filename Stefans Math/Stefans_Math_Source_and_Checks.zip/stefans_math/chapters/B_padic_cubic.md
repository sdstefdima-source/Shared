# Prime-power digits, valuation, and multiplicative coordinates

## B1. What a prime-power coordinate actually records

Stefan's recurring proposal is to expose a difficult quantity in several simpler coordinates, recover manageable pieces, and recombine them. Prime-power arithmetic supplies a precise version of that proposal. The useful pieces are residues, divisibility depths, finite unit components, and compatible digit corrections. Their roles differ. A residue describes a whole fiber of possibilities; a divisibility depth describes a scale; a unit coordinate describes the remaining multiplicative part. A reconstruction method becomes exact when every discarded possibility is excluded by a necessary condition and every retained ambiguity remains represented.

For a prime p and positive precision k, a residue modulo p^k records the first k least significant base-p digits. Increasing k exposes another digit at the high end of that known prefix. The ordinary integers producing one observation r are exactly r+p^k*t with t an integer. Thus the observation map O(x)=x modulo p^k generally loses the quotient t. A finite bound can later constrain that quotient. Rewriting the same observation in another coordinate cannot expose an additional digit that was never observed.

The finite ring Z/p^k Z and the infinite ring Z_p serve different purposes. The first is a finite calculation space with p^k elements. The second consists of compatible sequences of residues at every precision. Compatibility means that a residue at level k+1 reduces to the previously recorded residue at level k. An arbitrary sequence of modular answers need not have that property. The field Q_p additionally permits negative powers of p; an element with negative valuation lies outside Z_p.

The p-adic distance declares two numbers close when their difference is divisible by a high power of p. This is a different notion of closeness from small real error. The representatives p^k-1 grow as real integers but approach -1 p-adically, since their differences from -1 equal p^k. No contradiction occurs: the two metrics measure different features. A local solver reporting a p-adic approximation must name its prime and precision. Without those fields, an integer-looking answer can be mistaken for an ordinary integer root.

## B2. Valuation, cancellation, and finite precision

For nonzero rational x, write x=p^t*u with numerator and denominator of u both coprime to p. Define v_p(x)=t, v_p(0)=infinity, and |x|_p=p^(-t). The integer t counts net divisibility rather than ordinary magnitude. The basic rules follow immediately from factoring powers of p:

```text
v_p(x*y)=v_p(x)+v_p(y).
v_p(x/y)=v_p(x)-v_p(y), y != 0.
v_p(x+y)>=min(v_p(x),v_p(y)).
If v_p(x)!=v_p(y), equality holds in the final relation.
```

**B-P1, PROVED: the unique least-valuation obstruction.** A finite sum of nonzero terms cannot vanish if exactly one term has strictly smaller valuation than every other term. Divide by the smallest power of p. The exceptional term becomes a unit, while every other term becomes divisible by p. Reduction modulo p leaves a nonzero residue, contradicting zero. This proves a useful exclusion rule without solving the original equation.

For a polynomial f(X)=sum_j a_j*X^j and a proposed nonzero root of valuation t, its term weights are w_j(t)=v_p(a_j)+j*t, omitting zero coefficients. At least two weights must attain the minimum. Pairwise intersections of the weight lines supply possible scales, but an intersection matters only when its common weight is globally minimal. A rational intersection slope can describe a root in an extension field. In Q_p itself, nonzero valuations are integers; in Z_p they are nonnegative integers.

For example, X^3-3 has term weights 3t and 1. Equality would require t=1/3, so the equation has no root in Q_3. This says nothing about its positive real root or its roots in algebraic extensions of Q_3. In contrast, for X^3-27 the possible scale t=1 survives; setting x=3u produces u^3=1. The scale condition is necessary, and the normalized unit equation decides whether it is sufficient.

**B-P2, PROVED: scale normalization preserves roots.** Set m=min_j w_j(t), substitute X=p^t U, and define h(U)=p^(-m)f(p^t U). Every coefficient of h is p-integral because its valuation is w_j(t)-m>=0. On units U, the substitution is a bijection onto quantities of valuation t, and multiplication by the nonzero scalar p^(-m) preserves the zero set. This is an exact coordinate change. It is not a claim that all possible scales contain roots.

Finite observations need an explicit loss rule. If x is known modulo p^k and has observed valuation t<k, its unit quotient is known only modulo p^(k-t). If the observed residue is zero, the conclusion is v_p(x)>=k; exact zero has not been established. In a finite ring the truncated valuation of zero is conventionally k, whereas the field valuation of exact zero is infinity. Keeping those definitions separate prevents accidental division of unknown digits.

### B-E1. Extracting scale without inventing precision

Suppose x is observed as 75 modulo 243. Since 75=3*25 and 25 is not divisible by 3, the observed scale is t=1. Every possible original integer has the form 75+243q=3*(25+81q). The unit coordinate is therefore 25 modulo 81, and no stronger unit observation follows. Its known ternary digits are 25=1+2*3+2*9+0*27; the quotient digit beyond 81 remains unknown.

Multiplying two such observations gives a product of scale 2, provided both observed unit parts remain units. Their unit product is known modulo 81, which corresponds to the product modulo 3^6 after restoring scale 2. Addition behaves differently: 75+6=81 has valuation 4, although both summands have valuation 1. Their unit residues cancel. This numerical contrast explains why valuations add under multiplication but need a cancellation calculation under addition.

A practical representation stores the prime, absolute precision k, observed depth t, and unit precision k-t. A zero residue stores a lower bound on depth rather than a guessed unit. Every operation must propagate those fields. A logarithm taken after scale removal receives the smaller precision, not the original k.

## B3. Separating torsion from the principal unit

For odd p, a nonzero element of Q_p has a unique decomposition

```text
x=p^t*omega*u1,
t in Z, omega^(p-1)=1, u1 in 1+pZ_p.
```

The factor omega is the Teichmuller lift of the nonzero residue of the unit part. It exists uniquely because the polynomial W^(p-1)-1 has nonzero derivative at every nonzero residue root. The lifting proof appears in the next chapter. Removing omega leaves residue 1 modulo p, which is exactly the principal-unit condition. The finite root-of-unity factor and the principal unit intersect only in 1, establishing uniqueness.

At finite precision, for an ordinary scalar unit u and odd p, omega(u) can be computed as u^(p^(k-1)) modulo p^k. Raising a principal unit to p^(k-1) annihilates it at that precision; raising a torsion unit to this exponent fixes it because p^(k-1)==1 modulo p-1. The formula does not mean that integer exponentiation becomes cheap at every large precision. It is an exact alternative to lifting the torsion equation.

For Q_2, every odd unit is a sign times an element of 1+4Z_2. The sign is selected from the residue modulo 4: use +1 for residue 1 and -1 for residue 3. Consequently a full scalar coordinate is x=2^t*sign*u1. This binary sign rule is specific to residue degree one. In a larger unramified coefficient ring, the quotient (1+2O)/(1+4O) has several coefficient directions, and one sign bit does not remove them all.

The word logarithm names three different constructions in this project. The ordinary real logarithm measures real scale and satisfies log(ab)=log(a)+log(b) for positive real inputs. A finite-group discrete logarithm asks for an exponent residue n with g^n=h. The p-adic logarithm is a convergent series giving an additive coordinate on suitable principal units. None can be substituted for another merely because exponents occur in the problem.

## B4. The genuine logarithmic chart and its guards

The relevant analytic series are

```text
log_p(1+z)=sum_(n>=1) (-1)^(n+1)*z^n/n.
exp_p(y)=sum_(n>=0) y^n/n!.
Odd p: 1+pZ_p <-> pZ_p.
p=2:   1+4Z_2 <-> 4Z_2.
```

**B-P3, PROVED: inverse multiplicative coordinates on these domains.** Legendre's counting identity v_p(n!)=sum_(j>=1) floor(n/p^j) gives the exponential term valuations. For odd p and v_p(y)>=1, they tend to infinity; at p=2 the sufficient integral condition is v_2(y)>=2. The logarithm term valuations tend to infinity whenever v_p(z)>0. On the narrower common domains, every term after the first has strictly greater valuation than the first. Thus v_p(log_p(1+z))=v_p(z) and v_p(exp_p(y)-1)=v_p(y).

The formal identities exp(A+B)=exp(A)exp(B), log(exp(Y))=Y, and exp(log(1+Z))=1+Z hold over rational power series. The binomial theorem proves the first; formal differentiation and constant coefficients prove the second; compositional inversion with linear coefficient 1 proves the third. The term valuation bounds justify substitution and regrouping on the stated p-adic domains. Consequently log_p(uv)=log_p(u)+log_p(v) and the displayed charts are inverse group isomorphisms. This argument uses commutativity and cannot be silently transferred to noncommuting matrix products.

Convergence and injectivity are separate properties. The 2-adic logarithm converges on all odd scalar units, but log_2(-1)=0. Indeed, its product law gives 2log_2(-1)=log_2(1)=0 in characteristic zero. Hence log_2(1)=log_2(-1), so this larger domain is not an invertible chart. The sign must be retained or the inputs restricted to 1+4Z_2. Similarly, extending the odd-prime logarithm across all units erases their finite torsion component.

The chart linearizes products and powers. It supplies no identity log_p(u+v)=log_p(u)+log_p(v). In a general cubic, additive terms remain coupled. The useful operational form is therefore a guarded transform: first establish the unit domain, remove valuation and torsion when required, apply the product relation, retain its precision, and reconstruct with exp_p. Conditions established on that guard cannot reject candidates outside it.

## B5. Exact finite series evaluation

At precision p^k, infinite analytic functions can be evaluated by finite exact sums. For odd p and inputs divisible by p, terms with n>=2k vanish modulo p^k. The logarithm term has valuation at least n-v_p(n), while the exponential term has valuation at least n-v_p(n!). For odd p, both denominator valuations are at most (n-1)/2, so both lower bounds are at least (n+1)/2. At p=2 on the safe depth-two domains, the analogous bounds are at least n+1. Thus the same conservative cutoff 2k works there too.

A denominator divisible by p cannot be inverted modulo p^k. Write it as p^e*d0 with d0 a unit. Compute the numerator modulo p^(k+e), cancel p^e exactly, then multiply by inverse(d0) modulo p^k. The extra e digits are necessary: changing the original numerator by a multiple of p^(k+e) changes the quotient only by a multiple of p^k. The first individually vanishing series term is not a valid stopping rule, since denominator valuations jump at later powers of p.

### B-E2. A pure cube with its missing input digit supplied

For a 3-adic unit c, retain its sign eta in {+1,-1} and set u=eta*c, so u==1 modulo 3. The equation x^3=c becomes a fixed sign equation and 3*ell=log_3(u), with ell in 3Z_3. Multiplication by 3 is injective on 3Z_3 and its image is 9Z_3. Therefore a unit has a 3-adic cube root exactly when log_3(u) is divisible by 9, equivalently c==+1 or -1 modulo 9.

For c=343 the sign is +1. Desired root precision is 3^6=729, so the logarithm input precision must be 3^7=2187. Exact truncated evaluation gives log_3(343)==666 modulo 2187. Division gives ell==222 modulo 729, and exact exponential evaluation gives exp_3(222)==7 modulo 729. Cubing checks 7^3=343, establishing an ordinary integer root in this special example as well as the local answer.

Without the extra input digit, division by 3 would determine ell only modulo 243. Finite cube congruences can have three solutions although the infinite 3-adic unit root is unique. The ambiguity reflects precision loss in the map ell->3ell. For p different from 3, the principal-unit cube map is invertible; any remaining multiplicity comes from the torsion equation omega^3=eta. For nonunit c, the valuation condition 3t=v_p(c) must also be solved.

## B6. Exercises on typed multiplicative coordinates

**B-X1.** From x==0 modulo 81, determine the strongest justified scale statement. **Answer:** v_3(x)>=4, with exact zero still possible. No unit coordinate is available until a nonzero higher digit is observed.

**B-X2.** Determine whether X^3=6 has a root in Q_3. **Answer:** v_3(6)=1 would require 3v_3(X)=1, impossible for an integer-valued Q_3 valuation. The exclusion is local and does not exclude the real cube root.

**B-X3.** Determine whether 5 is a 3-adic unit cube. **Answer:** the unit cubes modulo 9 are 1 and 8; 5 is neither. This finite obstruction already excludes every higher compatible root.

# Coupled exponents in coefficient rings

## B7. Why coefficients can expose several directions

A finite-group exponent equation can be difficult because its representation hides the scalar exponent. A principal-unit equation in an explicitly represented coefficient ring is different: its successive layers expose additive coefficient vectors. Stefan's proposed decomposition becomes practical when the representation makes those vectors available. The advantage comes from that public arithmetic structure, not from declaring every group to have several coordinates.

Let F(T) be monic of degree d and work in the commutative ring R_k=(Z/p^k Z)[T]/(F(T)). Monic division gives a unique representative with d coefficients modulo p^k. If F modulo p is irreducible, the residue algebra is the field F_(p^d), and this construction is an unramified Galois ring. Without irreducibility it is still a free coefficient algebra, but it must not automatically be called a field or an unramified local ring. The principal-unit theorem below needs freeness and commutativity; its digit proof does not need irreducibility.

For k>1 the ring R_k is not the field with p^(dk) elements. Its characteristic is p^k, and p is a nonzero nilpotent element. A field has neither property. For example, R_k=(Z/3^k Z)[alpha]/(alpha^2+1) has coefficient pairs (a,b) with multiplication (a,b)(c,e)=(ac-be,ae+bc). The residue polynomial is irreducible over F_3. A pair is a unit exactly when its two coefficients are not both divisible by 3; its inverse is (a,-b)/(a^2+b^2).

The principal units U_j=1+p^j R_k have successive layers

```text
(1+p^j*a)(1+p^j*b)==1+p^j*(a+b) (mod p^(j+1)).
U_j/U_(j+1) is the additive coefficient space (F_p)^d.
```

The layer multiplication identity follows because the omitted product contains p^(2j), divisible by p^(j+1) for j>=1. Each increased precision therefore exposes d scalar digit directions. Precision depth k and coefficient degree d count different resources: one adds layers, the other adds directions in each layer.

## B8. The exact tangent-matrix criterion

Assume p is odd, k>=2, and bases g_ij=1+p*c_ij. For s equations and n unknown scalar exponents, define

```text
h_i=product_(j=1)^n g_ij^(x_j), h_i in U_1.
P=p^(k-1), x in (Z/PZ)^n.
A: stack the d coefficients of every c_ij modulo p.
A has d*s rows and n columns over F_p.
```

**B-P4, PROVED: square coupled recovery.** If n=d*s, the exponent map is bijective exactly when A is invertible over F_p. Every target then has one exponent vector modulo P, recoverable in k-1 digit rounds. The conclusion refers to the declared exponent domain. Bounds on ordinary integer exponents require a later fiber calculation.

The key powering identity is (1+p*c)^(p^j)==1+p^(j+1)*c modulo p^(j+2). For one pth power, the linear term has the displayed value; intermediate binomial terms contain an additional p and at least two copies of the input depth; the last term has depth at least p times that depth. For odd p, every omitted term lies in the required higher ideal. Induction proves the identity. One further power shows that every principal unit has exponent dividing P.

Start with x^(0)=0. At stage ell, an approximation fixed modulo p^ell matches the target modulo p^(ell+1). Form residuals r_i=h_i*product_j g_ij^(-x_j^(ell)). These lie in U_(ell+1). Extract the coefficients of (r_i-1)/p^(ell+1) modulo p and stack them as b_ell. Writing the next approximation as x^(ell+1)=x^(ell)+p^ell*d_ell produces exactly A*d_ell=b_ell. An invertible A determines one digit vector at every round; after k-1 rounds the complete products agree modulo p^k.

Necessity has a direct kernel proof. If A*v=0 with v nonzero, the nonzero exponent vector p^(k-2)*v maps to the identity by the final-layer powering formula. The exponent map cannot be injective. Conversely, for an invertible A, a nonzero exponent difference has a first nonzero p-adic digit vector, and its first surviving product layer equals A times that vector. It cannot vanish. The finite domain and target have the same cardinality P^n, so injectivity also proves bijectivity. This second argument exposes the exact obstruction rather than simply counting successful iterations.

For a rectangular A, full column rank proves injectivity onto the image; full row rank proves surjectivity onto every target. A deficient rank does not permit an arbitrary digit choice. A choice compatible at one layer may fail later, while a discarded alternative may have survived. A complete solver stores the full kernel directions or uses a complete modular matrix reduction.

### B-E3. Recovering two exponents from one ring-valued target

Work modulo 81 with alpha^2=-1, bases g_1=4 and g_2=1+3alpha, and target h=25+66alpha. The tangent columns are (1,0) and (0,1), so A is the identity. The scalar exponent period is P=27, and the target supplies two independent coefficient directions.

At the first round, (h-1)/3=(8,22)==(2,1) modulo 3. Thus the first exponent approximation is (2,1). Removing its product from h leaves residual 10+45alpha. At the second round, (r-1)/9=(1,5)==(1,2) modulo 3. Adding 3*(1,2) gives exponents (5,7). Their residual is now 1, so the last digit vector is (0,0). Direct repeated-squaring multiplication verifies 4^5*(1+3alpha)^7==25+66alpha modulo 81.

An independent logarithmic route uses lambda(u)=log(u)/3 modulo 27. Exact finite series give lambda(4)=(16,0), lambda(1+3alpha)=(15,25), and lambda(h)=(23,13). Hence

```text
C=[[16,15],[0,25]], C*(5,7)^T==(23,13)^T (mod 27).
16*5+15*7=185==23 (mod 27).
25*7=175==13 (mod 27).
det(C)=400==22 (mod 27), a unit.
```

The two computations share the same ring arithmetic, but one peels product residuals while the other transforms the whole equation to a modular matrix. Their agreement is a useful check. It is not an assertion that two mutually independent observations were supplied: both represent the same target.

## B9. Singular systems and complete solution families

For odd p, the map lambda(u)=log(u)/p identifies U_1 with the additive coefficient module modulo P=p^(k-1). Bases and targets therefore give a complete system C*x==b modulo P. The log input is required modulo p^k, since division by p consumes one absolute precision digit. This transformed system is equivalent in both directions to the original products, because lambda is an injective group coordinate.

When an integer Smith decomposition J=U*C*V is available, with U and V unimodular, set x=V*z and b'=U*b. Integer unimodularity makes both transformations invertible modulo every modulus. For each nonzero diagonal d_i, let delta_i=gcd(d_i,P). The scalar equation d_i*z_i==b'_i modulo P is compatible exactly when delta_i divides b'_i. Dividing that common factor yields one residue modulo P/delta_i and all delta_i lifts modulo P. A zero row requires b'_i==0 modulo P, and unused columns are free.

**B-P5, PROVED given the integer Smith decomposition:** a compatible transformed system has P^(n-r)*product_i delta_i solutions modulo P, where r is the number of nonzero integer diagonal entries. Each diagonal coordinate contributes delta_i solutions and each free column contributes P; independent coordinates multiply the counts. Equivalently, every nonempty homomorphism fiber is a coset of the homogeneous kernel. A zero answer count requires an actual failed compatibility condition, not a solver timeout.

If delta_i=P, the coordinate is completely free when compatible, and no inverse modulo 1 is needed. First-layer rank alone does not measure all remaining ambiguity: the valuations of the diagonal coefficients record how many exponent digits were lost. A compact affine kernel description may represent many solutions without enumerating each one. When ordinary integer bounds are imposed, they constrain x=V*z in the original coordinates and generally become coupled inequalities. Copying the original separate bounds directly onto z changes the problem.

### B-E4. A singular direction with a precisely measured ambiguity

At modulus 81, replace the second base in B-E3 by 1+9alpha. Its tangent column is zero, because its first nontrivial coefficient begins one layer later. Its logarithmic coordinate modulo 27 is (0,3): the linear term contributes 3alpha after division by 3, and the remaining terms vanish at that precision. The first base still has coordinate (16,0).

For target coordinates b=(23,21), the transformed equations are 16x==23 and 3y==21 modulo 27. Since 16 is a unit, x==5 modulo 27. Division of the second congruence gives y==7 modulo 9, with all three exponent residues y=7,16,25 modulo 27 retained. The second base has order 9, so these are three aliases of the same power. Declared exponent uniqueness fails while the produced ring element remains uniquely specified.

If the second target coordinate were 1, the equation 3y==1 modulo 27 would be impossible. This supplies a short inconsistency certificate: the right-hand side is not divisible by gcd(3,27)=3. A digit method that guessed y=0 before seeing the second layer could wrongly discard the valid y=7 branch. The complete modular family gives both the valid aliases and the exact unreachable-target condition.

## B10. Binary corrections and retained parity branches

The odd-prime powering formula cannot be transferred unchanged to p=2. In Z/8Z, the base 3 has square 1, while an unguarded odd-prime formula would predict 5. Binary principal units at depth one contain torsion, and their logarithm loses it. The safe logarithmic subgroup is U_2=1+4R_k.

For k>=3, declare scalar exponent residues modulo 2^(k-1) and write x_j=epsilon_j+2z_j uniquely, with epsilon_j in {0,1} and z_j modulo 2^(k-2). Retain every parity vector satisfying the first-layer equations. For each parity vector, remove its product from the target. The residual and all squared bases lie in U_2, because (1+2c)^2=1+4(c+c^2). Their remaining equations can be solved using lambda_2(u)=log(u)/4 modulo 2^(k-2), followed by x=epsilon+2z.

This branch construction is complete: every original exponent vector has one parity decomposition, and every reconstructed vector is checked in the original products. The declared period can exceed a base's actual order, so aliases remain possible. For k=2 only the parity layer is present; for k=1 the principal group is trivial. In coefficient degree greater than one, all coefficient parity directions must be solved. The scalar sign decomposition is insufficient there.

For a scalar example modulo 16, the equation 3^x==11 has exponent residues modulo 8. Its first layer forces odd parity, so x=1+2z. Removing 3 gives residual 9, and the squared base is also 9. The safe logarithmic coordinate is log_2(9)/4==2 modulo 4. The remaining equation 2z==2 modulo 4 gives z=1 or 3, hence x=3 or 7 modulo 8. Both pass direct powering. The two answers are aliases because the base 3 has actual order 4. This calculation retains the torsion and precision information that an unrestricted logarithmic inversion would erase.

A solver may cache its bases, coefficient matrix, Smith transforms, or an invertible matrix inverse for repeated targets. A valid cache key includes p, k, the defining polynomial, coefficient basis, bases, and logarithm domain. A matrix computed in another ring presentation needs a verified coordinate change before reuse. These requirements describe the mathematics of what is being reused, rather than implementation bookkeeping alone.

## B11. The base-two exponent bridge at powers of three

**B-P6, PROVED:** the order of 2 modulo 3^k is 2*3^(k-1). Modulo 3 its order is 2. For positive m, v_3(4^m-1)=1+v_3(m): cubing a unit 1+w of positive 3-adic depth increases the depth of its difference from 1 by exactly one, while an exponent coprime to 3 leaves that depth unchanged. Factoring m into its 3-power and coprime parts proves the valuation formula and hence the order. The order equals the number of units, so every unit has exactly one base-two exponent residue.

An observed unit u modulo 3^k first determines parity epsilon from u modulo 3. Remove 2^epsilon, obtaining w=u/2^epsilon in the principal units. Then n=epsilon+2t and 4^t=w. Taking logarithms and dividing by 3 gives

```text
t==(log_3(w)/3)*inverse(log_3(4)/3) (mod 3^(k-1)).
n==epsilon+2t (mod 2*3^(k-1)).
```

The coefficient log_3(4)/3 is a unit, so its inverse exists. For k=1 parity alone supplies the answer. This is an exact special discrete-logarithm coordinate for this explicitly represented smooth-order unit group. An arbitrary relation in a prime-field group does not lift to all higher powers of the characteristic; applying this formula to unrelated integer representatives solves another problem.

### B11.1. Doubling as a sign flip and a translation

The recovered doubling manuscript supplies another useful coordinate for the same unit tower. Set ell=log_3(-2)=log_3(1-3), whose valuation is 1. For a unit u, remove its sign and define tau=log_3((-1)^epsilon*u)/ell. Division by ell identifies 3Z_3 with Z_3, since ell/3 is a unit. The resulting map is

```text
Psi(u)=(epsilon,tau) in (Z/2Z) x Z_3.
Psi^(-1)(epsilon,tau)=(-1)^epsilon*exp_3(ell*tau).
Psi(2u)=(epsilon+1,tau+1).
```

The proof uses the same separate sign and principal-unit coordinates already established. Multiplication by 2 changes sign and adds log_3(-2) to the logarithmic component. Normalizing by ell changes that increment to 1. This is a conjugacy of the doubling map with a translation, not a claim that doubling is an automorphism of the multiplicative group: translating a group element by a fixed element generally does not preserve the identity.

At modulus 3^k, tau is known modulo 3^(k-1), because dividing the logarithm by a depth-one coefficient consumes one digit. The pair of increments (1,1) has order 2*3^(k-1), matching the finite doubling cycle. For k=5, exact finite evaluation gives ell==24 modulo 243 and exp_3(24)==241, which is -2 modulo 243. The normalized coordinates of 2 are therefore (1,1), and the inverse chart gives (-1)*241==2 modulo 243. The retained sign prevents confusing -2 with 2.

At infinite precision every unit orbit under repeated doubling is dense in Z_3's unit group: every finite unit quotient is traversed, so every residue-cylinder neighborhood is visited. No nonzero p-adic integer is periodic, since 2^n*u=u would give (2^n-1)u=0 in the characteristic-zero domain Z_3. Finite periodicity and infinite nonperiodicity coexist because they concern different state spaces.

The rational sequence x_n=243*(2/9)^n illustrates the scale extension. Its coordinates change by valuation -2, sign flip 1, and translation 1 at each step. Real magnitude tends to zero while its 3-adic magnitude grows; from n=3 onward it lies outside Z_3. Only its normalized unit part 2^n belongs to the finite unit tower. These coordinates can support exact cycle descriptions or numerical state machines, but an added spatial model requires its own map and compatibility conditions. The recovered manuscript states that the linked original Zenodo PDFs were unavailable; this compilation checks the supplied reconstruction and does not upgrade it to an audit of those inaccessible originals.

### B-E5. Exponent digits that remain ambiguous until the period grows

Take the observed value of 2^173 at successive powers of 3. The pairs of observation and reconstructed exponent residue are: modulo 3, u=2 and n==1 modulo 2; modulo 9, u=5 and n==5 modulo 6; modulo 27, u=23 and n==11 modulo 18; modulo 81, u=23 and n==11 modulo 54; modulo 243, u=104 and n==11 modulo 162; modulo 729, u=347 and n==173 modulo 486; modulo 2187, u=1805 and n==173 modulo 1458.

The repeated value 23 at two precisions does not mean identical information: its modulus increased. At modulus 243 the class 11 modulo 162 still includes both 11 and 173. At modulus 729, a stated ordinary bound 0<=n<=200 leaves exactly 173. Without that bound, the answer remains an exponent residue modulo 486. The residue itself is exact; selecting one ordinary exponent requires the residual fiber to be constrained.

## B12. Exercises on exponent families

**B-X4.** Solve 9x==18 modulo 27. **Answer:** divide the common factor 9 to obtain x==2 modulo 3. The nine residues 2,5,8,11,14,17,20,23,26 remain modulo 27. Inversion of 9 modulo 27 is invalid.

**B-X5.** Explain why the target in B-E3 can determine two scalar exponents although it is one ring element. **Answer:** its representation has two independent coefficient directions, and the tangent matrix is invertible. A single opaque group element supplies no automatic access to those coefficient equations.

# Polynomial lifting and the bounded cubic ratchet

## B13. The output domain comes before the numerical method

A cubic has roots over several domains, and a solver must name the required one. This chapter's exact finite method returns every distinct integer root in a certified interval D=[L,U] intersect Z. A reversible scaling extends it to every rational root of an integer-coefficient cubic. Finite modular roots and infinite p-adic roots are intermediate objects. Irrational real roots and complex roots need separate exact algebraic representations or rigorous numerical enclosures.

Write f(X)=aX^3+bX^2+cX+d with integer coefficients and a!=0, and S={x in D:f(x)=0}. A candidate enclosure C is valid when S is contained in C. The term precision ratchet means a sequence of compatible, nested enclosures C_new subset C. It does not require every step to remove a candidate or every raw residue count to decrease. The final verifier V(x) evaluates the original f exactly.

If D is not supplied as a genuine input restriction, derive a bound. Set A0=max(|b/a|,|c/a|,|d/a|) and B=1+ceil(A0). Every complex root has magnitude at most 1+A0. To prove this, suppose t=|z|>1+A0 for a root. The triangle inequality gives t^3<=A0*(t^2+t+1)<(t-1)*(t^2+t+1)=t^3-1, a contradiction. Thus [-B,B] contains all integer roots. Exact integer ceiling arithmetic avoids rounding errors for large coefficients.

The bound is a completeness tool, not an efficiency guarantee. A large coefficient may produce a wide interval. A solver can exploit residue structure to avoid testing every integer, but its work depends on branch counts and representation costs as well as interval width. A resource cap must return unresolved status if the required coverage certificate has not been obtained.

## B14. The exact local digit equation

For r a root modulo p^k with k>=1, every possible next residue is uniquely r+p^k*t with t in {0,...,p-1}. For a cubic, integer expansion gives

```text
f(r+T)=f(r)+f'(r)*T+(3ar+b)*T^2+a*T^3.
f'(r)=3ar^2+2br+c.
q=f(r)/p^k, an exact integer.
f(r+p^k*t)==0 (mod p^(k+1))
  iff q+f'(r)*t==0 (mod p).
```

**B-P7, PROVED: complete one-digit lifting.** The omitted terms are divisible by p^(2k), and 2k>=k+1. Dividing the remaining congruence by p^k reduces its modulus to p, giving the displayed affine equation. This proof uses an integral identity before reduction, so it is valid at p=2 and p=3 without inverting factorials.

If the slope f'(r) is nonzero modulo p, exactly one digit survives: t==-q*inverse(f'(r)) modulo p. If both slope and q vanish modulo p, all p digits survive. If the slope vanishes while q does not, no digit survives. These three cases are the entire branching rule. Every higher root reduces to a lower root and has one of these digits; every generated child satisfies the higher congruence. Starting with every seed modulo p therefore produces complete root lists at every finite level.

A simple seed retains a unit derivative at all descendants and has one child forever. Its coherent sequence defines one root in Z_p by completeness and polynomial continuity. Uniqueness concerns that initial residue class. Other simple seeds can define other roots, and a singular seed may produce several roots or none. Existence of one valid local chain never certifies that the polynomial has only one global solution.

### B-E6. A cubic root in Z_5 that is not an integer root

For f(X)=X^3-2, the seed r=3 satisfies f(3)=25 and f'(3)=27. At p=5, q=5==0 and slope 2, so the next digit is 0; the root remains 3 modulo 25. At that level q=25/25=1 and slope is still 2, giving digit -1/2==2 modulo 5. The next representative is 3+25*2=53 modulo 125.

At r=53, f(r)=148875 and q=1191==1 modulo 5; the next digit is again 2, giving 303 modulo 625. Further exact lifting gives 2178 modulo 3125 and 5303 modulo 15625. Each representative reduces to the previous one. These digits describe a 5-adic root of X^3-2.

No integer has cube 2, and the rational-root theorem excludes a rational root of this monic cubic. The local root remains useful for modular filtering while the ordinary rational root set is empty. A real approximation to the cube root of 2 requires a different error metric and output format. The integer-looking representative 5303 is neither a real approximation to that root nor an exact integer solution.

## B15. Singular branches, locked digits, and Newton acceleration

For f(X)=(X-2)^3, the congruence modulo 3^k is equivalent to x==2 modulo 3^ceil(k/3). Thus the number of residue roots is 3^(k-ceil(k/3)), giving counts 1,3,9,9,27,81,81,243 at levels 1 through 8. The raw count grows, yet the condition on ordinary candidates becomes stronger. Every child retains its parent prefix; this is the precise meaning of a locked digit relative to one branch.

By contrast, X^3-3 has seed 0 modulo 3 but no child modulo 9: q=-1 and slope 0. A finite surviving branch can later die, so survival at a depth cutoff is not proof of an infinite root. If a fixed prefix has descendants at arbitrarily high levels, finite branching ensures an infinite compatible path; the depth cutoff alone supplies no such premise.

For a unit derivative, a Newton block step can double precision. If p^k divides f(r), use r_new==r-f(r)*inverse(f'(r)) modulo p^(2k). The correction is divisible by p^k; its linear contribution cancels the residual, and its squared remainder vanishes modulo p^(2k). The block digit is uniquely determined because the slope is a unit.

A nonunit derivative needs a different guard. Let s=v_p(f'(r)) be finite and assume v_p(f(r))>2s. Substituting X=r+p^(s+1)Z and dividing by p^(2s+1) gives a p-integral polynomial whose reduction is linear with unit slope. Indeed, writing f'(r)=p^s*u gives

```text
f(r+p^(s+1)Z)/p^(2s+1)
=f(r)/p^(2s+1)+uZ+p*(3ar+b)Z^2+p^(s+2)*aZ^3.
```

Simple lifting therefore proves exactly one root in the ball v_p(alpha-r)>s. Newton corrections remain in that ball and their precision increases. This is the strong Hensel condition. It does not justify inverting a nonunit derivative in the finite residue ring. Division is carried out with appropriate extra precision and consumes s digits.

A tangent approximation also has a ceiling. If v_p(T)>=j, the omitted cubic remainder has depth at least min(2j+v_p(3ar+b),3j+v_p(a)). It can be omitted only modulo powers no higher than this bound. For f(X)=X^3+X^2-80, r=1, and T=3, the true root is 4; the linear part is -63 and the remainder is 63. Dropping the remainder is valid modulo 9 but would reject that true root modulo 27.

## B16. Recombination means all compatible bounded fibers

Local residues must concern the same original integer before they can be joined. For x==r modulo m and x==s modulo n, let g=gcd(m,n). Compatibility requires g to divide s-r. In that case the combined class has modulus M=lcm(m,n), obtained by writing x=r+mt and solving

```text
t==((s-r)/g)*inverse(m/g) (mod n/g).
R==r+m*t (mod M).
```

When n/g=1, take t=0 without seeking an inverse modulo 1. Different-prime constraints multiply their moduli. A deeper observation at the same prime replaces a contained power; it does not multiply two independent pieces of information. If local root lists have several branches, every compatible tuple must be retained until an explicit bound or equation excludes it.

The bounded fiber x=R+Mt has quotient interval ceil((L-R)/M)<=t<=floor((U-R)/M). Its exact count is the length of that integer interval, or zero when the interval is empty. If M>U-L, one class contributes at most one integer: two distinct members would differ by at least M but by at most the interval width. This is a per-class statement. A union of classes can still contain several candidates.

For X^3-X in [-10,10], local roots modulo 5 and 7 produce modulus 35 and bounded survivors -6,-1,0,1,6. Although 35 exceeds the width 20, the candidates are not a singleton. Exact substitution rejects -6 and 6, whose polynomial values are -210 and 210. CRT solved the congruence correctly; final verification supplies the original equation.

### B-E7. The complete 225-to-one cubic reconstruction

Take f(X)=X^3-37X^2+3X-111. Its coefficient bound gives B=112 and D=[-112,112], containing 225 integers. Modulo 3 the polynomial is X^2(X-1), so seeds 0 and 1 leave 150 candidates. At 0, q=f(0)/3=-37==2 and slope 3==0 modulo 3; this singular branch dies. At 1, q=-48==0 and slope -68==1; digit 0 gives the sole residue 1 modulo 9, leaving 25 candidates.

Modulo 5 the sole root is 2. Joining x==1 modulo 9 and x==2 modulo 5 gives x==37 modulo 45. The five bounded members are -98,-53,-8,37,82. The number 37 is at this point a convenient representative, not yet an established root.

Lift the ternary branch: f(1)/9=-16==2 and slope 1 give next digit 1, hence 10 modulo 27. Joining with residue 2 modulo 5 gives 37 modulo 135, leaving -98 and 37. Lift the five-adic branch: f(2)/5=-49==1, slope -133==2, inverse slope 3, and digit -3==2 give 12 modulo 25. Joining 10 modulo 27 and 12 modulo 25 gives 37 modulo 675.

Now 675 exceeds the interval width 224, and the sole bounded member is 37. Direct evaluation gives f(37)=0. The candidate counts are 225,150,25,5,2,1. Every seed and every child was covered, so completeness accompanies the accepted root. Independently expanding (X-37)(X^2+3) verifies the factorization and shows that 37 is the only real root; the other algebraic roots are +i*sqrt(3) and -i*sqrt(3).

## B17. Rational roots and height reconstruction

**B-P8, PROVED: rational-to-integer scaling.** Set Y=aX and g(Y)=Y^3+bY^2+acY+a^2d=a^2f(Y/a). A rational root of f maps to a rational root of the monic integer polynomial g. If a monic polynomial has reduced rational root m/n, clearing denominators and reducing modulo n forces n to divide m^3, hence n=1. Therefore Y is integral. Conversely any integer root Y of g gives rational root Y/a of f. These maps are inverse on the root sets, including negative a.

### B-E8. Three rational answers recovered through integers

For f(X)=2X^3-3X^2-3X+2, use Y=2X. The scaled polynomial is g(Y)=Y^3-3Y^2-6Y+8. Its integer root set is {-2,1,4}, established by a complete integer solver and independently checked through g(Y)=(Y+2)(Y-1)(Y-4). Mapping back gives {-1,1/2,2}. Exact fraction substitution into f verifies each answer. Applying the root bound to g supplies a complete domain; an assumed denominator bound is unnecessary.

A more general export interface reconstructs a rational u/v from a modular residue R when |u|<=A, 1<=v<=B, gcd(u,v)=1, gcd(v,M)=1, and u==Rv modulo M. If M>2AB, at most one such reduced rational exists. For two candidates, M divides u1v2-u2v1, whose magnitude is at most 2AB<M; it must be zero. Positive reduced denominators then give the identical fraction.

For R=44 modulo 101 with A=5 and B=7, the pair (5,7) passes 44*7==5 modulo 101. Since 101>70, the result 5/7 is unique within the declared height box. Existence still needs the displayed witness, and polynomial-root status still needs original substitution. A denominator sharing a factor with M lies outside this residue chart; a different prime or another representation is required.

## B18. Why a general cubic retains nonlinear coupling

An affine translation X=Y-b/(3a) gives the depressed cubic Y^3+P0Y+Q0, with P0=(3ac-b^2)/(3a^2) and Q0=(2b^3-9abc+27a^2d)/(27a^3). These are characteristic-zero identities; at p=3 their denominators can leave the integral ring. A local implementation must account for that change before applying an integral chart.

Writing Y=u+v gives Y^3+P0Y+Q0=u^3+v^3+Q0+(3uv+P0)(u+v). Thus the resolvent conditions are u^3+v^3=-Q0 and uv=-P0/3. The cube values satisfy a quadratic, but their cube roots cannot be chosen independently. Their product must retain the coupling. For Y^3-3Y-2, the cube values both equal 1. Taking u=1 and v=rho, where rho is a primitive cube root of unity, makes their cube sum correct but their product wrong; u+v is not a root.

Another proposed simplification uses a fractional coordinate X=(alphaY+beta)/(gammaY+delta). Homogenizing the cubic and applying an invertible linear change to its two homogeneous coordinates preserves its three projective root points. The chosen affine chart additionally requires a nonzero denominator. A transformed polynomial with smaller degree can mean that one root moved to the omitted point at infinity, rather than that the original equation lost a solution. For example, X(X-1)(X-2) under X=1/Y becomes 1-3Y+2Y^2 after multiplying by Y^3. Its affine roots 1 and 1/2 represent X=1 and X=2; the original root X=0 is represented at Y=infinity and must be retained separately. Modulo p^k, an invertible chart requires a unit determinant and a unit affine denominator. A merely nonzero rational determinant does not establish those modular guards.

A correct radical construction, when P0 is nonzero, chooses one nonzero cube root u and sets v=-P0/(3u). The other cube relation then follows from the resolvent product. Degenerate zero cases are treated separately. This established algebra explains the sound form of Stefan's multiple-projection idea: local linear or multiplicative pieces can simplify a problem while explicit compatibility equations retain its nonlinear content.

## B19. The operational contract and the verification boundary

The exact bounded kernel seeds complete root sets modulo selected primes, performs complete digit lifts, joins every compatible class, removes empty bounded fibers, and evaluates every final bounded candidate. Each update preserves S subset C_new subset C. Once the combined modulus exceeds the interval width, each class has at most one representative and the remaining evaluations give exactly S. A schedule that increases one prime-power precision at every successful step makes the modulus grow until this finite completion condition holds, unless the candidate set becomes empty earlier.

This termination argument counts arithmetic stages, not computational time. Singular root lists can grow, and many coprime prime branches can multiply. Valuation filters, unit Newton blocks, strong Hensel normalization, and logarithmic pure-cube extraction are useful optional operators under their own guards. The general integer/rational kernel does not require every operator on every input. Any operator allowed to delete candidates needs a root-preservation proof.

The fresh family-B script checks 3,000 complete cubic residue sets against direct enumeration; exact log/exp coordinates including the binary safe domain; every base-two exponent class through modulus 3^7; unit cube extraction through input modulus 3^6; all coupled exponent pairs at ring precisions 2,3,4; singular branch counts through 3^8; and 500 complete rational scaling cases. Its manifest names the actual bounds, inputs, hashes, and command. These are FINITE results supporting the implementation boundaries. The universal implications above rest on their stated proofs, and the run supplies no proof-assistant certificate.

**B-X6.** Explain why M=5 does not isolate the class 0 in [0,5]. **Answer:** both endpoints belong to it. The required width test is strict: M>U-L.

**B-X7.** A root-search budget expires with three retained branches. **Answer:** the result is unresolved, with the branches retained. Neither an empty solution set nor a complete root list follows.

## B20. Primary source map

[B-R1] Keith Conrad, Hensel's Lemma, author-hosted notes, Theorems 2.1 and 4.1. These supply the classical simple and strong lifting formulations; the finite branching and cubic interfaces above are derived explicitly. https://kconrad.math.uconn.edu/blurbs/gradnumthy/hensel.pdf

[B-R2] Keith Conrad, Infinite Series in p-adic Fields, author-hosted notes, Theorems 8.5, 8.7, 8.13. The product law, isometry domains, inverse maps, and binary torsion exception were checked against these statements. https://kconrad.math.uconn.edu/blurbs/gradnumthy/infseriespadic.pdf

[B-R3] R. Raghavendran, Finite Associative Rings, Compositio Mathematica 21(2), 1969, 195-229, Theorem 9. Its parameters n,r correspond to precision k and residue degree d; it supplies historical Galois-ring structure, while B-P4 gives the explicit coefficient criterion. https://www.numdam.org/item/CM_1969__21_2_195_0.pdf

[B-R4] Richard P. Stanley, Smith Normal Form in Combinatorics, author manuscript, 2016, Theorem 2.1(4). Integer Smith-form existence is the external structural input; B-P5 derives the finite congruence family from a stated decomposition. https://math.mit.edu/~rstan/papers/snf_survey.pdf

[B-R5] NIST Digital Library of Mathematical Functions, Section 1.11(iii), cubic equations. The depressed-cubic shift and coupled radical convention were checked; the product identity is proved directly above. https://dlmf.nist.gov/1.11
