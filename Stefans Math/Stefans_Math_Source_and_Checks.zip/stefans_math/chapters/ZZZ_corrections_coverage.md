# Correction register, coverage and reproducibility

## A concise register of consequential repairs

The detailed family audits retain source locators, normalized claims, proof dependencies, finite ranges and review findings. This register identifies the corrections most likely to affect reuse. A correction does not imply that every statement in its source family was false; it identifies the exact condition that must remain visible in the useful construction.

| Earlier inference or ambiguity | Standardized repaired statement |
| --- | --- |
| Repeated fixed constraint intersection keeps producing information | Intersection with a fixed predicate is idempotent. New progress requires new information, increased precision or a specified propagation fixed point. |
| A returned valid answer proves uniqueness | A sound complete solution description with cardinality one establishes uniqueness. A singleton partial output does not. |
| A known multiple of an order can replace the exact order | Projection and exponent periods use the actual cyclic subgroup order or a separately proved order certificate. |
| Every external exponent residue modulus divides the group order | An arbitrary residue modulus M yields a residual generator of order N/gcd(N,M), with bounded representatives and duplicate periodicity accounted for. |
| Division by a nonzero modular element is always valid | Division requires a unit. A linear congruence with a nonunit coefficient has zero, one or multiple branches according to its gcd conditions. |
| Completing a square always preserves modular roots | Multiplication by a nonunit can add roots. Retain the original equation or establish the needed invertibility/precision repair. |
| Principal-unit rank necessity also holds at precision k=1 | The nontrivial rank theorem is stated for k>=2. At k=1 the principal-unit/exponent problem is trivial. |
| A p-adic logarithm gives full-unit coordinates | Retain valuation and torsion coordinates; use log/exp only on their stated convergent principal neighborhoods. |
| Binary units behave exactly like odd-prime units | The scalar binary safe logarithm chart starts at 1+4Z_2. Higher residue-degree binary units need their actual quotient structure. |
| A polynomial product vanishes only when a factor vanishes | Zero divisors invalidate that inference in rings. Root unions, common roots and product roots are different sets. |
| Cyclotomic factorization automatically identifies primitive order in every ring | Primitive-order conclusions need field/unit and characteristic conditions; product identities alone do not supply them. |
| Quotient inversion and subgroup inversion guarantee layered inversion | Every conditional coset fiber needs its own inversion or coverage contract. |
| A small lattice vector is the recovered unknown | The exact observation box and original verifier determine validity. Reduction and nearest-plane methods can propose candidates without complete recovery. |
| A finite p-adic branch is an ordinary integer or rational root | Reconstruction needs ordinary bounds or a rational bridge, all compatible branches, and the original verifier. |
| Singular roots have one next digit | Singular branches can produce all digits or no digits at a level. A complete lift retains those alternatives. |
| A local Newton or quadratic step solves every algebra problem | Local regularity, rank, conditioning and acceptance conditions are needed. Global coverage is supplied separately. |
| Interval Newton permits a pivot outside its derivative enclosure | Put the pivot inside the interval, or enclose derivatives on the entire pivot-root hull. |
| Every fixed-ray limit establishes the multivariate limit | One uniform neighborhood bound across directions is required; a curved approach can contradict every fixed-ray observation. |
| A residual-energy stationary point is an equation root | Zero residual certifies the equations. Nonzero stationary residuals can occur and require rejection as roots. |
| Clearing denominators permits every cleared-polynomial root | Original denominator exclusions survive compilation and final checking. |
| Finite isolated algebraic roots cover every three-variable system | Positive-dimensional families, singular roots, domain distinctions and unsupported function grammars require explicit adapters. |
| One elliptic generator scan is a complete rational search | Completeness needs a generating-set/coset theorem. Negating one generator does not add an independent rank direction. |
| Distinct oscillatory carriers give uncontaminated derivatives | Sums, differences, doubles and sample-grid aliases must also be separated, or included in a full-rank design. |
| One circular quadratic scan determines every Hessian coefficient | An anchor or additional radial data is needed for the trace component; the circle alone loses information. |
| A divisor Mobius round trip creates an additional spectral filter | The forward transform followed by its inverse returns the original data. Any extra effect needs an additional operation. |
| Three directions spaced by 120 degrees are orthogonal | Their pairwise dot products are -1/2 for unit vectors in one plane. They form a dependent zero-sum configuration. |
| Phase exists through a zero without added structure | Phase is undefined at zero; a nonzero path and branch/unwrap convention are required. |
| A rotated funnel preserves the old circular top projection | A 90-degree rotation changes the projection geometry; a circle can project to a segment. |
| Orthogonal contracting spirals prove a strange attractor | Rigid orientation and negative contraction rates do not establish chaotic dynamics or a strange invariant attractor. |
| Triangle face inequalities realize any tetrahedron | A positive-definite Gram matrix is required; the displayed 1/1.9 edge counterexample fails it. |
| Correct incidence establishes a valid metric or continuum limit | Incidence, metric realizability, operator positivity and convergence are separate obligations. |
| Scalar window counts are automatically a Markov state | Ordered memory, position history or a sufficient belief state may be required. Count observations can lose transition-relevant information. |
| Any perturbation of a coprime probe stride keeps full coverage | The perturbation can collapse the orbit. Use a proved permutation or the separately stated longer-period coverage theorem. |
| High-frequency finite cosine sums are automatically fractal | Finite sums are smooth, and a finite lattice can alias high frequencies into constants. |
| A square-shell prime resonator defines a finite field | The shell is a finite integer set. Its exact sieve uses the least-prime-divisor bound; lower-root survivors can remain composite. |
| Repeated or salted deterministic data imply independence | Source identity, dependence and the actual conditional sampling law determine permissible evidence combination. |
| Local p-values remain calibrated after arbitrary adaptive search | Selection, repeated testing and optional stopping need a valid allocation or sequential-evidence contract. |
| Pairwise logic-array projections preserve a complete relation | XOR supplies a counterexample. Retain joint atoms, hyperedges or an equivalent higher-order constraint. |
| Four-valued material implication permits unrestricted detachment | The adopted designation can refute modus ponens. Use explicitly justified support-preserving rules. |
| A cyclic evidence graph proves its own unseeded claims | Grounded least closure introduces support only from declared seeds and rules. A dependency cycle supplies no new source. |
| A nibble selector and mechanical implication are the same IF | The operations have different types and truth tables. The compilation separates controlled selection from implication. |
| XOR/sum table checks detect arbitrary corruption | Trusted checks can correct one data-cell fault; the explicit four-cell change evades those checks. |
| Lane-wise NAND operations alone couple all bit positions | Routing, shifts or extraction are needed for cross-lane dependence and arithmetic carries. |
| Fixed-width square sums preserve ordinary equality automatically | Use sufficient width or proved overflow guards; wrapped arithmetic can admit false equality. |
| A wave simulator checked against its oracle proves physical reliability | Accepted simulation correctness follows from its oracle filter; hardware and noise reliability need an independent measurement contract. |
| A Hanoi shortest transfer is a Hamiltonian traversal of all states | The shortest three-peg transfer uses 2^n-1 moves; the full legal-state graph has 3^n states. These are distinct tasks. |
| A phase-priority factor search proves closest-factor optimality | It certifies returned divisibility. Optimality requires monotone ordering or an admissible objective bound and complete coverage. |
| A fitted sparse trajectory uniquely identifies a physical cause | Units, synchronization, model assumptions and surviving observation fibers remain part of the inverse problem. |

## What the source collection actually covers

The twelve supplied sources comprise approximately 175,390 words before consolidation. Their full source copies and hashes are included in the editable package. Every supplied file was assigned for family inspection. Repeated source proofs and versions were consolidated rather than counted as independent evidence.

| Supplied source family | Principal coverage in the book |
| --- | --- |
| 01 Math Work Exact Operational Formalization | Exact interfaces, cyclic residuals, coupled local units, bounded observations, reconstruction and arithmetic composition |
| 02 Project Mathematics Audited | Observations/anchors, local quadratic and oscillatory models, inverse identification, calculus/phase, conics and proof boundaries |
| 03 Cryptogram Operational Formalization | CRT, cyclic groups, finite coefficient algebras, p-adic and lattice coordinates, cryptogram/constraint semantics |
| 04 Solvers Certified Operationalization | Compiler contracts, numerical and geometric certificates, optimizer governance and cubic completion |
| 05 Cubic Ratchet Formalization | Prime-power root trees, rational scaling, singularity, precision accounting and bounded reconstruction |
| 06 Two Window Mathematical Investigation | Moving-window state, overlapping observations, memory and bounded exact/statistical methods |
| 07 Statistical Algebra State Machines | Symmetries, fields/codes, observation models, confidence and sequential evidence |
| 08 Arithmetic Connections Integrated | Offset/valuation decompositions, digit operations, norms and arithmetic state structure |
| 09 Primes Offsets Padic Machines | Prime masks, carries, residue machines and root-tree distinctions |
| 10 Erdos Primes Parity Quadratic Investigation | Quadratic examples, multiplicative signs, progression discrepancy and finite search |
| 11 Construct Pattern Finder v2 | Collision-checked hashes, array walks, symmetry, patch/state inspection and validation |
| 12 Construct Pattern Finder | Original constructs, comparison relations, model selection and testable pattern claims |

Supplemental records broaden coverage through the actual Mathcrack manuscripts, modular lab and reconstruction whitepapers, hidden-number specification, current solver notes, quaternion/p-adic lock-in algorithm, Dual Funnel manuscript, doubling-cycle geometry, Fourier Six guide and core, airplane epicycles, abstract temporal framework, three-dimensional logic array monograph, CH/cubical finite checker report, Terminator verification, electronic and mechanical logic notebooks, arithmetic logic blocks, logic certificates, prime/resonator notes, fractal hashing, phase/factorization demonstrations, homogeneous cubic controller revisions and sparse-flight reconstruction.

Supplemental records were inspected by the relevant constructions and claims recorded in each family audit. Duplicate bytes are identified by SHA256. Related-section inspection is not represented as exhaustive auditing of every historical conversational paragraph or embedded program. Mentioned but unseen records remain outside proof coverage. Primary external literature supplies attribution or a precisely checked dependency, and is not presented as Stefan's original theorem.

The Dual Funnel manuscript identifies Griff Gurwell as its author. Its conditional geometry is included as related mathematical material with attribution. The independent rotations and project extensions are distinguished from its original projection assumptions. Historical source-access failures concerning referenced Zenodo manuscripts remain failures; recovering a later reconstruction does not authenticate those unavailable originals.

## Fresh verification and its interpretation

The package includes exact checking scripts for all six main families and the coordinator's discrete-geometry/integration examples. Most use Python integers and fractions rather than floating-point arithmetic. The recovered Fourier demo has a separate JavaScript verification record with explicit tolerances. Computational ranges and individual outputs are preserved in their JSON evidence records. The checking workload is finite; the universal arguments are the chapter proofs.

| Family | What the fresh checks examine |
| --- | --- |
| A arithmetic | Linear congruence fibers, generalized CRT, cyclic projection, residual bounds, local units, finite polynomial algebra, HNP boxes and the complete small semidirect example |
| B p-adic/cubic | Finite polynomial root sets, singular and Newton lifts, safe log/exp domains, scalar/unit coordinates, coupled exponents and rational scaling |
| C solvers | Guarded domain examples, complete finite integer/rational comparisons, quadratic stencils, brackets/Halley identities, controller transitions and homogeneous-cubic maps |
| D spectral/geometry | Fourier inversion and rank, harmonic collisions, phase/derivative identities, projections/quaternions, dual-funnel conditions and actual recovered modem/epicycle behavior |
| E patterns/statistics | Window updates, augmented walks, wheel/shell sieves, digit/carry identities, masks/discrepancy, field codes and exact sequential evidence bounds |
| F logic/computation | Fibers and atoms, four-valued operations, closure/fixed points, finite temporal graphs, LUT integrity, gate arithmetic, width guards, original mechanical code and Hanoi distances |
| G/Z integration | Simplex coordinates and metric obstruction, incidence/energy, dyadic geometry, complete bounded cubic and factor-gap/reciprocal round trips |

Fresh cross-reviews examine another family's exact statements and derivations. They do not count agent agreement as proof. They identified, among other findings, the missing k>=2 boundary in the principal-unit rank necessity claim and an insufficient uniqueness-certificate wording; both were repaired before the final editions. Detailed peer records retain the findings and their resolution.

Evidence manifests record the actual environment and commands. Version-1 records retain their legacy provenance limitations; version-2 records include stronger artifact and execution information where available. A validated manifest confirms its record structure and hashes, not the truth of a theorem. A zero process exit code records successful execution, not universal correctness. None of these records silently upgrades an incomplete search to an impossibility or uniqueness certificate.

## Editable package and regeneration

The package preserves the two content levels: corrected manuscript chapters and unchanged historical sources. It includes the final PDF and ASCII edition, an editable Markdown manuscript, chapter files, mathematical audits, peer reviews, source inventory, scripts and their finite result records. Authenticated transfer helpers and temporary page images are excluded. External literature files are not redistributed wholesale; references retain their authors, titles and public locations.

The PDF build requires Python with reportlab and pypdf. Mathematical Python checks use the standard library unless a script explicitly declares otherwise. The Fourier demo check requires Node.js and the retained demo file. The package README gives regeneration commands and identifies the record authority for each run. A new execution can change timing and timestamps without changing the mathematical results.

This edition is a seed for further mathematical work with visible interfaces. A later revision can add an adapter, sharpen a bound, replace a heuristic, or settle an open implication while retaining the original-domain meaning and the evidence needed to check the change.
