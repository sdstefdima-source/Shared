# C1. Compiling equations into usable constraints

An equation can be solved without displaying a long hand elimination. A computer may test arithmetic possibilities, fit a local response, follow a numerical correction, or isolate an algebraic root. These routes share a responsibility: the answer must satisfy the original question in its declared domain. Stefan's solver work is useful as an organizing framework for that responsibility. It combines different representations with a separate verification stage, allowing an experimental search mechanism to contribute without controlling what counts as a correct answer.

The fundamental object is a finite equation list in the unknown tuple theta=(x,y,z), together with an original domain D. Write P(theta) for the predicate that every original expression is defined and every equation holds. Then S={theta in D:P(theta)} is the solution set. The domain may be a finite integer box, a rational grid, all real triples, or all complex triples. Those choices determine different problems even when the equation text is unchanged. For example, x^2=2 has no rational answer but two real answers; x^2=-1 has no real answer but two complex answers.

## C1.1 Meaning before manipulation

An expression is a partial function. The quotient 1/(x-y) has no value at x=y. A real logarithm requires a positive argument. A real even root uses the nonnegative branch; a literal negative integer power requires a nonzero base. A useful compiler records these conditions as guards, alongside the original expression tree. Simplification changes the evaluator representation while preserving the guard history.

Finite decimal literals also need a declared meaning. In an exact route, the string 0.1 denotes 1/10. It should be parsed directly as that rational number, rather than first rounded to a binary floating value. In an approximate route, conversion to floating arithmetic is a deliberate later operation. The distinction permits exact coefficients to coexist with numerical proposals without changing the mathematical input accidentally.

Equality transformations have different directions. Adding the same defined quantity to both sides is reversible. Multiplying by the same quantity preserves equality, but reversing that operation requires a nonzero multiplier. Squaring an equation generally supplies a necessary condition; recovering the original equation requires its signs or branches. Replacing x*(x-1)=0 by x-1=0 divides away a legitimate branch. The complete partition is x=0 or x!=0, and division is allowed only in the latter part.

For a rational expression, represent its value by a numerator A, denominator B, and guard list. Addition and division then obey the familiar fraction identities on the guarded domain:

```text
A/B + C/E = (A*E+C*B)/(B*E).
(A/B)/(C/E) = (A*E)/(B*C).
The quotient additionally requires C!=0, plus inherited guards.
```

C-TH1, PROVED: if normalization produces L-R=A/B, and the original sides are defined at theta, then B(theta)!=0 and L(theta)=R(theta) iff A(theta)=0. A structural induction proves the value identity. Constants and variables start with denominator one. Each arithmetic construction uses the fraction identities and records every new inverse condition. The resulting denominator is nonzero on the original defined domain. Multiplication by it preserves and reflects equality to zero. This proof licenses numerator constraints only with the retained guards.

The practical gain is substantial. Numerator polynomials admit exact arithmetic filters and algebraic elimination. Original-expression checking decides which of their roots are genuine. A cancelled factor is therefore an evaluation simplification, while its nonzero condition remains part of the problem.

### C-EX1. A denominator creates an excluded branch

Consider the three-variable system

```text
(x^2-1)/(x-1)=y; y=3; z=x+y.
Original guard: x!=1.
Cleared first row: x^2-1=3*(x-1).
Thus (x-1)*(x-2)=0.
```

The cleared system proposes (1,3,4) and (2,3,5). The first point fails definedness. At the second point the original quotient equals 3, and z=5. The exact solution set is consequently {(2,3,5)} over Q, R, or C. A small numerator residual near x=1 would not settle the original quotient. The independent original guard removes that apparent answer.

The equation (x^2-1)/(x-1)=2 is an even sharper diagnostic. Its only numerator root is x=1, which is excluded. Its guarded solution set is empty. A compiler that cancels the denominator and forgets its guard reports a false answer.

## C1.2 Finite rational grids are exact domains

Choose positive grid denominators d_x,d_y,d_z and exact physical bounds. Define x=X/d_x, y=Y/d_y, z=Z/d_z with integer coordinates in the converted inclusive ranges. The coordinate map T from grid integers to physical rationals is a bijection. A reduced fraction u/v belongs to the x-grid exactly when v divides d_x and the bounds hold. Choosing d_x=12 includes halves, thirds, fourths, sixths, and twelfths; it does not include every rational number.

The integer bounds are L_i=ceil(d_i*l_i), U_i=floor(d_i*u_i). Their exact conversion avoids losing boundary points through rounding. The grid has the product of the three axis counts, with an axis count zero when U_i<L_i. Substituting grid coordinates into a rational polynomial yields rational coefficients. Multiplication by a known nonzero common coefficient denominator produces an integer polynomial with the same zero set in those coordinates. This operation changes coefficient representation, rather than choosing the domain of the unknowns.

The equation 2*x=1 illustrates the difference. Clearing its coefficients does not turn x=1/2 into an integer. The grid denominator d_x=1 misses it; d_x=2 includes it. More generally, x*y=1 has rational points with arbitrarily large denominators. A complete result on one finite grid is therefore not a complete result on Q^3.

C-TH2, PROVED: suppose every filter retains every solution in the declared finite grid, and every surviving point receives a definitive original verification. The accepted points are exactly S on that grid. Soundness follows because each accepted point satisfies the original predicate. Completeness follows because every true point survives all filters and is eventually checked. The argument does not require descent to converge. Descent may find witnesses sooner, while coverage comes from the finite checking mechanism.

This yields distinct useful output contracts. EXACT_WITNESS reports verified points with no completeness claim. EXACT_COMPLETE reports the entire solution set in the declared finite domain. EMPTY_CERTIFICATE is a complete result with an empty set. UNKNOWN retains unresolved candidates or unfinished work. A resource cap cannot convert an unfinished scan into emptiness. An unsupported equation may remain as a final condition while other rows supply valid arithmetic constraints; an unresolved final condition prevents a complete answer.

### C-EX2. Ordinary coupled algebra with two complete answers

The system

```text
x^2+y=z; x+y+z=10; x=y
```

is not a sum/product invariant puzzle. It mixes a quadratic equation with two linear relations. Substitution gives y=x, z=x^2+x, and x^2+3*x-10=0. Hence x=2 or x=-5, producing (2,2,6) and (-5,-5,20). Substitution in the original rows verifies both answers.

The independent exact run checks all 26^3=17576 triples in [-5,20]^3 and returns precisely those two points. The elimination proves completeness globally over R and C because it gives an equivalent quadratic with no omitted divisions. The finite scan proves the same bounded integer conclusion through another method. This example shows how numerical or arithmetic solving can answer conventional algebra, while the mathematical notes still provide a compact independent explanation.

### C-EX3. A grid contains a fractional solution

For

```text
x+y+z=1;
2*x+y-z=-1;
x-y+2*z=15/4,
```

the exact solution is (1/2,-3/4,5/4). From the first row z=1-x-y. Substitution into the second yields 3*x+2*y=0. Substitution into the third yields -x-3*y=7/4. Thus y=-3*x/2 and 7*x/2=7/4, giving the stated point. The coefficient matrix has determinant -7, so no other real or complex solution exists.

Grid denominators (2,4,4), with all physical coordinates in [-2,2], contain 2601 points. Exhaustive rational checking returns exactly the stated tuple. An integer grid would return empty even though the real and rational systems have a unique solution. This is a domain distinction, rather than a disagreement between solvers.

## C1.3 Exact algebraic answers need not be radicals

A broad undergraduate scope includes linear systems, polynomial and rational systems, radicals with branches, and many elementary-function equations. It does not define one uniform algorithm or one completeness guarantee. Three unknowns can form a finite set, a curve, a surface, an inconsistent system, or a singular intersection. Three equation rows can also be dependent. The number of independent conditions and their domain matter more than the visual count of symbols.

For A*theta=b, reversible row operations provide complete linear solving. An inconsistent row 0=c with c!=0 proves emptiness. Otherwise pivot coordinates are expressed using free coordinates, producing an affine family theta=theta_0+V*t. Original denominator guards become restrictions on the parameters. A conditional family description can be complete even when feasibility of added parameter inequalities has not yet been decided.

For nonlinear polynomial systems, the source-described V4 showcase has a separate optional exact algebra route. Its grammar accepts rational or Gaussian-rational coefficients, arithmetic, and bounded literal integer powers. The route uses exact polynomial algorithms and algebraic number representations, with its own resource boundaries. The source notes distinguish supported finite algebraic systems from unsupported general nonlinear families. This compilation preserves that distinction; explaining the route is not a fresh execution of the entire external package.

The checked SymPy documentation supplies relevant software boundaries: a polynomial solver can signal incomplete radical output, while its triangular route can retain algebraic extension roots. Its set-based solver documentation also distinguishes unresolved sets and parameter families from finite answers. These are dependency descriptions, rather than an all-input theorem for an application built around them. [C-R1, C-R2]

A particularly transparent exact representation uses one parameter t. Suppose h(t)=0 and each coordinate obeys c_i(t)*theta_i+d_i(t)=0, with gcd(c_i,h)=1. The gcd condition ensures that c_i is nonzero at every root of h. Every root alpha then proposes theta_i=-d_i(alpha)/c_i(alpha). Completeness requires two checked arrows: every original solution must induce such an alpha and those coordinate relations; every reconstructed tuple must satisfy every original row and guard. Polynomial remainders can verify the latter without decimal approximation.

C-TH3, PROVED: under those two arrows, complete enumeration of the roots of h followed by exact guards returns precisely the desired finite solution set. The forward arrow forces each true tuple into the representation. The inverse arrow returns a valid tuple from every retained parameter root. This is a reusable contract for a rational univariate representation, without assuming every system already has that form.

For example, x^5-x=1, y=x^2, z=y+1 is represented by h(t)=t^5-t-1 and theta=(t,t^2,t^2+1). An exact answer may identify a root by its polynomial and an isolating interval. There is exactly one real root. Put a=5^(-1/4). The derivative vanishes at -a and a; the two critical values are 4*a/5-1 and -4*a/5-1, both negative. The polynomial therefore crosses zero once, on its final increasing branch. The signs h(1)=-1 and h(2)=29 locate it in (1,2). No radical formula is needed to specify that exact algebraic number.

The polynomial is also square-free. A common root with h' would satisfy alpha^4=1/5 and h(alpha)=-4*alpha/5-1=0, forcing alpha=-5/4, whose fourth power is not 1/5. By the fundamental theorem of algebra, its five complex roots are consequently distinct. The coupled system has five distinct complex tuples and one real tuple. Listing a decimal alone would conceal this domain and completeness information.

## C1.4 Homogeneous ratio search and its arithmetic boundary

The historical channel-search notebooks study positive integer solutions of

```text
a/(b+c)+b/(c+a)+c/(a+b)=4.
s=a+b+c; q=ab+bc+ca; r=abc.
C(a,b,c)=s^3-6*s*q+7*r.
```

Clearing the positive denominators gives C=0 exactly. Indeed their product is s*q-r, while the sum of the three numerator terms is s^3-2*s*q+3*r; subtracting four times the product yields C. Homogeneity allows common integer factors to be removed. Modulo 6, the necessary condition is s+r==0 (mod 6), since s^3==s (mod 6). Neither operation establishes that a proposed triple is a solution; exact original substitution does.

Scale-free coordinates u=a/(b+c), v=b/(a+c), w=c/(a+b) obey u+v+w=4 and uv+uw+vw+2*u*v*w=1. The latter follows from a/s=u/(1+u) and the corresponding identities, whose sum is one. The notebook's rational carrier uses

```text
Y^2=X^3+121*X^2+1144*X+2704;
T=-52/X; w=(T-1)/2;
u+v=(9-T)/2; u-v=-Y/(2*X).
```

Substitution gives precisely the two ratio relations when the denominators are nonzero. Conversely the relations recover this carrier on its admitted chart. The homogeneous cubic in three affine coordinates is a cone; removing scale leaves a projective cubic curve. The carrier provides an exact rational coordinate method, while log-axis feedback is an ordinary real proposal mechanism.

A continuous solution does not imply a rational point nearby. On the slice a=b=1, the equation becomes t^2-7*t-4=0 for t=c. Its positive solution (7+sqrt(65))/2 is irrational. Thus this positive real slice has no rational solution. It also proves that equal positive rational channels cannot solve this particular puzzle. Three separately named variables generally may take equal values; their inequality here requires this additional proof.

Group-coordinate searches need a coverage certificate. Enumerating n*P explores the subgroup generated by P. Using P and -P as separate axes still explores that same subgroup, because c_1*P+c_2*(-P)=(c_1-c_2)*P. Extra listed points need not be independent generators. A finite coefficient shell supplies coverage of that shell's generated points, not every rational point or every positive integer solution. Local Vieta replacements and rational line intersections similarly explore reachable neighbors unless a global reachability result is proved. The defensible ranking is smallest among discovered verified triples. Global minimality additionally requires complete generating data and a rigorous height or coverage argument, absent from these inspected records.

## C1.5 Powers, nonlinear families, and exact algebra boundaries

Unknowns may occur in a fraction, a base, or an exponent. The expression grammar must retain that position. A literal integer power belongs to polynomial arithmetic when its exponent is nonnegative; a negative one belongs to guarded rational arithmetic. A variable exponent is generally a different primitive. Turning every such expression into a polynomial by textual expansion changes its meaning.

For positive real a,b and a reduced rational exponent m/n with n>0, a^(m/n)=b iff a^m=b^n. The positive nth-root branch proves the converse. With a negative real base, an odd reduced denominator supplies the unique real odd-root branch; an even denominator has no real branch. For a positive base, the transformed equality alone can allow a negative b when n is even, so b>0 remains necessary. Complex powers require an explicit logarithm branch and are outside this real rule.

C-EX10: 4^(-1/2)=1/2 is exactly verified by 4^(-1)=(1/2)^2=1/4, with a positive output branch. The equation 4^(1/2)=b gives b^2=4, but only b=2 passes its original branch. The equation (-8)^(1/3)=b has the real answer -2, whereas (-8)^(1/2)=b has no real meaning. Fractions and negative exponents therefore fit an exact verifier through guarded arithmetic rather than an indiscriminate modular inverse or floating root.

At arbitrary real exponent t, a^t=exp(t*ln(a)) for a>0. This supplies a smooth evaluator on a positive-base neighborhood, but does not remove general nonlinear coupling. For a known a>0,a!=1, the special equation a^x+a^(x+k)=N reduces to a^x=N/(1+a^k), giving x=ln(N/(1+a^k))/ln(a) when N>0. An x-dependent multiplier would leave an implicit equation. Logs are useful where an actual inverse contract exists.

The exact algebra route has a separate issue with denominator exclusion. Let H be the product of original nonzero polynomial guards. Introducing an auxiliary variable t with t*H-1=0 forces H!=0. Every guarded solution has the unique auxiliary value t=1/H, and every extended solution projects to a guarded numerator solution. This correspondence is proved directly over a field. If elimination removes t, its equations can describe the algebraic closure of the projected set, so original guard checks remain necessary at final candidates.

A finite algebraic variety is called zero-dimensional over its algebraic closure, with an inconsistent ideal handled separately. A nonlinear set with free parameters instead requires a family representation; it must not be truncated to a few isolated examples. A source-described capability test for zero dimension concerns the complex algebraic problem even when real answers are requested. Exact realness, branch checks, and bounds then select the real portion. Positive complex dimension and finite real answers can coexist, as the later x^2+y^2 example demonstrates.

This yields a practical capability boundary for undergraduate systems. A bounded rational grid can give complete finite enumeration for supported definite verification. Exact algebraic adapters can broaden the domain for supported polynomial/rational systems and represent nonradical roots. Numerical elementary-function adapters can find residual-qualified real proposals on guarded boxes. Integrals, limits, general nonlinear parameter families, and arbitrary complex transcendental branches require their own adapters. A route should return UNSUPPORTED or UNKNOWN when those obligations are absent, while preserving already verified witnesses.

## C1.6 Compiler contract and exercises

A usable compiler retains original syntax, coefficient semantics, variable order, domain, bounds, and branch conventions. Every transformation records either equivalence on a guarded domain or a necessary-condition implication. Every proposed answer returns through V, the original verifier. Arithmetic, numerical, and symbolic routes can share this object, while each advertises its own output grade. This is the precise means by which the project can grow beyond one equation pattern.

C-EXERCISE1: determine the real solutions of sqrt(x+1)=x-1. Squaring gives x*(x-3)=0, but the original right side requires x>=1. The only solution is x=3. C-EXERCISE2: describe x+y+z=1 with the additional row 1/(x-1)=1/(x-1). The affine family is (1-s-t,s,t), restricted by s+t!=0. The apparently tautological row still excludes a plane. Both exercises test compilation rather than numerical speed.

# C2. Numerical discovery with root certificates

Numerical methods turn evaluations into proposed inverses. Their value is that an explicit symbolic formula is often unnecessary. Their proofs still depend on concrete properties of the forward map: continuity, derivative size, bounded remainder, or a contractive response. Stefan's local quadratic and oscillatory work fits naturally into this setting. Measurements build a model; its inverse proposes a correction; a certificate establishes what the correction accomplished.

## C2.1 Finite changes, derivatives, and polynomial models

The exact increment of f(x)=x^2 is 2*x*h+h^2. For h!=0 its quotient is 2*x+h, whose limit is 2*x. The derivative is an exact linear response coefficient, while the finite increment includes the quadratic remainder. Cancellation before a limit is legitimate; assigning a value to 0/0 is unnecessary and invalid in a field. For a product, the exact change is u*Delta(v)+v*Delta(u)+Delta(u)*Delta(v). The cross term disappears only after the corresponding derivative limit, not at every finite displacement.

Another exact mechanism uses dual numbers a+b*epsilon with epsilon^2=0. For polynomials, substitution gives f(x+h*epsilon)=f(x)+f'(x)*h*epsilon. Expansion proves the identity, and structural induction through addition and multiplication proves its automatic-differentiation rules. The dual unit is not an ordinary small real number and cannot be divided out; its coefficient is extracted. This alternate algebra explains how exact derivative rules and finite numerical sampling can coexist without contradictory claims about increments.

At a fixed base x_0 and nonzero h, obtain three values f_0=f(x_0), f_1=f(x_0+h), f_2=f(x_0+2*h). Their differences define

```text
d_1=f_1-f_0; d_2=f_2-2*f_1+f_0.
P(x_0+n*h)=f_0+n*d_1+n*(n-1)*d_2/2.
g=(d_1-d_2/2)/h; H=d_2/h^2.
P(x_0+t)=f_0+g*t+H*t^2/2.
```

C-TH4, PROVED: P equals f everywhere when f has degree at most two. Direct substitution gives equality at the three sample nodes. Their polynomial difference has degree at most two and three distinct zeros, so it is identically zero. Alternatively, substituting a quadratic directly recovers its coefficients. Solving P=0 is therefore an exact method for this class, subject to original guards and exact arithmetic.

### C-EX4. Correcting a finite-difference numerical example

For f(x)=2*x^2+3*x-15, x_0=0, h=1/10, the sample values are -15, -14.68, and -14.32. Hence d_1=0.32, d_2=0.04, g=3, and H=4. The reconstructed model is exactly the original polynomial. Its two roots are (-3+sqrt(129))/4 and (-3-sqrt(129))/4.

The historical sample used incorrect values, leading to incorrect curvature. Recomputing the values and independently recovering the known coefficient 2 identify the error. The corrected construction is useful because it solves from evaluations and differences; the mistake does not require rejecting finite differences as a method.

For a general C^3 function the model has a remainder. On an interval containing the nodes and trial point,

```text
f(x)-P(x)=f'''(xi)*(x-x_0)*(x-x_0-h)*(x-x_0-2*h)/6.
```

A proof subtracts a multiple of the cubic nodal product from f-P so that the difference vanishes at four points, then applies Rolle's theorem three times. A bound on f''' consequently supplies a residual bound at a model root. A small sample spacing does not justify a distant extrapolation: the three displacement factors can remain large. The relevant interval includes the proposed point, rather than only the sampled neighborhood.

Centered differences separate odd and even responses. With |f'''|<=M_3 and |f''''|<=M_4 on the sample interval,

```text
g_h=[f(x+h)-f(x-h)]/(2*h),
|g_h-f'(x)|<=M_3*h^2/6.
H_h=[f(x+h)-2*f(x)+f(x-h)]/h^2,
|H_h-f''(x)|<=M_4*h^2/12.
```

Taylor expansion and cancellation prove these bounds. If each value has absolute uncertainty eta, the additional bounds are eta/|h| and 4*eta/h^2. Shrinking the probe therefore reduces truncation while amplifying evaluation error. Minimizing the first conservative total bound M_3*h^2/6+eta/h gives h=(3*eta/M_3)^(1/3) when its hypotheses and neighborhood permit that choice. This is a concrete probe-scale decision, rather than a rule to shrink indefinitely.

## C2.2 Existence, uniqueness, and a bracket

For a continuous real f on [L,U], opposite endpoint signs imply at least one root by the intermediate value theorem. If f' has a fixed sign and |f'|>=m>0 throughout that interval, there is at most one root. For any x in the interval, the mean-value theorem then gives |x-alpha|<=|f(x)|/m. Integrating the fixed-sign derivative gives the same bound. Root existence must already be established; the residual inequality alone cannot create it.

Bisection evaluates the midpoint and keeps the half containing a sign change, handling an exact midpoint zero separately. Continuity preserves existence at every stage. After n strict bisections the width is (U-L)/2^n, and the midpoint has error at most half that width. Rational polynomial evaluation can make every sign decision exact. A numerical evaluator instead needs interval values with trustworthy signs; an interval containing zero represents an unresolved sign.

For f=x^3-x-1 on [1,2], f(1)=-1, f(2)=5, and f'>=2. Existence and uniqueness are therefore certified. The exact run performs 48 bisections and returns

```text
L=93218739040913/70368744177664;
U=372874956163653/281474976710656;
U-L=1/281474976710656=2^(-48).
```

The decimal midpoint is a display of the enclosed root, not an exact replacement for it. No modular residue calculation is needed for this real certificate.

A bracket must respect the original domain. The values of 1/x at -1 and 1 have opposite signs, but the connecting interval crosses a pole and contains no root. Conversely a sign scan can miss an even-multiplicity root: (x-1)^2 never changes sign. An all-root method needs treatment of such zeros beyond strict sign-change detection.

## C2.3 Newton's useful local theorem

Newton proposes x_new=x-f(x)/f'(x), requiring a defined nonzero derivative. Suppose alpha is a root, |f'|>=m>0 and |f''|<=M on a neighborhood containing alpha, x, and the segment between them. Taylor expansion of f(alpha) about x gives

```text
|x_new-alpha|<=M*|x-alpha|^2/(2*m).
```

C-TH5, PROVED: within a sufficiently small invariant neighborhood, this estimate gives local quadratic convergence. If K=M/(2*m), choose a radius rho with K*rho<1 and with the closed neighborhood inside the derivative bounds. Each new error is at most K*rho times the old error, stays inside the neighborhood, and tends to zero; once small, its next value is bounded by a constant times its square. The integral identity f(x)=integral_alpha^x f'(t)dt supplies another derivation by bounding the difference between f'(x) and f'(t).

This theorem concerns a simple root and a sufficiently close start. Fixed damping alpha_d in (0,1) changes the leading error to (1-alpha_d)*e+O(e^2), generally giving linear convergence. A repeated root also needs different analysis: for f=(x-r)^2, ordinary Newton halves the error instead of squaring it. The checked DLMF description distinguishes local simple-root behavior from multiple-root behavior. [C-R3]

### C-EX5. A genuine root function with a Newton cycle

For f=x^3-2*x+2, Newton sends 0 to 1 and 1 to 0 exactly. Both derivatives are nonzero, but the iteration does not reach a root. This refutes unrestricted global convergence even for a cubic. The method can still converge from appropriate other starts. A certified hybrid therefore treats its update as a proposal, accepts it only within the current valid bracket, and falls back to bracket reduction when it fails the progress contract.

If every retained off-center trial lies in the middle half of the bracket, the surviving width is at most 3/4 of the previous width. Bisection gives the stronger factor 1/2. Requiring a fallback after inadequate progress proves enclosure convergence independently of the proposal's quality. A finite backtracking or iteration budget prevents implementation stalls from becoming silent infinite loops.

## C2.4 Halley's cube update has a stronger special theorem

Halley's formula is x_new=x-2*f*f'/(2*(f')^2-f*f''), with its denominator nonzero. It is a different rational correction from solving a quadratic interpolant. For f=x^3-N, N>0, it simplifies to U(x)=x*(x^3+2*N)/(2*x^3+N). This specialization has a global result on x>0.

Put alpha=N^(1/3), s=x/alpha, and u=s*(s^3+2)/(2*s^3+1). Exact factorization gives

```text
u-1=(s-1)^3*(s+1)/(2*s^3+1);
u-s=-s*(s^3-1)/(2*s^3+1).
```

For s>1 these imply 1<u<s; for 0<s<1 they imply s<u<1. C-TH6, PROVED: every positive start stays on its original side and moves monotonically toward one. A bounded monotone sequence has a limit, and continuity identifies its positive fixed point as one. The first identity also shows local cubic error. Zero is a spurious fixed point outside the admitted theorem, while negative starts may encounter poles. A specialized global theorem should remain attached to this admitted domain.

### C-EX6. A cube-root approximation becomes a certified interval

For x^3=2 and x_0=1, the first two Halley iterates are 5/4 and 635/504. Exact substitution gives the second residual -253/128024064. Both are below the root by the monotonic theorem. On [1,2], f'>=3, so

```text
alpha in [635/504, 635/504+253/384072192].
Width=253/384072192 < 6.59*10^(-7).
```

The residual-to-distance theorem supplies the upper endpoint. Direct exact cubing of that endpoint independently confirms its positive residual. Thus a fast proposal and a slower certificate cooperate. Their roles remain visible even when a decimal estimate appears convincing.

The related corrected rational start for (1+e)^(1/3) is (1+2*e/3)/(1+e/3), e>-1. Expanding proves agreement through e^2. Exact cubing gives residual -e^3*(e+2)/(e+3)^3. It is precisely the specialized Halley update applied to the normalized anchor one. This repairs the historical second-order coefficient without inventing a generic rational convergence guarantee.

## C2.5 Exact boxes can certify a three-variable root

Interval arithmetic encloses every possible value on a box. Addition uses endpoint sums, multiplication takes the least and greatest of four endpoint products, and division requires the denominator interval to avoid zero. Exact rational endpoints suffice for polynomial examples. Floating implementations require outward rounding, and elementary functions require validated interval evaluations. The expression X-X over X=[0,1] may produce [-1,1] by independent occurrences, although its exact value is zero. That dependency loss weakens efficiency without making a sound enclosure false.

If any residual interval excludes zero, the box contains no root. For scalar interval Newton, a pivot c in I and a derivative enclosure f'(I) avoiding zero give N=c-f(c)/f'(I). Every root alpha in I lies in N by the mean-value theorem on the segment joining c and alpha, which remains in I. Hence I intersect N retains every root, and an empty intersection proves exclusion. A pivot outside I instead requires a derivative enclosure over the enlarged hull. The checked interval package documentation describes this distinction between point Newton and interval enclosure refinement. [C-R4]

For a square three-variable system F continuously differentiable on an open neighborhood of a closed box I, choose an invertible matrix B and define G(theta)=theta-B*F(theta). Write Id for the identity matrix. The box is centered at c with infinity-norm radius r. Suppose ||Id-B*DF(theta)||_infinity<=q<1 throughout I. If eta=||B*F(c)||_infinity and eta+q*r<=r, then G maps I into itself and is a contraction.

C-TH7, PROVED: this contract gives exactly one root in I. The derivative bound and integration along a segment give ||G(u)-G(v)||<=q*||u-v||. They also give ||G(theta)-c||<=eta+q*r<=r. Iteration stays in I. Successive differences are bounded by a geometric sequence, so the iterates are Cauchy; closedness and completeness supply a limit in I. Continuity makes it a fixed point. Two fixed points would satisfy their distance <=q times itself, forcing equality. Finally B invertible makes G(theta)=theta equivalent to F(theta)=0. This proof supplies existence, uniqueness, and a concrete checking target.

### C-EX7. A coupled contraction box

Take

```text
F_1=x+y^2/10-7/5;
F_2=y+z^2/10-29/10;
F_3=z+x^2/10-31/10.
c=(101/100,201/100,301/100); r=1/20; B=identity.
```

The box includes (1,2,3), whose original residual is exactly zero. More significantly, its derivative and drift provide a certificate independent of recognizing that point. The derivative of G has one off-diagonal entry per row, with magnitudes |y|/5, |z|/5, and |x|/5. Their largest value on the box is 153/250=0.612. The residual at c has largest magnitude 1601/100000=0.01601. Thus eta+q*r=4661/100000=0.04661<0.05. C-TH7 proves a unique root in the whole box.

The exact check also evaluates its eight corners and confirms that their images are strictly inside. Corner agreement alone is not a general contraction proof; here the derivative bound supplies the universal interior argument. The example demonstrates the missing step between a small numerical residual and a certified multivariate root.

## C2.6 Complex variables and global coverage

A complex tuple in C^3 has six real coordinates. For complex residuals the nonnegative loss is the sum of absolute squares, not unconjugated squares. Real-coordinate derivatives or explicitly specified complex derivatives must be used consistently. The function |F(z)|^2 generally depends on z and its conjugate, so it is not a holomorphic function merely because F is holomorphic.

For x^2+1=0, y=x, z=0, the complex solutions are (i,i,0) and (-i,-i,0); the real solution set is empty. Taking the real part of a complex root does not preserve the original polynomial equation. Another instructive system is x^2+y^2=0, z=0. Its real solution set contains only the origin, while its complex set has curve components. Positive complex dimension therefore does not prove infinitely many real answers. Singular-root methods and exact domain classification are indispensable in such cases.

Local certificates do not establish all-root completeness. A global box method must account for every portion of the requested domain: excluded boxes, isolated certified roots, and unresolved boxes. Shared boundaries need consistent treatment; singular Jacobians may prevent a contraction certificate even at genuine roots. Subdivision without a termination theorem is a systematic search, rather than a guaranteed finite all-roots procedure for every smooth function.

Ensemble starts help discovery but cannot replace coverage. If independent trajectories each find a particular root with probability q, the chance all n miss it is (1-q)^n. That statement needs an actual q and independence model. Deterministic dispersed starts do not automatically satisfy it. Similarly, clustering candidate points by distance does not establish multiplicity or uniqueness. Averaging two exact roots +a and -a of x^2-a^2 yields zero, a nonroot. Representatives require fresh verification, and close distinct roots require separate isolating certificates.

## C2.7 An executable numerical contract

A hybrid scalar solver can state its obligations without tying correctness to one proposal formula:

```text
Input: original evaluator, guarded interval, target width, budget.
Require trustworthy endpoint signs and continuity on the interval.
Store old interval and old point before producing a trial.
Propose an admissible Newton, Halley, or interpolation point.
If the trial is undefined or cannot reduce the bracket sufficiently,
    replace it with the midpoint.
If a reliable sign is unavailable, increase evaluation precision
    or return UNKNOWN with the preserved interval.
Otherwise retain the sign-changing subinterval.
Stop with a certified enclosure once its width meets the target.
```

The ordering matters. Computing a step after overwriting the old point makes its measured length identically zero, a historical control-flow error. A small step may mean stagnation; it is not a root proof. Nonfinite values, cancellation, domain violations, and underflow require explicit outcomes. In particular, a positive exponential that rounds to zero should not be accepted as an exact zero of the mathematical exponential.

A multivariate proposal route has comparable responsibilities. Derivative samples require defined neighborhoods, and a proposed path must respect original guards. Two finite endpoint evaluations of 1/x do not make a path across zero admissible. A guard interval excluding zero certifies safety for a polynomial denominator throughout the box; an interval containing zero is inconclusive. It can justify rejecting that numerical path, while the mathematical candidates in the region survive for another method.

Residual-qualified numerical output should include each original residual, the arithmetic precision, scaling, and tolerance. The equation 10^(-12)*(x-1)=0 accepts x=0 under a raw 10^(-9) residual threshold, even though its coordinate error is one. A derivative lower bound or a validated system certificate addresses that discrepancy. Empty numerical output retains UNKNOWN unless the whole declared domain has an independent exclusion certificate.

C-EXERCISE3: for f=x^2-2 on [1,2], derive the residual error bound and the width after ten bisections. The derivative is at least two; |x-alpha|<=|f(x)|/2 and the width is 1/1024. C-EXERCISE4: determine whether 1/x can be bracketed across zero. It cannot: the original function is undefined on the proposed interval. These tests establish which theorem is applicable before the iteration begins.

# C3. Descent, optimization, and controlled adaptation

The solver work contains a second important theme: a method can adapt its own probes, damping, gains, and restarts. This can improve practical search, provided adaptation remains distinct from mathematical acceptance. A controller decides what to try; the original predicate and certificate decide what has been established. That division supports experimentation with quadratic models, oscillatory estimates, memory, and scheduling without making their behavior a proof of root existence.

## C3.1 Root loss and its stationary points

For a real residual vector F and positive residual scales s_j, define J(theta)=sum_j(F_j(theta)/s_j)^2/2. Exact nonnegativity gives J=0 iff F=0. Each row must be squared separately: squaring their sum permits residuals 1 and -1 to cancel. Fixed scales preserve the exact zero set, while changing numerical conditioning and tolerance meaning.

With unit scales and A=DF, differentiation gives

```text
grad J=A^T*F;
Hess J=A^T*A+sum_j F_j*Hess F_j.
```

The product and chain rules prove these identities. They show both the usefulness and the limitation of least squares. F=0 implies stationarity; stationarity need not imply F=0, because F may lie in the nullspace of A^T. For f=x^2+1, the loss has a positive global minimum at zero and no real root. For f=x^2-1, zero is a stationary nonroot even though two roots exist elsewhere.

The distinction persists when the nonsolution is a strict local minimum. Set f=(x^2+1)*(x-3). At a=1-sqrt(6)/3, f'=0 but f(a)=-4+4*sqrt(6)/9!=0. The squared residual has curvature J''(a)=8*sqrt(6)-16/3>0. Adding residuals y and z makes (a,0,0) a strict local minimum in three dimensions, while the exact root (3,0,0) lies elsewhere. Local descent can correctly converge to that nonzero minimum. Restarts offer another opportunity; they do not supply a universal convergence theorem.

## C3.2 Quadratic solving and least-squares models

For q(p)=J_0+g^T*p+p^T*H*p/2, with H symmetric positive definite, the unique minimizer is p_star=-H^(-1)*g. Differentiation finds its stationarity, and completing the square proves global minimality:

```text
q(p)=J_0-g^T*H^(-1)*g/2
     +(p+H^(-1)*g)^T*H*(p+H^(-1)*g)/2.
```

Invertibility alone is insufficient: a negative definite H gives a maximum and an indefinite H gives a saddle. If H is positive semidefinite and singular, a minimizer exists precisely when g is orthogonal to ker(H); then minimizers differ by null vectors. Otherwise the linear term drives q unbounded below along a null direction. A local model also needs its proposed point inside the region where the model and original domain are valid.

### C-EX8. An exact least-squares snap

For A=[[1,2],[1,-1]], b=[5,-1], and J(theta)=||A*theta-b||^2/2, the gradient at zero is (-4,-11), and H=A^T*A=[[2,1],[1,5]]. Its determinant is 9, and its leading diagonal entry is positive, so H is positive definite. Solving H*p=(4,11) gives p=(1,2). Direct substitution gives A*p=b. The model minimizer is consequently an exact root as well as a global least-squares minimizer.

The latter conclusion would fail with inconsistent data. A=[1;1], b=[0;1] has full column rank and unique minimizer theta=1/2, but no exact root. Rank gives uniqueness of the minimizer; compatibility b in image(A) gives exact fitting. These obligations remain distinct even in very small dimensions.

For nonlinear F, Gauss-Newton minimizes ||F+A*p||^2/2, producing A^T*A*p=-A^T*F. It omits the residual-curvature term in the full Hessian. Positive damping yields the Levenberg-Marquardt model

```text
(A^T*A+mu*W)*p=-A^T*F;
mu>0; W symmetric positive definite.
```

For any nonzero v, its quadratic form is ||A*v||^2+mu*v^T*W*v>0. The model therefore has a unique solution even when A is rank deficient. This proves solvability of the proposal system, rather than nonlinear descent or a zero residual. Solving the linear system directly is preferable to explicitly forming an inverse. QR or singular-value methods also avoid the conditioning amplification of normal equations, whose spectral condition number squares that of a full-rank A.

## C3.3 A precise descent contract

Let grad J be L-Lipschitz along the complete segment of a proposed displacement p. Integration along that segment gives

```text
J(theta+p)<=J(theta)+g^T*p+L*||p||^2/2.
```

To prove it, subtract g from the gradient inside the line integral and bound the remainder by L*t*||p||^2; integration of t over [0,1] gives 1/2. For p=-eta*g, strict descent follows when 0<eta<2/L and g!=0. With J=x^2, taking eta=2 sends x to -3*x and multiplies loss by nine. A gradient direction alone therefore does not license every step length.

An estimated gradient g_hat=g+e, ||e||<=delta, gives the usable bound

```text
J(theta-eta*g_hat)-J(theta)
 <=-eta*(1-L*eta/2)*||g_hat||^2+eta*delta*||g_hat||.
```

The same integration followed by Cauchy-Schwarz proves it. If (1-L*eta/2)*||g_hat||>delta, the bound certifies decrease. This is the correct connection between probe accuracy and accepted descent. Near a stationary point, estimation error may dominate. Measured objective reevaluation or tighter error bounds must then decide acceptance.

Backtracking provides another contract. For a direction d with g^T*d<0, choose c in (0,1) and test J(theta+t*d)<=J(theta)+c*t*g^T*d. Differentiability gives J(theta+t*d)=J(theta)+t*g^T*d+o(t), so sufficiently small positive t satisfy the inequality. Domain guards must hold along the admitted trial, and practical code uses a finite budget. The checked Boyd-Vandenberghe text states the corresponding descent-direction backtracking procedure. [C-R5]

Monotone loss values alone do not prove stationary convergence. For J=x^2/2, steps alpha_k=2^(-k-2) produce x_(k+1)=(1-alpha_k)*x_k. They satisfy strict decrease and an Armijo test with c=1/2. Yet sum alpha_k=1/2, and finite products satisfy product(1-alpha_k)>=1-sum alpha_k>=1/2. The nonzero sequence cannot reach zero or converge to stationarity from x_0=1. This explicit example shows why infinitely many small successful moves still need a quantitative progress condition.

## C3.4 Curvature uncertainty and a trust radius

Suppose a true positive definite Hessian H has smallest eigenvalue lambda, and H_hat=H+E with ||E||<=eta_H<lambda. Let g_hat=g+e with ||e||<=eta_g. The ideal and fitted steps solve H*p_N=-g and H_hat*p=-g_hat. Subtraction yields

```text
H_hat*(p-p_N)=-e-E*p_N;
||p-p_N||<=(eta_g+eta_H*||p_N||)/(lambda-eta_H).
```

The denominator follows because every unit v obeys v^T*H_hat*v>=lambda-eta_H. This proves a model sensitivity bound and exposes the danger near singular curvature. More samples may reduce eta_H, but do not automatically increase the underlying lambda.

If the true Hessian is L_H-Lipschitz on the segment, the integral Taylor remainder is at most L_H*||p||^3/6. Combining this with gradient and Hessian uncertainty gives

```text
|J(theta+p)-q_hat(p)|
 <=eta_g*||p||+eta_H*||p||^2/2+L_H*||p||^3/6.
```

The integral weight t*(1-t) has total 1/6, proving the cubic term without assuming an everywhere defined third derivative. Predicted reduction larger than this bound proves actual decrease. Alternatively, two objective evaluations each uncertain by eta_J need a measured decrease exceeding 2*eta_J. Either certificate concerns descent; original root verification remains separate.

A trust region limits the model displacement to ||p||<=Delta. A sufficient certificate that p globally minimizes its quadratic subproblem is

```text
(H+lambda_t*I)*p=-g;
H+lambda_t*I positive semidefinite;
lambda_t>=0; ||p||<=Delta;
lambda_t*(||p||-Delta)=0.
```

For any feasible d, stationarity rewrites q(d)-q(p) as
(d-p)^T*(H+lambda_t*I)*(d-p)/2
+lambda_t*(||p||^2-||d||^2)/2. The first term is nonnegative. The second vanishes when lambda_t=0 and is nonnegative when lambda_t>0 because p then lies on the boundary. This proves sufficiency. It does not assert that an arbitrary damping choice finds those conditions or that the model minimum solves the nonlinear problem.

## C3.5 Inexact Newton rates depend on relative error

Probe amplitudes and regularization are sometimes said to vanish, with fast convergence then assumed. A useful local calculation states the missing rates. Let theta_star be a simple root, e=theta-theta_star, and A=DF(theta). Assume A is locally invertible with bounded inverse, its variation is Lipschitz, and the proposed step uses an approximate residual F+b and matrix A+E. Let s solve (A+E)*s=-(F+b) exactly. The residual expansion along the segment to the root gives A*e-F=r with ||r||<=K*||e||^2. Consequently

```text
(A+E)*(e+s)=r+E*e-b.
||e_new||<=K_0*(K*||e||^2+||E||*||e||+||b||),
```

where K_0 bounds the approximate inverse. This estimate is proved by substitution and a norm bound. An inexact linear solve adds its residual to the right side. Fixed damping adds a term proportional to e, as in the scalar calculation. These are distinct sources of error even if one user-facing routine manages all of them.

Quadratic convergence is preserved under sufficient controls ||E||=O(||e||), ||b||=O(||e||^2), and comparable solve/damping error. Sending an amplitude to zero geometrically does not establish those relations to the current unknown error. If an uncorrected probe has residual bias O(a^2), that bias can dominate the Newton correction and determine the observed rate. A trustworthy residual or enclosure is needed to govern further shrinking.

The same calculation explains when derivative measurements are useful. A measured model that is accurate relative to the current residual can provide a good inverse correction. A model with a tiny absolute error may still be inadequate near singularity or when the desired error is much smaller. Recording amplitude, estimator error, inverse bounds, and linear-solve residual makes the proposal assessable. It also supplies a concrete future experiment: compare exact derivatives, central differences, and paired oscillatory estimates under the same coordinate and evaluation budgets, checking whether their errors obey these rates.

## C3.6 Controller adaptation needs its own invariant

A numerical controller M can alter amplitude, damping, restart policy, or scheduling. A plant state y evolves under its actions. An observer O records the resulting measurements. A checker V assesses a candidate controller against an immutable contract epoch. Keeping these roles separate prevents measurements under the old controller from being treated as tests of a new controller's future behavior.

A corrected transition accepts a proposed controller only after checking finiteness, membership in an allowed set, displacement, cost, behavior, and the agreed objective bound. Every fallback passes the same gate. If no candidate passes, a hold is allowed only while the old certificate remains valid. A changed objective, measurement model, observer, or allowed set requires a new epoch and rechecking affected claims.

C-TH8, PROVED: with a sound checker and valid initial state, every committed controller remains valid in an unchanged epoch. Induction gives the proof. An accepted branch supplies the invariant directly; the hold branch repeats an already valid state. The proposal method can be sophisticated, random, or ineffective without changing this logical argument. Correctness of adaptation rests on the gate, rather than on a name such as cybernetic, Bayesian, or self-aware.

The historical ungated fallback fails a simple example. Let the allowed set be [0,1], the current controller 0, and V(M)=M with no allowed increase. A trial 1 is rejected. A smaller fallback 1/2 is feasible but still increases V. Backoff and clipping do not preserve the missing energy condition. The same checker must assess both trials.

Bounded increments also do not bound the state: M_k=k*delta has a fixed small change at every step and drifts indefinitely. If each accepted change obeys V(M_(k+1))<=V(M_k)+epsilon_k, summation gives V(M_n)<=V(M_0)+sum epsilon_k. Summable allowances bound energy above. With a lower bound and zero allowances, its scalar values converge. The states need not converge: M_k=(-1)^k with V=M^2 has constant energy. Controller boundedness and plant stability require their own conclusions.

For a nonempty closed convex allowed set, Euclidean projection gives a useful displacement property. If M is already allowed, N=projection(M+alpha*delta) satisfies ||N-M||<=alpha*||delta||. The projection variational inequality gives ||N-M||^2<=alpha*delta dot (N-M), followed by Cauchy-Schwarz. A nonconvex repair does not automatically have this property, so a separate displacement gate is then needed.

### C-EX9. A gain envelope proves a specific plant stable

Take an undisturbed scalar integrator with target 10,

```text
e=10-y; u=clip(K*e,-20,20); y_new=y+u.
Allowed gains: 1/20<=K<=6/5.
Overshoot: e*e_new<0.
```

An illustrative adaptation decreases K by 0.2 after overshoot, increases it by 0.1 after improvement, decreases it by 0.1 otherwise, and holds it when both old and new errors are within 0.02. Projection enforces the gain interval. Starting at y=0,K=1.1 gives (y,K)=(11,0.9), then (10.1,1.0), then (10,1.1). Arrival at exact zero is not an overshoot. Defining it by a change in a sign function instead would alter this trace.

For an unsaturated step, e_new=(1-K)*e. The envelope gives |e_new|<=0.95*|e|, so the squared error contracts by at most 0.9025. This holds for any gain schedule inside the envelope, independent of the illustrative adaptation rule.

For saturation, write E=|e| and q=min(K*E,20). Every nonzero state has 0<q<2*E, so |E-q|<E. If E>=20 during saturation, the magnitude drops by 20; if E lies between 50/3 and 20, the new magnitude is below 10/3. Hence finitely many saturated steps enter E<=50/3, where all allowed gains are unsaturated. Geometric convergence then follows. There is no uniform 0.95 factor for arbitrarily large saturated errors. The theorem applies to this stated plant, not every controlled system.

## C3.7 Evidence and useful performance questions

The new exact checks verify 2940 quadratic reconstruction instances, each at six additional trial coordinates, and 38424 gain/error transitions. They also reproduce the nonlinear integer and rational-grid examples, denominator exclusions, Newton cycle, Halley identities, exact real bracket, contraction box, and corrected gain trace. These FINITE records corroborate implementation of named contracts. The self-contained proofs carry their general conclusions. No speed comparison or general V4 package execution is inferred from the check count.

A fair performance comparison fixes equations, domain, coefficient semantics, starting policy, evaluation budget, and answer grade. Time to one approximate point differs from time to all exact grid roots. Count initial snapping, descent discoveries, arithmetic pruning, and exhaustive fallback separately. Otherwise an answer found by a first neighborhood scan may be wrongly credited to an elaborate optimizer. A seven-value central model and a thousand-value lock-in model cannot be compared solely by iteration count.

Adaptive scheduling is useful within this contract. It can choose another prime, a deeper precision, a fresh seed, a smaller trust radius, or immediate exact evaluation according to estimated cost. Failure memory can avoid duplicate attempts. None of those policies may delete an admissible solution merely because a local solve failed, a hash collided, or a score was poor. Saved failures should distinguish proved infeasibility from numerical non-discovery.

C-EXERCISE5: explain why positive damping makes A^T*A+mu*I invertible but cannot prove F=0. Its quadratic form is strictly positive; the solved model is only a local residual approximation. C-EXERCISE6: explain why P and -P do not create a second independent search axis. Their integer combinations reduce to multiples of P. These exercises connect the same core lesson across numerical and arithmetic search: a valid proposal mechanism and a complete mathematical answer have different proof obligations.

## C references and attribution

The polynomial identities, finite-grid arguments, derivative bounds, contraction proof, quadratic certificates, and stated controller theorem are proved above. Newton, interpolation, Halley, least squares, interval arithmetic, and projection are established methods. Stefan's contribution represented here is the project's combination of these methods into explicit solver contracts and its motivating examples; no mathematical novelty or universal efficiency claim is made.

[C-R1] SymPy developers, Solvers, SymPy 1.14.0 documentation, Systems of Polynomial Equations: solve_poly_system strict handling and solve_triangulated algebraic extensions. Checked 2026-10-13. https://docs.sympy.org/latest/modules/solvers/solvers.html

[C-R2] SymPy developers, Solveset, SymPy 1.14.0 documentation: unresolved sets, nonlinsolve, finite and parameterized output contracts. Checked 2026-10-13. https://docs.sympy.org/latest/modules/solvers/solveset.html

[C-R3] NIST Digital Library of Mathematical Functions, Section 3.8, Nonlinear Equations, Newton iteration and local simple/multiple-root distinctions. Checked 2026-10-13. https://dlmf.nist.gov/3.8

[C-R4] GNU Octave Interval Package, Root Finding, Sections 3.4.1-3.4.2, interval Newton and bisection documentation. Checked 2026-10-13. https://octave.sourceforge.io/interval/package_doc/Root-Finding.html

[C-R5] Stephen Boyd and Lieven Vandenberghe, Convex Optimization, Section 9.2, Algorithm 9.2, printed pp.464-466: descent-direction backtracking and admitted domain. Checked 2026-10-13 in the author PDF. https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf
