# Integrated practice: turning a representation into a useful solver

## Z1. A common interface that does not erase mathematical differences

The common framework can be specified with an original domain D, a solution predicate V, and the true solution set S={x in D:V(x)}. A candidate state represents an enclosure C with S subset C. A worker may propose an additional condition E, a smaller state C', or a reconstructed witness x. The acceptance rules depend on what is being claimed.

```text
Pruning certificate: every member of S satisfies E.
Accepted enclosure: C' = C intersect {x:E(x)}.
Witness certificate: x in D and V(x) is true.
Completeness certificate: every member of S is represented in output.
Uniqueness certificate: sound complete output represents S={x}.
```

PROVED Z-P1. Any finite sequence of accepted pruning operations preserves all original solutions. Initially S subset C_0. If S subset C_j and all x in S satisfy E_j, then every x in S belongs to C_j intersect E_j=C_(j+1). Induction establishes S subset C_j at every stage. The enclosure also decreases because intersection cannot add elements.

This proof supplies preservation, not automatic progress. A repeated constraint leaves an intersection unchanged. For fixed E, the operation C -> C intersect E is idempotent. Applying it a hundred times gives the same set as applying it once. A working ratchet needs genuinely new constraints, increased precision, smaller verified bounds, or updated constraint propagation whose fixed-point computation has been specified.

A second interface concerns reversible representations. Suppose R(x,z) relates original objects x to transformed objects z. Forward coverage requires every original solution to have a represented transformed state. Backward correctness requires every accepted decoded state to be an original solution. A transform can have many representations per object and still be useful. It need not be a bijective function, but its reconstruction relation must retain the missing choices.

A residue x == a (mod M) illustrates the point. It becomes exact ordinary reconstruction only when the fiber coordinate t is retained in x=a+Mt. A real or complex root can similarly be represented by an isolating interval or region and a polynomial, rather than by a decimal string pretending to be exact. A finite data transform can be stored with its normalization and indexing conventions so that the inverse is defined. The interface states what an object means before a particular engine is selected.

## Z2. A small complete arithmetic reconstruction

Consider the integer equation x^3-x=0 with the declared bound -2<=x<=2. The original verifier evaluates the exact integer polynomial. Modulo 3, every residue is a root, so that initial projection removes nothing. Lifting to modulus 9 gives roots 0,1,8. Modulo 5 the roots are 0,1,4. Every ordinary integer root must satisfy both local equations.

CRT combines each of the three modulus-9 branches with each of the three modulus-5 branches, giving nine classes modulo 45:

```text
{0,1,9,10,19,26,35,36,44} modulo 45.
```

Only classes 44,0,1 meet the integer interval [-2,2], through representatives -1,0,1. Exact substitution accepts all three. The complete output is therefore {-1,0,1}. The method has enumerated every local branch and every bounded representative, so its completeness is justified. The factorization x^3-x=x(x-1)(x+1) supplies a separate hand-check of the mathematical answer.

The example also records the usefulness boundary. The initial modulus 3 supplies no candidate reduction. The modulus-45 classes contain local roots that do not correspond to small ordinary roots; the bound and original verification finish the job. A different problem might make one prime much more selective than another. Testing selectivity is an engineering choice; eliminating an unpromising prime does not permit eliminating actual candidate branches without proof.

A suitable implementation reports the input domain, the primes and precision levels, the complete local root sets, the CRT classes, the interval representatives, and the original residuals. The output need not claim to have solved all cubic equations over every field. It has solved this declared integer problem completely, and it exposes a reusable pattern.

## Z3. Factorization on a hyperbola, in gap coordinates and on a circle

For an integer N>1, the positive real curve xy=N is easy to parameterize: every x>0 gives y=N/x. The factorization problem asks for its positive integer lattice intersections. Taking x<=y bounds the smaller factor by floor(sqrt(N)). This distinction prevents a continuous optimizer from being presented as an integer factorization algorithm merely because it follows the correct curve.

For a lower-factor interval with 0<L<=U and L<=x<=U, every integer cofactor must lie in

```text
ceil(N/U) <= y <= floor(N/L).
```

PROVED Z-P2. The reciprocal function decreases on positive reals, so N/U<=N/x<=N/L. Integer rounding preserves the necessary bounds. This gives a safe enclosing rectangle. It may be loose, and often supplies little pruning by itself; usefulness requires additional incompatible integer, parity, or modular conditions.

Gap coordinates write y=x+h with h>=0. Substitution gives x^2+hx-N=0. There is an integer factor pair with that gap exactly when

```text
h^2+4N=k^2;
k>=h;
k==h (mod 2);
x=(k-h)/2; y=(k+h)/2.
```

For N>0 the positive square-root branch has k>h. The parity guard is essential. Multiplying the reconstructed factors gives (k^2-h^2)/4=N, proving backward correctness. Starting from an integer factor pair gives h=y-x and k=x+y, proving forward coverage.

For odd N, writing m=(x+y)/2 and d=(y-x)/2 gives Fermat's difference of squares N=m^2-d^2. Because odd factor pairs have matching parity, m and d are integers. For N=10403, m_0=ceil(sqrt(N))=102. The difference m_0^2-N=1 gives d=1 and factors 101,103. In gap coordinates h=2 and h^2+4N=41616=204^2, returning the same pair. This is a useful example of exact coordinate transport; two presentations have the same underlying search condition.

A phase coordinate takes an integer candidate k and its Euclidean remainder r=N mod k, with 0<=r<k. Define z=exp(2*pi*i*r/k). Then z=1 exactly when r=0, which is exactly k dividing N. The chord distance and an alignment score are

```text
|1-z| = 2*abs(sin(pi*r/k));
P = (1+Re(z))/2 = cos(pi*r/k)^2.
```

These are exact identities in an exact mathematical complex model. In software, evaluating a floating-point phase is an approximate calculation; N mod k remains the direct exact verifier. Computing every remainder and then drawing every phase has already performed the corresponding divisibility workload. A geometric display does not erase that cost.

For N=77 and k=10, r=7. The phase is exp(1.4*pi*i)=exp(-0.6*pi*i). Its centered angular magnitude is 0.6*pi, but replacing the phase itself by exp(+0.6*pi*i) conjugates it. The magnitude-based score remains the same; a signed phase reconstruction does not. This repairs a small but consequential ambiguity in the phase-search notes.

A harmonic average A_M=(1/M)sum_(j=0)^(M-1)z^j has intensity |A_M|^2. At M=1 its intensity is 1 for every candidate, so it contains no divisor information. For M>=2, exact intensity 1 forces all averaged unit vectors to have the same direction; because the first vector is 1 and the second is z, this forces z=1. Finite tolerance can still produce high scores for nondivisors. A near-aligned phase is a ranking signal rather than an exact witness.

A phase-priority search does not automatically return the factor closest to sqrt(N). All actual divisors attain the maximum exact alignment score, and near misses can attain almost the same approximate score. The closest pair can be certified by monotonically enumerating Fermat centers until the first valid square, or by a complete objective-bound argument. Arbitrary best-first priorities need an independently proved admissible bound before they establish optimality.

## Z4. Exact information and heuristic information can cooperate

The useful hybrid arrangement has an exact candidate ledger and a separate proposal queue. Heuristics rank which branch, box, residue class, or experiment to inspect next. Exact certificates determine what may be removed, accepted, or declared complete. This separation allows a fast experimental method to contribute without weakening mathematical correctness.

For an integer polynomial, a numerical approximation may suggest which residue classes to test first. For a factorization problem, a phase score may suggest a candidate k. For a nonlinear system, an oscillatory probe may propose a local quadratic model. For a pattern finder, a high statistic may propose a walk or state representation. Each becomes an accepted mathematical result only through the corresponding original-domain condition.

There is one qualification: pruning can be probabilistic when the problem itself explicitly permits a statistical guarantee. Then the confidence contract, dependence assumptions, and total error allocation must travel with the candidate state. A 95% confidence statement is not interchangeable with a universal solution-preservation statement. It also does not become 99.75% merely because the same data are reported by two related workers.

The project is especially suitable for inspectable adapters. A modular adapter exposes modulus, representative convention, exact order where required, and a verified congruence. A p-adic adapter exposes prime, precision, valuation, and torsion branch. A real-root adapter exposes an interval and existence or uniqueness certificate. A spectral adapter exposes sample grid, frequency map, normalization, and retained coefficients. A logic adapter exposes context, evidence identity, and inference rule. These fields make a result portable between implementations.

## Z5. Sparse observations: units, averages and inverse models

The recovered flight-reconstruction note supplies a useful application of the observation contract. Its measurements, graph readings, derived quantities and assumptions are separate data types. This edition retains that mathematical method without adopting an accident-cause conclusion or revalidating the historical observation set.

For two altitude observations h_0,h_1 separated by Delta t seconds, the interval-average vertical rate in feet per minute is 60*(h_1-h_0)/Delta t. A change from 31,450 to 36,325 feet over 21 seconds gives 97500/7, approximately 13,929 feet per minute. This average does not identify an instantaneous rate at either endpoint. A derivative estimate from sparse data needs a smoothness and synchronization assumption, especially when different telemetry fields have different delays.

For a planar path modeled as a constant-curvature arc, endpoint chord length d and total angle change theta give radius R=d/(2*sin(abs(theta)/2)) and arc length R*abs(theta). The formula needs 0<abs(theta)<2*pi and an explicitly chosen arc. Endpoint headings alone do not uniquely identify the path between endpoints. A shortest signed angular difference fixes a convention; it does not rule out an additional full turn in unobserved motion.

Ground-relative velocity and air-relative velocity differ by the wind vector. Using a horizontal ground speed as airspeed requires a declared wind assumption. A three-dimensional speed norm additionally needs a synchronized vertical component. A coordinated steady-turn bank formula requires its dynamical assumptions; inserting an observed turn rate does not measure actual bank when the motion violates those assumptions.

An estimated average acceleration from velocity endpoints can be converted to an estimated average specific-force vector by subtracting gravity. The norm of that vector is not the peak force and is not generally the time-average force magnitude. By the triangle inequality, norm(average f)<=average(norm(f)). This distinction limits what sparse observations can establish about load.

Finally, fitting a drag parameter to a descent time is an inverse problem. One fitted effective parameter under a point-mass model need not identify attitude, control state, or a unique physical cause. The reusable result is a discipline for carrying units, synchronization, model assumptions and non-identifiability through a reconstruction. A detailed rendered trajectory remains a visualization of that model until additional observations identify its hidden variables.

## Z6. Directional observations and the missing uniformity in limits

The recovered Math and Limits note offers another instance of incomplete observation coverage. A function of two variables can approach the same value along every fixed straight ray and still fail to have a multivariate limit. Define f(x,y)=x^2*y/(x^4+y^2) away from the origin. Along (x,y)=(a*t,b*t), a fixed direction with b!=0 gives f=a^2*b*t/(a^4*t^2+b^2), which tends to zero. If b=0 the value is identically zero. Yet along the curved path (x,y)=(t,t^2), the value is exactly 1/2 for every nonzero t.

The correct full directional contract requires uniformity: for every epsilon>0 there is one delta>0 such that abs(f(t*v)-L)<epsilon for every unit direction v and every 0<t<delta in the domain. One delta must work across directions. Every nonzero point near the origin can be written t*v with t its norm and v a unit vector, so this uniform directional statement is precisely the ordinary multivariate limit criterion. Separate deltas chosen after each fixed direction do not supply it.

This example repairs the proposed scale/direction bookkeeping without discarding its useful coordinate view. Directions organize observations; uniform control or another complete neighborhood bound provides the missing coverage. A finite set of rays, and even every fixed ray checked separately, can miss a curved approach whose direction changes with scale.

## Z7. A research idea becomes testable through its first uncertain arrow

An open idea should be stated as a specific implication. For example, the assertion that a score identifies the smallest factor has two distinct uncertainties: whether a high score implies divisibility, and whether search order implies optimality. A counterexample to either implication blocks that version of the claim. It may leave a useful ranking heuristic and exact final verifier intact.

A claim that two projections reconstruct an object requires injectivity of their combined observation map, or a declared anchor that reduces each fiber to one admissible point. Testing a few objects can reveal a collision but cannot prove the absence of every collision in an infinite domain. A finite domain can be exhaustively tested, provided the enumerator itself covers that domain and no filter silently excludes the hard cases.

A claim that a local update converges requires a contraction, a descent-and-compactness argument, a bracket invariant, or another precise mechanism. Smaller residual on a few steps is evidence about that trace. A claim that a spiral diagram is a strange attractor additionally requires a dynamical system, an invariant attracting set, and a defensible account of nontrivial dynamics. A ninety-degree rotation of a contracting spiral is a valid geometric transformation and does not supply those additional properties.

These formulations allow speculation to remain productive. An idea can be retained as a model with a stated question, a proposal with a final check, or a theorem after a proof. The correction register preserves what changed and why. A false universal claim need not force the deletion of its useful restricted case.

## Z8. Building on the collection

A useful extension begins by choosing one original problem and one success condition. The next step is to state the computable observations and the missing information in their fibers. An adapter then records its preconditions and proposes a reconstruction or a safe refinement. Small exact examples expose boundary errors. Independent invariants or alternative implementations check the load-bearing calculation. A final write-up records the result and the first unresolved implication.

For a three-variable showcase, a practical extension sequence is guarded rational-polynomial parsing, exact linear families, bounded integer systems, isolated algebraic solutions, certified real boxes, and then carefully declared transcendental or exponent domains. Fractions, variable powers, and nonisolated families change the required adapter. Adding a button does not establish those mathematical interfaces. Adding an interface with explicit certificates does create a dependable extension point.

For a pattern finder, a practical sequence is a transparent finite-state representation, collision-checked hashes, a held-out chronological validation set, and a dependence-aware significance procedure. For a geometric model, it is a realizable metric, oriented incidence, a verified operator, and a bounded simulation contract. For a modular lab, it is exact arithmetic and reconstruction before adding performance optimizations. These are concrete ways to turn the collection into further work.

Exercise Z-E1. A worker repeats x == 2 (mod 3) ten times and reports tenfold information gain. What changes in the exact candidate set? Answer: nothing after the first accepted intersection; the repeated constraint is idempotent.

Exercise Z-E2. A routine returns x=1 for x^3-x=0 in [-2,2]. What is established? Answer: a sound witness. The roots -1 and 0 remain, so completeness and uniqueness are not established by that return value.

Exercise Z-E3. A phase calculation for N=10403 reports a near-zero angle at k=100. Can k be accepted? Answer: no; the exact remainder is 3. The valid nearby pair 101,103 must be verified through exact divisibility or the square-gap identity.

Exercise Z-E4. A real optimizer reaches zero residual for a homogeneous equation in positive real variables. Has an integer solution been found? Answer: only if the coordinates can additionally be reconstructed as admissible integers and verified exactly. A real zero alone has no such implication.

Exercise Z-E5. A mesh satisfies d1*d0=0. Does that establish a valid Euclidean metric? Answer: no. Incidence can be consistent while its assigned distances have an indefinite Gram matrix. The metric and topological contracts are separate.

The useful outcome is a collection of methods with visible interfaces. Arithmetic, numerical analysis, geometry, statistics, and logic can cooperate because their conclusions are declared precisely. The collection remains extendable without relying on an unproved universal solver to make its examples worthwhile.
