# Arithmetic coordinates: residues, bounds, and cyclic exponents

## A1. A number can have several exact addresses

A large integer can be described by its remainder after division by three, its remainder after division by five, its parity, and its position in a bounded interval. Each description answers a different question. The central arithmetic idea in Stefan's work is to collect these partial addresses, keep their meanings attached, and reconstruct the original number when enough genuine constraints have accumulated. This is useful in puzzle solving, exact computation, error checking, and analysis of algorithms. It also explains why a promising pattern sometimes stops short of an answer: several numbers can share every address collected so far.

An integer equality and a congruence must have different notation. The statement x=14 identifies an integer. The statement x==14 (mod 15) identifies every integer 14+15t, with t an integer. A congruence therefore has a fiber: all original objects mapped to the same residue. Keeping that fiber makes modular reasoning exact rather than merely suggestive.

Let D be the original domain, S its actual solution set, and C a candidate enclosure containing S. An observation map O sends candidates to a simpler space. If every solution has O(x) in an allowed set A, a sound update is

```text
C_new = {x in C : O(x) in A}.
S subset C_new subset C.
```

This is a necessary-condition filter. It becomes a complete solver when all surviving candidates are checked by the original verifier V and the search covers the declared domain. A residue filter can remove impossibilities even when it does not recover a value. Conversely, one passing value establishes existence without necessarily establishing that all answers have been found.

The earlier word "carrier" is standardized here as a domain or coordinate space. Integers modulo M form a ring; their additive structure is a cyclic group; only the invertible residues form the multiplicative unit group. Divisors of a fixed positive integer form a finite candidate set. A subgroup or its coset supplies a membership predicate. These objects fit one constraint architecture, but their operations remain distinct. Division in a group is available; division by every nonzero residue in a ring is not.

## A2. Cancellation with a noninvertible coefficient

Claim A-P1 [PROVED]. For integers a,b and a positive modulus M, put d=gcd(a,M). The complete solutions of a*x==b (mod M) exist exactly when d divides b. When compatible, they form one residue class modulo M/d.

The proof begins with an ordinary integer equation a*x-b=M*t. Its left coefficient and right modulus are divisible by d, so d must divide b. Divide the whole equality by d. Now a/d and M/d are coprime, so a/d has an inverse modulo M/d. The result is

```text
x == (b/d)*inverse(a/d, M/d) (mod M/d).
```

When M/d=1, every integer is allowed and no inverse is needed. This derivation proves completeness because reversing the division recovers the original equality with an integer t. There are exactly d solutions modulo M: the one residue modulo M/d has d different lifts to the original modulus.

Example A-E1. Solve 6x==8 (mod 14). The gcd is two. Dividing gives 3x==4 (mod 7); the inverse of three is five, so x==20==6 (mod 7). The original modulus has the two solutions 6 and 13. Direct checking gives 36==8 and 78==8 modulo 14. The nearby problem 6x==9 (mod 14) has no solution because two does not divide nine. These calculations expose exactly where an ordinary algebraic cancellation would fail.

The same rule explains equality after multiplication: a*x==a*y (mod M) implies only x==y (mod M/gcd(a,M)). Cancellation at the original modulus is justified precisely when the coefficient is a unit. This is important for modular matrices, collision equations, and derivative-based lifting; a coefficient can be nonzero and still lack an inverse.

## A3. Chinese remainders as exact intersection

Claim A-P2 [PROVED]. The two conditions x==a (mod M) and x==b (mod R) are compatible exactly when gcd(M,R) divides b-a. Their complete intersection, when nonempty, is one class modulo lcm(M,R).

Write x=a+M*t and put d=gcd(M,R). The second condition becomes M*t==b-a (mod R). Applying A-P1 gives

```text
u = ((b-a)/d)*inverse(M/d, R/d) mod (R/d),
x == a+M*u (mod M*(R/d)).
```

If R/d=1, take u=0. The displayed modulus is the least common multiple. For an independent check of its period, subtract two simultaneous solutions. Their difference is divisible by both M and R, hence by lcm(M,R). Adding that least common multiple preserves both premises. The construction supplies one solution; the difference argument proves that no further classes are missing.

Example A-E2. Suppose x==5 (mod 12), x==11 (mod 18), and 0<=x<=100. The gcd is six. Substitution gives 2t==1 (mod 3), so t==2. Therefore x==29 (mod 36). The bounded candidates are 29 and 65. Replacing the second residue by ten makes the pair incompatible because six does not divide 10-5. Multiplying 12 and 18 would produce 216 and erase valid possibilities: the overlapping divisibility information counts once.

For a class x==r (mod M) in [L,U], the complete integer list is

```text
x = r+M*t,
ceil((L-r)/M) <= t <= floor((U-r)/M).
```

This is exact for negative endpoints as well. With a positive denominator, ceil(n/M)=-floor(-n/M). Integer quotient operations avoid rounding errors at enormous boundaries. A class contains at most one integer when M>U-L. That inequality gives uniqueness within each fiber; several different fibers can still contain several answers.

CRT does not manufacture information across independent factors. If gcd(M,R)=1, every pair of residues occurs once modulo MR. Fixing the M-address leaves every R-address possible. Bounds or additional equations can couple the addresses, but that coupling comes from the extra constraint. The useful accounting quantity for a uniform finite candidate set is its size before and after an actual intersection.

## A4. Rational reconstruction uses a height bound

Residues can also represent fractions, provided their denominators are invertible. Claim A-P3 [PROVED]. Fix M>=2, numerator bound A>=0, and denominator bound B>=1. Among reduced fractions u/v with v>0, |u|<=A, v<=B, gcd(v,M)=1, and u==r*v (mod M), there is at most one if 2AB<M.

For two admissible fractions, the congruences make u*v'-u'*v divisible by M. Its magnitude is at most |u|v'+|u'|v<=2AB<M. The only possible multiple is zero. The fractions are equal, and reduction with positive denominator makes their pairs identical. Existence is a separate matter: the bounds can contain no fraction with the required residue.

Example A-E3. Modulo 101, residue 41 represents 3/5 because 41*5=205==3. With A=3 and B=5, 2AB=30<101 proves uniqueness. A direct finite generator can try denominators one through five and numerators -3 through three; a continued-fraction or lattice method can propose the same fraction faster for larger bounds. Acceptance needs only the gcd checks, the bounds, and the original congruence. The proof explains why recovering rational coefficients from modular computations requires a supplied height restriction.

These pairs form the integer lattice {(u,v):u-rv is divisible by M}, generated by (M,0) and (r,1). The determinant M measures its area per lattice point. Two independent bounded vectors would have determinant a nonzero multiple of M, while the height box forces magnitude below M. This geometric formulation expresses the same separation fact without treating a drawing as another observation.

## A5. The exponent modulus is the group order

Suppose g generates a cyclic group of exact order N and h belongs to that group. The original equation is h=g^x, with x naturally in Z/NZ. Claim A-P4 [PROVED]: g^u=g^v exactly when N divides u-v. Indeed, divide u-v by N; a nonzero remainder below N cannot produce the identity by exactness of the order.

The order of g^k is N/gcd(N,k). Write N=dN_0 and k=dk_0 with coprime N_0,k_0. The equation (g^k)^t=1 is equivalent to N_0 dividing k_0t, hence to N_0 dividing t. The least positive return time is N_0. Thus for m dividing N, the projection base g^(N/m) has exact order m and

```text
h^(N/m) = (g^(N/m))^r
    iff x == r (mod m).
```

This gives a short certificate for an exponent address. It requires no known full logarithm. It does require an exact order and a valid divisor. A proposed order N can be certified from its complete prime factorization by checking g^N=1 and g^(N/p)!=1 for every distinct prime p dividing N. The first check makes the actual order divide N; any proper divisor divides N/p for some such p, contradicting the corresponding check.

Membership is separate. In C_2 times C_2, g=(1,0) and h=(0,1) both square to the identity, but h is outside the two-element subgroup generated by g. Checking h^N=1 is therefore insufficient in an arbitrary ambient group. A constructed target, a valid subgroup test, or final equality with an actual power supplies the needed membership evidence.

A group element, its scalar exponent, and its serialized encoding must remain distinguishable. Multiplicative residues modulo a prime p use p for their field arithmetic and N for exponent arithmetic. Elliptic-curve points obey the same cyclic scalar reasoning, with scalar multiplication replacing powers. Their coordinate modulus can differ from the point order. A compressed point recovers the point when decoded; it does not recover its unknown scalar.

## A6. Known addresses create a residual problem

If m divides N and x==r (mod m) has been established, write x=r+m*t. The surviving scalar classes correspond bijectively to t modulo N/m. Substitution gives

```text
b = g^m, y = h*g^(-r), y=b^t.
```

Two t values produce the same x modulo N exactly when their difference is divisible by N/m. No inverse of m is used, so this works even when m and N/m share a factor. In an order-eight group, known odd parity gives x=1+2t with t modulo four, correctly representing 1,3,5,7.

External integer information can instead use an arbitrary positive modulus M. With x==r (mod M) and L<=x<=U, the substitution remains exact, but the residual group order becomes N/gcd(N,M). The interval for t comes from A3. If t_0 solves the residual equation, all integer aliases are t_0+j*N/gcd(N,M). Their original x values differ by lcm(N,M).

Example A-E4. In a group generated by g of order 12, let h=g, x==5 (mod 8), and 20<=x<=80. Then x=5+8t, 2<=t<=9, b=g^8 has order three, and y=g^(-4)=g^8=b. Thus t==1 (mod 3). The admissible t values are four and seven, yielding x=37 and x=61. Both are valid. The residue eight shortened an integer search interval; it did not create a subgroup of order 12/8.

A complete interval search uses the baby-step/giant-step idea. For J consecutive exponents shorter than one residual period, choose T near sqrt(J). Write each index z=i+Tj, with 0<=i<T. Store b^i and compare them with w*b^(-Tj), where w is the target shifted by the lower interval endpoint. Every z has a quotient-and-remainder decomposition, so this comparison covers the whole interval, with a final check excluding indices beyond its upper boundary. It costs roughly T+ceil(J/T) group operations and T stored elements. Hash matches require exact element equality. Additional integer aliases are then listed from their proved period.

## A7. Extracting prime-power digits

The factorwise method is standard Pohlig-Hellman mathematics [A-R1,A-R2]. Its usefulness in this compilation is the explicit preservation of each digit and reconstruction rule. For p^e dividing N, put gamma=g^(N/p^e), eta=h^(N/p^e), and beta=gamma^(p^(e-1)). Write the unknown projected exponent as sum d_j*p^j, with 0<=d_j<p. If s_j contains the digits already recovered, the next digit satisfies

```text
(eta*gamma^(-s_j))^(p^(e-1-j)) = beta^d_j.
s_(j+1) = s_j+d_j*p^j.
```

Proof A-P5 [PROVED]. The exponent after subtraction is d_j*p^j plus a multiple of p^(j+1). Raising it to p^(e-1-j) sends the latter terms to multiples of p^e, where they vanish. The surviving term is beta^d_j. Since beta has order p, the p possible digits have distinct images. Induction recovers every digit; CRT then joins the maximal prime-power components.

Example A-E5. Solve 5^x==23 (mod 97). Order 96 is certified by 5^96=1, 5^48=96, and 5^32=35. Its factors are 32 and three. For the binary component, gamma=28, eta=42, and beta=96. The successive known partial exponents are 0,1,1,5,13,13; the corresponding digits are 1,0,1,1,0. Their projected tests are 96,1,96,96,1. Hence x==13 (mod 32).

For the order-three component, base 35 has powers 1,35,61, and projected target 23^32=61. Therefore x==2 (mod 3). Substituting x=13+32t gives 1+2t==2 (mod 3), so t==2 and x==77 (mod 96). Direct evaluation 5^77==23 closes the calculation in its original domain. The residual after the binary address is already the tiny equation 35^t=61.

Given N=product p_i^e_i and square-root prime-order solvers, the standard group-operation bound is O(sum e_i*(log N+sqrt(p_i))) [A-R2]. Factorization and representation costs are additional. A large prime factor can retain the difficult component. Learning an independent smooth-factor coordinate does not determine that prime coordinate; CRT gives every prime coordinate a compatible original scalar. The organization improves auditability and allows useful partial work to accumulate, while its speed still comes from accessible arithmetic structure.

## A8. Collisions retain coefficient meanings

A collision search in y=b^t stores a state R=b^u*y^v together with u,v and the exact residual domain. Equal states imply

```text
(v-v')*t == u'-u (mod ord(b)).
```

This follows by substituting y=b^t and comparing powers. A-P1 solves the congruence safely, including a nonunit coefficient that yields only a partial address. A coefficient difference and constant both zero supply no information. An inconsistent gcd condition signals that the purported collision or its metadata is wrong.

An address t==c (mod m), with m dividing the residual order, changes coordinates to t=c+m*s. The new base is b^m and target y*b^(-c). An old state can be transported by setting delta=(u+cv) mod m and replacing R by R*b^(-delta). Its new coefficients are (u+cv-delta)/m and v, reduced modulo the new order. Substitution proves the identity. This preserves its algebraic meaning; it does not prove that a changed random walk continues the old trajectory. Old results can instead be converted to original x coordinates and checked there.

Stefan's fixed-point language also needs an operational distinction. If all allowed sets A_i are already fixed, intersecting with them is idempotent: applying the identical intersection twice changes nothing. Repeated propagation becomes useful when a smaller candidate set permits recomputation of stronger justified local constraints, or when another observation arrives. The mathematical ratchet is the nested candidate enclosure, with every new exclusion carrying its reason.

Exercise A-X1. Merge x==1 (mod 6) and x==3 (mod 10), then restrict to [-20,20]. Answer: x==13 (mod 30), giving -17 and 13. Exercise A-X2. An element has order 45. Its ninth power has order five; a fifth-power projection, by contrast, has order nine. These are different addresses and should retain their different moduli.

# Local coefficient rings: precision layers and reversible components

## A9. Three finite objects that look similar

The field F_p, the ring Z/p^k Z, and the polynomial quotient F_p[T]/(F) are different coordinate spaces. In F_p every nonzero element is invertible. In Z/p^k Z with k>1, the nonzero residue p is nilpotent: its kth power is zero. A quotient by an irreducible polynomial is a field; a quotient by several coprime factors is a product; a repeated factor introduces nilpotents. Their similar finite sizes do not make their arithmetic interchangeable.

For an explicit coefficient ring, choose a monic polynomial F of degree f and set R_k=(Z/p^k Z)[T]/(F). Monic division gives a unique coefficient vector of length f with coefficients modulo p^k. This free coefficient representation is exactly the access needed by the digit solver below. If F modulo p is irreducible, the residue ring is the field F_(p^f), and the construction is an unramified Galois ring [A-R3]. Irreducibility supplies this field interpretation; the principal-unit digit argument itself needs only the commutative monic coefficient algebra.

The concrete project ring is R_k=(Z/3^k Z)[alpha]/(alpha^2+1). Its multiplication is

```text
(a+b*alpha)(c+d*alpha) = (ac-bd)+(ad+bc)*alpha.
```

A unit has inverse (a-b*alpha)/(a^2+b^2). Modulo three, the denominator vanishes exactly when both a and b vanish, since each nonzero square is one. Thus units are precisely coefficient pairs not both divisible by three. This criterion depends on the chosen prime: modulo two, T^2+1=(T+1)^2, so the same display gives a different ring.

Division by a known p^j in a coefficient vector reduces precision. If z is known modulo p^k and is divisible by p^j, z/p^j is known only modulo p^(k-j). Changing the original representative by p^k changes the quotient by p^(k-j), proving the precise residual uncertainty. This is a recurring rule for valuations, derivative normalization, and finite logarithms.

## A10. Principal units expose an additive layer

A principal unit is an element of the form 1+p*c. It is invertible because p*c is nilpotent at finite precision; the finite geometric sum gives the inverse. Put U_j=1+p^jR_k. For j>=1,

```text
(1+p^j*a)(1+p^j*b) == 1+p^j*(a+b) (mod p^(j+1)).
```

The quadratic term contains p^(2j), which is divisible by p^(j+1). Therefore U_j/U_(j+1) has additive coefficient coordinates over F_p. Multiplication becomes addition in one layer even though the full elements remain multiplicative objects.

For odd p, binomial expansion also gives

```text
(1+p^j*c)^p == 1+p^(j+1)*c (mod p^(j+2)).
```

The intermediate binomial coefficients contain p, while the last term has valuation pj>=j+2. Repetition yields (1+p*c)^(p^r)==1+p^(r+1)*c modulo p^(r+2). Thus every principal unit is killed by p^(k-1). These identities identify both an exponent domain and a publicly extractable next digit.

The odd-prime restriction matters. Modulo eight, 3^2=1, whereas transferring the displayed leading-term formula would predict 1+4=5. Binary principal units require a different branch, addressed below. A proof attached to one prime regime cannot be licensed by similarity of notation.

## A11. Coupled exponent recovery from a fixed tangent matrix

At precision k>=2, consider s equations with n unknown exponent coordinates:

```text
h_i = product_j g_ij^(x_j), g_ij=1+p*c_ij,
x_j modulo P=p^(k-1), p odd.
```

Each equation contributes f residue coefficients. Stack the coefficient vectors of c_ij modulo p into an fs-by-n matrix A. This is called the first-layer matrix; the earlier "tangent" terminology refers to the same leading coefficient calculation. At k=1, principal units and the exponent domain modulo p^0=1 are both trivial, so their unique map is bijective independently of A; that case needs no digit recovery.

Claim A-P6 [PROVED]. If n=fs and A is invertible over F_p, the exponent map is a bijection from (Z/PZ)^n to U_1^s. Every target has exactly one exponent vector, recoverable one digit at a time.

Start with all exponents zero. Suppose x^(r) contains the first r digits and its products match the targets modulo p^(r+1). Form the residual

```text
w_i = h_i*product_j g_ij^(-x_j^(r)).
b_r = stacked coefficients of (w_i-1)/p^(r+1) modulo p.
```

The divisibility follows from the maintained precision. A next exponent correction p^r*d produces, by A10, exactly the additive layer A*d. Therefore the next digits solve A*d=b_r over F_p. Invertibility gives one digit vector. Update x^(r+1)=x^(r)+p^r*d. After k-1 rounds every original product agrees modulo p^k, and every digit was forced.

Necessity is equally explicit. If A has a nonzero kernel vector v, then the nonzero exponent difference p^(k-2)*v maps to identity: its final output layer is A*v=0. A singular first layer cannot yield a bijection on the stated full exponent domain. For rectangular matrices, full column rank establishes injectivity on the image, while full row rank establishes surjectivity with remaining exponent freedom. A deficient rank requires all compatible branches, not an arbitrary free-digit choice.

Example A-E6. Work modulo 81 with g_1=4, g_2=1+3alpha, and target h=25+66alpha. The first-layer matrix is the two-by-two identity. From (h-1)/3=(8,22), reduction modulo three gives digits (2,1). Removing g_1^2*g_2 leaves 10+45alpha. Dividing its difference from one by nine gives (1,5), whose next digits are (1,2). Hence x=(2,1)+3*(1,2)=(5,7). The new residual is one, so the last digits are zero. Direct multiplication verifies 4^5*(1+3alpha)^7=25+66alpha modulo 81.

A singular comparison replaces the second base by 1+9alpha modulo 27. Its first-layer coefficient column vanishes, and increasing its exponent by three changes no power. Targets whose alpha coefficient is divisible by three but not nine cannot lie in its image. The same machinery then produces either a complete family or an inconsistency certificate, rather than a unique reconstruction.

## A12. Finite logarithmic coordinates

There is another way to expose the additive principal-unit structure. For odd p, the convergent p-adic logarithm and exponential are inverse group maps between 1+pO and pO in the associated complete coefficient algebra; in a p-adic field these domains are standard [A-R7]:

```text
log(1+z) = z-z^2/2+z^3/3-...,
exp(w) = 1+w+w^2/2!+... .
```

The logarithm terms tend to zero because their valuations are at least j*v_p(z)-v_p(j). The exponential terms do so on this domain because v_p(j!)<=j/(p-1), with strict positive linear growth for odd p and v_p(w)>=1. Formal differentiation gives derivative one and constant zero for log(exp(w)); the series have invertible linear coefficient, so the inverse-composition identity follows. The corresponding two-variable formal calculation gives log(uv)=log(u)+log(v) for commuting inputs. Convergence licenses substitution into these identities, proving the asserted coordinate map rather than a resemblance to an ordinary real logarithm.

At finite precision the divided coordinate lambda(u)=log(u)/p lives modulo p^(k-1). Computing log at precision p^k is essential before division. If two input lifts agree modulo p^k, their ratio is 1 modulo p^k; its logarithm is divisible by p^k, so their lambda coordinates agree modulo p^(k-1). That proves independence of the chosen lift.

An exact finite evaluation avoids division by nonunits. Write u=1+p*c and j=p^v*j_0 with j_0 coprime to p. Then the jth term of lambda is

```text
(-1)^(j+1)*p^(j-1-v)*c^j*inverse(j_0,p^(k-1)).
```

For odd p, retaining j=1 through 2k-1 is a safe cutoff: for j>=2k, v_p(j)<=j/2 and j-1-v_p(j)>=k-1. Every omitted term vanishes at the required modulus. The first vanished term alone is not a valid stopping criterion because valuations of denominators jump at powers of p.

Example A-E7. In the previous ring, finite logarithms give lambda(4)=(16,0), lambda(1+3alpha)=(15,25), and lambda(h)=(23,13), all modulo 27. The original products therefore become

```text
16x+15y == 23 (mod 27),
      25y == 13 (mod 27).
```

The solution (5,7) satisfies both. The determinant 400 is a unit modulo 27. This is a second computational route through the same ring, using an additive coordinate isomorphism rather than successive multiplicative residuals. The finite verification package checks both routes independently against direct products.

A full unit may have a torsion coordinate outside the logarithm domain. In Z_3, each unit is uniquely (-1)^epsilon*v, where v==1 (mod 3). The logarithm records v and loses the sign unless epsilon is retained. Likewise, at p=2, the inverse logarithm/exponential chart uses 1+4O and 4O. Applying a logarithm to the larger binary unit group without retaining its extra first-layer or torsion information loses possible answers.

## A12a. The complete doubling clock, including nonunits

The familiar six-cycle is an exact part of a larger arithmetic system. Example A-E12. Doubling modulo nine gives the three disjoint cycles

```text
0 -> 0;
3 -> 6 -> 3;
1 -> 2 -> 4 -> 8 -> 7 -> 5 -> 1.
```

The units form the six-cycle. The additive ideal {0,3,6} is its invariant inner subsystem, rather than a pointwise fixed spine. The principal-unit subgroup {1,4,7} is a different object: its multiplicative coset {2,8,5} is exchanged with it by doubling. Applying doubling twice rotates inside those two triangles; it is multiplication by four, not the squaring map on residues. Zero and nine represent the same residue, so counting both invents an additional state.

Claim A-P11 [PROVED]. For positive n, v_3(2^n-1)=0 when n is odd, and 1+v_3(n) when n is even. Odd powers of two are minus one modulo three. For n=2m, start from four=1+3. Cubing 1+3^j*c with c not divisible by three produces a leading term 3^(j+1)*c in its difference from one; the remaining terms have strictly larger valuation. Each cubing therefore raises the valuation by one. Raising to a positive exponent coprime to three preserves the leading valuation by the same binomial argument. Writing m=3^r*u proves the formula.

Consequently two has order 2*3^(k-1) modulo 3^k, equal to the number of units, so it generates them all. A nonzero residue has a unique truncated valuation j<k and is represented by 3^j*u with u a unit modulo 3^(k-j). Its doubling period is 2*3^(k-j-1): cancelling 3^j in the return equation reduces to exactly that unit problem. The layer has the same number of residues, hence is one complete cycle. Together with fixed zero, the full graph has lengths 1,2,6,...,2*3^(k-1). Their sum is 3^k. Modulo 27, the lengths are 1,2,6,18, and the multiples of three reproduce the entire modulus-nine system.

This gives coordinates for every residue, not merely the outer units: zero has its own tag; a nonzero residue has valuation j and a base-two exponent modulo 2*3^(k-j-1). Multiplication adds valuations and adds exponent addresses at the final reduced precision, or gives zero when the valuation reaches k. Addition has no general exponent-addition rule because leading terms can cancel. The coordinates are a stratification of a multiplicative monoid, not a declaration that nonunits are groups.

The unit exponent can itself be recovered without traversing its long cycle. Maintain an address n_r modulo M_r=2*3^(r-1) with 2^n_r==u (mod 3^r). The strengthened induction 2^M_r==1+3^r (mod 3^(r+1)) shows that its three next lifts have addresses n_r+a*M_r for a=0,1,2. Compute q=u*inverse(2^n_r,3^(r+1)); its next digit a=(q-1)/3^r selects the unique lift. For u=158 modulo 729, the successive addresses are 1,5,11,29,137,137. Directly 2^137==158 modulo 729. Every step uses public residue arithmetic.

At infinite 3-adic precision, the two unit coordinates are a sign and a principal logarithm. Put ell=log(-2), with v_3(ell)=1. The map u=(-1)^epsilon*v -> (epsilon,log(v)/ell) identifies Z_3 units with C_2 times Z_3. Multiplication by two adds (1,1). The inverse is (-1)^epsilon*exp(t*ell), and exp(ell)=-2; retaining the sign returns two correctly. Division by ell cancels one factor of three before inverting its unit part. It is not inversion of three modulo 3^k.

Finite cycles do not imply nonzero periodic points in Z_3 itself. An equality 2^n*u=u would make (2^n-1)u=0 in a characteristic-zero integral domain, hence u=0. The finite quotients return, while successively refined residues trace an infinite compatible path. This distinction makes the clock useful for finite-state representations and precision algorithms without claiming a new physical oscillator or hidden source of randomness.

## A13. Singular matrices need families

Once principal units are converted into coefficient coordinates, the equations are C*x==b (mod P). Claim A-P7 [PROVED with standard Smith-form existence]. Let an integer Smith decomposition be D=U*C*W, where U and W are unimodular. Put x=W*z and b'=U*b. Integer unimodularity means determinant +1 or -1; these coordinate changes remain invertible at every modulus [A-R4].

For each nonzero diagonal d_i, put delta_i=gcd(d_i,P). Compatibility requires delta_i dividing b'_i. Every remaining zero row requires b'_i==0 (mod P). The constrained coordinate then has one residue modulo P/delta_i and delta_i lifts modulo P. Columns beyond the nonzero diagonal are free. If r diagonals are nonzero and n columns occur, a compatible system has exactly

```text
P^(n-r)*product_(i=1..r) delta_i
```

solutions modulo P. This follows by applying A-P1 separately to every diagonal and multiplying the independent counts. The existence theorem for Smith form supplies the coordinate change; the arithmetic here supplies its exact solution meaning.

Example A-E8. Solve x+y==16 and x+4y==13 modulo 18. Subtracting gives 3y==15, hence y==5 (mod 6). Its lifts are 5,11,17. Recovering x gives the three pairs (11,5), (5,11), and (17,17). Rational full rank does not imply a modular inverse: the determinant three shares a factor with 18.

For bounded integer unknowns, the complete modular family must be lifted to an affine integer lattice. Bounds on x become inequalities in W*z, generally coupling the transformed coordinates. Copying independent x bounds directly onto z changes the problem. A compact basis for the homogeneous kernel can describe many solutions without listing all of them; producing the complete explicit list necessarily costs at least its output size.

At p=2, a complete alternative retains parity branches. Write x_j=epsilon_j+2z_j, solve every compatible first-layer equation for epsilon over F_2, and remove its contribution. Squared bases and corrected targets then lie in 1+4R_k, where the divided logarithm works. Solve their complete modular families and recombine x=epsilon+2z. The branch union covers every original exponent because each has a unique parity decomposition. This is exact, though its number of branches can grow exponentially.

## A14. Polynomial CRT and the Mathcrack component construction

Stefan's Mathcrack material proposes another reusable organization: separate a finite algebra into components, invert a map locally, and recombine. Let F=product f_i^e_i over F_p, with distinct monic irreducibles f_i. The powers q_i=f_i^e_i are pairwise coprime. Polynomial Bezout supplies u_i*(F/q_i)==1 (mod q_i). Define epsilon_i=u_i*(F/q_i) modulo F.

Claim A-P8 [PROVED]. Reduction and reconstruction give inverse maps

```text
F_p[T]/(F) <-> product_i F_p[T]/(q_i),
z <-> (z mod q_i)_i,
z = sum_i epsilon_i*lift(z_i).
```

In component i, epsilon_i is one; in every other component it is zero. Thus epsilon_i^2=epsilon_i, epsilon_i*epsilon_j=0 for distinct indices, and sum epsilon_i=1. Agreement in every component means divisibility by every coprime q_i, hence by F, proving global equality. The reconstruction formula also proves independence of local representatives.

When every e_i is one, all components are fields. A repeated factor instead gives a local ring with nilpotents. For degree d and exponent e its size is p^(de), while its units number p^(d(e-1))*(p^d-1): the nonunits are exactly residues divisible by f. This count does not assert that its unit group is cyclic.

Example A-E9. Over F_2, take f_1=T^3+T+1 and f_2=T^4+T+1. The cubic has no root in F_2; the quartic has no linear root and is not divisible by the sole irreducible quadratic T^2+T+1, whose reduction gives remainder one. Both are therefore irreducible. Their product is F=T^7+T^5+T^3+T^2+1. The algebra has 128 elements and identifies with F_8 times F_16.

Its projectors are epsilon_1=T^5+T^2+T and epsilon_2=epsilon_1+1. Reducing them gives component pairs (1,0) and (0,1). Define E(z)=epsilon_1*z^3+epsilon_2*z^7. Componentwise this is (a,b)->(a^3,b^7). Since 3*5==1 (mod 7) and 7*13==1 (mod 15), its inverse is D(z)=epsilon_1*z^5+epsilon_2*z^13. Nonzero components follow their multiplicative orders; zero must be checked separately and is fixed by these positive powers. Hence D(E(z))=z on all 128 elements, including zero divisors.

The component construction also permits E_i(a)=c_i*a^k_i+b_i with c_i nonzero, k_i a positive integer, and gcd(k_i,p^d_i-1)=1. Subtracting b_i, multiplying by c_i^(-1), and raising to a positive inverse exponent gives the local inverse. An invertible linear change T produces the conjugate map T^(-1)*E*T and the matching inverse T^(-1)*D*T as functions. An arbitrary linear T need not preserve multiplication; describing it as a ring automorphism would be an extra claim.

This supplies a finite reversible-map laboratory, not a demonstrated secure trapdoor. Factorization, projectors, and local inverses are visible in this presentation. Hiding a coordinate choice does not by itself establish that public inversion is difficult. The valuable mathematical content is the checked decomposition, the exact local inversion criterion, and the explicit conditions under which information collapses.

## A15. Element orders, map cycles, and quotient fibers

Under repeated powering by k in a cyclic group of order N, exponent r evolves by r->kr modulo N. When k is a unit modulo N, its orbit length is ord_(N/gcd(N,r))(k), because return means N divides (k^t-1)r. This is different from the order N/gcd(N,r) of the represented group element. In A-E9 the exponent map r->3r modulo seven has a six-cycle 1,3,2,6,4,5. Six does not divide seven or the product unit-group exponent 105. Comparing such map periods only with divisors of 105 would reject a correct construction.

The cyclotomic identity X^n-1=product_(d|n) Phi_d(X) remains a polynomial identity after reduction. Its zero-set interpretation needs a field and characteristic coprime to n for primitive-order classification. In a ring with zero divisors, a product can vanish while no factor vanishes: modulo 15, 4^2-1=0 but 4-1=3 and 4+1=5 are both nonzero. A square image {x^2} is also different from the root-of-unity kernel {x:x^2=1}. These sets answer different questions and cannot be merged into one "power carrier."

Frobenius on a field component is a->a^p; its orbit period divides the field degree. On a square-free product, the fixed algebra has one F_p coordinate per irreducible factor. In a mixed-characteristic coefficient ring, however, raw pth powering is generally not the lifted Frobenius automorphism. On Z/9Z that automorphism is the identity, while 2^3=8 differs from two. Precision, characteristic, and retained coefficient operations determine the relevant map.

Normal-series reconstruction is useful when its inverse conditions are stated on every fiber. Suppose a map respects a quotient, its induced quotient map is invertible, and every resulting conditional coset map has an inverse. Invert the quotient, identify the relevant input coset, and invert its conditional fiber. Recursion through a finite series then yields an exact inverse. A quotient inverse and an inverse on just the preferred subgroup are insufficient: on Z/4Z, the map 0->0, 2->2, 1->1, 3->1 is bijective on the even subgroup and on the parity quotient, yet collapses the odd coset.

Example A-E10. The order-21 semidirect product uses pairs (a,b) modulo seven and three, with multiplication (a,b)(c,d)=(a+2^b*c,b+d). Associativity follows by expanding both orders to first coordinate a+2^b*c+2^(b+d)*e. Its inverse is (-2^(-b)*a,-b). To solve (3,1)*(c,d)=(5,0), first obtain d=2 modulo three, then 2c=2 modulo seven, hence c=1. Checking (3,1)*(1,2)=(5,0) verifies the quotient-first computation.

Elements with b=0 have order one or seven; elements with b nonzero have order three because 1+2^b+2^(2b)=0 modulo seven. None has order 21. In any finite odd-order group, however, squaring is reversible by x->x^((N+1)/2), since element orders divide N. This single-element root extraction can work in a nonabelian group without making the power map a homomorphism. It also supplies no arbitrary discrete logarithm. Quotient layers explain a decomposition; tractable layer equations supply an algorithm.

Exercise A-X3. In the modulus-18 system x+y==16, x+4y==13, impose 0<=x,y<=12. Answer: only (11,5) and (5,11) survive. Exercise A-X4. In F_8 times F_16, seventh powering on the unit group has kernel size seven: the first component collapses while the second remains invertible. A complete inverse must retain those seven alternatives.

# Bounded observations: exact lattices and verified recovery

## A16. Information before geometry

A hidden-number problem supplies several approximate modular observations of one shared scalar. It does not arise merely by drawing a discrete-log equation in a plane. The model must state known multipliers t_i, targets a_i, and justified error bounds B_i. For an odd modulus q, let H=(q-1)/2 and choose the centered residue

```text
ctr_q(u) = ((u+H) mod q)-H.
```

For a canonical scalar 0<=x<q, the observation condition is |ctr_q(t_i*x-a_i)|<=B_i. An additional verifier V may test a public group equation. Its presence can certify one recovered scalar without creating the bounds. The historical hidden-number terminology comes from Boneh and Venkatesan [A-R5]; the particular lattice equivalence below is proved directly.

Assume integer t_i,a_i and 0<=B_i<q/2. Noninteger bounds may be replaced by their integer floors because the centered errors are integers. Rational observation centers require a different scaling: discarding their denominators changes the model. The strict bound below half a period means a feasible residue has exactly one allowed integer error representative.

Two feasible scalars x,x' have difference Delta satisfying |ctr_q(t_i*Delta)|<=2*floor(B_i) in every coordinate. Therefore, if every nonzero Delta has some coordinate exceeding that limit, no target can admit two scalars. This is a uniform separation certificate. One particular target can be unique even when this stronger universal property fails. An expected information count or a large determinant can guide experiments but cannot substitute for this precise separation question.

## A17. A lattice whose last coordinate is the scalar

Use row vectors and m observations. Define an (m+1)-dimensional integer lattice by the rows

```text
B0 = (q^2*I_m, 0;
      q*t_1,...,q*t_m, 1).
Target = (q*a_1,...,q*a_m,0).
```

The semicolon separates the m diagonal rows from the last row. An integer combination with coefficients (z_1,...,z_m,beta) is

```text
v = (q*(q*z_1+t_1*beta),...,q*(q*z_m+t_m*beta),beta).
```

The determinant is q^(2m). Define the target box by |v_i-q*a_i|<=q*B_i and |v_last|<=H. Claim A-P9 [PROVED]. Lattice points in this box correspond bijectively to feasible canonical scalars, with x=v_last mod q.

For a feasible x, take its unique centered representative beta. Choose the unique bounded error e_i with t_i*beta+e_i==a_i (mod q), and set z_i=(a_i-e_i-t_i*beta)/q. The quotient is integral. The resulting point has target displacement (-q*e_1,...,-q*e_m,beta), so it lies in the box. Conversely, a boxed lattice point has v_i divisible by q. Setting e_i=a_i-v_i/q recovers all modular observation equations and their bounds. The centered beta is unique, as are the errors since their allowable intervals have width below q. That proves both directions and uniqueness of the witness point.

The last coordinate retains scalar aliases even if all multipliers vanish. This is a reason for using the augmented formulation: it avoids accidentally identifying several hidden scalars with one unaugmented observation vector. The containing sphere has squared radius q^2*sum B_i^2+H^2. The box lies inside that sphere, but sphere membership alone is insufficient; its coordinate inequalities remain the acceptance test.

## A18. Basis changes preserve the lattice

Let R=U*B0 where U is an integer unimodular matrix. Then R and B0 have exactly the same integer span, because U and U^(-1) both have integer entries. An integer coefficient row c in the reduced basis represents cR=(cU)B0. The original scalar coordinate is recovered from the actual lattice point, or equivalently from the last coordinate of cU. It is generally not the last coefficient of c.

Equal determinants alone do not certify equal lattices. In two dimensions, the lattices generated by (2,0),(0,1) and by (1,0),(0,2) have equal area but contain different points. The integer change-of-basis identity is the useful evidence. Reduction improves the search coordinates; it does not add observations or remove feasible original scalars.

Gram-Schmidt provides rational orthogonal measurement directions b_j^*, squared lengths D_j, and coefficients mu_(i,j). It need not produce lattice points. For a target T and integer coefficients z,

```text
||zR-T||^2 = sum_j D_j*(z_j+
             sum_(i>j) mu_(i,j)*z_i-y_j)^2,
y_j = dot(T,b_j^*)/D_j.
```

This identity follows by expanding the difference in the orthogonal directions. It supplies exact branch bounds and explains nearest-plane rounding. A nearest-plane pass chooses coefficients from the largest index downward, rounding the residual projection to a nearest integer. It always gives a lattice point. Its success as hidden-number recovery depends on that point also satisfying every original observation and V.

## A19. A complete worked observation recovery

Example A-E11. Let q=101, t=(1,10), a=(38,66), and both error bounds be one. The initial rows, reduced rows, and coordinate transformation are

```text
B0 = (10201,0,0; 0,10201,0; 101,1010,1).
R  = (0,0,101; 101,1010,1; 1010,-101,10).
U  = (-1,-10,101; 0,0,1; 0,-1,10).
T  = (3838,6666,0).
R=U*B0, det(U)=-1.
```

The orthogonal rows are (0,0,101), (101,1010,0), and (1010,-101,0), with squared lengths 10201,1030301,1030301. Rounding the successive residual coordinates 314/101, 698/101, and -37/101 gives coefficients c=(0,7,3). The lattice point is (3737,6767,37), while original coefficients cU are (0,-3,37).

The displacement from T is (-101,101,37), so the observation errors are (1,-1). Directly, 37+1=38 and 10*37-1=369==66 (mod 101). Its squared distance is 21771, below the containing radius squared 22902; each box coordinate also passes. The scalar is 37, not the last reduced coefficient three.

Uniqueness has an elementary independent proof. The first observation leaves x in {37,38,39}. Multiplying by ten modulo 101 gives {67,77,87}. Only 67 is within centered distance one of 66. Thus the feasible set is exactly {37}. The reduced basis itself includes the short vector (0,0,101), carrying scalar zero and no secret-bearing observation information. Recovery comes from a target-dependent combination and final checking.

This small example is a complete piece of operational mathematics: input data, coordinate map, inverse interpretation, numerical proposal, original verification, and uniqueness argument all fit. It also supplies a useful benchmark for implementations, because each matrix entry and each quotient can be checked with ordinary integer arithmetic.

## A20. Complete enumeration has exact endpoints

A single rounded proposal does not describe all feasible points. A complete lattice search traverses coefficients z from the largest index downward using the distance identity in A18. With the later coefficients fixed, let gamma be the remaining center and s the accumulated squared distance. The next coefficient must satisfy D*(z-gamma)^2<=R_sq-s. All terms are nonnegative, so excluding a branch above the radius cannot remove a boxed point.

Exact rational endpoints avoid a floating square root. Write gamma=P/Q with Q>0 and (R_sq-s)/D=C/E with E>0 and C>=0. Then set

```text
J = isqrt(floor(C*Q^2/E)),
ceil((P-J)/Q) <= z <= floor((P+J)/Q).
```

The quantity Qz-P is integral. Its square is at most C*Q^2/E precisely when its magnitude is at most J, proving the formula even on closed boundaries or at negative centers. Enumerate every integer in this interval, retain the original radius, and test the box and V at every leaf.

Claim A-P10 [PROVED]. This completed finite search returns exactly the observation-feasible scalars passing V. A-P9 gives every feasible scalar its boxed witness. Its partial squared-distance sums never exceed the enclosing radius, so its coefficient path is retained. Every accepted leaf reverses A-P9 and passes V. Finiteness follows because an invertible basis maps a bounded sphere to a bounded coefficient region containing finitely many integer tuples.

Shrinking the radius after finding one good answer changes the task to finding a nearer point; it can delete other observation-feasible scalars. Likewise, a search that examines only reduced basis rows is a candidate generator. It can produce a verified witness, while failure to produce one remains undecided unless another coverage certificate exists.

## A21. Signature equations provide an observation adapter

For ECDSA in a subgroup generated by G of prime order q, let d be the secret scalar and D=[d]G its public key. A valid signature has nonzero components r_i,s_i and correctly converted hash integer z_i. The signing equation is

```text
s_i*k_i == z_i+r_i*d (mod q).
```

SEC 1 specifies these arithmetic and hash-conversion conventions [A-R6]. Inverting s_i gives k_i==a_i*d+b_i, where a_i=r_i*s_i^(-1) and b_i=z_i*s_i^(-1). A independently justified interval for k_i then supplies bounded affine information about d. The signature equation alone does not supply that interval.

Low-s normalization is a concrete modeling issue. Replacing s_i by q-s_i replaces the effective nonce by q-k_i. A small-positive-nonce assumption can therefore turn into a near-q assumption. All signature conventions, signs, and observation origins belong in the model. A recovered d may correctly reproduce the public key while contradicting an assumed nonce bound; those two checks report different facts.

An embedding used in earlier project demonstrations has m diagonal rows with q^2 in the nonce coordinates, secret row (q*a_1,...,q*a_m,B,0), and offset row (q*b_1,...,q*b_m,0,Bq). If k_i=a_i*d_tilde+b_i-q*w_i, the coefficient vector (-w_1,...,-w_m,d_tilde,1) produces

```text
(q*k_1,...,q*k_m,B*d_tilde,Bq).
```

This is a correct exact membership identity. Centering d_tilde and bounding the nonces also prove a norm bound. They do not prove that the vector becomes an individual reduced basis row or the shortest lattice vector.

The obstruction is decisive: q times the secret row minus a_i times each diagonal row gives (0,...,0,Bq,0). It is always shorter than a secret-bearing vector with positive nonces, whose final coordinate already has length Bq. Therefore even an exact shortest-vector oracle has no obligation to return the intended marker-one vector. A marker-slice search, an appropriate closest-vector procedure, or an independent decoding theorem is needed for a universal recovery result. Historical successful synthetic runs remain examples of their executed algorithms rather than a missing general theorem.

The corrected useful product is an observation adapter: exact signing equations generate coefficients, independently supported leakage supplies bounds, a lattice or interval method proposes or enumerates candidates, and original public equations verify them. This design transfers cleanly to noncryptographic problems with bounded modular measurement errors.

## A22. Reusable contracts and practical value

An arithmetic module should record its original domain D, candidate enclosure C, coordinate map T, observation source O, and original verifier V. A congruence module returns a residue with its true period. A bounded module returns every integer alias or an exact compact description. A group module certifies order and scalar domain. A principal-unit module certifies its coefficient representation, prime regime, rank, and precision. A lattice module certifies its full span and searched region.

For a verified witness, the final check suffices to establish membership in S. For complete solutions, every branch and fiber must be covered. For uniqueness, the kernel, interval, or explicit solution count must remove all alternatives. For infeasibility, a complete contradiction or exhausted exact domain is needed. These contracts let several numerical methods collaborate without claiming that one backend handles every algebraic form.

The contribution of Stefan's organization is a persistent operational pattern: expose arithmetic coordinates, preserve their original preimages, exploit accessible structure, and verify the decoded result. Established CRT, cyclic-group methods, local-ring layers, Smith form, and lattice geometry provide the specific theorems. Their combined value is a usable arithmetic workbench and a language for deciding which partial observations genuinely help. The same language identifies the next missing item: another independent residue, a tighter justified bound, an unresolved prime-order logarithm, a singular kernel parameter, or a complete target search.

The accompanying exact family-A suite executes 651,719 assertions at explicitly declared finite ranges. It compares congruence formulas with direct enumeration, digit recovery with original products, polynomial recombination with every toy algebra element, and lattice-box membership with direct scalar tests. The proofs here justify the general identities; the computations check that the displayed finite procedures and examples implement them consistently.

Exercise A-X5. One observation modulo 101 is |ctr_101(x-38)|<=1. Its feasible scalars are 37,38,39. Adding the independent ten-times observation in A-E11 removes two; applying the first observation twice removes none. Exercise A-X6. For the same lattice, reduced coefficient c=(0,7,3) decodes to original scalar 37 because cU=(0,-3,37). A parser that reports three has confused a basis coefficient with the represented scalar.

## Family A references

[A-R1] S. C. Pohlig and M. E. Hellman, "An Improved Algorithm for Computing Logarithms over GF(p) and Its Cryptographic Significance," IEEE Transactions on Information Theory 24(1), 1978, 106-110, DOI 10.1109/TIT.1978.1055817. Sections III-IV establish prime-power digit extraction and CRT in the original prime-field setting. https://ee.stanford.edu/~hellman/publications/28.pdf

[A-R2] A. J. Menezes, P. C. van Oorschot, S. A. Vanstone, Handbook of Applied Cryptography, 1997, Chapter 3, Sections 3.6.2-3.6.4, Algorithm 3.63 and Facts 3.62/3.65. The cited operation count assumes the order factorization; the rho expected-cost statement assumes a suitable random-function model. https://cacr.uwaterloo.ca/hac/about/chap3.pdf

[A-R3] R. Raghavendran, "Finite associative rings," Compositio Mathematica 21(2), 1969, 195-229, Section 3.9, Theorem 9. Its odd-prime Galois-ring principal-unit structure is context for the constructive coefficient proof A-P6. https://www.numdam.org/article/CM_1969__21_2_195_0.pdf

[A-R4] Richard P. Stanley, "Smith Normal Form in Combinatorics," author manuscript dated 18 April 2016; JCTA 144, 476-495. Theorem 2.1(4) supplies Smith-form existence over principal ideal rings; A-P7 derives the modular solution interpretation. https://math.mit.edu/~rstan/papers/snf_survey.pdf

[A-R5] Dan Boneh and Ramarathnam Venkatesan, "Hardness of computing the most significant bits of secret keys in Diffie-Hellman and related schemes," CRYPTO 1996, LNCS 1109, 129-142. Historical hidden-number attribution; no universal recovery theorem from this paper is required here. https://crypto.stanford.edu/~dabo/abstracts/dhmsb.html

[A-R6] Standards for Efficient Cryptography, SEC 1, version 2.0, 21 May 2009, Sections 4.1.3-4.1.4, printed pages 44-47. Signing and verification conventions only; no attack-success theorem. https://www.secg.org/sec1-v2.pdf

[A-R7] Keith Conrad, Infinite Series in p-adic Fields, author-hosted mathematical exposition, Theorems 8.5 and 8.13. The inverse chart uses valuation greater than 1/(p-1); in Q_p this gives pZ_p for odd p and 4Z_2 for p=2. The commutative coefficient-algebra application is justified by the coefficientwise convergence and formal-series argument in A12. https://kconrad.math.uconn.edu/blurbs/gradnumthy/infseriespadic.pdf
