# Observation, reconstruction, and the information that survives

## F.1. A precise question before a method

Many of Stefan's proposals begin with an object that is difficult to obtain directly, followed by easier measurements, modular projections, differences, tables, or changes of coordinates. Their common mathematical problem is reconstruction. The useful first question is which original objects remain possible after the supplied information has been used. That question gives a reliable meaning to narrowing, collision, recovery, and uniqueness without requiring a particular algebraic technique.

Let D be the original domain, O:D->Y an observation map, and y an observed value. The exact observation fiber is the set of original objects producing that observation. If a further original predicate P is imposed, the target solution set S is obtained by intersecting the fiber with that predicate:

```text
Fiber_O(y) = {x in D : O(x)=y}.
S = {x in D : O(x)=y AND P(x)}.
C = a represented candidate enclosure satisfying S subset C.
```

The enclosure C can contain false candidates. That is acceptable during search. A final verifier V checks the original requirements on an original-domain object. A proposal, a candidate enclosure, and a verified answer therefore have different roles. These definitions standardize the recurring source language of carriers, constraints, and residual states while retaining the central organizing idea: exploit convenient representations and preserve the information needed to return to the original problem.

**F-P1, exact decoder criterion; PROVED.** A function Q on the actual image O(D) can satisfy Q(O(x))=x for every x in D exactly when O is injective on D. If O(x1)=O(x2), applying Q gives x1=x2, proving necessity. If O is injective, each actual observation has one preimage, which defines Q and proves sufficiency. This establishes existence of an inverse function. It supplies no bound on the cost of computing that inverse.

A quotient formulation gives the same distinction. Define x1~x2 when O(x1)=O(x2). An observation identifies one equivalence class in D/~. If that class has several members, choosing one representative is a convention or a search decision. It does not establish that the representative was the original object. A good operational interface can report the whole class, a bounded list, or a symbolic family rather than making an unsupported choice.

## F.2. Worked example: a correct set can still have a collision

**F-E1.** Consider ordered integer pairs with x+y=10 and xy=21. Substitution produces x(10-x)=21, so x^2-10x+21=(x-3)(x-7)=0. The ordered solution set is {(3,7),(7,3)}. Both solutions pass the original sum and product tests. A sum-product observation does not distinguish their order.

If the intended objects are unordered pairs, both ordered solutions represent the same object {3,7}, and uniqueness holds in that quotient domain. If the intended objects are ordered, the independent condition x<y selects (3,7). Changing the domain and adding a measurement are different repairs. The first changes what counts as the object; the second provides distinguishing information about the original object.

The example is useful for symbol puzzles, database records, and inverse numerical experiments. Two correct answers need not indicate a computational mistake. They can indicate that the stated observation omits order, sign, orientation, or another coordinate. Before demanding one answer, a reconstruction problem must say which of those distinctions matter.

## F.3. Coordinate transformations reorganize information

Suppose T:Y->Z transforms already available observations. Equal observations remain equal after transformation:

```text
O(x1)=O(x2) => T(O(x1))=T(O(x2)).
Fiber_O(y) subset Fiber_(T o O)(T(y)).
```

**F-P2; PROVED.** Every x in the original fiber has O(x)=y. Substitution gives T(O(x))=T(y), placing x in the transformed fiber. Therefore transforming the observation cannot remove an ambiguity between states that already gave identical observations. If T is injective on O(D), the fibers are equal. Otherwise the transformation can merge previously distinguishable observations.

This fact explains both the usefulness and the limits of Fourier channels, residue coordinates, complex carriers, and hashing. A reversible transform can expose cancellation or sparse structure and make decoding cheaper. A lossy transform can give a convenient necessary condition. Neither operation supplies an unmeasured distinguishing fact. A copied record, a plot of that record, and a different coordinate expression remain representations of the same observation.

An exact round trip is an appropriate certificate for a claimed coordinate equivalence: decode(T(y))=y on the declared domain. A projection instead needs a fiber coordinate. For integers, storing x modulo M together with an integer quotient t in x=r+Mt preserves the original value. Storing r alone preserves only the residue class. The quotient may be bounded, searched, or solved elsewhere, but it cannot silently disappear from the proof.

## F.4. Anchors restore missing coordinates

For observations Ax=y over a field, assume a consistent solution x0 exists. Every solution is x0+h with h in ker(A). Subtracting two solutions proves the forward assertion; adding a kernel vector proves the converse. Extra observations Bx=b identify the state uniquely precisely when the common kernel is zero:

```text
ker(A) intersection ker(B) = {0}.
Equivalently rank([A;B]) = the number of unknown coordinates.
```

**F-P3; PROVED.** Differences between solutions belong to both kernels, so a zero intersection forces equality. A nonzero common-kernel vector creates a second solution by addition. The equivalent rank assertion follows from rank-nullity for the stacked linear map. This statement concerns a field and consistent data. A real rank test cannot establish invertibility over a composite residue ring, where nonzero coefficients can fail to be units.

An anchor is useful only if it detects a remaining ambiguity. Repeating a linear combination of existing observations adds no independent row direction. A one-dimensional ambiguity may need one suitable scalar measurement. A two-dimensional ambiguity normally needs two independent scalar constraints for unrestricted linear recovery. Uniqueness also differs from stability: a nearly singular measurement matrix can have a unique inverse that greatly amplifies small errors.

**F-E2.** Suppose a path has observed increments 3,4,5. Its possible states are

```text
(b, b+3, b+7, b+12), with b arbitrary.
```

The independently measured terminal state 20 gives b+12=20 and hence b=8. The reconstructed path is (8,11,15,20). Its differences and terminal value verify the answer directly. A complex carrier such as Z_t=(x_t-b)+i*b can store the displacement and the recovered boundary separately. Reading its real and imaginary parts reconstructs x_t. The carrier stores the anchor result; it does not discover b from increments alone.

Declaring b=0 would select a reference path. Measuring b=8 identifies a path in the original problem. This is the distinction between fixing a gauge and observing a missing constant. It prevents a convenient zero convention from becoming an accidental factual claim.

## F.5. The boundary changes the inverse

Ordinary differencing D maps (x0,...,xn) to (x1-x0,...,xn-x_(n-1)). Its kernel consists of constant arrays: adjacent equality propagates across the whole chain. The cumulative transform is a different map, and its inverse includes a boundary component:

```text
Y_t = SUM_(j=0)^t u_j.
M(Y)_0 = Y_0.
M(Y)_t = Y_t-Y_(t-1), t>=1.
```

**F-P4; PROVED.** Telescoping gives M(Y)=u and cumulative summation gives Y back from M(Y). Therefore this anchored inverse has zero kernel. In particular, M(c,c,...,c)=(c,0,...,0), which is nonzero when c is nonzero. The source speculation that every difference-like inverse erases constants is repaired by naming the actual source, target, and boundary convention.

Multiplicative cumulative products need another guard. If P_t=PRODUCT_(j=0)^t u_j in a multiplicative group, then u_t=P_t/P_(t-1), with P_(-1)=1. If zero is allowed, later factors can disappear: u0=0 makes every P_t zero regardless of the remaining factors. The additive and multiplicative constructions resemble each other, but their inverse contracts differ.

This boundary discipline is practical for logs, cumulative counters, inventory changes, and sensor streams. A stream of absolute states is different from a stream of changes. A timestamp labeled zero is different from a zero sampling interval. Subtracting adjacent height measurements over a positive interval is well defined at the initial sample even when its index is zero.

## F.6. Worked example: a modulus can remain unidentified

**F-E3.** Let the known recurrence be f(x)=13-x, and let canonical recorded states be 1,0,1,0,... . Each transition residual x_(t+1)-f(x_t) equals -12. Thus every compatible positive modulus must divide 12. Canonical representatives require m>1, leaving m in {2,3,4,6,12}. Each of those moduli produces the same recorded orbit.

The calculation identifies a candidate set. It does not identify whether the generating modulus was 6 or 12. A temporal spectrum, a finite difference stream, and a hash computed solely from these observations have identical inputs in both histories. They cannot distinguish the histories by F-P2. An additional independent measurement, a justified modulus bound, or an explicit generating-model restriction is needed.

In general, for exact recurrence residuals r1,...,rt and G=gcd(|r1|,...,|rt|)>0, the compatible positive moduli are exactly the divisors of G before other constraints. A common divisor divides G by Bezout's identity, and a divisor of G divides each residual. If the true modulus is m and r_j=m*q_j, then G=m*gcd(|q_j|). Equality G=m requires the quotient gcd to equal one. When every residual is zero, the observations give no finite divisor list at all.

The example also separates internal verification from independent validation. Checking the same recurrence modulo a proposed m verifies compatibility with the data. It does not rule out other compatible moduli. Several mathematically equivalent checks can prevent coding mistakes without becoming several independent observations.

## F.7. Exact interfaces compose; missing hypotheses remain missing

A multi-stage reconstruction can use relations rather than insisting every intermediate representation be bijective. Suppose a stage connects an original solution set S0 to a transformed solution set S1 through R01. Forward coverage requires every original solution to have at least one related transformed solution. Backward correctness requires every related transformed solution to decode only to original solutions. Store every branch needed by these two obligations.

**F-P5; PROVED.** If R01 and R12 each have coverage and backward correctness, their composite R02(x,z), defined by existence of y with R01(x,y) and R12(y,z), has both properties. Coverage follows by selecting the two guaranteed witnesses in order. Backward correctness follows by applying the second stage's implication and then the first stage's implication to the shared intermediate witness. For deterministic decoders, the same statement is the set equality decode01(decode12(S2))=S0.

Sound pruning is a weaker and useful interface. If every x in S satisfies E, then

```text
S subset C  =>  S subset {x in C:E(x)} subset C.
```

Membership proves the assertion, and induction proves it for any finite chain of certified filters. Repeating the same filter is idempotent. A heuristic can reorder candidates or propose a witness; deleting candidates on its authority would require a separate soundness theorem. Complete finite enumeration of the remaining enclosure followed by V returns exactly S. An incomplete unsuccessful search returns unresolved.

## F.7a. Category language requires commuting interfaces

Some source proposals package the same operational chain with category, functor, natural-transformation, or monad terminology. Those terms are useful when their extra structure is supplied. Naming a sequence of functions does not by itself supply that structure. A precise finite example gives a reusable interpretation without making the notation carry an unsupported theorem.

Consider a record system with sets People and Tasks and an assignment function owner:Tasks->People. A second version has People_prime, Tasks_prime, and owner_prime. An update uses maps u:People->People_prime and v:Tasks->Tasks_prime. It preserves the assignment interface exactly when

```text
u(owner(task)) = owner_prime(v(task)) for every task.
```

This is a commuting-square contract: following the old assignment and then updating the person gives the same answer as updating the task and following the new assignment. A schema can represent the sets as objects, the assignment as an arrow, and their compositions and identities explicitly. A database instance then maps that schema to sets and functions. The pair (u,v) is a natural transformation for this simple schema precisely when the displayed equality holds. The abstract terminology earns its use by making every preserved relationship an obligation.

**F-E3a.** Tasks t1,t2 belong to people p1,p2 respectively. An update renames p1 to q1 and p2 to q2, and renames tasks to t1_prime,t2_prime. If their new owners are q1,q2 in the same order, the square commutes. Swapping the new task owners violates it. Both updates are ordinary functions; only the first preserves the declared assignment interface. A diagram with four matching box labels cannot distinguish them unless its arrows and equations are retained.

A stateful computation has an equally explicit construction. Let K be the state set. A computation producing a value in X is a function f:K->X times K. A value x is injected by returning (x,s) at incoming state s. Sequencing f with g:X->(K->Y times K) means first calculate f(s)=(x,s1), then calculate g(x)(s1). Both returned value and returned state are threaded into the next stage.

The unit laws follow by substitution: injecting x and then g evaluates g(x) on the original state, while sequencing f with value injection returns exactly f's value and state. Associativity follows because either parenthesization runs the same three calculations with the same intermediate states. This standard state-monad construction explains the structure that a source's memory/controller analogy can legitimately mean. Merely storing a log does not establish these laws.

The practical benefit is a contract for composing software modules. A residue-decoding stage and its verifier must agree on modulus, precision, branch, and coefficient revision. A state update that changes one of these fields must thread the new field into every dependent stage. A numerical gradient also requires declared coordinates and an inner product when a differential is converted into a vector. Integer modulus choices require a discrete search contract rather than an ordinary tangent direction.

Such packaging can make interface mistakes easier to detect. It does not strengthen the underlying mathematical result unless the extra commuting equations, domains, and preservation conditions are proved. A well-typed false empirical premise remains a false premise. A commuting pair of programs can preserve an incorrect model perfectly. Correct composition and correct interpretation of the input evidence therefore remain separate obligations throughout the book.

## F.8. Practical exercises and answers

**F-X1.** Differences are (2,-1,4), and the final state is 13. The cumulative displacement is 5, so the initial state is 8 and the path is (8,10,9,13). Recomputing all differences checks the reconstruction. Without the final observation, all constant translations remain possible.

**F-X2.** O(x)=x^2 on the real domain. The derivative is nonzero at x=2, but O is not globally injective because O(2)=O(-2). Restricting to nonnegative reals removes the sign ambiguity. A local nondegeneracy argument should not be promoted into global uniqueness without that restriction.

**F-X3.** An enclosure contains integers 0 through 20, and the proved condition is x==1 (mod 3). The safe retained set is {1,4,7,10,13,16,19}. A ranking procedure preferring 10 can propose 10; it cannot certify that the other six values are impossible. A final exact predicate must supply that conclusion.

# Logic arrays, temporal scope, and grounded evidence

## F.9. Cases, propositions, and layout coordinates

Stefan's three-dimensional logic array becomes precise when its geometry is a view of an underlying semantic store. The store names formulas, contexts, sources, constraints, and witnesses. The layout map assigns display locations to persistent record IDs. Moving a record can improve navigation, but its truth conditions and dependencies remain attached to its identity.

For a finite classical vocabulary and hard theory Gamma, let Omega be the satisfying assignments. An ordinary substantive verdict requires Omega to be nonempty. A formula Q denotes the region [[Q]] of assignments where Q is true. Evidence selects a region E subset Omega. The query is established when E is nonempty and E subset [[Q]], excluded when E is nonempty and E intersection [[Q]] is empty, and undetermined when both truth sides survive. An empty E is model conflict. An unfinished search adds the operational status unresolved.

The source's signed z display can show Q and its complement. The witness wing stores choices and their dependencies. The provenance wing stores where claims originated. The diagnostic wing records consistency, coverage, counterexamples, and certificates. These are record roles; a geometric axis is not an additional logical operator. The semantic algebra can have many more than three independent dimensions even when the display occupies three-dimensional space.

## F.10. Atomization gives the intended orthogonality

Choose interpreted classical generators P1,...,Pt. For every Boolean signature sigma, form the region where each Pi has its specified value, retaining only nonempty regions. These are complete observable cases rather than merely individual propositions:

```text
A_sigma = INTERSECTION_i
  ([[P_i]] if sigma_i=1, otherwise Omega minus [[P_i]]).
```

**F-P6; PROVED.** Every assignment has exactly one signature, establishing coverage. Two different signatures disagree on at least one generator, so their regions are disjoint. Each generator is the union of regions whose corresponding signature bit is one. Boolean combinations are reconstructed from these unions by structural induction. Thus atomization gives a disjoint partition together with exact maps back to the original propositions.

The construction can be performed one generator at a time: replace each region A by A intersection [[Pi]] and A minus [[Pi]]. Their union is A and their intersection is empty. Children of different parents stay disjoint. Processing the same generators in another order produces the same denoted regions because intersection commutes, although their printed signatures can be reordered.

Permutation of overlapping proposition labels does not perform this operation. If two original propositions overlap, permuting their matrix rows and columns preserves the nonempty intersection. Gram-Schmidt is also a different operation: it can produce negative vector coefficients that are no longer truth regions. In a finite indicator-vector model with strictly positive weights, disjoint regions have zero inner product and conversely. The logical partition supplies that interpretation; physically perpendicular display directions do not supply the partition.

**F-E4.** Let Omega contain all four assignments to P and Q. The complete regions are 00,01,10,11. P is the union {10,11}; Q is {01,11}; they overlap at 11. The four cases are mutually exclusive even though P and Q are not. A shared proposition true on all four cases belongs in the common core, and adds no new disjoint case.

## F.11. Pairwise faces can hide the essential relation

**F-E5.** Let R=P XOR Q. The satisfying triples are 000,011,101,110. Every possible assignment to a chosen pair appears in some satisfying triple. Consequently all three pairwise compatibility tables are unrestricted. Nevertheless 111 is excluded by the full relation. Joining the three pairwise projections gives all eight triples and creates four spurious candidates.

The proof is the explicit enumeration. Each pair has four possible values and receives all four; the original relation has only four rows. A display containing every pairwise face is therefore not necessarily a complete representation of joint constraints. The backing store needs the three-way relation, an equivalent formula, or a proved lossless decomposition.

Even pairwise constraints can defeat purely local propagation. Requiring P!=Q, Q!=R, and P!=R over Boolean values is globally impossible. Every variable value nevertheless has a supporting neighbor value in each individual relation. Three pairwise distinct values cannot be drawn from a two-element domain. A propagation fixed point means the selected propagation rules have stopped finding deletions. It does not certify a satisfying global assignment.

For practical logic-puzzle grids, this is a central improvement: preserve constraint scopes as graph or hypergraph records. Local tables make deductions readable, and a complete checker handles the joint relation. Otherwise the visual system can look complete while having lost precisely the interaction that determines its answer.

## F.12. Finite CH profiles remain a conditional application

The recovered CH and choice report tracks H for the continuum hypothesis, L for V=L, and AC for choice. Its finite Boolean kernel assumes AC AND (L implies H). The three retained profiles are (AC,L,H), (AC,not L,H), and (AC,not L,not H). Their Boolean disjointness and coverage relative to that kernel are elementary. Realization by the claimed forcing histories is a separate set-theoretic input.

The chapter uses this example only as a conditional finite adapter. It neither constructs finite models of ZFC nor reproves CH independence. Choice is shared by the three profiles and therefore cannot select the H side. Evidence not L leaves both H and not H profiles. Evidence L leaves the first profile and establishes H within that current-context scope.

With the declared accessibility from the first profile to all three, from the second to the last two, and from the third only to itself, H can hold currently while BOX H fails. Evaluating BOX uses the original declared successor relation; restricting the current evidence does not delete contrary accessible contexts. This is a useful demonstration of scope even without importing the deeper forcing interpretation. The imported infinite theorems remain source dependencies, not finite-table conclusions.

## F.13. Evidence pairs keep ignorance separate from conflict

Reports about an arithmetic fact can disagree even though the fact itself has an ordinary classical truth value. Represent positive and negative support as independent Boolean bits. The four statuses are neither (0,0), positive only (1,0), negative only (0,1), and both (1,1). They are records of support, not probabilities and not permission to contradict an exact equality inside its checked arithmetic domain.

The adopted Dunn-Belnap style operations are explicitly defined:

```text
neg(p,n) = (n,p).
(p,n) AND (q,m) = (p AND q, n OR m).
(p,n) OR  (q,m) = (p OR q, n AND m).
Clean(P) = p(P) AND Boolean-NOT n(P).
```

Double negation and De Morgan identities follow coordinate by coordinate from Boolean identities. Adding support to either channel cannot remove existing support under these operations. Clean acceptance can nevertheless be withdrawn: a positive-only record becomes conflicted when a negative report arrives. Monotone evidence accumulation and a revisable acceptance policy are different processes.

**F-E6.** Let P=(1,1), Q=(0,0), and define a material conditional as neg(P) OR Q. Its value is (1,0). Both P and that conditional have positive support, while Q has none. Material-conditional modus ponens fails for this evidence algebra. A correct forward rule instead explicitly requires the Boolean preservation condition p(P) implies p(Q). Once that condition is admitted or proved, p(P)=1 licenses p(Q)=1.

The failure prevents conflict from generating arbitrary conclusions. Likewise, absence of positive support is not support for a negation. A countermodel to positive entailment needs p(Q)=0; it need not have n(Q)=1. Searching only for a positively supported strong negation can miss an unsupported neither-valued conclusion.

## F.14. A signed compilation preserves both channels

Each evidential atom P can be translated into two independent classical atoms P_plus and P_minus. Define translations tau_plus and tau_minus recursively. Strong negation swaps the translations; positive conjunction keeps AND, negative conjunction uses OR; positive disjunction uses OR, negative disjunction uses AND. Quantifiers fold over the same declared domain:

```text
All_j(p_j,n_j) = (AND_j p_j, OR_j n_j).
Some_j(p_j,n_j) = (OR_j p_j, AND_j n_j).
```

**F-P7; PROVED.** Structural induction shows that the classical truth values of the two translations equal the two support coordinates. The atomic case is the definition of the doubled interpretation. Each connective case substitutes the inductive hypotheses into its coordinate equations. Quantifier cases substitute them into the corresponding Boolean fold over the identical domain. Modal and finite-state temporal adapters require their additional frame clauses, rather than acquiring them from the propositional proof automatically.

When every atomic instance has exactly one support bit, complementarity is preserved by the same induction, and the positive channel agrees with ordinary classical interpretation. This gives a justified classical subproblem when complementarity has actually been established. It does not permit arbitrary classical simplifications in a conflicted database. Negation normal form must preserve both bits and every variable scope, time index, and modality label.

## F.15. Time, revision, causation, and alternatives have separate indexes

A temporal transition says which state can follow another. A modal accessibility relation says which alternatives are considered by a named modality. A causal mechanism specifies how variables depend under equations and interventions. A revision index records changes in available information. These roles can coincide in a particular model, but no such coincidence is assumed.

Event time and receipt revision are especially important. A later report about an earlier event changes the current evidence description of that event. It does not put that report into an earlier decision maker's information set. A finite state can also be revisited while occurrence time advances. Assigning one strictly increasing timestamp to each reusable state would incorrectly forbid ordinary loops.

A practical claim context stores domain, object identity, event interval, branch, coefficient revision, assumptions, and precision. Two records with the same printed formula can concern different contexts. A fact at precision p^(k+1) can be reduced to precision p^k through a proved bridge. A fact about one polynomial revision cannot certify a different coefficient revision merely because the solver retained the same variable name.

The source's natural-language certificate proposals supply a useful engineering checklist: lexical sense, argument types, asserted versus reported content, quantifier scope, and premise dependencies. These fields make particular equivocations detectable when the formalization captures them. They do not prove that language has been interpreted uniquely, that all manipulation is detectable, or that a chosen ontology is correct.

## F.16. Witness order is an operational dependency

**F-E7.** Two admissible contexts contain objects a and b. The first permits only a as a successful witness, and the second permits only b. Every context has some witness:

```text
FOR ALL contexts w, EXISTS x, Success(w,x).
```

No one constant witness works everywhere:

```text
NOT [EXISTS x, FOR ALL contexts w, Success(w,x)].
```

The two statements differ because the first selection can depend on the already chosen context. A case-dependent function selecting a in the first context and b in the second succeeds semantically. Executing it additionally requires enough observation to identify the context. If the available observations are identical, one observation-based decision cannot choose the two different required values.

The same distinction governs game strategies, task planning, future existence, and inverse arithmetic branches. A future witness need not exist now. A witness in one residue branch need not solve another branch. A statement that every branch has some solution does not imply that one object solves every branch. Exporting a local witness requires a persistence or compatibility theorem, not deletion of its context subscript.

## F.17. Grounded closure excludes circular corroboration

Let the finite signed atoms form a set L. A rule has a finite premise set A subset L and conclusion q in L. With admitted seed evidence E, define

```text
F_E(X) = E union X union {q : rule A->q exists AND A subset X}.
X_0 = empty; X_(j+1)=F_E(X_j).
```

**F-P8; PROVED.** The operator is monotone and inflationary. Every iterate is contained in every rule-closed superset of E, by induction. Since L is finite, the chain stabilizes after at most |L| strict growth steps. The stabilized set is closed and contains E, so it is exactly the least closed superset. Every newly admitted atom has a finite derivation rooted in seed evidence or a declared empty-body axiom.

**F-E8.** Rules P->Q and Q->P with no seeds derive neither atom. Their equations admit an all-supported assignment, but that assignment is not grounded evidence. Adding seed P produces closure {P,Q}. Rewriting the resulting Q report three times preserves the same original seed ancestry. Several renderings can be useful cross-checks without becoming several independent sources.

Provenance can retain alternative root sets. If Q has one derivation jointly using e1 and e2 and another using e3, the schematic expression e1*e2+e3 records joint versus alternative use. It supplies no probability multiplication rule. The primary provenance-semiring paper identifies this distinction in database annotations; the elementary root-set discipline here is explicitly defined and separately proved.

## F.18. Temporal reachability, inevitability, and fixed points

On a finite serial transition graph, let Goal be the goal states. Define Pre_some(Z) as states with at least one successor in Z, and Pre_all(Z) as states whose every successor lies in Z. Existential reachability EF Goal is the least fixed point of Goal union Pre_some(Z). Universal eventuality AF Goal is the least fixed point of Goal union Pre_all(Z).

**F-P9; PROVED.** Starting from the empty set, EF iteration adds goals and then states reaching a previously added state. Induction identifies finite-path reachability. For AF, induction identifies states whose every continuation reaches the goal within a uniform finite bound. In a finite graph, if every path eventually reaches the goal but no such bound exists, arbitrarily long avoiding prefixes contain an avoiding cycle, creating an infinite counterexample. Therefore the finite iteration characterizes AF as well. Each increasing chain has at most the number of states strict additions.

**F-E9.** A state s has a self-loop and an edge to an absorbing goal g. EF Goal includes both states. AF Goal includes only g because the self-loop permits indefinite postponement. The goal remains reachable at every reachable state, so AG EF Goal holds at s while AF Goal fails. Continuing possibility does not establish inevitability.

For safety set H, AG H is the greatest fixed point of H intersection Pre_all(Z). Starting from all states deletes those violating H or reaching a deleted state. Inductive invariance gives a compact certificate: initial states lie in I, I subset H, and every successor of I remains in I. A safe loop can satisfy safety while failing progress. Fairness restrictions, terminal self-loops, and finite-trace next operators change the model and need explicit conventions.

## F.19. Causal cycles do not certify their own existence

Boolean equations x=y and y=x have solutions 00 and 11. They permit a populated cycle without forcing it. The update F(x,y)=(y,x) has those fixed points, yet iteration from 01 oscillates through 10 forever. Existence of a fixed point, convergence of a dynamical procedure, and grounded inference are different questions. The recovered Terminator report is usable as finite dependency examples under this distinction; it is not a physical time-travel theorem.

For a declared mechanism Y=(A AND G) OR O, disabling route A leaves Y=O. Eliminating the named route prevents Y only when the residual alternatives O are also excluded. The local inference from A implies Y and not A to not Y is invalid: A=0,Y=1 is a counterexample. An intervention replaces the selected equation; an observation constrains the existing equations. These are separate operations even if the same variable value is printed.

## F.20. Exercises and answers

**F-X4.** A logic array stores only pairwise tables for R=P XOR Q. The tables admit 111, but the original relation rejects it. The repair is to retain the three-argument factor or an equivalent exact formula.

**F-X5.** Evidence P=(1,0) later receives negative support. Its new status is (1,1). Positive support remains; clean acceptance fails. Removing a clean certificate therefore need not assert that P is false.

**F-X6.** A three-state serial graph has s->t, t->t and t->g, g->g. Goal={g}. EF includes all states. AF includes only g because s can reach t and remain there forever. A progress or fairness premise would be needed to establish universal completion.

# Tables, circuits, and finite computational machines

## F.21. Exact indexing turns quantities into usable coordinates

An array address is a coordinate map with an explicit inverse. For r rows and c columns, row-major indexing is i=c*a+b, with 0<=a<r and 0<=b<c. Division with remainder gives a=floor(i/c) and b=i modulo c for 0<=i<rc. These formulas prove a bijection; neither primality nor coprimality of r and c is needed.

**F-E10.** Forty objects fit exactly in five rows of eight. Object index 29 has row 3 and column 5 because 29=8*3+5. The last index 39 has coordinates (4,7). Every pair in {0,...,4} times {0,...,7} decodes to exactly one index from 0 through 39. Transposing the array uses new index i'=5*b+a and preserves the object through the two coordinate maps.

This array factorization differs from Chinese remainder coordinates. Recording i modulo r and i modulo c identifies i modulo rc only when gcd(r,c)=1. In a 4 by 8 layout, row-column division still indexes all 32 objects, but the residue pair (i mod 4,i mod 8) repeats every eight. Memory layout and independent CRT channels are related uses of arithmetic with different inverse hypotheses.

## F.22. The recovered six-operation nibble block

The source logic block stores NOT, AND, OR, XOR, XNOR, and scalar-control IF on four-bit nibbles. Its data region has 96 rows and 32 columns. With operation index op in 0 through 5, inputs a,b in 0 through 15, and control bit cbit in {0,1}, its exact addressing is

```text
row = 16*op+a; column = b+16*cbit.
full_block_address = 34*row+column.
```

Two check columns and two check rows enlarge the block to 98 by 34. There are 3,332 nibbles, occupying 3,332 bytes if stored one per byte or 1,666 bytes under exact nibble packing. The data region contains 3,072 entries. The duplicated control halves for the first five operations are deliberate redundancy; IF selects a when cbit=1 and b when cbit=0.

**F-E11.** XOR has op=3. With a=10 and b=6, row=58 and column=6, giving address 1,978 and output 12. In binary, 1010 XOR 0110=1100. IF has op=5; with the same inputs and cbit=1, row=90 and column=22, giving address 3,082 and output 10. These are exact table semantics, independent of the machine used to store the array.

The source later lets IF accept a nibble mask while retaining the original one-bit-control table. That is a type change. A mask selector is instead (mask AND a) OR ((NOT mask) AND b), with complement restricted to four bits. It can be composed from the existing operations, but it is not one call to the scalar IF table.

Per-bit arithmetic belongs to F_2: NOT x=1+x, AND(x,y)=xy, OR(x,y)=x+y+xy, and XOR(x,y)=x+y. The source's row and column sums modulo 16 belong to Z/16 Z. These two rings play different roles. Packing four bits into a nibble does not turn bitwise XOR into ordinary addition modulo 16.

## F.23. Trusted syndromes correct one fault, not every fault

The block stores each row's and column's nibble XOR and sum modulo 16. Under the precise assumption that one data cell changes from u to v while all stored check values remain correct, both its row and column have nonzero XOR discrepancy u XOR v. Their intersection identifies the changed cell. Its original value is recovered by XORing the corrupted cell with that discrepancy. The sum discrepancy provides an additional consistency check.

**F-P10; PROVED.** Every unchanged row has its original XOR. The changed row's recomputed XOR differs by u XOR v, which is nonzero because u!=v. The same holds for the changed column. Removing the discrepancy reverses the change. This is exact correction under the single-data-cell and trusted-check assumptions. It is not a theorem about arbitrary corruption of the checks themselves.

**F-E12.** In the AND table, rows 16 and 17, columns 0 and 16, contain four zeros. Change all four cells to 8. Each affected row and column receives two XOR changes of 8, which cancel. Its sum increases by 16, which vanishes modulo 16. Every stored row, column, and corner check remains satisfied even though four table outputs are wrong.

This counterexample refutes universal integrity claims based on these syndromes. The correct guarantee is a specified fault model. It also shows why describing the two checks as independent equations must not imply statistical independence or full error correction. Their combination is useful redundancy; correlated structured errors can lie in their common undetected set.

## F.24. NAND builds the arithmetic, with explicit carries

Define NAND(a,b)=1-ab for Boolean inputs. Then NOT a=NAND(a,a), AND(a,b)=NOT NAND(a,b), and OR(a,b)=NAND(NOT a,NOT b). A finite Boolean function can be expressed as a disjunction of conjunctions describing its satisfying rows. These three identities therefore give a NAND implementation of every finite Boolean function, with a circuit size that may be large.

A concrete nine-NAND full adder supplies sum and carry for bits a,b,c:

```text
t=NAND(a,b); u=NAND(a,t); v=NAND(b,t); p=NAND(u,v).
q=NAND(p,c); r=NAND(p,q); s=NAND(c,q).
sum_bit=NAND(r,s); carry_bit=NAND(t,q).
```

**F-P11; PROVED.** The first four gates compute p=a XOR b; checking the four input pairs or substituting the definitions establishes that identity. The next four gates apply the same construction to p,c and produce p XOR c. The last gate produces (a AND b) OR (p AND c) by De Morgan's law. Exactly one of these carry routes applies when the integer sum needs a carry. Hence a+b+c=sum_bit+2*carry_bit on all eight input triples.

**F-E13.** Four-bit inputs 13=1101 and 7=0111 add from low to high. The bit triples with incoming carry are (1,1,0), (0,1,1), (1,1,1), (1,0,1). Their output sum bits are 0,0,1,0, with final carry 1. Reading high to low gives 10100=20. Four sum bits alone give 0100=4, the answer modulo 16. Exact addition and fixed-width modular addition therefore need different output contracts.

A ripple chain obeys the invariant that processed input bits plus initial carry equal processed output bits plus the outgoing carry at the next power of two. Summing a+b+c=sum_bit+2*carry_bit with weights 2^i telescopes the carries and proves the word result. The naive construction uses at most nine NAND gates per bit with available fan-out. This is a constructive bound, not a minimum or a universal twelve-gate arithmetic theorem.

Lane-wise nibble gates act independently at each bit position. Their composition alone cannot make a higher output bit depend on a lower input bit. Arithmetic therefore also needs declared extraction, shifts, routing, or carry connections. Calling the block a universal Boolean basis is justified once those interconnections are supplied. It is too strong for a fixed lane-isolated array without them.

## F.25. Squaring is self-convolution followed by carry normalization

For an unsigned W-bit integer x=SUM_i x_i*2^i, expansion gives

```text
x^2 = SUM_i x_i*2^(2i)
    + SUM_(i<j) (x_i AND x_j)*2^(i+j+1).
```

**F-P12; PROVED.** Multiplying the two bit expansions gives diagonal terms x_i^2*2^(2i) and two equal cross terms for each pair i<j. Since a Boolean bit satisfies x_i^2=x_i, the displayed expression follows. Equal-weight terms must then be added with carries. They cannot be combined by XOR alone.

**F-E14.** For x=3, active bits 0 and 1 produce diagonal weights 1 and 4 and a cross weight 4. The two fours carry to 8, giving 9. For x=5, the active bits 0 and 2 produce 1,16,8, giving 25. Thus merely doubling active bit indexes squares powers of two but fails on general integers unless the cross terms and carries are retained.

Unsigned squaring maps 0 through 2^W-1 into values below 2^(2W). It is injective on this nonnegative integer domain because x<y implies y^2-x^2=(y-x)(y+x)>0. It is not a surjection onto every 2W-bit value. A root request can therefore return one exact root or none. Signed integers add the sign ambiguity, and modular squaring can have several roots.

A complete finite root procedure can intersect the original W-bit domain with x^2==N modulo 2^k for k=1 through 2W, retaining every branch. If 0<=N<2^(2W), the final congruence is equivalent to exact equality because both values lie in that interval. The intermediate filters are necessary conditions. Singular low-bit behavior can retain several branches, so a guessed partial root should not be called uniquely forced.

## F.26. Triangle circuits need a width contract

The source builds a right-triangle verifier by squaring a,b,c, adding the first two squares, and comparing to c^2. Each individual W-bit square fits in 2W bits. Their sum can require 2W+1 bits. Exact computation of that sum must retain the extra bit or establish the guard a^2+b^2<2^(2W). A bare modular equality circuit without further guards can accept false integer equalities: with W=3, 4^2+7^2=65 becomes 1 modulo 64 and falsely matches 1^2.

An independently checked largest-side condition gives another valid equality-verification repair. If c>=a,b and all three inputs are W-bit, then -2^(2W)<a^2+b^2-c^2<2^(2W), because the positive difference is at most c^2 and the negative difference is at least -c^2. A difference divisible by 2^(2W) must therefore be zero. This certifies the comparison under that additional guard, even though its internal wrapped sum is not the exact integer sum.

**F-E15.** The (3,4,5) trace gives 9+16=25, so an exact root of the sum is 5. The missing-leg trace gives 25-9=16 and root 4. With positive sorted sides x<=y<=z, triangle existence reduces to x+y>z. The sign of x^2+y^2-z^2 then classifies the largest angle as acute, right, or obtuse. For (4,5,6), the difference is 41-36=5, so the triangle is acute. For (2,3,4), it is 13-16=-3, so the triangle is obtuse.

This classifier handles exact integer side data without angle encoding. A general angle-based law of cosines needs a declared real, rational, or fixed-point cosine representation and an error contract. Replacing cos(C) by floor(S*cos(C))/S creates an approximation, with absolute cosine error below 1/S and corresponding squared-side error below 2ab/S. The resulting integer equality is not automatically the original exact geometric equality.

## F.27. Table lookup exchanges computation for storage

A finite function on k input bits with l output bits can be represented by 2^k rows of l bits. Lookup is one abstract table read when addressing is already available. Constructing, storing, transferring, and checking the table remain costs. The same function may have a much smaller circuit or formula.

**F-E16.** Four-bit addition has 256 ordered input pairs and five exact output bits, so its packed answer table uses 1,280 bits, or 160 bytes. Eight-bit addition has 65,536 pairs and nine output bits, requiring 73,728 bytes. The recovered primitive nibble table is larger than the first example because it stores several operations and integrity channels, but it can be reused as a basis for wider circuits.

A single indexed read is not a hardware constant-latency theorem. Real memory systems can depend on cache state, address, alignment, and contention. An instruction-count statement is useful, but timing and performance need a specified implementation and measurements. Likewise, tabulating a finite encoding of a calculator operation does not establish exact handling of arbitrary real inputs, unbounded integers, or every transcendental output.

## F.28. Mechanical and wave implementations share the logical contract

The recovered mechanical simulator tokenizes a finite propositional expression, parses it into an explicit node tape, normalizes its negations, emits gate instructions, and enumerates assignments. Its truth cams are finite Boolean tables. Induction over emitted gate instructions proves that each computed stack value matches its source subformula when the parser and compilation preserve the syntax tree. Complete enumeration of n variables uses 2^n assignments; a satisfying row certifies existence, and evaluating every row certifies the finite classification.

The simulator's token named IF means material implication, with truth table (1,1,0,1) on inputs 00,01,10,11. The nibble block's IF instead means selection with a separate control bit. This volume standardizes material implication as IMP and keeps IF(cbit,a,b) for selection. The archived names remain visible in source records, but their operations are not equated.

An argument check searches premises AND NOT conclusion. No satisfying row establishes classical validity relative to complete enumeration. A separate satisfiability check of the premises distinguishes substantive validity from vacuous validity under inconsistent premises. The simulator's finite capacities, simulated ticks, and gate tables describe an executable model. They do not demonstrate a constructed mechanical apparatus or measured physical speed.

The electronic source encodes bit b as signed phase state s=2b-1. Ideal compensated transport H(L)=exp(-alpha*L)*exp(-i*k*L), with inverse launch compensation, makes the received contribution equal to the intended weight. For an n-input AND detector use z=SUM s_j-(n-1); for OR use z=SUM s_j+(n-1); for NOT use z=-s. Thresholding z>0 gives the exact Boolean gate. All ideal cases are at least one unit from zero.

**F-P13; PROVED.** AND gives z=1 only when all s_j=1; one false input lowers it to -1 or less. OR gives z=-1 only when all inputs are false; one true input raises it to 1 or more. NOT reverses the sign. Thus an additive detector error of magnitude strictly below one preserves every ideal result. This is a bounded-error theorem in the stated mathematical model.

Independent channel averaging reduces variance only for the independent noise component. Common bias and detector noise can leave a nonvanishing floor. Gaussian noise is unbounded, so finite redundancy cannot provide an absolute success guarantee from that model alone. Equalizing a nonzero weak transfer factor can demand a large launch amplitude, and power limits belong in any physical design contract.

The source accepts an attempted physical gate only when its output matches an independently computed logical oracle. Consequently every accepted simulated output is correct by the acceptance definition. The acceptance rate, rejected attempts, and channel cost are meaningful simulation results. They are not independent proof that an unassisted physical device produces correct answers. A physical implementation would need a realizable reference checker, calibrated transfer measurements, and measured error bounds. The logical compiler and the noise experiment should keep those different purposes explicit.

## F.29. Programs as clocks and Hanoi as a verified state graph

A deterministic bounded program can be described by state s_(t+1)=F(s_t) and output O(s_t). If its admissible state set has K elements, some state repeats among K+1 successive states. Determinism makes the subsequent orbit periodic. The state must include every relevant register, memory location, and control position. External inputs require F(s_t,u_t), and unbounded storage invalidates the finite bound.

The clock description standardizes indexed execution. It does not make F easy to invert or identify F from a short output trace. Outputs can merge distinct internal states, returning exactly to the observation-fiber issue. A memory leak can reveal additional coordinates, but its value depends on what it actually observes.

For ordinary three-peg Hanoi, a state assigns each of n ordered disks to one of three pegs; each peg's stack order is fixed by size. All 3^n assignments are legal configurations. A legal edge moves only the smallest present disk on its peg to an empty peg or onto a larger disk. The source mentions Hanoi as a planning application; the following complete example is an editorial standard construction rather than a recovered proprietary algorithm.

**F-P14; PROVED.** Transferring a full tower has minimum length H(n)=2^n-1. The recursive construction transfers n-1 disks aside, moves the largest, and transfers the smaller tower onto it. Hence H(n)<=2H(n-1)+1. For a shortest unrestricted transfer, consider the first and last moves of the largest disk. Before its first move, all smaller disks must form a tower on the third peg, costing at least H(n-1). After its last move onto the destination, all smaller disks must form a tower on the remaining peg and then be transferred to the destination, again costing at least H(n-1). There is at least one largest-disk move. Thus H(n)>=2H(n-1)+1. With H(0)=0, induction gives the formula.

**F-E17.** Three disks move from peg 0 to peg 2 through state vectors, listed smallest disk first:

```text
000 -> 200 -> 210 -> 110 -> 112 -> 012 -> 022 -> 222.
```

Each edge changes one disk and satisfies the top-disk rule. There are seven moves and eight visited states. The entire configuration graph has 27 states. Therefore this shortest transfer is not a Hamiltonian traversal of all configurations. State-graph coverage and optimal point-to-point planning ask different questions.

Caching five levels can reuse a 31-move subroutine for a specified peg transfer. It reduces repeated planning overhead, but cannot reduce the unavoidable number of executed moves. A lookahead policy needs a cost-to-go or graph proof before it can claim shortest paths from arbitrary partial states. Breadth-first search on a bounded state graph supplies an exact oracle for small cases and can expose where a proposed policy fails.

## F.30. Exercises and answers

**F-X7.** Index 23 in a four-by-eight array has row 2, column 7. Its residue pair modulo 4 and 8 is (3,7), also obtained by indices 7 and 15. Division coordinates identify the cell; those noncoprime residue coordinates do not identify the object.

**F-X8.** The scalar-control IF block cannot directly perform a different selection in each bit lane. Compose the mask selector from two AND operations, a restricted NOT, and OR, or create a larger mask-indexed table with its own addressing contract.

**F-X9.** Exact W-bit addition needs W+1 output bits. Exact multiplication needs 2W bits. A sum of two W-bit squares can need 2W+1. These bounds follow from the maximum unsigned inputs, and determine whether a circuit verifies an integer equality or only a modular one.

**F-X10.** A five-disk full transfer requires 31 moves. Reusing a cached optimal sequence can save sequence-generation work, but a machine executing the puzzle still performs 31 legal moves. This is the same distinction between a compact mathematical description and the work required to realize its output.
