# Standard terms and the project vocabulary

## Terms that keep the different methods compatible

Candidate enclosure. A represented set that contains every solution of the declared original problem. It can contain objects that will later be rejected. It need not be a literal list.

Certificate. Data and an argument that a checker can use to establish a specified conclusion. Its force depends on the conclusion: a witness certificate differs from a completeness or optimality certificate.

Soundness. Every returned answer is an admissible solution. Completeness. Every admissible solution is represented in the output. Uniqueness. Exactly one admissible solution exists. These three terms do not imply one another without additional conditions.

Observation map and fiber. An observation map sends original objects to observed data. Its fiber above a datum is the set of original objects consistent with that datum. An observation is identifying when the admissible fiber contains one object.

Anchor and gauge. An anchor supplies a reference that removes an ambiguity such as an additive offset. A gauge is a freedom in representation that leaves the relevant observations unchanged. Fixing a gauge needs a stated convention or legitimate observation.

Projection. A map retaining selected components or equivalence-class information. A projection is commonly lossy. A reconstruction must retain a fiber coordinate, add identifying observations, or return the complete permitted fiber.

Coordinate change. A representation with a stated inverse or reconstruction relation. Changing coordinates can simplify operations without reducing the number of possible answers.

Congruence. Agreement modulo an integer M: a == b (mod M) means M divides a-b. Residue class. All integers agreeing with one representative modulo M. A representative is one member, chosen by convention.

Unit. An element possessing a multiplicative inverse in its ring. Modulo M, an integer a is a unit exactly when gcd(a,M)=1. Nonzero does not imply unit in a composite-modulus ring.

Group order and element order. The group order is its cardinality. The order of an element is the smallest positive exponent giving the identity. A supplied multiple of an element order must not be treated as its exact order.

Discrete logarithm. An exponent relative to a specified generator of a cyclic subgroup. It is a residue modulo the generator's exact order. Defining that coordinate does not make it cheap to compute.

Valuation. The exponent of a specified prime in divisibility, with an explicit convention for zero. In p-adic arithmetic v_p measures divisibility and |x|_p=p^(-v_p(x)) measures the corresponding distance scale.

p-adic precision. Agreement modulo a specified prime power, or a declared valuation of the uncertainty. Absolute and relative precision must be distinguished when multiplication, division or cancellation changes valuations.

Hensel lifting. Refinement of a polynomial root modulo p^k to compatible roots at higher prime-power precision. A simple root has a unique next digit; a singular root can branch or die.

Principal unit and torsion unit. Principal units are congruent to one in the stated residue layer. Torsion units have finite multiplicative order. A logarithm that annihilates torsion needs a separate torsion coordinate for full-unit reconstruction.

Lattice. The integer span of linearly independent vectors in a real vector space, or an explicitly declared integer module embedded there. A small-vector heuristic and a complete box-lattice search have different guarantees.

Root bracket. A real interval with an existence certificate, commonly opposite signs and continuity. It is a uniqueness certificate only with additional conditions such as strict monotonicity.

Residual. The result of substituting a candidate into an equation or model. A residual norm is an objective for proposals. Its stationary points need not be equation roots.

Interval enclosure. A range guaranteed to contain the values of an expression or its admissible solutions. Rounded arithmetic must be outward if it is used as a rigorous numerical certificate.

Fourier coefficient. A coordinate in a declared harmonic basis with stated normalization. The transform can be invertible on its finite sample space while still failing to identify a continuous signal outside the sampling assumptions.

Aliasing. Different original frequencies or signals producing the same observations on a sample grid. Extra plotted precision does not recover the lost information.

Phase. An angle class associated with a nonzero complex value. A branch or unwrapped path supplies additional angle information. Phase is undefined at a zero signal.

Harmonic collision. Different terms contributing to the same observed frequency. Distinct original carrier frequencies do not by themselves exclude collisions among sums, differences and multiples.

Barycentric coordinates. Affine vertex weights summing to one. Nonnegative weights characterize membership in the simplex. Affine independence is necessary for uniqueness.

Incidence and metric. Incidence records which cells are boundaries of other cells, with orientation signs. A metric records lengths or inner products. Correct incidence does not establish a realizable metric.

Angle deficit. The difference between a reference flat angle and incident angle sum in a declared piecewise-Euclidean geometry. It is an integrated curvature quantity, not automatically a density.

State and transition. A state contains the information needed to determine the next permitted evolution under the declared input model. A transition is its update rule. An omitted input or hidden memory can invalidate a proposed finite-state model.

Hash and collision. A hash is a compact fingerprint. A collision is agreement of fingerprints for distinct original data. Exact pattern matching retains the originals and verifies candidate matches.

Statistical null and validation. A null specifies the reference distribution being tested. Validation tests a selected model on appropriate fresh or held-out data. Dependence, selection and repeated testing belong to the model contract.

Context and provenance. A context fixes the domain in which a statement is interpreted. Provenance records the observations and inference steps supporting it. Renaming a source or repeating a derived claim does not create new independent evidence.

## A dictionary for earlier informal names

Carrier becomes a coordinate space, state space, or observation channel after its type is declared. The earlier phrase carrier/projection/intersection is retained as an organizing shorthand for representation, observation, and constraint intersection.

Ratchet becomes monotone solution-preserving refinement. Precision ratchet adds compatible increasing precision. Neither phrase by itself supplies a convergence theorem.

Shake and wobble becomes oscillatory probing, harmonic coefficient extraction, or finite-difference local modeling, according to the actual experiment. The associated update becomes a quadratic or Newton proposal after its coefficients and admissibility are specified.

Resonator becomes a periodic phase encoding, an exact roots-of-unity filter, or a heuristic score. Those are different constructions even when they share a circular picture.

Mirror constraint becomes reciprocal interval propagation when the original relation is xy=N. It is a necessary enclosure, whose selectivity must be measured separately.

Descent becomes verified objective decrease or a precisely defined arithmetic height reduction. A visually downward motion in a chosen coordinate chart need not decrease the original objective.

Entropy becomes Shannon entropy only when a probability distribution and logarithm base are declared. Counting arithmetic operations or decomposing a number into offsets does not automatically define information entropy.

Clock becomes indexed state evolution with specified inputs and memory. A periodic component can be a clock; a complete program need not be periodic or easily invertible.

Three-dimensional logic array becomes a typed atlas of semantic objects, projections and transitions. Hyperedges or atoms retain joint constraints that pairwise pictures can lose.

Binary or ternary part becomes a digit, a valuation, a parity class, or an exponent residue after the actual coordinate is identified. A base-3 digit of an exponent is different from the 3-adic valuation of the group element it encodes.

Collision becomes either a repeated observation, a hash collision, a group-walk relation, an aliased frequency, or multiple problem solutions. Each meaning has its own witness and consequences; the name alone supplies no common recovery theorem.
