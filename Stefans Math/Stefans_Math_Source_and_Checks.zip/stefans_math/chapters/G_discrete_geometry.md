# Discrete geometry: coordinates, meshes and measurable curvature

## G1. Geometry becomes operational when its objects are realizable

A triangular or simplicial picture becomes a mathematical model after its vertices, edges, metric, and incidence rules have been specified. A simplex is the convex hull of d+1 affinely independent points in d-dimensional Euclidean space. Affine independence is essential: three collinear points do not define a nondegenerate triangle, and four coplanar points do not define a nondegenerate tetrahedron. An appealing list of pairwise distances must first pass a realization test.

Let the vertices be q_0,...,q_d and put B=[q_1-q_0,...,q_d-q_0]. When det(B) != 0, every point x has unique affine coordinates

```text
z = B^(-1)(x-q_0);
lambda_i = z_i, i=1,...,d;
lambda_0 = 1-sum_(i=1)^d z_i;
x = sum_(i=0)^d lambda_i*q_i;
sum_i lambda_i = 1.
```

PROVED G-P1. These formulas are inverse coordinate maps. Substituting z into q_0+Bz gives x. If two sets of coefficients with sum one represent the same x, subtracting the representations gives B(z-z')=0. Invertibility implies z=z' and then lambda_0=lambda'_0. Membership in the simplex additionally requires lambda_i >= 0 for every i, because those are exactly the convex-combination conditions.

For a triangle with vertices (0,0),(2,0),(0,3), B is diagonal with entries 2 and 3. The point (1/2,1) has z=(1/4,1/3), so its coordinates are (5/12,1/4,1/3). All are positive. The point (2,3) instead has coordinates (-1,1,1) and lies outside the triangle. The coordinate transformation still exists outside the simplex; the sign test determines which geometric region is being described.

An affine interpolant with vertex values f_0,...,f_d is f_h(x)=sum lambda_i(x)f_i. It reproduces every affine function because it reproduces constants and coordinates. Its gradient satisfies

```text
B^T * grad(f_h) = (f_1-f_0,...,f_d-f_0)^T;
grad(f_h) = B^(-T)*(f_1-f_0,...,f_d-f_0)^T.
```

For the preceding triangle, values (1,5,7) give f_h(x,y)=1+2x+2y. At (1/2,1) the value is 4, either by direct evaluation or the barycentric weighted sum. The triangle area is |det(B)|/2=3. The average affine value is (1+5+7)/3=13/3, so its integral is 13. This exactness is a property of affine functions; a nonlinear field requires an approximation-error contract.

## G2. Distances must satisfy a positive-definite Gram test

If only edge lengths l_ij are supplied, the candidate Gram matrix is

```text
G_ij = (l_0i^2+l_0j^2-l_ij^2)/2, i,j=1,...,d.
```

PROVED G-P2. A nondegenerate Euclidean simplex with those lengths exists exactly when G is positive definite. If vertices exist, G=B^T B by the polarization identity, so v^T Gv=||Bv||^2>0 for nonzero v. Conversely, a positive-definite G has a factorization G=B^T B. Taking the columns of B as vertex differences realizes the supplied lengths. A positive-semidefinite matrix can describe a degenerate lower-dimensional configuration and must not be presented as a nondegenerate d-simplex.

REFUTED G-R1. Face triangle inequalities alone suffice for a tetrahedron. Consider three edges from q_0 of length 1 and the three edges between the remaining vertices of length 19/10. Every face satisfies strict triangle inequalities. The Gram matrix has diagonal 1 and off-diagonal -161/200. Along the vector (1,1,1), its eigenvalue is 1-322/200=-61/100. A squared Euclidean length cannot be negative. The tetrahedron therefore does not exist despite its individually plausible faces.

Uniform scaling by s>0 sends B to sB, G to s^2G, and d-dimensional volume to s^d times its former value. Angles and barycentric coordinates remain unchanged. A triangular area scales by s^2; a tetrahedral volume scales by s^3. This dimensional bookkeeping is useful for mesh comparison. It does not establish a preferred scaling ratio or a physical law for a galaxy merely because one ratio is visually attractive.

The earlier simplex proposals include discrete scale invariance. Its valid elementary consequence can be stated directly: if a dimensionless function h(r) obeys h(lambda*r)=h(r) for lambda>1, then H(t)=h(exp(t)) is periodic with period ln(lambda). Indeed H(t+ln(lambda))=h(lambda*exp(t))=h(exp(t)). This consequence is conditional on the scale-invariance premise. The premise's emergence from a dynamical model, and the model's agreement with observations, require additional mathematics and data.

## G3. Discrete differentiation is an incidence operation

An oriented edge ij has a start vertex i and end vertex j. A vertex function f induces the edge difference (d0 f)(ij)=f(j)-f(i). An oriented face ijk has boundary edges ij,jk,ki. For an antisymmetric edge quantity w, define (d1 w)(ijk)=w(ij)+w(jk)+w(ki).

PROVED G-P3. Applying these operations successively gives zero:

```text
(d1*d0 f)(ijk)
 = [f(j)-f(i)]+[f(k)-f(j)]+[f(i)-f(k)]
 = 0.
```

The cancellation is exact and independent of edge lengths. The more general identity is that the boundary of a boundary vanishes, and coboundary matrices consequently satisfy d_(k+1)*d_k=0. This is a structural statement about incidence and orientation. A metric enters later when differences are assigned physical norms or converted into an adjoint operator.

For vertex values 2,5,11 on an oriented triangle, the edge differences are 3,6,-9. Their face sum is zero. For an independently supplied edge field (3,6,-8), the face sum is 1. That value detects inconsistency with a pure vertex potential on this face. It does not by itself locate the responsible edge; multiple fault assignments can yield the same sum.

The discrete Stokes identity states that summing a coboundary over a collection of oriented faces equals summing the original edge field over its boundary. Internal edges occur twice with opposite signs and cancel. A pair of adjacent triangles can therefore be checked either through its two face sums or through its outside loop. These are two calculations of the same incidence identity, not two independent measurements of the field.

For the triangle orientation 01,12,20, the matrices are

```text
d0 = [-1  1  0;
       0 -1  1;
       1  0 -1];
d1 = [1 1 1];
d1*d0 = [0 0 0].
```

This example supplies a compact exact implementation check. Changing an edge orientation requires changing its matrix signs consistently. Merely reversing a drawn arrow while retaining the old incidence row changes the model.

## G4. The metric supplies energy and diffusion

Choose positive-definite cochain metric matrices H_k. The weighted inner product is <u,v>_(H_k)=u^T H_k v. The adjoint of d_k is H_k^(-1)d_k^T H_(k+1). The corresponding Laplacian in degree k is

```text
L_k = d_k_adjoint*d_k + d_(k-1)*d_(k-1)_adjoint.
```

PROVED G-P4. Its energy is nonnegative:

```text
<w,L_k w>_(H_k)
 = ||d_k w||_(H_(k+1))^2
   + ||d_(k-1)_adjoint w||_(H_(k-1))^2 >= 0.
```

The formula follows by moving each differential across the inner product using its adjoint definition. A different signed or indefinite metric does not inherit this positive-energy conclusion. Declaring a matrix a Hodge star does not establish positivity or geometric admissibility.

With the identity metric on the preceding triangle, the vertex Laplacian is d0^T d0, with diagonal entries 2 and off-diagonal entries -1. The constant vector has eigenvalue zero. Every vector whose coordinates sum to zero has eigenvalue 3. Under df/dt=-L_0 f, the mean stays fixed and the deviations decay as exp(-3t). Starting from (2,5,11), the mean is 6 and

```text
f(t) = (6,6,6)+exp(-3t)*(-4,-1,5).
```

This is an exactly soluble finite diffusion model. Its monotone energy and conserved mean follow from the stated operator. They are not claims about every numerical time integrator: an explicit Euler step f'=f-hL_0f has deviation multiplier 1-3h. For energy nonincrease in this example, |1-3h|<=1, giving 0<=h<=2/3. A larger step can destabilize an otherwise dissipative continuous equation.

Cotangent weights on a Euclidean triangular mesh arise from integrating squared gradients of affine basis functions. Individual weights can be negative around obtuse triangles, while the assembled stiffness remains positive semidefinite as an integral of nonnegative energy. A Markov-chain interpretation needs stronger sign conditions than an energy interpretation. The familiar phrase graph Laplacian must therefore be accompanied by its actual coefficients and metric.

The relevant established framework is discrete exterior calculus; the primary Desbrun-Hirani-Leok-Marsden paper describes the simplicial and dual-complex setting. This chapter derives its limited incidence and weighted-energy identities directly. It imports no general continuum convergence or physical-gravity theorem from that attribution. [G-S1]

## G5. Angle deficits supply integrated curvature

For a piecewise-Euclidean triangulated two-manifold, let Theta(v) be the sum of incident face angles. At an interior vertex define k(v)=2*pi-Theta(v). At a boundary vertex define k_b(v)=pi-Theta(v). These quantities are integrated curvature or boundary turning angles. A pointwise density requires division by a specified area, and different area conventions can give different densities.

PROVED G-P5. For a finite triangulated two-manifold,

```text
sum_interior k(v)+sum_boundary k_b(v)
 = 2*pi*(V-E+F).
```

Every face contributes pi to the total angle sum. The left side is consequently 2*pi*V_int+pi*V_b-pi*F. For a manifold triangulation, 3F=2E_int+E_b and E_b=V_b. Substituting gives 2*pi*(V-E+F). The manifold and boundary assumptions are part of the proof; arbitrary glued complexes do not automatically satisfy the counting identities.

For a regular tetrahedral surface, three equilateral face angles meet at each vertex. Theta=pi and each deficit is pi. Four vertices give total curvature 4*pi. The combinatorial counts V=4,E=6,F=4 give Euler characteristic 2, so the right side is also 4*pi. A square disk divided into two triangles has V=4,E=5,F=2 and Euler characteristic 1. Its four boundary corner turns are pi/2, summing to 2*pi. A boundary contribution is necessary for that example.

Transport around a vertex can be defined by unfolding its Euclidean faces. With a fixed orientation convention, the frame mismatch is rotation by its deficit modulo 2*pi. Arbitrarily assigning independent edge rotations need not reproduce this metric transport. Moreover, exp(i*k)=1 means only that k is a multiple of 2*pi; it does not identify which multiple without an admissible range. A phase representation retains an angle class, not an unrestricted real angle.

The project curvature ratchet uses a_j=pi/2^(j+3) and repeatedly subtracts the largest permitted multiple of a_j from a positive target angle Theta*. After level N, the accumulated angle is

```text
Theta_N = a_N*floor(Theta*/a_N);
0 <= Theta*-Theta_N < a_N.
```

This is a valid dyadic approximation. For Theta*=5*pi/3, the initial counts are 13,0,1,0,1,0. At N=4 and N=5 the remainder is pi/384, with error bounds pi/128 and pi/256 respectively. Equal successive approximants do not mean the bound failed; a zero digit still increases declared precision.

The arithmetic approximation must be separated from mesh realization. Congruent right-isosceles faces offer angles pi/4 and pi/2. Gluing them cannot automatically realize every dyadic angle such as pi/8. Subdivision or a changed face palette can supply new wedges, but then shared edge lengths, vertex links, and global topology need fresh checks. A numerical angle list is a proposal for a geometry until those conditions pass.

## G6. Useful extension contracts and exercises

A mesh adapter should expose its oriented incidence matrices, its valid geometric realization, and its positive metric before reporting energy or diffusion. A curvature adapter should declare dimension and hinge type: vertices in a triangular surface, edges in a tetrahedral three-dimensional mesh, and triangles in a four-dimensional simplicial mesh play different roles. A scale-model adapter should distinguish an imposed scaling law from one derived from dynamics or measured in data.

Exercise G-E1. On the triangle (0,0),(2,0),(0,3), find coordinates of (1,1). Answer: (1/6,1/2,1/3). Its location is inside because all three coefficients are nonnegative.

Exercise G-E2. Decide whether a four-point distance set with all six lengths 1 is a valid tetrahedron. Answer: its Gram matrix has diagonal 1 and off-diagonal 1/2, with eigenvalues 2,1/2,1/2; it is positive definite and realizable.

Exercise G-E3. For the identity-metric triangle diffusion, compare Euler steps h=1/2 and h=1. Answer: their deviation multipliers are -1/2 and -2; the first decreases squared deviation by a factor 1/4, the second increases it by a factor 4.

Exercise G-E4. An oriented triangular sphere has V vertices and every vertex deficit zero. Can it satisfy the preceding assumptions? Answer: no. Its Euler characteristic is 2, so total deficit must be 4*pi. A claimed flat closed spherical mesh has violated some metric, topological, or deficit condition.

These examples show a useful version of the original geometric ambition. Coordinates, incidence, metric, energy, and topology can be compiled into separate checkable interfaces. Their relations are exact when their hypotheses are stated. The interfaces also identify where an attractive physical speculation still needs a model, an existence argument, or observational evidence.

G-S1. Mathieu Desbrun, Anil N. Hirani, Melvin Leok, Jerrold E. Marsden, Discrete Exterior Calculus, arXiv:math/0508341v2 (2005), https://arxiv.org/abs/math/0508341v2. Attribution to the established framework; chapter proofs are self-contained.
