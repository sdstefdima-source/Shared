# E1. Patterns as inspectable constructions

Stefan's pattern work begins with a practical question: which useful relationships can be exposed by reading the same objects in different ways? Residues reveal divisibility; differences reveal changes; windows reveal repeated local structure; array walks reveal relationships that an ordinary row scan misses. The useful unifying idea is a pattern construct. A construct specifies the observations, the reading order, the retained representation, the allowed relationship and the finite search domain. It is a reproducible mathematical question rather than an impression that two displays look alike.

Standard matching, automata, group actions and experimental design provide the established mathematics. Stefan's contribution to this compilation is the organizing approach: preserve several views of an object, search for relationships between them, and carry a witness back to the original observations. A transformation that simplifies recognition is valuable even when it loses information, provided that the lost distinctions remain explicit.

## E1.1 Observations, windows and relationships

Let x_c(n) be channel c at integer index n. A sampled window is

```text
W(i,w,s,c) = (x_c(i), x_c(i+s), ..., x_c(i+(w-1)s)).
```

Here i is the start, w is the number of samples and s is the sampling stride. A movement step changes i between comparisons; it does not change s. For finite data of length L, a legal window requires i>=0 and i+(w-1)s<L when s>0. Missing values are marked as missing and never silently converted into zeros. Every retained sample has a source identity: dataset revision, channel and physical index, or another declared event identifier.

A representation O may retain the raw word, its differences, centered values, ranks with ties, residues modulo M or valuations v_p. A relationship then compares O(W_A) and O(W_B). Literal equality preserves every typed value. Translation asks for y_j=x_j+delta. Affine matching asks for y_j=a*x_j+b. Equal totals preserve only one aggregate. Equal ranks preserve order and ties while discarding distances. These are distinct statements about the original data.

Example E1-A uses X=(3,1,4,1,5), Y=(13,11,14,11,15) and Z=(6,2,8,2,10). X and Y match by translation delta=10; X and Z match by scale a=2,b=0. Their common rank pattern does not distinguish translation from scaling. The sequence (3,2,1) has the same total as (1,2,3), but the opposite order. A claim about equal sums cannot be promoted into equal ordered windows.

PROVED E1-P1: two nonempty equal-width integer windows differ by one constant exactly when their successive differences agree. Translation cancels in subtraction. Conversely, if y_(j+1)-y_j=x_(j+1)-x_j, then y_(j+1)-x_(j+1)=y_j-x_j; induction makes every difference equal to y_0-x_0. Thus a translation matcher can index difference words, then retain the offset as its witness. At width one the condition is automatic and supplies no structural evidence.

Exact integer or rational calculations should decide exact relations. Numerical affine fitting instead has an APPROXIMATE contract: a stated residual norm, tolerance, support size and degeneracy policy. A constant source window cannot identify an affine slope. Allowing a=0 also makes affine matching directional: every window can map to a constant target, while the inverse relation need not exist. Calling every such fit an equivalence class would be mathematically wrong.

Example E1-B concerns sampling. The tape 2,7,2,7,... yields the constant word 2,2,2,... when read from index zero with stride two. The observed word is constant; the tape is not. An observation map can erase a period component. The construct must therefore retain its stride before a statement is translated back to the tape.

## E1.2 Two moving heads and a comparison map

For equal contiguous widths define D_w(i,j) as the Hamming distance between W(i,w,1,c) and W(j,w,1,c). It counts unequal aligned symbols. On binary words it also equals the squared raw Euclidean distance. The matrix of these distances organizes several familiar tasks. Fixing i gives a distance profile. Keeping j-i fixed follows a diagonal. Recording the least permitted entry in each row gives a nearest-window profile. Thresholding the entries gives a recurrence map.

The matrix-profile literature uses this same all-pairs organization with z-normalized Euclidean windows [E-R1]. The present Hamming version changes the metric deliberately. A constant binary window has zero standard deviation, so its z-normalization needs an explicit convention. An exclusion zone can remove self-matches and near-overlap matches, but it is a search rule, not a statistical independence certificate.

PROVED E1-P2 is the diagonal update

```text
D_w(i+1,j+1) = D_w(i,j)
                 - 1[x(i)!=x(j)] + 1[x(i+w)!=x(j+w)].
```

Every old interior alignment remains; one old pair departs and one new pair enters. The same argument updates an aligned product sum by subtracting its departing product and adding its entering product. This avoids rescanning w pairs for each common one-step movement.

Example E1-C uses the tape (1,0,1,1,0,0,1). Width-three windows at starts zero and three are (1,0,1) and (1,0,0), giving distance one. Moving both starts one step gives (0,1,1) and (0,0,1), also distance one. The departing comparison is 1 versus 1 and the entering comparison is 1 versus 1, so both boundary contributions are zero. If only one head moves, interior alignments change and the recurrence no longer applies. Independent movements need recomputation or a separately proved update.

Widths, strides, channels and allowed transformations enlarge the hypothesis search. A smallest distance selected from thousands of comparisons is still a descriptive optimum. Dividing by width changes units; it supplies no probability calibration. A complete comparison report records the number of visited constructs, the exclusions, ties and any unsearched scope caused by a resource budget.

## E1.3 The state must retain the information that affects the future

A state machine is useful when the retained state determines legal next states or their declared probabilities. Under independent identically distributed fair incoming bits, an ordered width-w trailing word is a first-order Markov state: remove its oldest bit and append one fresh bit. A graph alone identifies possible transitions. A probabilistic transition law requires the incoming-bit assumption as well.

Example E1-D explains why a count is often inadequate. Both words 01 and 10 contain one 1. From 01, appending a fair bit produces counts one or two with probabilities one half each. From 10 it produces counts zero or one. The two hidden words were merged, but their successor laws differ. The count process cannot inherit a first-order Markov law merely because the ordered word has one.

The stationary width-two count process actually has no finite Markov order. For any proposed memory length m, consider a count history beginning at zero followed by m counts of one, and another beginning at two followed by the same suffix of ones. Count zero forces terminal bit zero; count two forces terminal bit one. Each subsequent count one forces the terminal bit to flip. The terminal bits therefore remain opposite despite the arbitrarily long identical observed suffix. Their next-count probabilities differ, and both histories have positive probability under fair bits. No fixed m suffices.

This is an observation-memory issue rather than a need for infinitely many hidden physical states. Let u be the conditional probability that the latest hidden bit is one given the entire count history. The next counts zero, one and two have probabilities ((1-u)/2,1/2,u/2). After observing them, u becomes zero, 1-u or one respectively. With stationary initialization the belief state takes only the values zero, one half and one. A small recursively updated belief can retain information that no fixed recent count suffix retains.

Two heads reading one unknown fixed tape introduce another memory requirement. Revisiting an old physical index reveals a value already known. Even if that index has left both current windows, its value is not a fresh independent bit. A revealed-index cache or equivalent sufficient state is required. For a fully specified deterministic arithmetic tape, positions and settings can determine the output exactly; that is a different model from an unknown random tape.

## E1.4 Coordinate walks, symmetries and exact indexing

An array walk maps an ordered visit number to a row and column. A row, column, diagonal, serpentine path or custom step word can all feed the same window machinery. The coordinate map remains part of the result. A repeated symbol word on a diagonal and a repeated square patch are different relationships: the latter verifies the complete two-dimensional arrangement.

For an R-by-C wrapped grid, a repeating step word of length L has augmented state (row,column,next-step phase). Let its total displacement be (a,b). After L moves the phase returns and the coordinates translate by (a,b) in Z/RZ times Z/CZ. PROVED E1-P3 gives the exact augmented period

```text
T = L*lcm(R/gcd(R,a), C/gcd(C,b)).
```

Returning the phase requires a multiple of L, and the remaining factor is the order of the total translation. Example E1-E uses one row, two columns and steps right,right,stay. The starting cell is revisited after two moves, but the step phase differs. The full state returns after three moves. A cell-only repeat detector stops too soon.

A square patch has eight rigid orientations, forming the standard group D4. Taking the least complete serialization over its eight orientations defines an exact canonical representative. Equal representatives mean equal orbits: transformations taking the two patches to their common representative compose to a transformation between them. The result should retain that orientation witness. A symmetric patch may have fewer than eight distinct images, so it must not be counted eight times automatically.

Example E1-F has patch rows (1,2) and (3,4). Its clockwise rotation has rows (3,1) and (4,2). They share the same D4 representative while their row words differ. A diagonal word agreement alone would not verify this patch relation. Canonicalization intentionally identifies permitted symmetries. A hash collision is an unintended information loss and has a different role.

A rolling fingerprint of a token word is

```text
h = sum_(j=0)^(w-1) token_j * B^(w-1-j) mod M.
h_next = ((h-token_out*B^(w-1))*B+token_in) mod M.
```

Equal words have equal fingerprints; the reverse implication fails. The safe matcher indexes by fingerprint, then compares complete typed values. If every fingerprint is deliberately forced to zero, all candidates enter one bucket and the accepted match set must remain unchanged. This tests correctness under total loss of filtering power. A fixed polynomial hash can improve a workload while supplying no randomized collision bound and no cryptographic authentication.

Dictionary matching reuses a prefix automaton and suffix fallback links to recognize many literal patterns in one traversal. Walk boundaries and missing cells reset its state unless concatenation is explicitly part of the input. Inserting the final value of one row beside the first value of an unrelated column would otherwise manufacture a match. Correctness means reproducing the declared direct match set, including overlaps; speed is a separate measured claim.

## E1.5 Repairing the modular multiscale hash proposal

The supplemental hashing proposal constructs a sampled carrier R(k)=sum a_j*cos(2*pi*lambda_j*k/N+theta_j), quantizes it as floor(C*R(k)), folds it modulo m and adds a small arithmetic perturbation. This is a well-defined candidate address map once all parameters and numerical conventions are fixed. It is not automatically uniform, independent across salts, hard to invert or efficient. Those conclusions require a model or benchmark beyond the compositional formula.

REFUTED E1-C1 concerns the full-cycle probe claim. A linear probe a_t=a_0+t*g modulo m visits every bucket when gcd(g,m)=1. An arbitrary added perturbation can destroy this property: adding -t*g makes every address equal a_0. Even a periodic perturbation with a period coprime to m can repeat heavily in its first m steps. With m=5,g=1,a_0=0 and period-four offsets (0,4,3,2), the first five addresses are 0,0,0,0,4. Three buckets have not been visited.

A repaired full-cycle design uses a proved permutation pi of the bucket set:

```text
a_t = pi((a_0+t*g) mod m), gcd(g,m)=1.
```

The inner sequence visits every residue once, and a permutation preserves that coverage. A multiscale field can rank or propose such a permutation during construction; duplicate proposed addresses must be resolved before the permutation is accepted. If an offset has period N and gcd(N*g,m)=1, a longer contract is also possible: holding its phase fixed while t advances by N visits all m buckets, so m*N steps suffice. That does not prove coverage in the first m probes or make a small fixed probe cap complete.

REFUTED E1-C2 concerns the specified high-frequency lattice. At N=2^16,b=2,lambda_j=2^(j^2), every j>=4 has lambda_j divisible by N. At integer k its cosine becomes cos(theta_j), constant over the whole lattice. Adding more such terms changes the offset but supplies no finer sampled oscillation. Frequencies should be reduced modulo N before assessing distinct modes. A finite cosine sum is smooth in its continuous argument; an infinite fractal regularity claim needs separate hypotheses and proof.

Quantization introduces a further reproducibility obligation. Tiny numerical errors near an integer boundary can change floor(C*R(k)) and therefore a bucket address. Persisting the final integer lookup table and its checksum makes the operational map exact after construction. Cross-platform regeneration requires specified arithmetic or certified distance from every quantization threshold. This is a useful engineering repair, not evidence that the map is cryptographically secure.

The experiment contract compares the same key sets, loads and operation histories against a baseline. It includes sequential keys, arithmetic progressions, common-prefix strings, repeated keys, deletions, tombstones and deliberately colliding encodings. It measures cold build cost, warm query cost, memory, probe distribution, stash use and complete key equality. The source prehash can already dominate dispersion; removing the new layer is therefore a necessary control. A short fingerprint never replaces the full key comparison.

## E1.6 A reusable pattern-search contract

An investigation begins by freezing the dataset revision and construct grammar. It enumerates legal windows or paths, computes the chosen representation, proposes relationships and verifies each accepted witness against the underlying samples. An index may reduce comparisons, but cannot silently remove candidates unless its exclusion is proved sound. A bounded run returns both results and unfinished scope. Its descriptive best match stays HEURISTIC as a predictor until tested under a separate prediction contract.

Exercise E1-X1 asks whether equal differences imply equal raw words. They imply translation, not literal equality; one initial aligned value is additionally sufficient. Exercise E1-X2 asks whether visiting every lag modulo M visits every pair of two absolute head phases. It does not: one constant-stride trajectory has at most M states, while the pair space has M^2 states. Exercise E1-X3 asks whether a row match and a serpentine match reading the same cells count as two independent discoveries. They are two descriptions of the same physical support. These answers give operational tests for the most common representation and provenance mistakes.

# E2. Arithmetic regularity, prime filters and discrepancy

Arithmetic often produces strong nonrandom-looking patterns for elementary reasons. Parity forbids some offsets. Residue classes synchronize divisibility. Carries synchronize digit signs. A graph can favor long surviving regions because short regions are killed sooner. These are useful structures to find and explain. Their interpretation depends on the object being counted: allowed residue classes, actual primes, sign correlations or admissible paths. The same attractive plot can represent very different mathematical claims.

Stefan's prime investigations become most useful as exact filters and organized tests of arithmetic explanations. Prime generation means producing a number with a complete primality certificate. A residue survivor is a candidate until all required divisibility checks or another complete test have been performed. A finite local density is an exact counting theorem on its declared wheel. Predicting an ordinary prime interval from that density is a separate HEURISTIC step.

## E2.1 Prime wheels and the support of an offset

For the pair n,n+h, a prime p excludes n==0 and n==-h modulo p. These classes coincide if p divides h; otherwise they are distinct. Hence the number of allowed classes is p-1 or p-2 respectively. The Chinese remainder theorem gives the exact product of these counts over a finite collection of distinct primes. Independence here is a property of the uniform distribution over the complete CRT period, not a claim about arbitrary short intervals.

Example E2-A uses M=2*3*5*7*11=2310. At h=2 the allowed count is 1*1*3*5*9=135. At h=6 it is 1*2*3*5*9=270. At h=30 it is 1*2*4*5*9=360. Offsets 2,4,8,32 and 64 have the same prime support within this wheel and the same count 135. Increasing a prime exponent already present in h changes no first-level wheel factor. An odd h has zero allowed classes at p=2. Actual odd-gap prime pairs remain possible when one endpoint is the exceptional prime 2, which the raw wheel removes.

The original primorial-center construction instead fixes W=210 and examines L(k)=210k-1,R(k)=210k+1 for k>=1. Both endpoints escape the wheel primes 2,3,5 and 7. For an external prime p>7, the forbidden k classes are +/-210^(-1) modulo p. A finite external wheel therefore has product (p-2) survivors. This searches a particular center subfamily; most twin-prime centers need not be divisible by 210.

Example E2-B has k=1, giving 209=11*19 and 211. Modulo 11,210==1, so k==1 is an immediate left obstruction. Modulo 13,210==2 and 2^(-1)==7, so forbidden parameters are 7 and 6. Every prime through floor(sqrt(211))=14 is now accounted for: 211 is prime, while its partner is composite. At k=2 the endpoints are 419 and 421; trial divisibility through 20 certifies both prime. This is a functioning sieve, not an infinite twin-prime theorem.

The split algebra F_p[e]/(e^2-1) packages the two branches. Because p is odd, evaluation at e=1 and e=-1 identifies it with F_p times F_p. The element 1+210k*e has norm 1-(210k)^2, the negative endpoint product. Its norm vanishes precisely when an endpoint is divisible by p. This is a split algebra, not a quadratic field. Multiplicative exponent coordinates can organize the nonzero k residues, but require a separate zero state and do not make integer addition into exponent addition.

## E2.2 A square shell and higher-root filters

The original resonator notes choose a known prime p and the shell D={n:p<n<=p^2}. Knowledge of every prime q<=p suffices to classify this shell exactly. PROVED E2-P1: if n is composite, write n=a*b with 1<a<=b, so a<=sqrt(n). Some prime divisor of a is at most sqrt(n)<=p. Conversely a prime n>p has no divisor q<=p. Thus survival of all those divisibility tests is exactly primality on D. The shell is a finite integer set; it has no automatically inherited finite-field structure.

The roots-of-unity projector gives an exact identity

```text
D_d(n) = (1/d)*sum_(j=0)^(d-1) exp(2*pi*i*j*n/d)
       = 1[d divides n], for integer n.
T_p(n) = product_(q prime,q<=p) (1-D_q(n)).
```

If d does not divide n, the geometric ratio z=exp(2*pi*i*n/d) is not one, while z^d=1, so the sum is (1-z^d)/(1-z)=0. This proof does not require the phases to be all distinct: when gcd(n,d)>1, some roots repeat. Integer remainder tests implement the same Boolean decision exactly without numerical cancellation.

Example E2-C uses p=11,X=121. Prime 97 passes the complete list 2,3,5,7,11. Number 77 passes the cube-root list 2,3 because X^(1/3)<5, but 77=7*11 fails the square-root layer. Number 121 fails at 11 and activates the prime-square channel. Number 64 activates the divisibility channels 2,4,8,16,32 and 64; subtracting consecutive cumulative detectors isolates its exact valuation v_2(64)=6.

PROVED E2-P2 is the higher-root roughness bound. Suppose 1<n<=X and n avoids every prime q with q^k<=X. Every prime factor of n exceeds X^(1/k). If n had at least k prime factors counted with multiplicity, their product would exceed X, a contradiction. Therefore n has at most k-1 factors. The converse fails: the semiprime 6 has only two factors but fails many cube-root filters at larger X. Higher k gives a weaker filter, because it tests fewer primes. Using the exact integer comparison q^k<=X avoids rounding at a root boundary.

The zeta-related layer has a different job. At x>=2 define the finite weighted prime-power count J(x)=sum_(e>=1) pi(x^(1/e))/e. Only e<=log_2(x) contribute. Ordinary prime counting is recovered by the finite identity pi(x)=sum_(m>=1) mu(m)*J(x^(1/m))/m. Substitution groups the coefficient of pi(x^(1/r)) as (1/r)*sum_(m divides r)mu(m); it is one at r=1 and zero otherwise. This is the exact algebra behind removing prime-power repetitions.

Example E2-D has J(16)=6+1+1/3+1/4=91/12. The six primes contribute six, the squares 4 and 9 contribute one, 8 contributes one third and 16 one quarter. The inversion subtracts J(4)/2=5/4 and J(16^(1/3))/3=1/3, yielding six. No numerical zeta zeros are needed. A finite sum of zero modes can visualize an approximate global fluctuation, but supplies no exact integer prime indicator without an independently proved remainder bound and endpoint conventions. The complete divisibility layer remains the verifier.

## E2.3 Euler's quadratic and shifted exclusions

For F(n)=n^2+n+41,

```text
4F(n)=(2n+1)^2+163,
F(-n-1)=F(n),
F(n+h)-F(n)=h*(2n+h+1).
```

Direct reduction at every prime below 41 gives no root. Consequently none of those primes divides any F(n), for all integer n. At n=0,...,39, the values lie between 41 and 1601, below 41^2. A composite there would require a prime divisor below 41, which is impossible. These forty values are therefore prime. At n=40 the value is 41^2. Reflection gives eighty input positions from -40 to 39 but only forty distinct prime values.

For odd p not dividing h, common roots of F(n) and F(n+h) modulo p^k are forced by subtraction to n==-(h+1)/2. Substituting gives 4F(n)==h^2+163. PROVED E2-P3: there is exactly one common residue if p^k divides h^2+163, and none otherwise. Division by 2h is legitimate under the hypotheses; it must not be imported when p divides h.

Example E2-E takes h=2 and p=167, since h^2+163=167. The common residue is -(3)/2==82 modulo 167. Indeed F(82)=41*167 and F(84)=43*167. At h=81, h^2+163=4*41^2, so the common-root overlap at p=41 persists through precision two but stops at three. First-level prime survival is unchanged by that extra depth; it describes the interior structure of a class already excluded for divisibility.

Let R_p be the roots of F modulo p, rho_p their number and c_p(h)=|R_p intersect (R_p-h)|. The pair filter allows p-2*rho_p+c_p(h) classes, by inclusion-exclusion. Multiplying these counts over a finite CRT wheel is exact. Peaks at selected offsets can therefore have ordinary explanations in overlapping forbidden classes. A local factor computed from only two primes can miss an advantage caused by a third prime. The factor must be interpreted as a finite filter statistic before any prime-density prediction is fitted.

The mask A(n)=1[gcd(F(n),1763)=1],1763=41*43, illustrates the difference. It has 1599 allowed phases. Many are composite-valued: F(49)=47*53 survives both filters. Treating A as a prime label would fail even at this small input. Prime-preserving sieves also retain equality cases: F(0)=41 and F(1)=43 are prime although their corresponding divisibility bits fire.

## E2.4 Precision trees can expand and terminate

Prime-power lifting refines divisibility, not primality. A product root modulo p^k means v_p(F(n))+v_p(F(n+h))>=k. It need not mean either factor individually vanishes modulo p^k. Common roots, union roots and product roots are separate sets.

Example E2-F has p=h=41,n=0. The two factors are 41 and 41*43, neither divisible by 41^2, while their product is divisible by 41^2. No field-style inference from a zero product is valid in the residue ring Z/41^2 Z.

A sharper example uses p=h=163. The only first-level root is n==81, and

```text
F(81+163t)=163*(41+163*(t+t^2)).
```

The factor in parentheses is 41 modulo 163, so its valuation is exactly one. The shifted factor has the same property. Their product has one root modulo 163,163 roots modulo 163^2, and no roots modulo 163^3. Every apparently abundant second-level branch dies. The identity proves there are no later branches. A precision ratchet requires compatible survival through later levels; a wide finite layer alone is no convergence certificate.

## E2.5 Digits, carries and exact imbalance

The binary digit sign t(n)=(-1)^(s_2(n)), where s_2 counts one bits, is the standard Thue-Morse sign sequence. Reading digits requires only a parity state; its values satisfy t(2n)=t(n),t(2n+1)=-t(n). Addition can nevertheless create a structured signal. Adding one changes a run of trailing ones and the preceding zero; the run length is v_2(n+1). Thus

```text
t(n)*t(n+1) = -(-1)^v_2(n+1).
```

Example E2-G compares n=7 and n=8. Binary 111 has three ones, so t(7)=-1; 1000 has one, so t(8)=-1. Their product is +1, matching -(-1)^3. At n=8 the increment to 9 changes one zero to one, giving product -1. A deterministic carry rule creates correlation without any randomness assumption.

In every odd base b, s_b(n)==n modulo 2 because all powers of b are odd. Consequently odd-base digit parity is simply ordinary parity. A ternary sign scan that puts every odd prime in one channel has found this identity, not a new prime law. Grouping binary digits into base four preserves the binary digit parity; changing to ternary parity defines another sequence.

For an odd prime p, the completed quadratic-character sequence strips powers of p: f(n)=epsilon^(v_p(n))*chi_p(n/p^(v_p(n))),epsilon in {-1,+1}. Here chi_p is +1 on nonzero squares and -1 on nonsquares. Full blocks of nonmultiples cancel, while multiples provide a smaller signed copy. If B(r)=sum_(a=1)^r chi_p(a), then

```text
S(pm+r)=epsilon*S(m)+B(r), 0<=r<p.
```

At p=3,epsilon=+1,B(0)=B(2)=0,B(1)=1, so S(N) equals the number of ternary digits equal to one. Example E2-H gives N=1,4,13,40,121, with sums 1,2,3,4,5. Slow growth is still unbounded. A finite-state sign generator does not imply a bounded accumulated sum.

## E2.6 Shared progression constraints and exact finite search

For a sign sequence f on positive integers define S_d(k)=sum_(j=1)^k f(dj) and D_N=max_(dk<=N)|S_d(k)|. Ordinary prefix balance concerns d=1; discrepancy concerns every homogeneous progression. The alternating sequence f(n)=(-1)^(n+1) has ordinary partial sums bounded by one, but S_2(k)=-k. Local balance can hide arbitrarily large drift on another sampling pattern.

A finite search assigns f(t+1) and updates exactly the counters whose spacing d divides t+1. Rejecting a branch when any updated counter exceeds a declared bound C is sound. Every old progression prefix was checked earlier, and every newly completed prefix is one of those updated counters. Induction proves that surviving words satisfy all original constraints. At a fixed depth the complete counter vector determines future legality in the unrestricted model. A multiplicative model must additionally enforce prime-factor choices.

Example E2-I gives the length-eleven word (+,-,-,+,-,+,+,-,-,+,+), valid at C=1. Before position twelve its spacing-one sum is +1 and needs a negative next sign; its spacing-three sum is -1 and needs a positive next sign. The shared position cannot satisfy both. Complete enumeration gives four valid words at length eleven and none at twelve, proving the finite impossibility. This is a compatibility contradiction, not a statistical rarity argument.

Complete multiplicativity is an additional condition f(ab)=f(a)f(b). Choosing prime signs determines composite signs by unique factorization, gives f(n^2)=1 and S_d(k)=f(d)S_1(k). Under independent fair prime choices, E[f(n)] is one for squares and zero otherwise; E[f(a)f(b)] is one when ab is a square. At N=20 the complete 256-assignment ensemble has final-sum mean four, second moment 42 and variance 26. Independent fair signs at integer positions instead have mean zero and variance 20. The two meanings of random signs are measurably different.

Tao's Erdos discrepancy theorem establishes unbounded discrepancy for every infinite +/-1 sequence [E-R2]. The custom digit examples and finite search above illustrate particular mechanisms; they are not a replacement proof of that general result. Exercise E2-X1 asks why zeros in a raw character sequence matter. Its values are not all +/-1, so the theorem's hypothesis fails. Exercise E2-X2 asks whether survival of a cube-root filter certifies prime. It permits semiprimes, as 77 demonstrates. Exercise E2-X3 asks whether addition is entropy. Addition changes a quantity; entropy requires a probability distribution and a specified random variable.

# E3. Useful inference with explicit evidence contracts

Pattern search suggests hypotheses; exact verification eliminates impossible states; statistics compares uncertain explanations under a declared model. These activities can cooperate, but their conclusions have different meanings. A sound exact filter preserves the solution set S inside its candidate enclosure C. A probability model assigns weights to states in C. A statistical confidence procedure controls a repeated-sampling error event. A fitted score ranks relationships in observed data. Converting one of these objects into another without an additional argument is a central source of mistakes.

Stefan's incomplete-information proposal becomes operational when the hidden state, transition, observation, dependence and evidence goal are specified together. A useful result can be a small exact candidate set, a noisy posterior with unresolved aliases, a selected probe that breaks a symmetry or an alarm process with a stated false-alarm bound. A sharply concentrated number alone does not certify that the assumptions producing it are true.

## E3.1 Hard support, likelihood and state evolution

For a finite hidden state x_t, fixed parameter theta, transition K_theta and observation likelihood L_t, an unnormalized filtering step is

```text
w_t(x,theta) = 1_C_t(x,theta)*L_t(y_t|x,theta)
               *sum_u K_theta(u,x)*w_(t-1)(u,theta).
```

Normalize by the total weight when it is positive. The equation follows by summing over the previous state and applying Bayes' rule. It assumes that the chosen state retains every variable needed for this factorization. Unknown timing, correlated errors and revisited physical sources may require extra state components or a joint likelihood.

A hard support bound excludes an impossible state. A small positive likelihood leaves it possible under the model. If every weight becomes zero, the hard assumptions and observations are inconsistent; this diagnoses the contract, not the absence of reality. A noisy report outside a state's physical range can still be possible if the sensor channel permits that report.

Example E3-A uses three candidate integers {2,5,8}, uniform prior, and a noisy modulo-three sensor. It reports the correct residue with probability 4/5 and each wrong residue with probability 1/10. All three candidates predict residue two. Observing two multiplies each weight by eight relative to a mismatch, but preserves their equal odds. Repeating the same precision with independent sensor errors strengthens evidence for the shared residue class while adding no information inside it. A new modulo-five reading predicts three distinct symbols and can change their relative weights.

If a modulo-five channel is correct with probability 4/5 and distributes its remaining probability equally among the four wrong symbols, a favorable independent reading supplies likelihood odds 16:1 against a particular incorrect candidate. Four independent reports supply 16^4=65536:1. Four copies of one source event supply 16:1. Once the first report is known, its copies have conditional probability one under either state and contribute no new likelihood ratio.

This extends to coordinate transforms. A residue, a logarithm and a Fourier representation derived from one observation are three descriptions of that observation. They can reveal useful structure to the solver but cannot be multiplied as three independent sensor events. Source lineage is part of the mathematical likelihood, not merely an archival convenience.

## E3.2 Symmetry proves when another kind of observation is needed

Let sigma be a permutation of the finite hidden-state domain. Require pointwise prior invariance pi_0(sigma(x))=pi_0(x), invariant hard support sigma(C_t)=C_t, transition equivariance K(sigma(u),sigma(x))=K(u,x), and likelihood invariance L_t(y|sigma(x))=L_t(y|x). Reindexing the predecessor sum by the permutation proves by induction that x and sigma(x) retain equal weights after every observation. A policy selecting its next action only from past invariant observations has the same action law in both cases. If every chosen action's transitions, likelihoods and hard-support updates preserve the same symmetry, induction after each action preserves the alias. More measurements of the same invariant kind cannot identify its members.

The hard-support condition is essential. Candidates two and five give identical modulo-three observations. A separately justified bound x<3 selects two and destroys their exchange symmetry. Thus an independent exact constraint can distinguish an observation alias just as a new sensor channel can. The theorem forbids identification only while every applied part of the model preserves that alias.

Example E3-B uses F_9=F_3[u]/(u^2+1). The polynomial has no root in F_3, so this quotient is a field. Write z=a+b*u. Its Frobenius conjugate is a-b*u, its trace is 2a and its norm is a^2+b^2. The elements 1+u and 1-u both have trace two and norm two. Dynamics z_t=z_0+t satisfy

```text
Tr(z+t)=Tr(z)+2t,
N(z+t)=N(z)+t*Tr(z)+t^2.
```

Every invariant time record is determined by the initial pair. A basis-sensitive observation of b breaks the ambiguity. The field F_9 is distinct from Z/9Z; the latter contains nonzero zero divisors. Integer labels attached to field elements introduce no intrinsic interval order.

The same time record can protect the information that it does contain. For t=0,1,2, interleave trace and norm to form a six-symbol ternary codeword. There are six conjugacy orbits. Different traces differ in all three trace coordinates and two norm coordinates, giving distance five. With equal trace and different norm, all three norm coordinates differ, giving distance three. Minimum distance three means one arbitrary symbol error can be corrected to the orbit. It does not resolve the two-member orbit, nor guarantee correction of two errors.

For a uniform prior on all nine field elements, perfect invariant information leaves average uncertainty 2/3 bit: six elements belong to pairs, each contributing one conditional bit, while three singletons contribute zero. Conditioning on one selected pair instead leaves exactly one bit. These are different averaging questions. Entropy is H=-sum p_x*log_2(p_x), with 0*log(0)=0 by continuity; it is not a count difference or an arithmetic operation itself.

## E3.3 Candidate partitions and active probes

For a finite hypothesis family H and exact observation map O_q at query q, the response partitions H into fibers H_j. Under a uniform prior, the probability of response j is |H_j|/|H| and the surviving count is |H_j|. Therefore the expected surviving count is sum_j |H_j|^2/|H|. Dividing expected elimination by a positive query cost is a defensible experiment objective. It is different from maximizing Shannon information, and the two need not rank queries identically.

Example E3-C uses f_d(n)=n+d*n*(n-1)/2 for d=-2,-1,0,1,2. Every rule gives zero at n=0 and one at n=1. Querying n=2 gives the distinct predictions 0,1,2,3,4. Under the uniform five-rule prior, expected survivors fall from five to one, an elimination gain of four. A rule outside this grammar can still agree at all three positions. Exact identification within H is not a proof that H contains the true rule.

A version-space algorithm fits only on designated training observations, retains candidates consistent with them, then checks additional unrevealed observations without refitting. A falsified candidate remains falsified. Missing values supply no contradiction. Duplicate syntactic formulas with identical predictions on the declared query pool should not acquire extra default weight merely because they have several descriptions.

Positive tolerance changes this partition logic. If two predictions are 10 and 11 with acceptance tolerance one, an observation of 10.5 is compatible with both. Distinct predicted means do not define disjoint response fibers. A noisy active design needs an explicit likelihood and expected posterior calculation, or a worst-case compatible-set objective. The exact partition formula cannot be borrowed unchanged.

The periodic mask A(n)=1[gcd(F(n),1763)=1] supplies a concrete finite phase problem. Ordered width-42 cyclic words leave five two-member collision fibers; width 43 distinguishes all 1763 phases. Prefix refinement means shorter words cannot distinguish a pair still colliding at width 42. Thus the minimum identifying width is 43 for this fixed known mask. Its equality with a filter prime is a property of this example, not a universal rule about identifying lengths.

A different structural reconstruction result concerns all M-periodic rational tapes, with positive integers M and w. For C_w(n)=sum_(r=0)^(w-1)x(n+r), PROVED E3-P1 gives kernel dimension gcd(M,w)-1. If C_w is zero, adjacent differences imply x(n+w)=x(n). Together with M-periodicity this forces d-periodicity for d=gcd(M,w). Each window consists of w/d copies of its d entries, whose sum must be zero. Conversely every zero-sum d-periodic tape gives zero C_w. There are d-1 free coordinates over Q. Hence C_w is invertible exactly when gcd(M,w)=1.

Example E3-D uses M=6,w=2. The nonzero tape (1,-1,1,-1,1,-1) has every window sum zero, proving information loss. At w=5 the gcd is one and the operator is invertible over Q. One count remains ambiguous; the complete count record can identify the tape. Changing the coefficient characteristic can change the rank and must be checked separately.

## E3.4 Conditioning can create a peak without a new physical mechanism

Consider a lazy walk on positions 1,...,9 with left/right probability one quarter and hold probability one half, killed on exit. Multiplying its substochastic transition matrix Q by four gives an integer matrix W counting four equally likely move labels, including two hold labels. If H_r=W^r*1 counts future surviving continuations, then conditional on survival for r further steps,

```text
P_r(i,j)=W(i,j)*H_(r-1)(j)/H_r(i).
```

Its row sum is one by the recurrence. Products along a path telescope, so it is exactly the original path law conditioned on the specified finite survival horizon.

Example E3-E begins at position one. Survival for one step leaves two hold labels and one inward label, so the conditional inward probability is one third rather than one quarter. Paths escaping left have been removed. This apparent inward preference requires no new force. Reflecting a forbidden move into a hold would define a different process.

For a component of L consecutive allowed sites, h_i=sin(i*pi/(L+1)) is a positive eigenvector of Q. The sine addition identity gives eigenvalue lambda_L=(1+cos(pi/(L+1)))/2. It grows strictly with L. Thus, from an initial mixture placing positive mass in all components, long survival eventually favors a unique longest component. A fixed starting point in another disconnected component cannot travel to it.

For completeness, the other sine modes use k*pi/(L+1),k=2,...,L, and have strictly smaller eigenvalues. Orthogonality gives a full eigenbasis because Q is symmetric. A nonnegative nonzero starting distribution has positive inner product with the positive first mode. Its surviving mass is therefore a positive constant times lambda_L^t plus lower-order modes. Comparing these exponential rates proves the component-selection statement. Conditioning on zero-probability eternal survival is not used; the construction takes the limit of specified finite survival horizons.

The 1763-phase arithmetic mask splits into 117 nearest-neighbor components; the unique longest consists of phases 862 through 900. Its center is 881, and F(881)=777083=853*911, composite. A survival peak at that location is an exact consequence of mask geometry and the added walk model. It is not prime-generation evidence. The conditional endpoint law on a long component is proportional to h_i; the stationary law of the limiting conditioned process is proportional to h_i^2. Distinguishing these laws prevents a second misinterpretation of the same plot.

Indeed its limiting transition is P*(i,j)=Q(i,j)*h_j/(lambda_L*h_i). Its row sum is one by the eigenvector equation. Since Q is symmetric, h_i^2*P*(i,j)=h_j^2*P*(j,i), proving the stated stationary law by detailed balance. This supplies the exact distinction between where long surviving paths end and how the limiting conditioned chain spends its time.

## E3.5 Overlap and multiple searches change error probabilities

Under independent Bernoulli(p) source bits with 0<p<1, sums over index sets A and B have covariance p*(1-p)*|A intersect B|. Expanding the covariance leaves only identical source indices, since distinct inputs are independent. Equal width-w windows at lag h therefore have correlation max(1-|h|/w,0). High adjacent-window correlation occurs even in independent input.

In the difference of the two window sums, shared bits cancel. At nonnegative lag h there are m=min(w,h) exclusive bits on either side, so the absolute difference is at most m. With fair bits, complementing each subtracted bit shows that difference+m has Binomial(2m,1/2) distribution. Its variance is m/2. This is a hard range and an exact distribution under the fair-input model, respectively.

Example E3-F has w=5,h=2,m=2. The difference probabilities at -2,-1,0,1,2 are 1,4,6,4,1 divided by 16. Treating the ten displayed window entries as ten independent sources would give the wrong variance: six displayed positions are duplicate readings of the three shared physical indices. Source provenance determines the distribution.

A correct local test can still give incorrect whole-search error control. Testing many widths, lags and starts and reporting the smallest p-value changes the statistic being tested. Complete finite-null enumeration can calibrate the whole scan, including its selection rule. Alternatively a union bound controls a prespecified finite family without requiring independence, though it can be conservative. A held-out block avoids refitting on the same targets, but a deterministic arithmetic interval is not automatically an independent identically distributed sample. Changing size-dependent prime density must be accounted for in its interpretation.

## E3.6 Sequential evidence with a proof of the monitoring guarantee

Let X_t be a fresh bit whose conditional probability is one half given the complete past information F_(t-1). Choose q_t between zero and one using only that past. Multiply E_(t-1) by 2q_t for X_t=1 and by 2(1-q_t) for X_t=0. The conditional average factor is q_t+(1-q_t)=1. Starting at E_0=1 gives a nonnegative martingale. Adaptive window rules are allowed to choose the next prediction; peeking at the target bit is not.

PROVED E3-P2 gives the threshold guarantee. Let tau be the first time E_t>=1/alpha and stop at tau or a finite horizon T. The stopped process has expected value at most one. On tau<=T it is at least 1/alpha, so P(tau<=T)<=alpha. Letting T increase gives P(ever cross)<=alpha. This is the discrete-time specialization of Ville's inequality; the exact source hypothesis and formula were checked in Howard et al., Lemma 1 [E-R3]. The proof requires the conditional fair-bit model, not merely a balanced final count.

A fixed weighted average of valid evidence processes remains valid by linearity of conditional expectation, even when the strategies share all observations. Selecting a strategy for the next bet from its past performance can also be valid. Taking the retrospective maximum of their final capitals is a different process and has no automatic threshold guarantee. Re-reading a known bit contributes no fresh factor.

Example E3-G mixes alternative Bernoulli probabilities one quarter and three quarters with equal weights. After t observations with k ones,

```text
E_t=(3^k+3^(t-k))/2^(t+1).
```

Under fair bits its average next value equals its present value. Threshold 20 gives an anytime false-alarm bound of 5%. Fresh exact dynamic programming gives crossing probabilities about 1.8919% by t=20 and 4.166676% by t=512. An initially plausible limit 1/24 is refuted because the exact 512-step probability already exceeds 1/24 and crossing probabilities cannot decrease with the horizon.

Repeatedly using an ordinary fixed-time two-sided binomial 5% test is different. Exact enumeration by count and prior-alarm status gives an ever-alarm probability about 10.6617% by 20 observations and 35.7797% by 512. The single fixed-time test remains valid at its specified time. The increase concerns the probability of at least one selected crossing over the timeline.

Example E3-H duplicates each of five independent fair bits. If all original bits agree, probability 1/16=6.25%, the incorrect ten-independent-bit calculation yields E=29525/1024>20. The correct five-source calculation gives E=61/16<4. This event alone violates a claimed 5% guarantee for the duplicated-data calculation. No larger simulation is needed to establish the counterexample.

## E3.7 Learned parameter ranges and an operational research loop

For a Bernoulli success probability 0<p<1, integrate one common alternative parameter q uniformly over [0,1]. The beta integral yields the likelihood-ratio process

```text
E_t(p)=1/((t+1)*binom(t,k)*p^k*(1-p)^(t-k)).
```

For each fixed true p it is a nonnegative martingale under independent Bernoulli(p) input. Retaining p only if E_s(p)<20 for every time s so far gives a nested confidence set with at least 95% simultaneous coverage. The guarantee concerns the one true parameter; computing many candidate p values does not require dividing alpha by their count. The method-of-mixtures connection and inversion semantics were checked against Howard et al. [E-R4]; the particular formula is derived here.

Example E3-I uses the 99-point grid p=r/100,r=1,...,99 and the selected record 1110 repeated. Exact rational arithmetic gives retained ranges 0.43 through 0.95 at t=16,0.58 through 0.89 at t=64 and 0.66 through 0.83 at t=256. Coverage applies when the true parameter is on the grid and the stated sampling model holds. The periodic illustrative record demonstrates calculation; it does not validate an independent-data model. A real off-grid parameter has no membership guarantee from this finite grid alone.

The reusable research loop freezes the observation identities, declares the exact target and separates exploratory score from tested prediction. It fits the finite grammar on designated training data, records the candidate enclosure, chooses an informative unrevealed observation and checks the resulting witness or likelihood. Exact rejection preserves the original domain and all surviving branches. Statistical rejection records its model and error event. A failed prediction stays in the record; it is not repaired by silently refitting on its own counterexample.

A successful report states what was reconstructed, what remained aliased, what was checked finitely and which source assumption made the probability meaningful. A resource-limited search records unvisited scope. A finite execution may falsify a universal conjecture by a valid counterexample; success over its range supports only that range unless a separate proof supplies the reduction. This lets the pattern machinery remain exploratory while its accepted claims remain inspectable.

Exercise E3-X1 asks whether a hard residue constraint and a noisy residue report use the same update. The former can delete incompatible candidates; the latter ordinarily reweights them. Exercise E3-X2 asks why repeating trace and norm does not distinguish conjugates. Their likelihoods are invariant under the same symmetry. Exercise E3-X3 asks whether threshold 20 means that a hypothesis is 95% true. It bounds a false-alarm event under a specified null process; it is not a posterior probability of truth.

## E references and verification boundary

E-R1. C.-C. M. Yeh et al., Time series joins, motifs, discords and shapelets: a unifying view that exploits the matrix profile, Data Mining and Knowledge Discovery, 2017, DOI 10.1007/s10618-017-0519-9. Author-hosted journal PDF, definitions 2-7 inspected 2026-10-13. https://www.cs.ucr.edu/~eamonn/MP_journal.pdf . The Hamming metric and exact diagonal update in this chapter are explicit adaptations with their own proofs.

E-R2. Terence Tao, The Erdos discrepancy problem, Discrete Analysis 2016:1, DOI 10.19086/da.609; arXiv:1509.05363v6, 2017-01-13. Corollary 1.2 and the distinction between raw and completed characters inspected 2026-10-13. https://arxiv.org/pdf/1509.05363v6 . The general theorem is attributed; the local finite search is independently specified here.

E-R3. Steven R. Howard, Aaditya Ramdas, Jon McAuliffe and Jasjeet Sekhon, Time-uniform Chernoff bounds via nonnegative supermartingales, Probability Surveys 17, 2020,257-317, DOI 10.1214/18-PS321; arXiv:1808.03204v8, 2025-12-17. Lemma 1, equation 2.11 and section 6.1 inspected 2026-10-13. https://arxiv.org/html/1808.03204v8 . The finite-bit construction directly verifies its nonnegative martingale hypothesis.

E-R4. The same authors, Time-uniform, nonparametric, nonasymptotic confidence sequences, Annals of Statistics 49(2),2021,1055-1080, DOI 10.1214/20-AOS1991; arXiv:1810.08240v9, 2022-08-06. Method-of-mixtures and inversion discussion inspected 2026-10-13. https://arxiv.org/pdf/1810.08240v9 . The finite Bernoulli grid is a restricted implementation, not a claim of continuum coverage.

The accompanying E_verify.py and E_results.json rerun declared finite instances using integers and rational arithmetic. They include complete small binary tapes, wrapped walks, rational window ranks, residue wheels, dying product roots, mask components, phase identification, discrepancy words, prime-sign ensembles and sequential crossing probabilities. Historical reports' larger workloads and browser benchmarks are preserved as source claims but are not silently counted as new executions. No global novelty search or universal complexity improvement is asserted.
