# Stefans Math

STEFANS MATH
Coordinates, Constraints and Reconstruction
Corrected collected reference - Edition 1 - 13 October 2026
Project ideas and collected work: Stefan
Mathematical compilation, editing and checking: AI-assisted

# Reader guide: what Stefans Math is trying to do

## A collected method, with several mathematical engines

Stefans Math collects a sustained line of mathematical exploration by Stefan. The recurring interest is concrete: a difficult equation or hidden quantity may become easier to handle when its information is separated into useful coordinates. Remainders expose divisibility. Valuations expose precision. Group exponents expose cycles. Fourier coefficients expose independent modes. Finite differences expose local polynomial structure. Tables and finite-state transitions expose the actual operations performed by a computer. The point of the collection is to make these ideas usable, with the conditions needed to turn an appealing representation into a dependable method.

This is a unified mathematical reference rather than a chronological transcript. Several earlier reports repeat the same reconstruction theorem under different project names. Those repetitions have been consolidated. Different mechanisms keep different contracts: a ring is not a field merely because it is drawn as a grid; a numerical minimum is not an equation root merely because its residual is small; a compatible p-adic root is not automatically an ordinary integer; an informative picture is not automatically an invertible observation. Keeping those distinctions makes the common architecture stronger and easier to extend.

The practical organizing principle is:

```text
state the original problem;
expose computable structure;
retain the information needed for reconstruction;
remove candidates only with an appropriate certificate;
verify the reconstructed result in the original problem.
```

Each step has its own purpose. Declaring the problem prevents a change of subject halfway through a calculation. Exposing structure can reduce work. Retaining information prevents an attractive but lossy projection from being treated as a solution. Certified pruning keeps actual solutions from disappearing. The final check detects mistakes in a transform or a proposal. A final check alone establishes the validity of a returned answer; coverage is additionally necessary to establish that all answers have been found.

The book contains ordinary established mathematics, corrected project constructions, and carefully bounded research ideas. Stefan's contribution is recorded as the project questions, the selection of connections, and the continuing effort to organize them into operational procedures. Standard results retain their standard names and attributions. This edition makes no general claim of mathematical novelty. The organizing work can be useful even when its individual components are classical.

## Four questions that belong beside every result

The first question is existence: does an admissible solution occur at all? The second is soundness: does a returned object satisfy the stated problem? The third is completeness: does the procedure represent every admissible solution? The fourth is uniqueness: does exactly one admissible solution remain? Efficiency is a fifth, separate question about work, storage, and the available representation.

For example, x == 2 (mod 3) has infinitely many integer solutions. A procedure returning x=5 is sound for that congruence. It is incomplete as a description of all integers satisfying it. With the additional bound 0 <= x <= 5, the complete solution set is {2,5}; neither member is uniquely determined. Adding x == 0 (mod 5) leaves {5}, and the finite problem now has a unique solution. The value 5 has not appeared through a mysterious inversion. Two independently justified constraints and a declared bound have identified it.

The same distinction applies to a system in three variables. A numerical iteration can return one verified real root while missing another root or a continuous family. A bounded integer enumerator can be complete in its box while saying nothing about integers outside the box. An exact algebraic backend can describe isolated algebraic roots while requiring separate treatment of positive-dimensional solution sets. These are useful methods with different output meanings.

Throughout the book, a candidate enclosure means a set still permitted to contain solutions. It can be stored compactly as an interval, a residue class, a union of boxes, an affine lattice, or a relation. It need not be a list of every candidate. A precision ratchet is a sequence of nested compatible enclosures. The name describes preservation and refinement; it does not promise that every process converges, or that the limit is computable.

## How the notation is standardized

An equality a=b means that the two quantities are equal in their declared domain. The notation a == b (mod M) means that M divides a-b. In ordinary prose, congruence is described as agreement modulo M. The original project texts sometimes use multiple equal signs as a formatting device. This edition reserves them for the stated modular meaning.

The letters p and k usually denote a prime and a precision level. M denotes a general positive integer modulus. N denotes a finite group order when a group is under discussion. The symbols x,y,z denote unknowns; a,b,c usually denote coefficients or supplied values. Local examples may declare different roles explicitly. A subscript is an index, not automatically a time coordinate. Superscript notation ^ means a power. Square brackets in formulas denote an interval only when its endpoints and domain have been specified.

Three logarithms occur and must remain separate. The real logarithm maps positive real multiplication to addition. A discrete logarithm records an exponent in a specified finite cyclic subgroup and may be computationally difficult. A p-adic logarithm is a convergent series on a specified p-adic unit neighborhood; it loses torsion information unless that information is separately retained. Similar-looking notation does not give the three maps the same domain or cost.

The rational numbers Q, the real numbers R, the complex numbers C, a finite field F_p, a finite ring Z/p^k Z, the p-adic integers Z_p, and the p-adic field Q_p are different environments. Their relationships are explained when they are used. A fraction requires a nonzero denominator in a field; modular division additionally requires a unit. Multiplication by a denominator without retaining its exclusion can change the solution set.

## Evidence labels used in this edition

PROVED marks a result supported by the displayed argument under its stated hypotheses. RESTRICTED marks a repaired statement that holds after an explicit restriction. FINITE marks an exact computational check in a declared finite range. APPROXIMATE marks a numerical result with a declared tolerance or error model. HEURISTIC marks a proposal or a ranking rule. OPEN marks a precisely stated implication that this edition does not settle. REFUTED marks a claim contradicted by an admissible example. CONDITIONAL marks a dependency on a named premise or external result that has not been established in the needed form.

These labels communicate mathematical force, rather than prestige. A finite calculation can be extremely useful for detecting an implementation error. A heuristic can find an answer that a complete search would reach too slowly. Neither needs to be described as a universal proof to be valuable. Conversely, a short exact identity may have a stronger conclusion than thousands of matching plots.

A model assumption and a mathematical theorem are also different. An observation bound may be assumed in a reconstruction problem. The theorem can correctly say that recovery is unique under that bound. If a measured input violates the bound, the theorem has not become false; the application has failed its input contract. Recording assumption failure separately from search failure prevents misleading conclusions in both directions.

## Reading routes

The arithmetic route begins with modular candidates, CRT, cyclic groups, and then p-adic lifting. It explains how ordinary quantities can be represented in several compatible remainder systems, and how the remaining fiber coordinate supplies the information that a projection discards. The examples begin small enough to check by hand and then show the same structure in richer finite rings and lattice problems.

The numerical route begins with the original-domain compiler and continues through brackets, local models, interval certificates, and controlled optimization. It demonstrates how numerical procedures can solve algebraic problems without relying on a hand-derived elimination formula for each problem. It also makes visible when a symbolic adapter, a global bound, a singular branch, or a complete enumeration is still required.

The spectral and geometric route studies modes, phases, oscillatory probes, coordinate changes, quaternions, and discrete geometry. The useful question is always what the representation preserves. An invertible finite Fourier transform retains its finite data; a projection normally does not. A rigid quaternion rotation preserves three-dimensional distances; discarding a coordinate afterward does not. Geometry can expose a relation clearly while still leaving the inverse search to perform.

The pattern route studies windows, state machines, array walks, hashing, arithmetic populations, and statistical validation. It supplies an inspectable way to investigate apparent regularity. Exact arithmetic constraints and statistical prediction can cooperate, but they retain different acceptance criteria. An observed correlation proposes a model; an exact constraint certifies a relation on its stated domain.

The logic and computation route supplies the language needed to keep those interfaces honest. It distinguishes observation identity, contextual truth, causal dependency, and computational verification. It then gives concrete finite constructions: arrays, nibble tables, mechanical Boolean operations, state machines, and recursive puzzle graphs. These are useful bridges between abstract mathematics and computer behavior.

## Scope of the recovered collection

The twelve supplied reports are the main source corpus. Additional mathematical records were recovered by title and subject from related projects, including Mathcrack, modular reconstruction, the hidden-number specification, current solver notes, the temporal framework, three-dimensional logic arrays, Fourier demonstrations, phase and factorization notes, doubling-cycle geometry, and computational table designs. Original records remain unchanged. The inventory and family audit records distinguish direct inspection, related-section inspection, duplicate versions, and contextual material.

The phrase collected works refers to that inspected and recovered corpus. No account can certify an unseen manuscript or an inaccessible historical conversation. A historical report's claim that it audited another file is not a substitute for inspecting that file when its precise contents matter. This edition consequently records its coverage rather than claiming access to every mathematical sentence written during the preceding two years.

The matching ASCII edition contains the same manuscript mathematics as the PDF, without relying on special equation fonts. The editable source package includes chapter sources, correction records, source inventories, and fresh checking scripts. These are intended to make later revision possible: a repaired hypothesis can be changed in one place, its dependencies can be traced, and a numerical example can be rerun. The supplied historical texts are preserved as historical inputs, not silently rewritten into an appearance of having always contained the final corrections.

# Arithmetic coordinates: residues, bounds, and cyclic exponents

## A1. A number can have several exact addresses

A large integer can be described by its remainder after division by three, its remainder after division by five, its parity, and its position in a bounded interval. Each description answers a different question. The central arithmetic idea in Stefan's work is to collect these partial addresses, keep their meanings attached, and reconstruct the original number when enough genuine constraints have accumulated. This is useful in puzzle solving, exact computation, error checking, and analysis of algorithms. It also explains why a promising pattern sometimes stops short of an answer: several numbers can share every address collected so far.

An integer equality and a congruence must have different notation. The statement x=14 identifies an integer. The statement x==14 (mod 15) identifies every integer 14+15t, with t an integer. A congruence therefore has a fiber: all original objects mapped to the same residue. Keeping that fiber makes modular reasoning exact rather than merely suggestive.

Let D be the original domain, S its actual solution set, and C a candidate enclosure containing S. An observation map O sends candidates to a simpler space. If every solution has O(x) in an allowed set A, a sound update is

```text
C_new = {x in C : O(x) in A}.
S subset C_new subset C.
```

This is a necessary-condition filter. It becomes a complete solver when all surviving candidates are checked by the original verifier V and the search covers the declared domain. A residue filter can remove impossibilities even when it does not recover a value. Conversely, one passing value establishes existence without necessarily establishing that all answers have been found.

The earlier word "carrier" is standardized here as a domain or coordinate space. Integers modulo M form a ring; their additive structure is a cyclic group; only the invertible residues form the multiplicative unit group. Divisors of a fixed positive integer form a finite candidate set. A subgroup or its coset supplies a membership predicate. These objects fit one constraint architecture, but their operations remain distinct. Division in a group is available; division by every nonzero residue in a ring is not.

## A2. Cancellation with a noninvertible coefficient

Claim A-P1 [PROVED]. For integers a,b and a positive modulus M, put d=gcd(a,M). The complete solutions of a*x==b (mod M) exist exactly when d divides b. When compatible, they form one residue class modulo M/d.

The proof begins with an ordinary integer equation a*x-b=M*t. Its left coefficient and right modulus are divisible by d, so d must divide b. Divide the whole equality by d. Now a/d and M/d are coprime, so a/d has an inverse modulo M/d. The result is

```text
x == (b/d)*inverse(a/d, M/d) (mod M/d).
```

When M/d=1, every integer is allowed and no inverse is needed. This derivation proves completeness because reversing the division recovers the original equality with an integer t. There are exactly d solutions modulo M: the one residue modulo M/d has d different lifts to the original modulus.

Example A-E1. Solve 6x==8 (mod 14). The gcd is two. Dividing gives 3x==4 (mod 7); the inverse of three is five, so x==20==6 (mod 7). The original modulus has the two solutions 6 and 13. Direct checking gives 36==8 and 78==8 modulo 14. The nearby problem 6x==9 (mod 14) has no solution because two does not divide nine. These calculations expose exactly where an ordinary algebraic cancellation would fail.

The same rule explains equality after multiplication: a*x==a*y (mod M) implies only x==y (mod M/gcd(a,M)). Cancellation at the original modulus is justified precisely when the coefficient is a unit. This is important for modular matrices, collision equations, and derivative-based lifting; a coefficient can be nonzero and still lack an inverse.

## A3. Chinese remainders as exact intersection

Claim A-P2 [PROVED]. The two conditions x==a (mod M) and x==b (mod R) are compatible exactly when gcd(M,R) divides b-a. Their complete intersection, when nonempty, is one class modulo lcm(M,R).

Write x=a+M*t and put d=gcd(M,R). The second condition becomes M*t==b-a (mod R). Applying A-P1 gives

```text
u = ((b-a)/d)*inverse(M/d, R/d) mod (R/d),
x == a+M*u (mod M*(R/d)).
```

If R/d=1, take u=0. The displayed modulus is the least common multiple. For an independent check of its period, subtract two simultaneous solutions. Their difference is divisible by both M and R, hence by lcm(M,R). Adding that least common multiple preserves both premises. The construction supplies one solution; the difference argument proves that no further classes are missing.

Example A-E2. Suppose x==5 (mod 12), x==11 (mod 18), and 0<=x<=100. The gcd is six. Substitution gives 2t==1 (mod 3), so t==2. Therefore x==29 (mod 36). The bounded candidates are 29 and 65. Replacing the second residue by ten makes the pair incompatible because six does not divide 10-5. Multiplying 12 and 18 would produce 216 and erase valid possibilities: the overlapping divisibility information counts once.

For a class x==r (mod M) in [L,U], the complete integer list is

```text
x = r+M*t,
ceil((L-r)/M) <= t <= floor((U-r)/M).
```

This is exact for negative endpoints as well. With a positive denominator, ceil(n/M)=-floor(-n/M). Integer quotient operations avoid rounding errors at enormous boundaries. A class contains at most one integer when M>U-L. That inequality gives uniqueness within each fiber; several different fibers can still contain several answers.

CRT does not manufacture information across independent factors. If gcd(M,R)=1, every pair of residues occurs once modulo MR. Fixing the M-address leaves every R-address possible. Bounds or additional equations can couple the addresses, but that coupling comes from the extra constraint. The useful accounting quantity for a uniform finite candidate set is its size before and after an actual intersection.

## A4. Rational reconstruction uses a height bound

Residues can also represent fractions, provided their denominators are invertible. Claim A-P3 [PROVED]. Fix M>=2, numerator bound A>=0, and denominator bound B>=1. Among reduced fractions u/v with v>0, |u|<=A, v<=B, gcd(v,M)=1, and u==r*v (mod M), there is at most one if 2AB<M.

For two admissible fractions, the congruences make u*v'-u'*v divisible by M. Its magnitude is at most |u|v'+|u'|v<=2AB<M. The only possible multiple is zero. The fractions are equal, and reduction with positive denominator makes their pairs identical. Existence is a separate matter: the bounds can contain no fraction with the required residue.

Example A-E3. Modulo 101, residue 41 represents 3/5 because 41*5=205==3. With A=3 and B=5, 2AB=30<101 proves uniqueness. A direct finite generator can try denominators one through five and numerators -3 through three; a continued-fraction or lattice method can propose the same fraction faster for larger bounds. Acceptance needs only the gcd checks, the bounds, and the original congruence. The proof explains why recovering rational coefficients from modular computations requires a supplied height restriction.

These pairs form the integer lattice {(u,v):u-rv is divisible by M}, generated by (M,0) and (r,1). The determinant M measures its area per lattice point. Two independent bounded vectors would have determinant a nonzero multiple of M, while the height box forces magnitude below M. This geometric formulation expresses the same separation fact without treating a drawing as another observation.

## A5. The exponent modulus is the group order

Suppose g generates a cyclic group of exact order N and h belongs to that group. The original equation is h=g^x, with x naturally in Z/NZ. Claim A-P4 [PROVED]: g^u=g^v exactly when N divides u-v. Indeed, divide u-v by N; a nonzero remainder below N cannot produce the identity by exactness of the order.

The order of g^k is N/gcd(N,k). Write N=dN_0 and k=dk_0 with coprime N_0,k_0. The equation (g^k)^t=1 is equivalent to N_0 dividing k_0t, hence to N_0 dividing t. The least positive return time is N_0. Thus for m dividing N, the projection base g^(N/m) has exact order m and

```text
h^(N/m) = (g^(N/m))^r
    iff x == r (mod m).
```

This gives a short certificate for an exponent address. It requires no known full logarithm. It does require an exact order and a valid divisor. A proposed order N can be certified from its complete prime factorization by checking g^N=1 and g^(N/p)!=1 for every distinct prime p dividing N. The first check makes the actual order divide N; any proper divisor divides N/p for some such p, contradicting the corresponding check.

Membership is separate. In C_2 times C_2, g=(1,0) and h=(0,1) both square to the identity, but h is outside the two-element subgroup generated by g. Checking h^N=1 is therefore insufficient in an arbitrary ambient group. A constructed target, a valid subgroup test, or final equality with an actual power supplies the needed membership evidence.

A group element, its scalar exponent, and its serialized encoding must remain distinguishable. Multiplicative residues modulo a prime p use p for their field arithmetic and N for exponent arithmetic. Elliptic-curve points obey the same cyclic scalar reasoning, with scalar multiplication replacing powers. Their coordinate modulus can differ from the point order. A compressed point recovers the point when decoded; it does not recover its unknown scalar.

## A6. Known addresses create a residual problem

If m divides N and x==r (mod m) has been established, write x=r+m*t. The surviving scalar classes correspond bijectively to t modulo N/m. Substitution gives

```text
b = g^m, y = h*g^(-r), y=b^t.
```

Two t values produce the same x modulo N exactly when their difference is divisible by N/m. No inverse of m is used, so this works even when m and N/m share a factor. In an order-eight group, known odd parity gives x=1+2t with t modulo four, correctly representing 1,3,5,7.

External integer information can instead use an arbitrary positive modulus M. With x==r (mod M) and L<=x<=U, the substitution remains exact, but the residual group order becomes N/gcd(N,M). The interval for t comes from A3. If t_0 solves the residual equation, all integer aliases are t_0+j*N/gcd(N,M). Their original x values differ by lcm(N,M).

Example A-E4. In a group generated by g of order 12, let h=g, x==5 (mod 8), and 20<=x<=80. Then x=5+8t, 2<=t<=9, b=g^8 has order three, and y=g^(-4)=g^8=b. Thus t==1 (mod 3). The admissible t values are four and seven, yielding x=37 and x=61. Both are valid. The residue eight shortened an integer search interval; it did not create a subgroup of order 12/8.

A complete interval search uses the baby-step/giant-step idea. For J consecutive exponents shorter than one residual period, choose T near sqrt(J). Write each index z=i+Tj, with 0<=i<T. Store b^i and compare them with w*b^(-Tj), where w is the target shifted by the lower interval endpoint. Every z has a quotient-and-remainder decomposition, so this comparison covers the whole interval, with a final check excluding indices beyond its upper boundary. It costs roughly T+ceil(J/T) group operations and T stored elements. Hash matches require exact element equality. Additional integer aliases are then listed from their proved period.

## A7. Extracting prime-power digits

The factorwise method is standard Pohlig-Hellman mathematics [A-R1,A-R2]. Its usefulness in this compilation is the explicit preservation of each digit and reconstruction rule. For p^e dividing N, put gamma=g^(N/p^e), eta=h^(N/p^e), and beta=gamma^(p^(e-1)). Write the unknown projected exponent as sum d_j*p^j, with 0<=d_j<p. If s_j contains the digits already recovered, the next digit satisfies

```text
(eta*gamma^(-s_j))^(p^(e-1-j)) = beta^d_j.
s_(j+1) = s_j+d_j*p^j.
```

Proof A-P5 [PROVED]. The exponent after subtraction is d_j*p^j plus a multiple of p^(j+1). Raising it to p^(e-1-j) sends the latter terms to multiples of p^e, where they vanish. The surviving term is beta^d_j. Since beta has order p, the p possible digits have distinct images. Induction recovers every digit; CRT then joins the maximal prime-power components.

Example A-E5. Solve 5^x==23 (mod 97). Order 96 is certified by 5^96=1, 5^48=96, and 5^32=35. Its factors are 32 and three. For the binary component, gamma=28, eta=42, and beta=96. The successive known partial exponents are 0,1,1,5,13,13; the corresponding digits are 1,0,1,1,0. Their projected tests are 96,1,96,96,1. Hence x==13 (mod 32).

For the order-three component, base 35 has powers 1,35,61, and projected target 23^32=61. Therefore x==2 (mod 3). Substituting x=13+32t gives 1+2t==2 (mod 3), so t==2 and x==77 (mod 96). Direct evaluation 5^77==23 closes the calculation in its original domain. The residual after the binary address is already the tiny equation 35^t=61.

Given N=product p_i^e_i and square-root prime-order solvers, the standard group-operation bound is O(sum e_i*(log N+sqrt(p_i))) [A-R2]. Factorization and representation costs are additional. A large prime factor can retain the difficult component. Learning an independent smooth-factor coordinate does not determine that prime coordinate; CRT gives every prime coordinate a compatible original scalar. The organization improves auditability and allows useful partial work to accumulate, while its speed still comes from accessible arithmetic structure.

## A8. Collisions retain coefficient meanings

A collision search in y=b^t stores a state R=b^u*y^v together with u,v and the exact residual domain. Equal states imply

```text
(v-v')*t == u'-u (mod ord(b)).
```

This follows by substituting y=b^t and comparing powers. A-P1 solves the congruence safely, including a nonunit coefficient that yields only a partial address. A coefficient difference and constant both zero supply no information. An inconsistent gcd condition signals that the purported collision or its metadata is wrong.

An address t==c (mod m), with m dividing the residual order, changes coordinates to t=c+m*s. The new base is b^m and target y*b^(-c). An old state can be transported by setting delta=(u+cv) mod m and replacing R by R*b^(-delta). Its new coefficients are (u+cv-delta)/m and v, reduced modulo the new order. Substitution proves the identity. This preserves its algebraic meaning; it does not prove that a changed random walk continues the old trajectory. Old results can instead be converted to original x coordinates and checked there.

Stefan's fixed-point language also needs an operational distinction. If all allowed sets A_i are already fixed, intersecting with them is idempotent: applying the identical intersection twice changes nothing. Repeated propagation becomes useful when a smaller candidate set permits recomputation of stronger justified local constraints, or when another observation arrives. The mathematical ratchet is the nested candidate enclosure, with every new exclusion carrying its reason.

Exercise A-X1. Merge x==1 (mod 6) and x==3 (mod 10), then restrict to [-20,20]. Answer: x==13 (mod 30), giving -17 and 13. Exercise A-X2. An element has order 45. Its ninth power has order five; a fifth-power projection, by contrast, has order nine. These are different addresses and should retain their different moduli.

# Local coefficient rings: precision layers and reversible components

## A9. Three finite objects that look similar

The field F_p, the ring Z/p^k Z, and the polynomial quotient F_p[T]/(F) are different coordinate spaces. In F_p every nonzero element is invertible. In Z/p^k Z with k>1, the nonzero residue p is nilpotent: its kth power is zero. A quotient by an irreducible polynomial is a field; a quotient by several coprime factors is a product; a repeated factor introduces nilpotents. Their similar finite sizes do not make their arithmetic interchangeable.

For an explicit coefficient ring, choose a monic polynomial F of degree f and set R_k=(Z/p^k Z)[T]/(F). Monic division gives a unique coefficient vector of length f with coefficients modulo p^k. This free coefficient representation is exactly the access needed by the digit solver below. If F modulo p is irreducible, the residue ring is the field F_(p^f), and the construction is an unramified Galois ring [A-R3]. Irreducibility supplies this field interpretation; the principal-unit digit argument itself needs only the commutative monic coefficient algebra.

The concrete project ring is R_k=(Z/3^k Z)[alpha]/(alpha^2+1). Its multiplication is

```text
(a+b*alpha)(c+d*alpha) = (ac-bd)+(ad+bc)*alpha.
```

A unit has inverse (a-b*alpha)/(a^2+b^2). Modulo three, the denominator vanishes exactly when both a and b vanish, since each nonzero square is one. Thus units are precisely coefficient pairs not both divisible by three. This criterion depends on the chosen prime: modulo two, T^2+1=(T+1)^2, so the same display gives a different ring.

Division by a known p^j in a coefficient vector reduces precision. If z is known modulo p^k and is divisible by p^j, z/p^j is known only modulo p^(k-j). Changing the original representative by p^k changes the quotient by p^(k-j), proving the precise residual uncertainty. This is a recurring rule for valuations, derivative normalization, and finite logarithms.

## A10. Principal units expose an additive layer

A principal unit is an element of the form 1+p*c. It is invertible because p*c is nilpotent at finite precision; the finite geometric sum gives the inverse. Put U_j=1+p^jR_k. For j>=1,

```text
(1+p^j*a)(1+p^j*b) == 1+p^j*(a+b) (mod p^(j+1)).
```

The quadratic term contains p^(2j), which is divisible by p^(j+1). Therefore U_j/U_(j+1) has additive coefficient coordinates over F_p. Multiplication becomes addition in one layer even though the full elements remain multiplicative objects.

For odd p, binomial expansion also gives

```text
(1+p^j*c)^p == 1+p^(j+1)*c (mod p^(j+2)).
```

The intermediate binomial coefficients contain p, while the last term has valuation pj>=j+2. Repetition yields (1+p*c)^(p^r)==1+p^(r+1)*c modulo p^(r+2). Thus every principal unit is killed by p^(k-1). These identities identify both an exponent domain and a publicly extractable next digit.

The odd-prime restriction matters. Modulo eight, 3^2=1, whereas transferring the displayed leading-term formula would predict 1+4=5. Binary principal units require a different branch, addressed below. A proof attached to one prime regime cannot be licensed by similarity of notation.

## A11. Coupled exponent recovery from a fixed tangent matrix

At precision k>=2, consider s equations with n unknown exponent coordinates:

```text
h_i = product_j g_ij^(x_j), g_ij=1+p*c_ij,
x_j modulo P=p^(k-1), p odd.
```

Each equation contributes f residue coefficients. Stack the coefficient vectors of c_ij modulo p into an fs-by-n matrix A. This is called the first-layer matrix; the earlier "tangent" terminology refers to the same leading coefficient calculation. At k=1, principal units and the exponent domain modulo p^0=1 are both trivial, so their unique map is bijective independently of A; that case needs no digit recovery.

Claim A-P6 [PROVED]. If n=fs and A is invertible over F_p, the exponent map is a bijection from (Z/PZ)^n to U_1^s. Every target has exactly one exponent vector, recoverable one digit at a time.

Start with all exponents zero. Suppose x^(r) contains the first r digits and its products match the targets modulo p^(r+1). Form the residual

```text
w_i = h_i*product_j g_ij^(-x_j^(r)).
b_r = stacked coefficients of (w_i-1)/p^(r+1) modulo p.
```

The divisibility follows from the maintained precision. A next exponent correction p^r*d produces, by A10, exactly the additive layer A*d. Therefore the next digits solve A*d=b_r over F_p. Invertibility gives one digit vector. Update x^(r+1)=x^(r)+p^r*d. After k-1 rounds every original product agrees modulo p^k, and every digit was forced.

Necessity is equally explicit. If A has a nonzero kernel vector v, then the nonzero exponent difference p^(k-2)*v maps to identity: its final output layer is A*v=0. A singular first layer cannot yield a bijection on the stated full exponent domain. For rectangular matrices, full column rank establishes injectivity on the image, while full row rank establishes surjectivity with remaining exponent freedom. A deficient rank requires all compatible branches, not an arbitrary free-digit choice.

Example A-E6. Work modulo 81 with g_1=4, g_2=1+3alpha, and target h=25+66alpha. The first-layer matrix is the two-by-two identity. From (h-1)/3=(8,22), reduction modulo three gives digits (2,1). Removing g_1^2*g_2 leaves 10+45alpha. Dividing its difference from one by nine gives (1,5), whose next digits are (1,2). Hence x=(2,1)+3*(1,2)=(5,7). The new residual is one, so the last digits are zero. Direct multiplication verifies 4^5*(1+3alpha)^7=25+66alpha modulo 81.

A singular comparison replaces the second base by 1+9alpha modulo 27. Its first-layer coefficient column vanishes, and increasing its exponent by three changes no power. Targets whose alpha coefficient is divisible by three but not nine cannot lie in its image. The same machinery then produces either a complete family or an inconsistency certificate, rather than a unique reconstruction.

## A12. Finite logarithmic coordinates

There is another way to expose the additive principal-unit structure. For odd p, the convergent p-adic logarithm and exponential are inverse group maps between 1+pO and pO in the associated complete coefficient algebra; in a p-adic field these domains are standard [A-R7]:

```text
log(1+z) = z-z^2/2+z^3/3-...,
exp(w) = 1+w+w^2/2!+... .
```

The logarithm terms tend to zero because their valuations are at least j*v_p(z)-v_p(j). The exponential terms do so on this domain because v_p(j!)<=j/(p-1), with strict positive linear growth for odd p and v_p(w)>=1. Formal differentiation gives derivative one and constant zero for log(exp(w)); the series have invertible linear coefficient, so the inverse-composition identity follows. The corresponding two-variable formal calculation gives log(uv)=log(u)+log(v) for commuting inputs. Convergence licenses substitution into these identities, proving the asserted coordinate map rather than a resemblance to an ordinary real logarithm.

At finite precision the divided coordinate lambda(u)=log(u)/p lives modulo p^(k-1). Computing log at precision p^k is essential before division. If two input lifts agree modulo p^k, their ratio is 1 modulo p^k; its logarithm is divisible by p^k, so their lambda coordinates agree modulo p^(k-1). That proves independence of the chosen lift.

An exact finite evaluation avoids division by nonunits. Write u=1+p*c and j=p^v*j_0 with j_0 coprime to p. Then the jth term of lambda is

```text
(-1)^(j+1)*p^(j-1-v)*c^j*inverse(j_0,p^(k-1)).
```

For odd p, retaining j=1 through 2k-1 is a safe cutoff: for j>=2k, v_p(j)<=j/2 and j-1-v_p(j)>=k-1. Every omitted term vanishes at the required modulus. The first vanished term alone is not a valid stopping criterion because valuations of denominators jump at powers of p.

Example A-E7. In the previous ring, finite logarithms give lambda(4)=(16,0), lambda(1+3alpha)=(15,25), and lambda(h)=(23,13), all modulo 27. The original products therefore become

```text
16x+15y == 23 (mod 27),
      25y == 13 (mod 27).
```

The solution (5,7) satisfies both. The determinant 400 is a unit modulo 27. This is a second computational route through the same ring, using an additive coordinate isomorphism rather than successive multiplicative residuals. The finite verification package checks both routes independently against direct products.

A full unit may have a torsion coordinate outside the logarithm domain. In Z_3, each unit is uniquely (-1)^epsilon*v, where v==1 (mod 3). The logarithm records v and loses the sign unless epsilon is retained. Likewise, at p=2, the inverse logarithm/exponential chart uses 1+4O and 4O. Applying a logarithm to the larger binary unit group without retaining its extra first-layer or torsion information loses possible answers.

## A12a. The complete doubling clock, including nonunits

The familiar six-cycle is an exact part of a larger arithmetic system. Example A-E12. Doubling modulo nine gives the three disjoint cycles

```text
0 -> 0;
3 -> 6 -> 3;
1 -> 2 -> 4 -> 8 -> 7 -> 5 -> 1.
```

The units form the six-cycle. The additive ideal {0,3,6} is its invariant inner subsystem, rather than a pointwise fixed spine. The principal-unit subgroup {1,4,7} is a different object: its multiplicative coset {2,8,5} is exchanged with it by doubling. Applying doubling twice rotates inside those two triangles; it is multiplication by four, not the squaring map on residues. Zero and nine represent the same residue, so counting both invents an additional state.

Claim A-P11 [PROVED]. For positive n, v_3(2^n-1)=0 when n is odd, and 1+v_3(n) when n is even. Odd powers of two are minus one modulo three. For n=2m, start from four=1+3. Cubing 1+3^j*c with c not divisible by three produces a leading term 3^(j+1)*c in its difference from one; the remaining terms have strictly larger valuation. Each cubing therefore raises the valuation by one. Raising to a positive exponent coprime to three preserves the leading valuation by the same binomial argument. Writing m=3^r*u proves the formula.

Consequently two has order 2*3^(k-1) modulo 3^k, equal to the number of units, so it generates them all. A nonzero residue has a unique truncated valuation j<k and is represented by 3^j*u with u a unit modulo 3^(k-j). Its doubling period is 2*3^(k-j-1): cancelling 3^j in the return equation reduces to exactly that unit problem. The layer has the same number of residues, hence is one complete cycle. Together with fixed zero, the full graph has lengths 1,2,6,...,2*3^(k-1). Their sum is 3^k. Modulo 27, the lengths are 1,2,6,18, and the multiples of three reproduce the entire modulus-nine system.

This gives coordinates for every residue, not merely the outer units: zero has its own tag; a nonzero residue has valuation j and a base-two exponent modulo 2*3^(k-j-1). Multiplication adds valuations and adds exponent addresses at the final reduced precision, or gives zero when the valuation reaches k. Addition has no general exponent-addition rule because leading terms can cancel. The coordinates are a stratification of a multiplicative monoid, not a declaration that nonunits are groups.

The unit exponent can itself be recovered without traversing its long cycle. Maintain an address n_r modulo M_r=2*3^(r-1) with 2^n_r==u (mod 3^r). The strengthened induction 2^M_r==1+3^r (mod 3^(r+1)) shows that its three next lifts have addresses n_r+a*M_r for a=0,1,2. Compute q=u*inverse(2^n_r,3^(r+1)); its next digit a=(q-1)/3^r selects the unique lift. For u=158 modulo 729, the successive addresses are 1,5,11,29,137,137. Directly 2^137==158 modulo 729. Every step uses public residue arithmetic.

At infinite 3-adic precision, the two unit coordinates are a sign and a principal logarithm. Put ell=log(-2), with v_3(ell)=1. The map u=(-1)^epsilon*v -> (epsilon,log(v)/ell) identifies Z_3 units with C_2 times Z_3. Multiplication by two adds (1,1). The inverse is (-1)^epsilon*exp(t*ell), and exp(ell)=-2; retaining the sign returns two correctly. Division by ell cancels one factor of three before inverting its unit part. It is not inversion of three modulo 3^k.

Finite cycles do not imply nonzero periodic points in Z_3 itself. An equality 2^n*u=u would make (2^n-1)u=0 in a characteristic-zero integral domain, hence u=0. The finite quotients return, while successively refined residues trace an infinite compatible path. This distinction makes the clock useful for finite-state representations and precision algorithms without claiming a new physical oscillator or hidden source of randomness.

## A13. Singular matrices need families

Once principal units are converted into coefficient coordinates, the equations are C*x==b (mod P). Claim A-P7 [PROVED with standard Smith-form existence]. Let an integer Smith decomposition be D=U*C*W, where U and W are unimodular. Put x=W*z and b'=U*b. Integer unimodularity means determinant +1 or -1; these coordinate changes remain invertible at every modulus [A-R4].

For each nonzero diagonal d_i, put delta_i=gcd(d_i,P). Compatibility requires delta_i dividing b'_i. Every remaining zero row requires b'_i==0 (mod P). The constrained coordinate then has one residue modulo P/delta_i and delta_i lifts modulo P. Columns beyond the nonzero diagonal are free. If r diagonals are nonzero and n columns occur, a compatible system has exactly

```text
P^(n-r)*product_(i=1..r) delta_i
```

solutions modulo P. This follows by applying A-P1 separately to every diagonal and multiplying the independent counts. The existence theorem for Smith form supplies the coordinate change; the arithmetic here supplies its exact solution meaning.

Example A-E8. Solve x+y==16 and x+4y==13 modulo 18. Subtracting gives 3y==15, hence y==5 (mod 6). Its lifts are 5,11,17. Recovering x gives the three pairs (11,5), (5,11), and (17,17). Rational full rank does not imply a modular inverse: the determinant three shares a factor with 18.

For bounded integer unknowns, the complete modular family must be lifted to an affine integer lattice. Bounds on x become inequalities in W*z, generally coupling the transformed coordinates. Copying independent x bounds directly onto z changes the problem. A compact basis for the homogeneous kernel can describe many solutions without listing all of them; producing the complete explicit list necessarily costs at least its output size.

At p=2, a complete alternative retains parity branches. Write x_j=epsilon_j+2z_j, solve every compatible first-layer equation for epsilon over F_2, and remove its contribution. Squared bases and corrected targets then lie in 1+4R_k, where the divided logarithm works. Solve their complete modular families and recombine x=epsilon+2z. The branch union covers every original exponent because each has a unique parity decomposition. This is exact, though its number of branches can grow exponentially.

## A14. Polynomial CRT and the Mathcrack component construction

Stefan's Mathcrack material proposes another reusable organization: separate a finite algebra into components, invert a map locally, and recombine. Let F=product f_i^e_i over F_p, with distinct monic irreducibles f_i. The powers q_i=f_i^e_i are pairwise coprime. Polynomial Bezout supplies u_i*(F/q_i)==1 (mod q_i). Define epsilon_i=u_i*(F/q_i) modulo F.

Claim A-P8 [PROVED]. Reduction and reconstruction give inverse maps

```text
F_p[T]/(F) <-> product_i F_p[T]/(q_i),
z <-> (z mod q_i)_i,
z = sum_i epsilon_i*lift(z_i).
```

In component i, epsilon_i is one; in every other component it is zero. Thus epsilon_i^2=epsilon_i, epsilon_i*epsilon_j=0 for distinct indices, and sum epsilon_i=1. Agreement in every component means divisibility by every coprime q_i, hence by F, proving global equality. The reconstruction formula also proves independence of local representatives.

When every e_i is one, all components are fields. A repeated factor instead gives a local ring with nilpotents. For degree d and exponent e its size is p^(de), while its units number p^(d(e-1))*(p^d-1): the nonunits are exactly residues divisible by f. This count does not assert that its unit group is cyclic.

Example A-E9. Over F_2, take f_1=T^3+T+1 and f_2=T^4+T+1. The cubic has no root in F_2; the quartic has no linear root and is not divisible by the sole irreducible quadratic T^2+T+1, whose reduction gives remainder one. Both are therefore irreducible. Their product is F=T^7+T^5+T^3+T^2+1. The algebra has 128 elements and identifies with F_8 times F_16.

Its projectors are epsilon_1=T^5+T^2+T and epsilon_2=epsilon_1+1. Reducing them gives component pairs (1,0) and (0,1). Define E(z)=epsilon_1*z^3+epsilon_2*z^7. Componentwise this is (a,b)->(a^3,b^7). Since 3*5==1 (mod 7) and 7*13==1 (mod 15), its inverse is D(z)=epsilon_1*z^5+epsilon_2*z^13. Nonzero components follow their multiplicative orders; zero must be checked separately and is fixed by these positive powers. Hence D(E(z))=z on all 128 elements, including zero divisors.

The component construction also permits E_i(a)=c_i*a^k_i+b_i with c_i nonzero, k_i a positive integer, and gcd(k_i,p^d_i-1)=1. Subtracting b_i, multiplying by c_i^(-1), and raising to a positive inverse exponent gives the local inverse. An invertible linear change T produces the conjugate map T^(-1)*E*T and the matching inverse T^(-1)*D*T as functions. An arbitrary linear T need not preserve multiplication; describing it as a ring automorphism would be an extra claim.

This supplies a finite reversible-map laboratory, not a demonstrated secure trapdoor. Factorization, projectors, and local inverses are visible in this presentation. Hiding a coordinate choice does not by itself establish that public inversion is difficult. The valuable mathematical content is the checked decomposition, the exact local inversion criterion, and the explicit conditions under which information collapses.

## A15. Element orders, map cycles, and quotient fibers

Under repeated powering by k in a cyclic group of order N, exponent r evolves by r->kr modulo N. When k is a unit modulo N, its orbit length is ord_(N/gcd(N,r))(k), because return means N divides (k^t-1)r. This is different from the order N/gcd(N,r) of the represented group element. In A-E9 the exponent map r->3r modulo seven has a six-cycle 1,3,2,6,4,5. Six does not divide seven or the product unit-group exponent 105. Comparing such map periods only with divisors of 105 would reject a correct construction.

The cyclotomic identity X^n-1=product_(d|n) Phi_d(X) remains a polynomial identity after reduction. Its zero-set interpretation needs a field and characteristic coprime to n for primitive-order classification. In a ring with zero divisors, a product can vanish while no factor vanishes: modulo 15, 4^2-1=0 but 4-1=3 and 4+1=5 are both nonzero. A square image {x^2} is also different from the root-of-unity kernel {x:x^2=1}. These sets answer different questions and cannot be merged into one "power carrier."

Frobenius on a field component is a->a^p; its orbit period divides the field degree. On a square-free product, the fixed algebra has one F_p coordinate per irreducible factor. In a mixed-characteristic coefficient ring, however, raw pth powering is generally not the lifted Frobenius automorphism. On Z/9Z that automorphism is the identity, while 2^3=8 differs from two. Precision, characteristic, and retained coefficient operations determine the relevant map.

Normal-series reconstruction is useful when its inverse conditions are stated on every fiber. Suppose a map respects a quotient, its induced quotient map is invertible, and every resulting conditional coset map has an inverse. Invert the quotient, identify the relevant input coset, and invert its conditional fiber. Recursion through a finite series then yields an exact inverse. A quotient inverse and an inverse on just the preferred subgroup are insufficient: on Z/4Z, the map 0->0, 2->2, 1->1, 3->1 is bijective on the even subgroup and on the parity quotient, yet collapses the odd coset.

Example A-E10. The order-21 semidirect product uses pairs (a,b) modulo seven and three, with multiplication (a,b)(c,d)=(a+2^b*c,b+d). Associativity follows by expanding both orders to first coordinate a+2^b*c+2^(b+d)*e. Its inverse is (-2^(-b)*a,-b). To solve (3,1)*(c,d)=(5,0), first obtain d=2 modulo three, then 2c=2 modulo seven, hence c=1. Checking (3,1)*(1,2)=(5,0) verifies the quotient-first computation.

Elements with b=0 have order one or seven; elements with b nonzero have order three because 1+2^b+2^(2b)=0 modulo seven. None has order 21. In any finite odd-order group, however, squaring is reversible by x->x^((N+1)/2), since element orders divide N. This single-element root extraction can work in a nonabelian group without making the power map a homomorphism. It also supplies no arbitrary discrete logarithm. Quotient layers explain a decomposition; tractable layer equations supply an algorithm.

Exercise A-X3. In the modulus-18 system x+y==16, x+4y==13, impose 0<=x,y<=12. Answer: only (11,5) and (5,11) survive. Exercise A-X4. In F_8 times F_16, seventh powering on the unit group has kernel size seven: the first component collapses while the second remains invertible. A complete inverse must retain those seven alternatives.

# Bounded observations: exact lattices and verified recovery

## A16. Information before geometry

A hidden-number problem supplies several approximate modular observations of one shared scalar. It does not arise merely by drawing a discrete-log equation in a plane. The model must state known multipliers t_i, targets a_i, and justified error bounds B_i. For an odd modulus q, let H=(q-1)/2 and choose the centered residue

```text
ctr_q(u) = ((u+H) mod q)-H.
```

For a canonical scalar 0<=x<q, the observation condition is |ctr_q(t_i*x-a_i)|<=B_i. An additional verifier V may test a public group equation. Its presence can certify one recovered scalar without creating the bounds. The historical hidden-number terminology comes from Boneh and Venkatesan [A-R5]; the particular lattice equivalence below is proved directly.

Assume integer t_i,a_i and 0<=B_i<q/2. Noninteger bounds may be replaced by their integer floors because the centered errors are integers. Rational observation centers require a different scaling: discarding their denominators changes the model. The strict bound below half a period means a feasible residue has exactly one allowed integer error representative.

Two feasible scalars x,x' have difference Delta satisfying |ctr_q(t_i*Delta)|<=2*floor(B_i) in every coordinate. Therefore, if every nonzero Delta has some coordinate exceeding that limit, no target can admit two scalars. This is a uniform separation certificate. One particular target can be unique even when this stronger universal property fails. An expected information count or a large determinant can guide experiments but cannot substitute for this precise separation question.

## A17. A lattice whose last coordinate is the scalar

Use row vectors and m observations. Define an (m+1)-dimensional integer lattice by the rows

```text
B0 = (q^2*I_m, 0;
      q*t_1,...,q*t_m, 1).
Target = (q*a_1,...,q*a_m,0).
```

The semicolon separates the m diagonal rows from the last row. An integer combination with coefficients (z_1,...,z_m,beta) is

```text
v = (q*(q*z_1+t_1*beta),...,q*(q*z_m+t_m*beta),beta).
```

The determinant is q^(2m). Define the target box by |v_i-q*a_i|<=q*B_i and |v_last|<=H. Claim A-P9 [PROVED]. Lattice points in this box correspond bijectively to feasible canonical scalars, with x=v_last mod q.

For a feasible x, take its unique centered representative beta. Choose the unique bounded error e_i with t_i*beta+e_i==a_i (mod q), and set z_i=(a_i-e_i-t_i*beta)/q. The quotient is integral. The resulting point has target displacement (-q*e_1,...,-q*e_m,beta), so it lies in the box. Conversely, a boxed lattice point has v_i divisible by q. Setting e_i=a_i-v_i/q recovers all modular observation equations and their bounds. The centered beta is unique, as are the errors since their allowable intervals have width below q. That proves both directions and uniqueness of the witness point.

The last coordinate retains scalar aliases even if all multipliers vanish. This is a reason for using the augmented formulation: it avoids accidentally identifying several hidden scalars with one unaugmented observation vector. The containing sphere has squared radius q^2*sum B_i^2+H^2. The box lies inside that sphere, but sphere membership alone is insufficient; its coordinate inequalities remain the acceptance test.

## A18. Basis changes preserve the lattice

Let R=U*B0 where U is an integer unimodular matrix. Then R and B0 have exactly the same integer span, because U and U^(-1) both have integer entries. An integer coefficient row c in the reduced basis represents cR=(cU)B0. The original scalar coordinate is recovered from the actual lattice point, or equivalently from the last coordinate of cU. It is generally not the last coefficient of c.

Equal determinants alone do not certify equal lattices. In two dimensions, the lattices generated by (2,0),(0,1) and by (1,0),(0,2) have equal area but contain different points. The integer change-of-basis identity is the useful evidence. Reduction improves the search coordinates; it does not add observations or remove feasible original scalars.

Gram-Schmidt provides rational orthogonal measurement directions b_j^*, squared lengths D_j, and coefficients mu_(i,j). It need not produce lattice points. For a target T and integer coefficients z,

```text
||zR-T||^2 = sum_j D_j*(z_j+
             sum_(i>j) mu_(i,j)*z_i-y_j)^2,
y_j = dot(T,b_j^*)/D_j.
```

This identity follows by expanding the difference in the orthogonal directions. It supplies exact branch bounds and explains nearest-plane rounding. A nearest-plane pass chooses coefficients from the largest index downward, rounding the residual projection to a nearest integer. It always gives a lattice point. Its success as hidden-number recovery depends on that point also satisfying every original observation and V.

## A19. A complete worked observation recovery

Example A-E11. Let q=101, t=(1,10), a=(38,66), and both error bounds be one. The initial rows, reduced rows, and coordinate transformation are

```text
B0 = (10201,0,0; 0,10201,0; 101,1010,1).
R  = (0,0,101; 101,1010,1; 1010,-101,10).
U  = (-1,-10,101; 0,0,1; 0,-1,10).
T  = (3838,6666,0).
R=U*B0, det(U)=-1.
```

The orthogonal rows are (0,0,101), (101,1010,0), and (1010,-101,0), with squared lengths 10201,1030301,1030301. Rounding the successive residual coordinates 314/101, 698/101, and -37/101 gives coefficients c=(0,7,3). The lattice point is (3737,6767,37), while original coefficients cU are (0,-3,37).

The displacement from T is (-101,101,37), so the observation errors are (1,-1). Directly, 37+1=38 and 10*37-1=369==66 (mod 101). Its squared distance is 21771, below the containing radius squared 22902; each box coordinate also passes. The scalar is 37, not the last reduced coefficient three.

Uniqueness has an elementary independent proof. The first observation leaves x in {37,38,39}. Multiplying by ten modulo 101 gives {67,77,87}. Only 67 is within centered distance one of 66. Thus the feasible set is exactly {37}. The reduced basis itself includes the short vector (0,0,101), carrying scalar zero and no secret-bearing observation information. Recovery comes from a target-dependent combination and final checking.

This small example is a complete piece of operational mathematics: input data, coordinate map, inverse interpretation, numerical proposal, original verification, and uniqueness argument all fit. It also supplies a useful benchmark for implementations, because each matrix entry and each quotient can be checked with ordinary integer arithmetic.

## A20. Complete enumeration has exact endpoints

A single rounded proposal does not describe all feasible points. A complete lattice search traverses coefficients z from the largest index downward using the distance identity in A18. With the later coefficients fixed, let gamma be the remaining center and s the accumulated squared distance. The next coefficient must satisfy D*(z-gamma)^2<=R_sq-s. All terms are nonnegative, so excluding a branch above the radius cannot remove a boxed point.

Exact rational endpoints avoid a floating square root. Write gamma=P/Q with Q>0 and (R_sq-s)/D=C/E with E>0 and C>=0. Then set

```text
J = isqrt(floor(C*Q^2/E)),
ceil((P-J)/Q) <= z <= floor((P+J)/Q).
```

The quantity Qz-P is integral. Its square is at most C*Q^2/E precisely when its magnitude is at most J, proving the formula even on closed boundaries or at negative centers. Enumerate every integer in this interval, retain the original radius, and test the box and V at every leaf.

Claim A-P10 [PROVED]. This completed finite search returns exactly the observation-feasible scalars passing V. A-P9 gives every feasible scalar its boxed witness. Its partial squared-distance sums never exceed the enclosing radius, so its coefficient path is retained. Every accepted leaf reverses A-P9 and passes V. Finiteness follows because an invertible basis maps a bounded sphere to a bounded coefficient region containing finitely many integer tuples.

Shrinking the radius after finding one good answer changes the task to finding a nearer point; it can delete other observation-feasible scalars. Likewise, a search that examines only reduced basis rows is a candidate generator. It can produce a verified witness, while failure to produce one remains undecided unless another coverage certificate exists.

## A21. Signature equations provide an observation adapter

For ECDSA in a subgroup generated by G of prime order q, let d be the secret scalar and D=[d]G its public key. A valid signature has nonzero components r_i,s_i and correctly converted hash integer z_i. The signing equation is

```text
s_i*k_i == z_i+r_i*d (mod q).
```

SEC 1 specifies these arithmetic and hash-conversion conventions [A-R6]. Inverting s_i gives k_i==a_i*d+b_i, where a_i=r_i*s_i^(-1) and b_i=z_i*s_i^(-1). A independently justified interval for k_i then supplies bounded affine information about d. The signature equation alone does not supply that interval.

Low-s normalization is a concrete modeling issue. Replacing s_i by q-s_i replaces the effective nonce by q-k_i. A small-positive-nonce assumption can therefore turn into a near-q assumption. All signature conventions, signs, and observation origins belong in the model. A recovered d may correctly reproduce the public key while contradicting an assumed nonce bound; those two checks report different facts.

An embedding used in earlier project demonstrations has m diagonal rows with q^2 in the nonce coordinates, secret row (q*a_1,...,q*a_m,B,0), and offset row (q*b_1,...,q*b_m,0,Bq). If k_i=a_i*d_tilde+b_i-q*w_i, the coefficient vector (-w_1,...,-w_m,d_tilde,1) produces

```text
(q*k_1,...,q*k_m,B*d_tilde,Bq).
```

This is a correct exact membership identity. Centering d_tilde and bounding the nonces also prove a norm bound. They do not prove that the vector becomes an individual reduced basis row or the shortest lattice vector.

The obstruction is decisive: q times the secret row minus a_i times each diagonal row gives (0,...,0,Bq,0). It is always shorter than a secret-bearing vector with positive nonces, whose final coordinate already has length Bq. Therefore even an exact shortest-vector oracle has no obligation to return the intended marker-one vector. A marker-slice search, an appropriate closest-vector procedure, or an independent decoding theorem is needed for a universal recovery result. Historical successful synthetic runs remain examples of their executed algorithms rather than a missing general theorem.

The corrected useful product is an observation adapter: exact signing equations generate coefficients, independently supported leakage supplies bounds, a lattice or interval method proposes or enumerates candidates, and original public equations verify them. This design transfers cleanly to noncryptographic problems with bounded modular measurement errors.

## A22. Reusable contracts and practical value

An arithmetic module should record its original domain D, candidate enclosure C, coordinate map T, observation source O, and original verifier V. A congruence module returns a residue with its true period. A bounded module returns every integer alias or an exact compact description. A group module certifies order and scalar domain. A principal-unit module certifies its coefficient representation, prime regime, rank, and precision. A lattice module certifies its full span and searched region.

For a verified witness, the final check suffices to establish membership in S. For complete solutions, every branch and fiber must be covered. For uniqueness, the kernel, interval, or explicit solution count must remove all alternatives. For infeasibility, a complete contradiction or exhausted exact domain is needed. These contracts let several numerical methods collaborate without claiming that one backend handles every algebraic form.

The contribution of Stefan's organization is a persistent operational pattern: expose arithmetic coordinates, preserve their original preimages, exploit accessible structure, and verify the decoded result. Established CRT, cyclic-group methods, local-ring layers, Smith form, and lattice geometry provide the specific theorems. Their combined value is a usable arithmetic workbench and a language for deciding which partial observations genuinely help. The same language identifies the next missing item: another independent residue, a tighter justified bound, an unresolved prime-order logarithm, a singular kernel parameter, or a complete target search.

The accompanying exact family-A suite executes 651,719 assertions at explicitly declared finite ranges. It compares congruence formulas with direct enumeration, digit recovery with original products, polynomial recombination with every toy algebra element, and lattice-box membership with direct scalar tests. The proofs here justify the general identities; the computations check that the displayed finite procedures and examples implement them consistently.

Exercise A-X5. One observation modulo 101 is |ctr_101(x-38)|<=1. Its feasible scalars are 37,38,39. Adding the independent ten-times observation in A-E11 removes two; applying the first observation twice removes none. Exercise A-X6. For the same lattice, reduced coefficient c=(0,7,3) decodes to original scalar 37 because cU=(0,-3,37). A parser that reports three has confused a basis coefficient with the represented scalar.

## Family A references

[A-R1] S. C. Pohlig and M. E. Hellman, "An Improved Algorithm for Computing Logarithms over GF(p) and Its Cryptographic Significance," IEEE Transactions on Information Theory 24(1), 1978, 106-110, DOI 10.1109/TIT.1978.1055817. Sections III-IV establish prime-power digit extraction and CRT in the original prime-field setting. https://ee.stanford.edu/~hellman/publications/28.pdf

[A-R2] A. J. Menezes, P. C. van Oorschot, S. A. Vanstone, Handbook of Applied Cryptography, 1997, Chapter 3, Sections 3.6.2-3.6.4, Algorithm 3.63 and Facts 3.62/3.65. The cited operation count assumes the order factorization; the rho expected-cost statement assumes a suitable random-function model. https://cacr.uwaterloo.ca/hac/about/chap3.pdf

[A-R3] R. Raghavendran, "Finite associative rings," Compositio Mathematica 21(2), 1969, 195-229, Section 3.9, Theorem 9. Its odd-prime Galois-ring principal-unit structure is context for the constructive coefficient proof A-P6. https://www.numdam.org/article/CM_1969__21_2_195_0.pdf

[A-R4] Richard P. Stanley, "Smith Normal Form in Combinatorics," author manuscript dated 18 April 2016; JCTA 144, 476-495. Theorem 2.1(4) supplies Smith-form existence over principal ideal rings; A-P7 derives the modular solution interpretation. https://math.mit.edu/~rstan/papers/snf_survey.pdf

[A-R5] Dan Boneh and Ramarathnam Venkatesan, "Hardness of computing the most significant bits of secret keys in Diffie-Hellman and related schemes," CRYPTO 1996, LNCS 1109, 129-142. Historical hidden-number attribution; no universal recovery theorem from this paper is required here. https://crypto.stanford.edu/~dabo/abstracts/dhmsb.html

[A-R6] Standards for Efficient Cryptography, SEC 1, version 2.0, 21 May 2009, Sections 4.1.3-4.1.4, printed pages 44-47. Signing and verification conventions only; no attack-success theorem. https://www.secg.org/sec1-v2.pdf

[A-R7] Keith Conrad, Infinite Series in p-adic Fields, author-hosted mathematical exposition, Theorems 8.5 and 8.13. The inverse chart uses valuation greater than 1/(p-1); in Q_p this gives pZ_p for odd p and 4Z_2 for p=2. The commutative coefficient-algebra application is justified by the coefficientwise convergence and formal-series argument in A12. https://kconrad.math.uconn.edu/blurbs/gradnumthy/infseriespadic.pdf

# Prime-power digits, valuation, and multiplicative coordinates

## B1. What a prime-power coordinate actually records

Stefan's recurring proposal is to expose a difficult quantity in several simpler coordinates, recover manageable pieces, and recombine them. Prime-power arithmetic supplies a precise version of that proposal. The useful pieces are residues, divisibility depths, finite unit components, and compatible digit corrections. Their roles differ. A residue describes a whole fiber of possibilities; a divisibility depth describes a scale; a unit coordinate describes the remaining multiplicative part. A reconstruction method becomes exact when every discarded possibility is excluded by a necessary condition and every retained ambiguity remains represented.

For a prime p and positive precision k, a residue modulo p^k records the first k least significant base-p digits. Increasing k exposes another digit at the high end of that known prefix. The ordinary integers producing one observation r are exactly r+p^k*t with t an integer. Thus the observation map O(x)=x modulo p^k generally loses the quotient t. A finite bound can later constrain that quotient. Rewriting the same observation in another coordinate cannot expose an additional digit that was never observed.

The finite ring Z/p^k Z and the infinite ring Z_p serve different purposes. The first is a finite calculation space with p^k elements. The second consists of compatible sequences of residues at every precision. Compatibility means that a residue at level k+1 reduces to the previously recorded residue at level k. An arbitrary sequence of modular answers need not have that property. The field Q_p additionally permits negative powers of p; an element with negative valuation lies outside Z_p.

The p-adic distance declares two numbers close when their difference is divisible by a high power of p. This is a different notion of closeness from small real error. The representatives p^k-1 grow as real integers but approach -1 p-adically, since their differences from -1 equal p^k. No contradiction occurs: the two metrics measure different features. A local solver reporting a p-adic approximation must name its prime and precision. Without those fields, an integer-looking answer can be mistaken for an ordinary integer root.

## B2. Valuation, cancellation, and finite precision

For nonzero rational x, write x=p^t*u with numerator and denominator of u both coprime to p. Define v_p(x)=t, v_p(0)=infinity, and |x|_p=p^(-t). The integer t counts net divisibility rather than ordinary magnitude. The basic rules follow immediately from factoring powers of p:

```text
v_p(x*y)=v_p(x)+v_p(y).
v_p(x/y)=v_p(x)-v_p(y), y != 0.
v_p(x+y)>=min(v_p(x),v_p(y)).
If v_p(x)!=v_p(y), equality holds in the final relation.
```

**B-P1, PROVED: the unique least-valuation obstruction.** A finite sum of nonzero terms cannot vanish if exactly one term has strictly smaller valuation than every other term. Divide by the smallest power of p. The exceptional term becomes a unit, while every other term becomes divisible by p. Reduction modulo p leaves a nonzero residue, contradicting zero. This proves a useful exclusion rule without solving the original equation.

For a polynomial f(X)=sum_j a_j*X^j and a proposed nonzero root of valuation t, its term weights are w_j(t)=v_p(a_j)+j*t, omitting zero coefficients. At least two weights must attain the minimum. Pairwise intersections of the weight lines supply possible scales, but an intersection matters only when its common weight is globally minimal. A rational intersection slope can describe a root in an extension field. In Q_p itself, nonzero valuations are integers; in Z_p they are nonnegative integers.

For example, X^3-3 has term weights 3t and 1. Equality would require t=1/3, so the equation has no root in Q_3. This says nothing about its positive real root or its roots in algebraic extensions of Q_3. In contrast, for X^3-27 the possible scale t=1 survives; setting x=3u produces u^3=1. The scale condition is necessary, and the normalized unit equation decides whether it is sufficient.

**B-P2, PROVED: scale normalization preserves roots.** Set m=min_j w_j(t), substitute X=p^t U, and define h(U)=p^(-m)f(p^t U). Every coefficient of h is p-integral because its valuation is w_j(t)-m>=0. On units U, the substitution is a bijection onto quantities of valuation t, and multiplication by the nonzero scalar p^(-m) preserves the zero set. This is an exact coordinate change. It is not a claim that all possible scales contain roots.

Finite observations need an explicit loss rule. If x is known modulo p^k and has observed valuation t<k, its unit quotient is known only modulo p^(k-t). If the observed residue is zero, the conclusion is v_p(x)>=k; exact zero has not been established. In a finite ring the truncated valuation of zero is conventionally k, whereas the field valuation of exact zero is infinity. Keeping those definitions separate prevents accidental division of unknown digits.

### B-E1. Extracting scale without inventing precision

Suppose x is observed as 75 modulo 243. Since 75=3*25 and 25 is not divisible by 3, the observed scale is t=1. Every possible original integer has the form 75+243q=3*(25+81q). The unit coordinate is therefore 25 modulo 81, and no stronger unit observation follows. Its known ternary digits are 25=1+2*3+2*9+0*27; the quotient digit beyond 81 remains unknown.

Multiplying two such observations gives a product of scale 2, provided both observed unit parts remain units. Their unit product is known modulo 81, which corresponds to the product modulo 3^6 after restoring scale 2. Addition behaves differently: 75+6=81 has valuation 4, although both summands have valuation 1. Their unit residues cancel. This numerical contrast explains why valuations add under multiplication but need a cancellation calculation under addition.

A practical representation stores the prime, absolute precision k, observed depth t, and unit precision k-t. A zero residue stores a lower bound on depth rather than a guessed unit. Every operation must propagate those fields. A logarithm taken after scale removal receives the smaller precision, not the original k.

## B3. Separating torsion from the principal unit

For odd p, a nonzero element of Q_p has a unique decomposition

```text
x=p^t*omega*u1,
t in Z, omega^(p-1)=1, u1 in 1+pZ_p.
```

The factor omega is the Teichmuller lift of the nonzero residue of the unit part. It exists uniquely because the polynomial W^(p-1)-1 has nonzero derivative at every nonzero residue root. The lifting proof appears in the next chapter. Removing omega leaves residue 1 modulo p, which is exactly the principal-unit condition. The finite root-of-unity factor and the principal unit intersect only in 1, establishing uniqueness.

At finite precision, for an ordinary scalar unit u and odd p, omega(u) can be computed as u^(p^(k-1)) modulo p^k. Raising a principal unit to p^(k-1) annihilates it at that precision; raising a torsion unit to this exponent fixes it because p^(k-1)==1 modulo p-1. The formula does not mean that integer exponentiation becomes cheap at every large precision. It is an exact alternative to lifting the torsion equation.

For Q_2, every odd unit is a sign times an element of 1+4Z_2. The sign is selected from the residue modulo 4: use +1 for residue 1 and -1 for residue 3. Consequently a full scalar coordinate is x=2^t*sign*u1. This binary sign rule is specific to residue degree one. In a larger unramified coefficient ring, the quotient (1+2O)/(1+4O) has several coefficient directions, and one sign bit does not remove them all.

The word logarithm names three different constructions in this project. The ordinary real logarithm measures real scale and satisfies log(ab)=log(a)+log(b) for positive real inputs. A finite-group discrete logarithm asks for an exponent residue n with g^n=h. The p-adic logarithm is a convergent series giving an additive coordinate on suitable principal units. None can be substituted for another merely because exponents occur in the problem.

## B4. The genuine logarithmic chart and its guards

The relevant analytic series are

```text
log_p(1+z)=sum_(n>=1) (-1)^(n+1)*z^n/n.
exp_p(y)=sum_(n>=0) y^n/n!.
Odd p: 1+pZ_p <-> pZ_p.
p=2:   1+4Z_2 <-> 4Z_2.
```

**B-P3, PROVED: inverse multiplicative coordinates on these domains.** Legendre's counting identity v_p(n!)=sum_(j>=1) floor(n/p^j) gives the exponential term valuations. For odd p and v_p(y)>=1, they tend to infinity; at p=2 the sufficient integral condition is v_2(y)>=2. The logarithm term valuations tend to infinity whenever v_p(z)>0. On the narrower common domains, every term after the first has strictly greater valuation than the first. Thus v_p(log_p(1+z))=v_p(z) and v_p(exp_p(y)-1)=v_p(y).

The formal identities exp(A+B)=exp(A)exp(B), log(exp(Y))=Y, and exp(log(1+Z))=1+Z hold over rational power series. The binomial theorem proves the first; formal differentiation and constant coefficients prove the second; compositional inversion with linear coefficient 1 proves the third. The term valuation bounds justify substitution and regrouping on the stated p-adic domains. Consequently log_p(uv)=log_p(u)+log_p(v) and the displayed charts are inverse group isomorphisms. This argument uses commutativity and cannot be silently transferred to noncommuting matrix products.

Convergence and injectivity are separate properties. The 2-adic logarithm converges on all odd scalar units, but log_2(-1)=0. Indeed, its product law gives 2log_2(-1)=log_2(1)=0 in characteristic zero. Hence log_2(1)=log_2(-1), so this larger domain is not an invertible chart. The sign must be retained or the inputs restricted to 1+4Z_2. Similarly, extending the odd-prime logarithm across all units erases their finite torsion component.

The chart linearizes products and powers. It supplies no identity log_p(u+v)=log_p(u)+log_p(v). In a general cubic, additive terms remain coupled. The useful operational form is therefore a guarded transform: first establish the unit domain, remove valuation and torsion when required, apply the product relation, retain its precision, and reconstruct with exp_p. Conditions established on that guard cannot reject candidates outside it.

## B5. Exact finite series evaluation

At precision p^k, infinite analytic functions can be evaluated by finite exact sums. For odd p and inputs divisible by p, terms with n>=2k vanish modulo p^k. The logarithm term has valuation at least n-v_p(n), while the exponential term has valuation at least n-v_p(n!). For odd p, both denominator valuations are at most (n-1)/2, so both lower bounds are at least (n+1)/2. At p=2 on the safe depth-two domains, the analogous bounds are at least n+1. Thus the same conservative cutoff 2k works there too.

A denominator divisible by p cannot be inverted modulo p^k. Write it as p^e*d0 with d0 a unit. Compute the numerator modulo p^(k+e), cancel p^e exactly, then multiply by inverse(d0) modulo p^k. The extra e digits are necessary: changing the original numerator by a multiple of p^(k+e) changes the quotient only by a multiple of p^k. The first individually vanishing series term is not a valid stopping rule, since denominator valuations jump at later powers of p.

### B-E2. A pure cube with its missing input digit supplied

For a 3-adic unit c, retain its sign eta in {+1,-1} and set u=eta*c, so u==1 modulo 3. The equation x^3=c becomes a fixed sign equation and 3*ell=log_3(u), with ell in 3Z_3. Multiplication by 3 is injective on 3Z_3 and its image is 9Z_3. Therefore a unit has a 3-adic cube root exactly when log_3(u) is divisible by 9, equivalently c==+1 or -1 modulo 9.

For c=343 the sign is +1. Desired root precision is 3^6=729, so the logarithm input precision must be 3^7=2187. Exact truncated evaluation gives log_3(343)==666 modulo 2187. Division gives ell==222 modulo 729, and exact exponential evaluation gives exp_3(222)==7 modulo 729. Cubing checks 7^3=343, establishing an ordinary integer root in this special example as well as the local answer.

Without the extra input digit, division by 3 would determine ell only modulo 243. Finite cube congruences can have three solutions although the infinite 3-adic unit root is unique. The ambiguity reflects precision loss in the map ell->3ell. For p different from 3, the principal-unit cube map is invertible; any remaining multiplicity comes from the torsion equation omega^3=eta. For nonunit c, the valuation condition 3t=v_p(c) must also be solved.

## B6. Exercises on typed multiplicative coordinates

**B-X1.** From x==0 modulo 81, determine the strongest justified scale statement. **Answer:** v_3(x)>=4, with exact zero still possible. No unit coordinate is available until a nonzero higher digit is observed.

**B-X2.** Determine whether X^3=6 has a root in Q_3. **Answer:** v_3(6)=1 would require 3v_3(X)=1, impossible for an integer-valued Q_3 valuation. The exclusion is local and does not exclude the real cube root.

**B-X3.** Determine whether 5 is a 3-adic unit cube. **Answer:** the unit cubes modulo 9 are 1 and 8; 5 is neither. This finite obstruction already excludes every higher compatible root.

# Coupled exponents in coefficient rings

## B7. Why coefficients can expose several directions

A finite-group exponent equation can be difficult because its representation hides the scalar exponent. A principal-unit equation in an explicitly represented coefficient ring is different: its successive layers expose additive coefficient vectors. Stefan's proposed decomposition becomes practical when the representation makes those vectors available. The advantage comes from that public arithmetic structure, not from declaring every group to have several coordinates.

Let F(T) be monic of degree d and work in the commutative ring R_k=(Z/p^k Z)[T]/(F(T)). Monic division gives a unique representative with d coefficients modulo p^k. If F modulo p is irreducible, the residue algebra is the field F_(p^d), and this construction is an unramified Galois ring. Without irreducibility it is still a free coefficient algebra, but it must not automatically be called a field or an unramified local ring. The principal-unit theorem below needs freeness and commutativity; its digit proof does not need irreducibility.

For k>1 the ring R_k is not the field with p^(dk) elements. Its characteristic is p^k, and p is a nonzero nilpotent element. A field has neither property. For example, R_k=(Z/3^k Z)[alpha]/(alpha^2+1) has coefficient pairs (a,b) with multiplication (a,b)(c,e)=(ac-be,ae+bc). The residue polynomial is irreducible over F_3. A pair is a unit exactly when its two coefficients are not both divisible by 3; its inverse is (a,-b)/(a^2+b^2).

The principal units U_j=1+p^j R_k have successive layers

```text
(1+p^j*a)(1+p^j*b)==1+p^j*(a+b) (mod p^(j+1)).
U_j/U_(j+1) is the additive coefficient space (F_p)^d.
```

The layer multiplication identity follows because the omitted product contains p^(2j), divisible by p^(j+1) for j>=1. Each increased precision therefore exposes d scalar digit directions. Precision depth k and coefficient degree d count different resources: one adds layers, the other adds directions in each layer.

## B8. The exact tangent-matrix criterion

Assume p is odd, k>=2, and bases g_ij=1+p*c_ij. For s equations and n unknown scalar exponents, define

```text
h_i=product_(j=1)^n g_ij^(x_j), h_i in U_1.
P=p^(k-1), x in (Z/PZ)^n.
A: stack the d coefficients of every c_ij modulo p.
A has d*s rows and n columns over F_p.
```

**B-P4, PROVED: square coupled recovery.** If n=d*s, the exponent map is bijective exactly when A is invertible over F_p. Every target then has one exponent vector modulo P, recoverable in k-1 digit rounds. The conclusion refers to the declared exponent domain. Bounds on ordinary integer exponents require a later fiber calculation.

The key powering identity is (1+p*c)^(p^j)==1+p^(j+1)*c modulo p^(j+2). For one pth power, the linear term has the displayed value; intermediate binomial terms contain an additional p and at least two copies of the input depth; the last term has depth at least p times that depth. For odd p, every omitted term lies in the required higher ideal. Induction proves the identity. One further power shows that every principal unit has exponent dividing P.

Start with x^(0)=0. At stage ell, an approximation fixed modulo p^ell matches the target modulo p^(ell+1). Form residuals r_i=h_i*product_j g_ij^(-x_j^(ell)). These lie in U_(ell+1). Extract the coefficients of (r_i-1)/p^(ell+1) modulo p and stack them as b_ell. Writing the next approximation as x^(ell+1)=x^(ell)+p^ell*d_ell produces exactly A*d_ell=b_ell. An invertible A determines one digit vector at every round; after k-1 rounds the complete products agree modulo p^k.

Necessity has a direct kernel proof. If A*v=0 with v nonzero, the nonzero exponent vector p^(k-2)*v maps to the identity by the final-layer powering formula. The exponent map cannot be injective. Conversely, for an invertible A, a nonzero exponent difference has a first nonzero p-adic digit vector, and its first surviving product layer equals A times that vector. It cannot vanish. The finite domain and target have the same cardinality P^n, so injectivity also proves bijectivity. This second argument exposes the exact obstruction rather than simply counting successful iterations.

For a rectangular A, full column rank proves injectivity onto the image; full row rank proves surjectivity onto every target. A deficient rank does not permit an arbitrary digit choice. A choice compatible at one layer may fail later, while a discarded alternative may have survived. A complete solver stores the full kernel directions or uses a complete modular matrix reduction.

### B-E3. Recovering two exponents from one ring-valued target

Work modulo 81 with alpha^2=-1, bases g_1=4 and g_2=1+3alpha, and target h=25+66alpha. The tangent columns are (1,0) and (0,1), so A is the identity. The scalar exponent period is P=27, and the target supplies two independent coefficient directions.

At the first round, (h-1)/3=(8,22)==(2,1) modulo 3. Thus the first exponent approximation is (2,1). Removing its product from h leaves residual 10+45alpha. At the second round, (r-1)/9=(1,5)==(1,2) modulo 3. Adding 3*(1,2) gives exponents (5,7). Their residual is now 1, so the last digit vector is (0,0). Direct repeated-squaring multiplication verifies 4^5*(1+3alpha)^7==25+66alpha modulo 81.

An independent logarithmic route uses lambda(u)=log(u)/3 modulo 27. Exact finite series give lambda(4)=(16,0), lambda(1+3alpha)=(15,25), and lambda(h)=(23,13). Hence

```text
C=[[16,15],[0,25]], C*(5,7)^T==(23,13)^T (mod 27).
16*5+15*7=185==23 (mod 27).
25*7=175==13 (mod 27).
det(C)=400==22 (mod 27), a unit.
```

The two computations share the same ring arithmetic, but one peels product residuals while the other transforms the whole equation to a modular matrix. Their agreement is a useful check. It is not an assertion that two mutually independent observations were supplied: both represent the same target.

## B9. Singular systems and complete solution families

For odd p, the map lambda(u)=log(u)/p identifies U_1 with the additive coefficient module modulo P=p^(k-1). Bases and targets therefore give a complete system C*x==b modulo P. The log input is required modulo p^k, since division by p consumes one absolute precision digit. This transformed system is equivalent in both directions to the original products, because lambda is an injective group coordinate.

When an integer Smith decomposition J=U*C*V is available, with U and V unimodular, set x=V*z and b'=U*b. Integer unimodularity makes both transformations invertible modulo every modulus. For each nonzero diagonal d_i, let delta_i=gcd(d_i,P). The scalar equation d_i*z_i==b'_i modulo P is compatible exactly when delta_i divides b'_i. Dividing that common factor yields one residue modulo P/delta_i and all delta_i lifts modulo P. A zero row requires b'_i==0 modulo P, and unused columns are free.

**B-P5, PROVED given the integer Smith decomposition:** a compatible transformed system has P^(n-r)*product_i delta_i solutions modulo P, where r is the number of nonzero integer diagonal entries. Each diagonal coordinate contributes delta_i solutions and each free column contributes P; independent coordinates multiply the counts. Equivalently, every nonempty homomorphism fiber is a coset of the homogeneous kernel. A zero answer count requires an actual failed compatibility condition, not a solver timeout.

If delta_i=P, the coordinate is completely free when compatible, and no inverse modulo 1 is needed. First-layer rank alone does not measure all remaining ambiguity: the valuations of the diagonal coefficients record how many exponent digits were lost. A compact affine kernel description may represent many solutions without enumerating each one. When ordinary integer bounds are imposed, they constrain x=V*z in the original coordinates and generally become coupled inequalities. Copying the original separate bounds directly onto z changes the problem.

### B-E4. A singular direction with a precisely measured ambiguity

At modulus 81, replace the second base in B-E3 by 1+9alpha. Its tangent column is zero, because its first nontrivial coefficient begins one layer later. Its logarithmic coordinate modulo 27 is (0,3): the linear term contributes 3alpha after division by 3, and the remaining terms vanish at that precision. The first base still has coordinate (16,0).

For target coordinates b=(23,21), the transformed equations are 16x==23 and 3y==21 modulo 27. Since 16 is a unit, x==5 modulo 27. Division of the second congruence gives y==7 modulo 9, with all three exponent residues y=7,16,25 modulo 27 retained. The second base has order 9, so these are three aliases of the same power. Declared exponent uniqueness fails while the produced ring element remains uniquely specified.

If the second target coordinate were 1, the equation 3y==1 modulo 27 would be impossible. This supplies a short inconsistency certificate: the right-hand side is not divisible by gcd(3,27)=3. A digit method that guessed y=0 before seeing the second layer could wrongly discard the valid y=7 branch. The complete modular family gives both the valid aliases and the exact unreachable-target condition.

## B10. Binary corrections and retained parity branches

The odd-prime powering formula cannot be transferred unchanged to p=2. In Z/8Z, the base 3 has square 1, while an unguarded odd-prime formula would predict 5. Binary principal units at depth one contain torsion, and their logarithm loses it. The safe logarithmic subgroup is U_2=1+4R_k.

For k>=3, declare scalar exponent residues modulo 2^(k-1) and write x_j=epsilon_j+2z_j uniquely, with epsilon_j in {0,1} and z_j modulo 2^(k-2). Retain every parity vector satisfying the first-layer equations. For each parity vector, remove its product from the target. The residual and all squared bases lie in U_2, because (1+2c)^2=1+4(c+c^2). Their remaining equations can be solved using lambda_2(u)=log(u)/4 modulo 2^(k-2), followed by x=epsilon+2z.

This branch construction is complete: every original exponent vector has one parity decomposition, and every reconstructed vector is checked in the original products. The declared period can exceed a base's actual order, so aliases remain possible. For k=2 only the parity layer is present; for k=1 the principal group is trivial. In coefficient degree greater than one, all coefficient parity directions must be solved. The scalar sign decomposition is insufficient there.

For a scalar example modulo 16, the equation 3^x==11 has exponent residues modulo 8. Its first layer forces odd parity, so x=1+2z. Removing 3 gives residual 9, and the squared base is also 9. The safe logarithmic coordinate is log_2(9)/4==2 modulo 4. The remaining equation 2z==2 modulo 4 gives z=1 or 3, hence x=3 or 7 modulo 8. Both pass direct powering. The two answers are aliases because the base 3 has actual order 4. This calculation retains the torsion and precision information that an unrestricted logarithmic inversion would erase.

A solver may cache its bases, coefficient matrix, Smith transforms, or an invertible matrix inverse for repeated targets. A valid cache key includes p, k, the defining polynomial, coefficient basis, bases, and logarithm domain. A matrix computed in another ring presentation needs a verified coordinate change before reuse. These requirements describe the mathematics of what is being reused, rather than implementation bookkeeping alone.

## B11. The base-two exponent bridge at powers of three

**B-P6, PROVED:** the order of 2 modulo 3^k is 2*3^(k-1). Modulo 3 its order is 2. For positive m, v_3(4^m-1)=1+v_3(m): cubing a unit 1+w of positive 3-adic depth increases the depth of its difference from 1 by exactly one, while an exponent coprime to 3 leaves that depth unchanged. Factoring m into its 3-power and coprime parts proves the valuation formula and hence the order. The order equals the number of units, so every unit has exactly one base-two exponent residue.

An observed unit u modulo 3^k first determines parity epsilon from u modulo 3. Remove 2^epsilon, obtaining w=u/2^epsilon in the principal units. Then n=epsilon+2t and 4^t=w. Taking logarithms and dividing by 3 gives

```text
t==(log_3(w)/3)*inverse(log_3(4)/3) (mod 3^(k-1)).
n==epsilon+2t (mod 2*3^(k-1)).
```

The coefficient log_3(4)/3 is a unit, so its inverse exists. For k=1 parity alone supplies the answer. This is an exact special discrete-logarithm coordinate for this explicitly represented smooth-order unit group. An arbitrary relation in a prime-field group does not lift to all higher powers of the characteristic; applying this formula to unrelated integer representatives solves another problem.

### B11.1. Doubling as a sign flip and a translation

The recovered doubling manuscript supplies another useful coordinate for the same unit tower. Set ell=log_3(-2)=log_3(1-3), whose valuation is 1. For a unit u, remove its sign and define tau=log_3((-1)^epsilon*u)/ell. Division by ell identifies 3Z_3 with Z_3, since ell/3 is a unit. The resulting map is

```text
Psi(u)=(epsilon,tau) in (Z/2Z) x Z_3.
Psi^(-1)(epsilon,tau)=(-1)^epsilon*exp_3(ell*tau).
Psi(2u)=(epsilon+1,tau+1).
```

The proof uses the same separate sign and principal-unit coordinates already established. Multiplication by 2 changes sign and adds log_3(-2) to the logarithmic component. Normalizing by ell changes that increment to 1. This is a conjugacy of the doubling map with a translation, not a claim that doubling is an automorphism of the multiplicative group: translating a group element by a fixed element generally does not preserve the identity.

At modulus 3^k, tau is known modulo 3^(k-1), because dividing the logarithm by a depth-one coefficient consumes one digit. The pair of increments (1,1) has order 2*3^(k-1), matching the finite doubling cycle. For k=5, exact finite evaluation gives ell==24 modulo 243 and exp_3(24)==241, which is -2 modulo 243. The normalized coordinates of 2 are therefore (1,1), and the inverse chart gives (-1)*241==2 modulo 243. The retained sign prevents confusing -2 with 2.

At infinite precision every unit orbit under repeated doubling is dense in Z_3's unit group: every finite unit quotient is traversed, so every residue-cylinder neighborhood is visited. No nonzero p-adic integer is periodic, since 2^n*u=u would give (2^n-1)u=0 in the characteristic-zero domain Z_3. Finite periodicity and infinite nonperiodicity coexist because they concern different state spaces.

The rational sequence x_n=243*(2/9)^n illustrates the scale extension. Its coordinates change by valuation -2, sign flip 1, and translation 1 at each step. Real magnitude tends to zero while its 3-adic magnitude grows; from n=3 onward it lies outside Z_3. Only its normalized unit part 2^n belongs to the finite unit tower. These coordinates can support exact cycle descriptions or numerical state machines, but an added spatial model requires its own map and compatibility conditions. The recovered manuscript states that the linked original Zenodo PDFs were unavailable; this compilation checks the supplied reconstruction and does not upgrade it to an audit of those inaccessible originals.

### B-E5. Exponent digits that remain ambiguous until the period grows

Take the observed value of 2^173 at successive powers of 3. The pairs of observation and reconstructed exponent residue are: modulo 3, u=2 and n==1 modulo 2; modulo 9, u=5 and n==5 modulo 6; modulo 27, u=23 and n==11 modulo 18; modulo 81, u=23 and n==11 modulo 54; modulo 243, u=104 and n==11 modulo 162; modulo 729, u=347 and n==173 modulo 486; modulo 2187, u=1805 and n==173 modulo 1458.

The repeated value 23 at two precisions does not mean identical information: its modulus increased. At modulus 243 the class 11 modulo 162 still includes both 11 and 173. At modulus 729, a stated ordinary bound 0<=n<=200 leaves exactly 173. Without that bound, the answer remains an exponent residue modulo 486. The residue itself is exact; selecting one ordinary exponent requires the residual fiber to be constrained.

## B12. Exercises on exponent families

**B-X4.** Solve 9x==18 modulo 27. **Answer:** divide the common factor 9 to obtain x==2 modulo 3. The nine residues 2,5,8,11,14,17,20,23,26 remain modulo 27. Inversion of 9 modulo 27 is invalid.

**B-X5.** Explain why the target in B-E3 can determine two scalar exponents although it is one ring element. **Answer:** its representation has two independent coefficient directions, and the tangent matrix is invertible. A single opaque group element supplies no automatic access to those coefficient equations.

# Polynomial lifting and the bounded cubic ratchet

## B13. The output domain comes before the numerical method

A cubic has roots over several domains, and a solver must name the required one. This chapter's exact finite method returns every distinct integer root in a certified interval D=[L,U] intersect Z. A reversible scaling extends it to every rational root of an integer-coefficient cubic. Finite modular roots and infinite p-adic roots are intermediate objects. Irrational real roots and complex roots need separate exact algebraic representations or rigorous numerical enclosures.

Write f(X)=aX^3+bX^2+cX+d with integer coefficients and a!=0, and S={x in D:f(x)=0}. A candidate enclosure C is valid when S is contained in C. The term precision ratchet means a sequence of compatible, nested enclosures C_new subset C. It does not require every step to remove a candidate or every raw residue count to decrease. The final verifier V(x) evaluates the original f exactly.

If D is not supplied as a genuine input restriction, derive a bound. Set A0=max(|b/a|,|c/a|,|d/a|) and B=1+ceil(A0). Every complex root has magnitude at most 1+A0. To prove this, suppose t=|z|>1+A0 for a root. The triangle inequality gives t^3<=A0*(t^2+t+1)<(t-1)*(t^2+t+1)=t^3-1, a contradiction. Thus [-B,B] contains all integer roots. Exact integer ceiling arithmetic avoids rounding errors for large coefficients.

The bound is a completeness tool, not an efficiency guarantee. A large coefficient may produce a wide interval. A solver can exploit residue structure to avoid testing every integer, but its work depends on branch counts and representation costs as well as interval width. A resource cap must return unresolved status if the required coverage certificate has not been obtained.

## B14. The exact local digit equation

For r a root modulo p^k with k>=1, every possible next residue is uniquely r+p^k*t with t in {0,...,p-1}. For a cubic, integer expansion gives

```text
f(r+T)=f(r)+f'(r)*T+(3ar+b)*T^2+a*T^3.
f'(r)=3ar^2+2br+c.
q=f(r)/p^k, an exact integer.
f(r+p^k*t)==0 (mod p^(k+1))
  iff q+f'(r)*t==0 (mod p).
```

**B-P7, PROVED: complete one-digit lifting.** The omitted terms are divisible by p^(2k), and 2k>=k+1. Dividing the remaining congruence by p^k reduces its modulus to p, giving the displayed affine equation. This proof uses an integral identity before reduction, so it is valid at p=2 and p=3 without inverting factorials.

If the slope f'(r) is nonzero modulo p, exactly one digit survives: t==-q*inverse(f'(r)) modulo p. If both slope and q vanish modulo p, all p digits survive. If the slope vanishes while q does not, no digit survives. These three cases are the entire branching rule. Every higher root reduces to a lower root and has one of these digits; every generated child satisfies the higher congruence. Starting with every seed modulo p therefore produces complete root lists at every finite level.

A simple seed retains a unit derivative at all descendants and has one child forever. Its coherent sequence defines one root in Z_p by completeness and polynomial continuity. Uniqueness concerns that initial residue class. Other simple seeds can define other roots, and a singular seed may produce several roots or none. Existence of one valid local chain never certifies that the polynomial has only one global solution.

### B-E6. A cubic root in Z_5 that is not an integer root

For f(X)=X^3-2, the seed r=3 satisfies f(3)=25 and f'(3)=27. At p=5, q=5==0 and slope 2, so the next digit is 0; the root remains 3 modulo 25. At that level q=25/25=1 and slope is still 2, giving digit -1/2==2 modulo 5. The next representative is 3+25*2=53 modulo 125.

At r=53, f(r)=148875 and q=1191==1 modulo 5; the next digit is again 2, giving 303 modulo 625. Further exact lifting gives 2178 modulo 3125 and 5303 modulo 15625. Each representative reduces to the previous one. These digits describe a 5-adic root of X^3-2.

No integer has cube 2, and the rational-root theorem excludes a rational root of this monic cubic. The local root remains useful for modular filtering while the ordinary rational root set is empty. A real approximation to the cube root of 2 requires a different error metric and output format. The integer-looking representative 5303 is neither a real approximation to that root nor an exact integer solution.

## B15. Singular branches, locked digits, and Newton acceleration

For f(X)=(X-2)^3, the congruence modulo 3^k is equivalent to x==2 modulo 3^ceil(k/3). Thus the number of residue roots is 3^(k-ceil(k/3)), giving counts 1,3,9,9,27,81,81,243 at levels 1 through 8. The raw count grows, yet the condition on ordinary candidates becomes stronger. Every child retains its parent prefix; this is the precise meaning of a locked digit relative to one branch.

By contrast, X^3-3 has seed 0 modulo 3 but no child modulo 9: q=-1 and slope 0. A finite surviving branch can later die, so survival at a depth cutoff is not proof of an infinite root. If a fixed prefix has descendants at arbitrarily high levels, finite branching ensures an infinite compatible path; the depth cutoff alone supplies no such premise.

For a unit derivative, a Newton block step can double precision. If p^k divides f(r), use r_new==r-f(r)*inverse(f'(r)) modulo p^(2k). The correction is divisible by p^k; its linear contribution cancels the residual, and its squared remainder vanishes modulo p^(2k). The block digit is uniquely determined because the slope is a unit.

A nonunit derivative needs a different guard. Let s=v_p(f'(r)) be finite and assume v_p(f(r))>2s. Substituting X=r+p^(s+1)Z and dividing by p^(2s+1) gives a p-integral polynomial whose reduction is linear with unit slope. Indeed, writing f'(r)=p^s*u gives

```text
f(r+p^(s+1)Z)/p^(2s+1)
=f(r)/p^(2s+1)+uZ+p*(3ar+b)Z^2+p^(s+2)*aZ^3.
```

Simple lifting therefore proves exactly one root in the ball v_p(alpha-r)>s. Newton corrections remain in that ball and their precision increases. This is the strong Hensel condition. It does not justify inverting a nonunit derivative in the finite residue ring. Division is carried out with appropriate extra precision and consumes s digits.

A tangent approximation also has a ceiling. If v_p(T)>=j, the omitted cubic remainder has depth at least min(2j+v_p(3ar+b),3j+v_p(a)). It can be omitted only modulo powers no higher than this bound. For f(X)=X^3+X^2-80, r=1, and T=3, the true root is 4; the linear part is -63 and the remainder is 63. Dropping the remainder is valid modulo 9 but would reject that true root modulo 27.

## B16. Recombination means all compatible bounded fibers

Local residues must concern the same original integer before they can be joined. For x==r modulo m and x==s modulo n, let g=gcd(m,n). Compatibility requires g to divide s-r. In that case the combined class has modulus M=lcm(m,n), obtained by writing x=r+mt and solving

```text
t==((s-r)/g)*inverse(m/g) (mod n/g).
R==r+m*t (mod M).
```

When n/g=1, take t=0 without seeking an inverse modulo 1. Different-prime constraints multiply their moduli. A deeper observation at the same prime replaces a contained power; it does not multiply two independent pieces of information. If local root lists have several branches, every compatible tuple must be retained until an explicit bound or equation excludes it.

The bounded fiber x=R+Mt has quotient interval ceil((L-R)/M)<=t<=floor((U-R)/M). Its exact count is the length of that integer interval, or zero when the interval is empty. If M>U-L, one class contributes at most one integer: two distinct members would differ by at least M but by at most the interval width. This is a per-class statement. A union of classes can still contain several candidates.

For X^3-X in [-10,10], local roots modulo 5 and 7 produce modulus 35 and bounded survivors -6,-1,0,1,6. Although 35 exceeds the width 20, the candidates are not a singleton. Exact substitution rejects -6 and 6, whose polynomial values are -210 and 210. CRT solved the congruence correctly; final verification supplies the original equation.

### B-E7. The complete 225-to-one cubic reconstruction

Take f(X)=X^3-37X^2+3X-111. Its coefficient bound gives B=112 and D=[-112,112], containing 225 integers. Modulo 3 the polynomial is X^2(X-1), so seeds 0 and 1 leave 150 candidates. At 0, q=f(0)/3=-37==2 and slope 3==0 modulo 3; this singular branch dies. At 1, q=-48==0 and slope -68==1; digit 0 gives the sole residue 1 modulo 9, leaving 25 candidates.

Modulo 5 the sole root is 2. Joining x==1 modulo 9 and x==2 modulo 5 gives x==37 modulo 45. The five bounded members are -98,-53,-8,37,82. The number 37 is at this point a convenient representative, not yet an established root.

Lift the ternary branch: f(1)/9=-16==2 and slope 1 give next digit 1, hence 10 modulo 27. Joining with residue 2 modulo 5 gives 37 modulo 135, leaving -98 and 37. Lift the five-adic branch: f(2)/5=-49==1, slope -133==2, inverse slope 3, and digit -3==2 give 12 modulo 25. Joining 10 modulo 27 and 12 modulo 25 gives 37 modulo 675.

Now 675 exceeds the interval width 224, and the sole bounded member is 37. Direct evaluation gives f(37)=0. The candidate counts are 225,150,25,5,2,1. Every seed and every child was covered, so completeness accompanies the accepted root. Independently expanding (X-37)(X^2+3) verifies the factorization and shows that 37 is the only real root; the other algebraic roots are +i*sqrt(3) and -i*sqrt(3).

## B17. Rational roots and height reconstruction

**B-P8, PROVED: rational-to-integer scaling.** Set Y=aX and g(Y)=Y^3+bY^2+acY+a^2d=a^2f(Y/a). A rational root of f maps to a rational root of the monic integer polynomial g. If a monic polynomial has reduced rational root m/n, clearing denominators and reducing modulo n forces n to divide m^3, hence n=1. Therefore Y is integral. Conversely any integer root Y of g gives rational root Y/a of f. These maps are inverse on the root sets, including negative a.

### B-E8. Three rational answers recovered through integers

For f(X)=2X^3-3X^2-3X+2, use Y=2X. The scaled polynomial is g(Y)=Y^3-3Y^2-6Y+8. Its integer root set is {-2,1,4}, established by a complete integer solver and independently checked through g(Y)=(Y+2)(Y-1)(Y-4). Mapping back gives {-1,1/2,2}. Exact fraction substitution into f verifies each answer. Applying the root bound to g supplies a complete domain; an assumed denominator bound is unnecessary.

A more general export interface reconstructs a rational u/v from a modular residue R when |u|<=A, 1<=v<=B, gcd(u,v)=1, gcd(v,M)=1, and u==Rv modulo M. If M>2AB, at most one such reduced rational exists. For two candidates, M divides u1v2-u2v1, whose magnitude is at most 2AB<M; it must be zero. Positive reduced denominators then give the identical fraction.

For R=44 modulo 101 with A=5 and B=7, the pair (5,7) passes 44*7==5 modulo 101. Since 101>70, the result 5/7 is unique within the declared height box. Existence still needs the displayed witness, and polynomial-root status still needs original substitution. A denominator sharing a factor with M lies outside this residue chart; a different prime or another representation is required.

## B18. Why a general cubic retains nonlinear coupling

An affine translation X=Y-b/(3a) gives the depressed cubic Y^3+P0Y+Q0, with P0=(3ac-b^2)/(3a^2) and Q0=(2b^3-9abc+27a^2d)/(27a^3). These are characteristic-zero identities; at p=3 their denominators can leave the integral ring. A local implementation must account for that change before applying an integral chart.

Writing Y=u+v gives Y^3+P0Y+Q0=u^3+v^3+Q0+(3uv+P0)(u+v). Thus the resolvent conditions are u^3+v^3=-Q0 and uv=-P0/3. The cube values satisfy a quadratic, but their cube roots cannot be chosen independently. Their product must retain the coupling. For Y^3-3Y-2, the cube values both equal 1. Taking u=1 and v=rho, where rho is a primitive cube root of unity, makes their cube sum correct but their product wrong; u+v is not a root.

Another proposed simplification uses a fractional coordinate X=(alphaY+beta)/(gammaY+delta). Homogenizing the cubic and applying an invertible linear change to its two homogeneous coordinates preserves its three projective root points. The chosen affine chart additionally requires a nonzero denominator. A transformed polynomial with smaller degree can mean that one root moved to the omitted point at infinity, rather than that the original equation lost a solution. For example, X(X-1)(X-2) under X=1/Y becomes 1-3Y+2Y^2 after multiplying by Y^3. Its affine roots 1 and 1/2 represent X=1 and X=2; the original root X=0 is represented at Y=infinity and must be retained separately. Modulo p^k, an invertible chart requires a unit determinant and a unit affine denominator. A merely nonzero rational determinant does not establish those modular guards.

A correct radical construction, when P0 is nonzero, chooses one nonzero cube root u and sets v=-P0/(3u). The other cube relation then follows from the resolvent product. Degenerate zero cases are treated separately. This established algebra explains the sound form of Stefan's multiple-projection idea: local linear or multiplicative pieces can simplify a problem while explicit compatibility equations retain its nonlinear content.

## B19. The operational contract and the verification boundary

The exact bounded kernel seeds complete root sets modulo selected primes, performs complete digit lifts, joins every compatible class, removes empty bounded fibers, and evaluates every final bounded candidate. Each update preserves S subset C_new subset C. Once the combined modulus exceeds the interval width, each class has at most one representative and the remaining evaluations give exactly S. A schedule that increases one prime-power precision at every successful step makes the modulus grow until this finite completion condition holds, unless the candidate set becomes empty earlier.

This termination argument counts arithmetic stages, not computational time. Singular root lists can grow, and many coprime prime branches can multiply. Valuation filters, unit Newton blocks, strong Hensel normalization, and logarithmic pure-cube extraction are useful optional operators under their own guards. The general integer/rational kernel does not require every operator on every input. Any operator allowed to delete candidates needs a root-preservation proof.

The fresh family-B script checks 3,000 complete cubic residue sets against direct enumeration; exact log/exp coordinates including the binary safe domain; every base-two exponent class through modulus 3^7; unit cube extraction through input modulus 3^6; all coupled exponent pairs at ring precisions 2,3,4; singular branch counts through 3^8; and 500 complete rational scaling cases. Its manifest names the actual bounds, inputs, hashes, and command. These are FINITE results supporting the implementation boundaries. The universal implications above rest on their stated proofs, and the run supplies no proof-assistant certificate.

**B-X6.** Explain why M=5 does not isolate the class 0 in [0,5]. **Answer:** both endpoints belong to it. The required width test is strict: M>U-L.

**B-X7.** A root-search budget expires with three retained branches. **Answer:** the result is unresolved, with the branches retained. Neither an empty solution set nor a complete root list follows.

## B20. Primary source map

[B-R1] Keith Conrad, Hensel's Lemma, author-hosted notes, Theorems 2.1 and 4.1. These supply the classical simple and strong lifting formulations; the finite branching and cubic interfaces above are derived explicitly. https://kconrad.math.uconn.edu/blurbs/gradnumthy/hensel.pdf

[B-R2] Keith Conrad, Infinite Series in p-adic Fields, author-hosted notes, Theorems 8.5, 8.7, 8.13. The product law, isometry domains, inverse maps, and binary torsion exception were checked against these statements. https://kconrad.math.uconn.edu/blurbs/gradnumthy/infseriespadic.pdf

[B-R3] R. Raghavendran, Finite Associative Rings, Compositio Mathematica 21(2), 1969, 195-229, Theorem 9. Its parameters n,r correspond to precision k and residue degree d; it supplies historical Galois-ring structure, while B-P4 gives the explicit coefficient criterion. https://www.numdam.org/item/CM_1969__21_2_195_0.pdf

[B-R4] Richard P. Stanley, Smith Normal Form in Combinatorics, author manuscript, 2016, Theorem 2.1(4). Integer Smith-form existence is the external structural input; B-P5 derives the finite congruence family from a stated decomposition. https://math.mit.edu/~rstan/papers/snf_survey.pdf

[B-R5] NIST Digital Library of Mathematical Functions, Section 1.11(iii), cubic equations. The depressed-cubic shift and coupled radical convention were checked; the product identity is proved directly above. https://dlmf.nist.gov/1.11

# C1. Compiling equations into usable constraints

An equation can be solved without displaying a long hand elimination. A computer may test arithmetic possibilities, fit a local response, follow a numerical correction, or isolate an algebraic root. These routes share a responsibility: the answer must satisfy the original question in its declared domain. Stefan's solver work is useful as an organizing framework for that responsibility. It combines different representations with a separate verification stage, allowing an experimental search mechanism to contribute without controlling what counts as a correct answer.

The fundamental object is a finite equation list in the unknown tuple theta=(x,y,z), together with an original domain D. Write P(theta) for the predicate that every original expression is defined and every equation holds. Then S={theta in D:P(theta)} is the solution set. The domain may be a finite integer box, a rational grid, all real triples, or all complex triples. Those choices determine different problems even when the equation text is unchanged. For example, x^2=2 has no rational answer but two real answers; x^2=-1 has no real answer but two complex answers.

## C1.1 Meaning before manipulation

An expression is a partial function. The quotient 1/(x-y) has no value at x=y. A real logarithm requires a positive argument. A real even root uses the nonnegative branch; a literal negative integer power requires a nonzero base. A useful compiler records these conditions as guards, alongside the original expression tree. Simplification changes the evaluator representation while preserving the guard history.

Finite decimal literals also need a declared meaning. In an exact route, the string 0.1 denotes 1/10. It should be parsed directly as that rational number, rather than first rounded to a binary floating value. In an approximate route, conversion to floating arithmetic is a deliberate later operation. The distinction permits exact coefficients to coexist with numerical proposals without changing the mathematical input accidentally.

Equality transformations have different directions. Adding the same defined quantity to both sides is reversible. Multiplying by the same quantity preserves equality, but reversing that operation requires a nonzero multiplier. Squaring an equation generally supplies a necessary condition; recovering the original equation requires its signs or branches. Replacing x*(x-1)=0 by x-1=0 divides away a legitimate branch. The complete partition is x=0 or x!=0, and division is allowed only in the latter part.

For a rational expression, represent its value by a numerator A, denominator B, and guard list. Addition and division then obey the familiar fraction identities on the guarded domain:

```text
A/B + C/E = (A*E+C*B)/(B*E).
(A/B)/(C/E) = (A*E)/(B*C).
The quotient additionally requires C!=0, plus inherited guards.
```

C-TH1, PROVED: if normalization produces L-R=A/B, and the original sides are defined at theta, then B(theta)!=0 and L(theta)=R(theta) iff A(theta)=0. A structural induction proves the value identity. Constants and variables start with denominator one. Each arithmetic construction uses the fraction identities and records every new inverse condition. The resulting denominator is nonzero on the original defined domain. Multiplication by it preserves and reflects equality to zero. This proof licenses numerator constraints only with the retained guards.

The practical gain is substantial. Numerator polynomials admit exact arithmetic filters and algebraic elimination. Original-expression checking decides which of their roots are genuine. A cancelled factor is therefore an evaluation simplification, while its nonzero condition remains part of the problem.

### C-EX1. A denominator creates an excluded branch

Consider the three-variable system

```text
(x^2-1)/(x-1)=y; y=3; z=x+y.
Original guard: x!=1.
Cleared first row: x^2-1=3*(x-1).
Thus (x-1)*(x-2)=0.
```

The cleared system proposes (1,3,4) and (2,3,5). The first point fails definedness. At the second point the original quotient equals 3, and z=5. The exact solution set is consequently {(2,3,5)} over Q, R, or C. A small numerator residual near x=1 would not settle the original quotient. The independent original guard removes that apparent answer.

The equation (x^2-1)/(x-1)=2 is an even sharper diagnostic. Its only numerator root is x=1, which is excluded. Its guarded solution set is empty. A compiler that cancels the denominator and forgets its guard reports a false answer.

## C1.2 Finite rational grids are exact domains

Choose positive grid denominators d_x,d_y,d_z and exact physical bounds. Define x=X/d_x, y=Y/d_y, z=Z/d_z with integer coordinates in the converted inclusive ranges. The coordinate map T from grid integers to physical rationals is a bijection. A reduced fraction u/v belongs to the x-grid exactly when v divides d_x and the bounds hold. Choosing d_x=12 includes halves, thirds, fourths, sixths, and twelfths; it does not include every rational number.

The integer bounds are L_i=ceil(d_i*l_i), U_i=floor(d_i*u_i). Their exact conversion avoids losing boundary points through rounding. The grid has the product of the three axis counts, with an axis count zero when U_i<L_i. Substituting grid coordinates into a rational polynomial yields rational coefficients. Multiplication by a known nonzero common coefficient denominator produces an integer polynomial with the same zero set in those coordinates. This operation changes coefficient representation, rather than choosing the domain of the unknowns.

The equation 2*x=1 illustrates the difference. Clearing its coefficients does not turn x=1/2 into an integer. The grid denominator d_x=1 misses it; d_x=2 includes it. More generally, x*y=1 has rational points with arbitrarily large denominators. A complete result on one finite grid is therefore not a complete result on Q^3.

C-TH2, PROVED: suppose every filter retains every solution in the declared finite grid, and every surviving point receives a definitive original verification. The accepted points are exactly S on that grid. Soundness follows because each accepted point satisfies the original predicate. Completeness follows because every true point survives all filters and is eventually checked. The argument does not require descent to converge. Descent may find witnesses sooner, while coverage comes from the finite checking mechanism.

This yields distinct useful output contracts. EXACT_WITNESS reports verified points with no completeness claim. EXACT_COMPLETE reports the entire solution set in the declared finite domain. EMPTY_CERTIFICATE is a complete result with an empty set. UNKNOWN retains unresolved candidates or unfinished work. A resource cap cannot convert an unfinished scan into emptiness. An unsupported equation may remain as a final condition while other rows supply valid arithmetic constraints; an unresolved final condition prevents a complete answer.

### C-EX2. Ordinary coupled algebra with two complete answers

The system

```text
x^2+y=z; x+y+z=10; x=y
```

is not a sum/product invariant puzzle. It mixes a quadratic equation with two linear relations. Substitution gives y=x, z=x^2+x, and x^2+3*x-10=0. Hence x=2 or x=-5, producing (2,2,6) and (-5,-5,20). Substitution in the original rows verifies both answers.

The independent exact run checks all 26^3=17576 triples in [-5,20]^3 and returns precisely those two points. The elimination proves completeness globally over R and C because it gives an equivalent quadratic with no omitted divisions. The finite scan proves the same bounded integer conclusion through another method. This example shows how numerical or arithmetic solving can answer conventional algebra, while the mathematical notes still provide a compact independent explanation.

### C-EX3. A grid contains a fractional solution

For

```text
x+y+z=1;
2*x+y-z=-1;
x-y+2*z=15/4,
```

the exact solution is (1/2,-3/4,5/4). From the first row z=1-x-y. Substitution into the second yields 3*x+2*y=0. Substitution into the third yields -x-3*y=7/4. Thus y=-3*x/2 and 7*x/2=7/4, giving the stated point. The coefficient matrix has determinant -7, so no other real or complex solution exists.

Grid denominators (2,4,4), with all physical coordinates in [-2,2], contain 2601 points. Exhaustive rational checking returns exactly the stated tuple. An integer grid would return empty even though the real and rational systems have a unique solution. This is a domain distinction, rather than a disagreement between solvers.

## C1.3 Exact algebraic answers need not be radicals

A broad undergraduate scope includes linear systems, polynomial and rational systems, radicals with branches, and many elementary-function equations. It does not define one uniform algorithm or one completeness guarantee. Three unknowns can form a finite set, a curve, a surface, an inconsistent system, or a singular intersection. Three equation rows can also be dependent. The number of independent conditions and their domain matter more than the visual count of symbols.

For A*theta=b, reversible row operations provide complete linear solving. An inconsistent row 0=c with c!=0 proves emptiness. Otherwise pivot coordinates are expressed using free coordinates, producing an affine family theta=theta_0+V*t. Original denominator guards become restrictions on the parameters. A conditional family description can be complete even when feasibility of added parameter inequalities has not yet been decided.

For nonlinear polynomial systems, the source-described V4 showcase has a separate optional exact algebra route. Its grammar accepts rational or Gaussian-rational coefficients, arithmetic, and bounded literal integer powers. The route uses exact polynomial algorithms and algebraic number representations, with its own resource boundaries. The source notes distinguish supported finite algebraic systems from unsupported general nonlinear families. This compilation preserves that distinction; explaining the route is not a fresh execution of the entire external package.

The checked SymPy documentation supplies relevant software boundaries: a polynomial solver can signal incomplete radical output, while its triangular route can retain algebraic extension roots. Its set-based solver documentation also distinguishes unresolved sets and parameter families from finite answers. These are dependency descriptions, rather than an all-input theorem for an application built around them. [C-R1, C-R2]

A particularly transparent exact representation uses one parameter t. Suppose h(t)=0 and each coordinate obeys c_i(t)*theta_i+d_i(t)=0, with gcd(c_i,h)=1. The gcd condition ensures that c_i is nonzero at every root of h. Every root alpha then proposes theta_i=-d_i(alpha)/c_i(alpha). Completeness requires two checked arrows: every original solution must induce such an alpha and those coordinate relations; every reconstructed tuple must satisfy every original row and guard. Polynomial remainders can verify the latter without decimal approximation.

C-TH3, PROVED: under those two arrows, complete enumeration of the roots of h followed by exact guards returns precisely the desired finite solution set. The forward arrow forces each true tuple into the representation. The inverse arrow returns a valid tuple from every retained parameter root. This is a reusable contract for a rational univariate representation, without assuming every system already has that form.

For example, x^5-x=1, y=x^2, z=y+1 is represented by h(t)=t^5-t-1 and theta=(t,t^2,t^2+1). An exact answer may identify a root by its polynomial and an isolating interval. There is exactly one real root. Put a=5^(-1/4). The derivative vanishes at -a and a; the two critical values are 4*a/5-1 and -4*a/5-1, both negative. The polynomial therefore crosses zero once, on its final increasing branch. The signs h(1)=-1 and h(2)=29 locate it in (1,2). No radical formula is needed to specify that exact algebraic number.

The polynomial is also square-free. A common root with h' would satisfy alpha^4=1/5 and h(alpha)=-4*alpha/5-1=0, forcing alpha=-5/4, whose fourth power is not 1/5. By the fundamental theorem of algebra, its five complex roots are consequently distinct. The coupled system has five distinct complex tuples and one real tuple. Listing a decimal alone would conceal this domain and completeness information.

## C1.4 Homogeneous ratio search and its arithmetic boundary

The historical channel-search notebooks study positive integer solutions of

```text
a/(b+c)+b/(c+a)+c/(a+b)=4.
s=a+b+c; q=ab+bc+ca; r=abc.
C(a,b,c)=s^3-6*s*q+7*r.
```

Clearing the positive denominators gives C=0 exactly. Indeed their product is s*q-r, while the sum of the three numerator terms is s^3-2*s*q+3*r; subtracting four times the product yields C. Homogeneity allows common integer factors to be removed. Modulo 6, the necessary condition is s+r==0 (mod 6), since s^3==s (mod 6). Neither operation establishes that a proposed triple is a solution; exact original substitution does.

Scale-free coordinates u=a/(b+c), v=b/(a+c), w=c/(a+b) obey u+v+w=4 and uv+uw+vw+2*u*v*w=1. The latter follows from a/s=u/(1+u) and the corresponding identities, whose sum is one. The notebook's rational carrier uses

```text
Y^2=X^3+121*X^2+1144*X+2704;
T=-52/X; w=(T-1)/2;
u+v=(9-T)/2; u-v=-Y/(2*X).
```

Substitution gives precisely the two ratio relations when the denominators are nonzero. Conversely the relations recover this carrier on its admitted chart. The homogeneous cubic in three affine coordinates is a cone; removing scale leaves a projective cubic curve. The carrier provides an exact rational coordinate method, while log-axis feedback is an ordinary real proposal mechanism.

A continuous solution does not imply a rational point nearby. On the slice a=b=1, the equation becomes t^2-7*t-4=0 for t=c. Its positive solution (7+sqrt(65))/2 is irrational. Thus this positive real slice has no rational solution. It also proves that equal positive rational channels cannot solve this particular puzzle. Three separately named variables generally may take equal values; their inequality here requires this additional proof.

Group-coordinate searches need a coverage certificate. Enumerating n*P explores the subgroup generated by P. Using P and -P as separate axes still explores that same subgroup, because c_1*P+c_2*(-P)=(c_1-c_2)*P. Extra listed points need not be independent generators. A finite coefficient shell supplies coverage of that shell's generated points, not every rational point or every positive integer solution. Local Vieta replacements and rational line intersections similarly explore reachable neighbors unless a global reachability result is proved. The defensible ranking is smallest among discovered verified triples. Global minimality additionally requires complete generating data and a rigorous height or coverage argument, absent from these inspected records.

## C1.5 Powers, nonlinear families, and exact algebra boundaries

Unknowns may occur in a fraction, a base, or an exponent. The expression grammar must retain that position. A literal integer power belongs to polynomial arithmetic when its exponent is nonnegative; a negative one belongs to guarded rational arithmetic. A variable exponent is generally a different primitive. Turning every such expression into a polynomial by textual expansion changes its meaning.

For positive real a,b and a reduced rational exponent m/n with n>0, a^(m/n)=b iff a^m=b^n. The positive nth-root branch proves the converse. With a negative real base, an odd reduced denominator supplies the unique real odd-root branch; an even denominator has no real branch. For a positive base, the transformed equality alone can allow a negative b when n is even, so b>0 remains necessary. Complex powers require an explicit logarithm branch and are outside this real rule.

C-EX10: 4^(-1/2)=1/2 is exactly verified by 4^(-1)=(1/2)^2=1/4, with a positive output branch. The equation 4^(1/2)=b gives b^2=4, but only b=2 passes its original branch. The equation (-8)^(1/3)=b has the real answer -2, whereas (-8)^(1/2)=b has no real meaning. Fractions and negative exponents therefore fit an exact verifier through guarded arithmetic rather than an indiscriminate modular inverse or floating root.

At arbitrary real exponent t, a^t=exp(t*ln(a)) for a>0. This supplies a smooth evaluator on a positive-base neighborhood, but does not remove general nonlinear coupling. For a known a>0,a!=1, the special equation a^x+a^(x+k)=N reduces to a^x=N/(1+a^k), giving x=ln(N/(1+a^k))/ln(a) when N>0. An x-dependent multiplier would leave an implicit equation. Logs are useful where an actual inverse contract exists.

The exact algebra route has a separate issue with denominator exclusion. Let H be the product of original nonzero polynomial guards. Introducing an auxiliary variable t with t*H-1=0 forces H!=0. Every guarded solution has the unique auxiliary value t=1/H, and every extended solution projects to a guarded numerator solution. This correspondence is proved directly over a field. If elimination removes t, its equations can describe the algebraic closure of the projected set, so original guard checks remain necessary at final candidates.

A finite algebraic variety is called zero-dimensional over its algebraic closure, with an inconsistent ideal handled separately. A nonlinear set with free parameters instead requires a family representation; it must not be truncated to a few isolated examples. A source-described capability test for zero dimension concerns the complex algebraic problem even when real answers are requested. Exact realness, branch checks, and bounds then select the real portion. Positive complex dimension and finite real answers can coexist, as the later x^2+y^2 example demonstrates.

This yields a practical capability boundary for undergraduate systems. A bounded rational grid can give complete finite enumeration for supported definite verification. Exact algebraic adapters can broaden the domain for supported polynomial/rational systems and represent nonradical roots. Numerical elementary-function adapters can find residual-qualified real proposals on guarded boxes. Integrals, limits, general nonlinear parameter families, and arbitrary complex transcendental branches require their own adapters. A route should return UNSUPPORTED or UNKNOWN when those obligations are absent, while preserving already verified witnesses.

## C1.6 Compiler contract and exercises

A usable compiler retains original syntax, coefficient semantics, variable order, domain, bounds, and branch conventions. Every transformation records either equivalence on a guarded domain or a necessary-condition implication. Every proposed answer returns through V, the original verifier. Arithmetic, numerical, and symbolic routes can share this object, while each advertises its own output grade. This is the precise means by which the project can grow beyond one equation pattern.

C-EXERCISE1: determine the real solutions of sqrt(x+1)=x-1. Squaring gives x*(x-3)=0, but the original right side requires x>=1. The only solution is x=3. C-EXERCISE2: describe x+y+z=1 with the additional row 1/(x-1)=1/(x-1). The affine family is (1-s-t,s,t), restricted by s+t!=0. The apparently tautological row still excludes a plane. Both exercises test compilation rather than numerical speed.

# C2. Numerical discovery with root certificates

Numerical methods turn evaluations into proposed inverses. Their value is that an explicit symbolic formula is often unnecessary. Their proofs still depend on concrete properties of the forward map: continuity, derivative size, bounded remainder, or a contractive response. Stefan's local quadratic and oscillatory work fits naturally into this setting. Measurements build a model; its inverse proposes a correction; a certificate establishes what the correction accomplished.

## C2.1 Finite changes, derivatives, and polynomial models

The exact increment of f(x)=x^2 is 2*x*h+h^2. For h!=0 its quotient is 2*x+h, whose limit is 2*x. The derivative is an exact linear response coefficient, while the finite increment includes the quadratic remainder. Cancellation before a limit is legitimate; assigning a value to 0/0 is unnecessary and invalid in a field. For a product, the exact change is u*Delta(v)+v*Delta(u)+Delta(u)*Delta(v). The cross term disappears only after the corresponding derivative limit, not at every finite displacement.

Another exact mechanism uses dual numbers a+b*epsilon with epsilon^2=0. For polynomials, substitution gives f(x+h*epsilon)=f(x)+f'(x)*h*epsilon. Expansion proves the identity, and structural induction through addition and multiplication proves its automatic-differentiation rules. The dual unit is not an ordinary small real number and cannot be divided out; its coefficient is extracted. This alternate algebra explains how exact derivative rules and finite numerical sampling can coexist without contradictory claims about increments.

At a fixed base x_0 and nonzero h, obtain three values f_0=f(x_0), f_1=f(x_0+h), f_2=f(x_0+2*h). Their differences define

```text
d_1=f_1-f_0; d_2=f_2-2*f_1+f_0.
P(x_0+n*h)=f_0+n*d_1+n*(n-1)*d_2/2.
g=(d_1-d_2/2)/h; H=d_2/h^2.
P(x_0+t)=f_0+g*t+H*t^2/2.
```

C-TH4, PROVED: P equals f everywhere when f has degree at most two. Direct substitution gives equality at the three sample nodes. Their polynomial difference has degree at most two and three distinct zeros, so it is identically zero. Alternatively, substituting a quadratic directly recovers its coefficients. Solving P=0 is therefore an exact method for this class, subject to original guards and exact arithmetic.

### C-EX4. Correcting a finite-difference numerical example

For f(x)=2*x^2+3*x-15, x_0=0, h=1/10, the sample values are -15, -14.68, and -14.32. Hence d_1=0.32, d_2=0.04, g=3, and H=4. The reconstructed model is exactly the original polynomial. Its two roots are (-3+sqrt(129))/4 and (-3-sqrt(129))/4.

The historical sample used incorrect values, leading to incorrect curvature. Recomputing the values and independently recovering the known coefficient 2 identify the error. The corrected construction is useful because it solves from evaluations and differences; the mistake does not require rejecting finite differences as a method.

For a general C^3 function the model has a remainder. On an interval containing the nodes and trial point,

```text
f(x)-P(x)=f'''(xi)*(x-x_0)*(x-x_0-h)*(x-x_0-2*h)/6.
```

A proof subtracts a multiple of the cubic nodal product from f-P so that the difference vanishes at four points, then applies Rolle's theorem three times. A bound on f''' consequently supplies a residual bound at a model root. A small sample spacing does not justify a distant extrapolation: the three displacement factors can remain large. The relevant interval includes the proposed point, rather than only the sampled neighborhood.

Centered differences separate odd and even responses. With |f'''|<=M_3 and |f''''|<=M_4 on the sample interval,

```text
g_h=[f(x+h)-f(x-h)]/(2*h),
|g_h-f'(x)|<=M_3*h^2/6.
H_h=[f(x+h)-2*f(x)+f(x-h)]/h^2,
|H_h-f''(x)|<=M_4*h^2/12.
```

Taylor expansion and cancellation prove these bounds. If each value has absolute uncertainty eta, the additional bounds are eta/|h| and 4*eta/h^2. Shrinking the probe therefore reduces truncation while amplifying evaluation error. Minimizing the first conservative total bound M_3*h^2/6+eta/h gives h=(3*eta/M_3)^(1/3) when its hypotheses and neighborhood permit that choice. This is a concrete probe-scale decision, rather than a rule to shrink indefinitely.

## C2.2 Existence, uniqueness, and a bracket

For a continuous real f on [L,U], opposite endpoint signs imply at least one root by the intermediate value theorem. If f' has a fixed sign and |f'|>=m>0 throughout that interval, there is at most one root. For any x in the interval, the mean-value theorem then gives |x-alpha|<=|f(x)|/m. Integrating the fixed-sign derivative gives the same bound. Root existence must already be established; the residual inequality alone cannot create it.

Bisection evaluates the midpoint and keeps the half containing a sign change, handling an exact midpoint zero separately. Continuity preserves existence at every stage. After n strict bisections the width is (U-L)/2^n, and the midpoint has error at most half that width. Rational polynomial evaluation can make every sign decision exact. A numerical evaluator instead needs interval values with trustworthy signs; an interval containing zero represents an unresolved sign.

For f=x^3-x-1 on [1,2], f(1)=-1, f(2)=5, and f'>=2. Existence and uniqueness are therefore certified. The exact run performs 48 bisections and returns

```text
L=93218739040913/70368744177664;
U=372874956163653/281474976710656;
U-L=1/281474976710656=2^(-48).
```

The decimal midpoint is a display of the enclosed root, not an exact replacement for it. No modular residue calculation is needed for this real certificate.

A bracket must respect the original domain. The values of 1/x at -1 and 1 have opposite signs, but the connecting interval crosses a pole and contains no root. Conversely a sign scan can miss an even-multiplicity root: (x-1)^2 never changes sign. An all-root method needs treatment of such zeros beyond strict sign-change detection.

## C2.3 Newton's useful local theorem

Newton proposes x_new=x-f(x)/f'(x), requiring a defined nonzero derivative. Suppose alpha is a root, |f'|>=m>0 and |f''|<=M on a neighborhood containing alpha, x, and the segment between them. Taylor expansion of f(alpha) about x gives

```text
|x_new-alpha|<=M*|x-alpha|^2/(2*m).
```

C-TH5, PROVED: within a sufficiently small invariant neighborhood, this estimate gives local quadratic convergence. If K=M/(2*m), choose a radius rho with K*rho<1 and with the closed neighborhood inside the derivative bounds. Each new error is at most K*rho times the old error, stays inside the neighborhood, and tends to zero; once small, its next value is bounded by a constant times its square. The integral identity f(x)=integral_alpha^x f'(t)dt supplies another derivation by bounding the difference between f'(x) and f'(t).

This theorem concerns a simple root and a sufficiently close start. Fixed damping alpha_d in (0,1) changes the leading error to (1-alpha_d)*e+O(e^2), generally giving linear convergence. A repeated root also needs different analysis: for f=(x-r)^2, ordinary Newton halves the error instead of squaring it. The checked DLMF description distinguishes local simple-root behavior from multiple-root behavior. [C-R3]

### C-EX5. A genuine root function with a Newton cycle

For f=x^3-2*x+2, Newton sends 0 to 1 and 1 to 0 exactly. Both derivatives are nonzero, but the iteration does not reach a root. This refutes unrestricted global convergence even for a cubic. The method can still converge from appropriate other starts. A certified hybrid therefore treats its update as a proposal, accepts it only within the current valid bracket, and falls back to bracket reduction when it fails the progress contract.

If every retained off-center trial lies in the middle half of the bracket, the surviving width is at most 3/4 of the previous width. Bisection gives the stronger factor 1/2. Requiring a fallback after inadequate progress proves enclosure convergence independently of the proposal's quality. A finite backtracking or iteration budget prevents implementation stalls from becoming silent infinite loops.

## C2.4 Halley's cube update has a stronger special theorem

Halley's formula is x_new=x-2*f*f'/(2*(f')^2-f*f''), with its denominator nonzero. It is a different rational correction from solving a quadratic interpolant. For f=x^3-N, N>0, it simplifies to U(x)=x*(x^3+2*N)/(2*x^3+N). This specialization has a global result on x>0.

Put alpha=N^(1/3), s=x/alpha, and u=s*(s^3+2)/(2*s^3+1). Exact factorization gives

```text
u-1=(s-1)^3*(s+1)/(2*s^3+1);
u-s=-s*(s^3-1)/(2*s^3+1).
```

For s>1 these imply 1<u<s; for 0<s<1 they imply s<u<1. C-TH6, PROVED: every positive start stays on its original side and moves monotonically toward one. A bounded monotone sequence has a limit, and continuity identifies its positive fixed point as one. The first identity also shows local cubic error. Zero is a spurious fixed point outside the admitted theorem, while negative starts may encounter poles. A specialized global theorem should remain attached to this admitted domain.

### C-EX6. A cube-root approximation becomes a certified interval

For x^3=2 and x_0=1, the first two Halley iterates are 5/4 and 635/504. Exact substitution gives the second residual -253/128024064. Both are below the root by the monotonic theorem. On [1,2], f'>=3, so

```text
alpha in [635/504, 635/504+253/384072192].
Width=253/384072192 < 6.59*10^(-7).
```

The residual-to-distance theorem supplies the upper endpoint. Direct exact cubing of that endpoint independently confirms its positive residual. Thus a fast proposal and a slower certificate cooperate. Their roles remain visible even when a decimal estimate appears convincing.

The related corrected rational start for (1+e)^(1/3) is (1+2*e/3)/(1+e/3), e>-1. Expanding proves agreement through e^2. Exact cubing gives residual -e^3*(e+2)/(e+3)^3. It is precisely the specialized Halley update applied to the normalized anchor one. This repairs the historical second-order coefficient without inventing a generic rational convergence guarantee.

## C2.5 Exact boxes can certify a three-variable root

Interval arithmetic encloses every possible value on a box. Addition uses endpoint sums, multiplication takes the least and greatest of four endpoint products, and division requires the denominator interval to avoid zero. Exact rational endpoints suffice for polynomial examples. Floating implementations require outward rounding, and elementary functions require validated interval evaluations. The expression X-X over X=[0,1] may produce [-1,1] by independent occurrences, although its exact value is zero. That dependency loss weakens efficiency without making a sound enclosure false.

If any residual interval excludes zero, the box contains no root. For scalar interval Newton, a pivot c in I and a derivative enclosure f'(I) avoiding zero give N=c-f(c)/f'(I). Every root alpha in I lies in N by the mean-value theorem on the segment joining c and alpha, which remains in I. Hence I intersect N retains every root, and an empty intersection proves exclusion. A pivot outside I instead requires a derivative enclosure over the enlarged hull. The checked interval package documentation describes this distinction between point Newton and interval enclosure refinement. [C-R4]

For a square three-variable system F continuously differentiable on an open neighborhood of a closed box I, choose an invertible matrix B and define G(theta)=theta-B*F(theta). Write Id for the identity matrix. The box is centered at c with infinity-norm radius r. Suppose ||Id-B*DF(theta)||_infinity<=q<1 throughout I. If eta=||B*F(c)||_infinity and eta+q*r<=r, then G maps I into itself and is a contraction.

C-TH7, PROVED: this contract gives exactly one root in I. The derivative bound and integration along a segment give ||G(u)-G(v)||<=q*||u-v||. They also give ||G(theta)-c||<=eta+q*r<=r. Iteration stays in I. Successive differences are bounded by a geometric sequence, so the iterates are Cauchy; closedness and completeness supply a limit in I. Continuity makes it a fixed point. Two fixed points would satisfy their distance <=q times itself, forcing equality. Finally B invertible makes G(theta)=theta equivalent to F(theta)=0. This proof supplies existence, uniqueness, and a concrete checking target.

### C-EX7. A coupled contraction box

Take

```text
F_1=x+y^2/10-7/5;
F_2=y+z^2/10-29/10;
F_3=z+x^2/10-31/10.
c=(101/100,201/100,301/100); r=1/20; B=identity.
```

The box includes (1,2,3), whose original residual is exactly zero. More significantly, its derivative and drift provide a certificate independent of recognizing that point. The derivative of G has one off-diagonal entry per row, with magnitudes |y|/5, |z|/5, and |x|/5. Their largest value on the box is 153/250=0.612. The residual at c has largest magnitude 1601/100000=0.01601. Thus eta+q*r=4661/100000=0.04661<0.05. C-TH7 proves a unique root in the whole box.

The exact check also evaluates its eight corners and confirms that their images are strictly inside. Corner agreement alone is not a general contraction proof; here the derivative bound supplies the universal interior argument. The example demonstrates the missing step between a small numerical residual and a certified multivariate root.

## C2.6 Complex variables and global coverage

A complex tuple in C^3 has six real coordinates. For complex residuals the nonnegative loss is the sum of absolute squares, not unconjugated squares. Real-coordinate derivatives or explicitly specified complex derivatives must be used consistently. The function |F(z)|^2 generally depends on z and its conjugate, so it is not a holomorphic function merely because F is holomorphic.

For x^2+1=0, y=x, z=0, the complex solutions are (i,i,0) and (-i,-i,0); the real solution set is empty. Taking the real part of a complex root does not preserve the original polynomial equation. Another instructive system is x^2+y^2=0, z=0. Its real solution set contains only the origin, while its complex set has curve components. Positive complex dimension therefore does not prove infinitely many real answers. Singular-root methods and exact domain classification are indispensable in such cases.

Local certificates do not establish all-root completeness. A global box method must account for every portion of the requested domain: excluded boxes, isolated certified roots, and unresolved boxes. Shared boundaries need consistent treatment; singular Jacobians may prevent a contraction certificate even at genuine roots. Subdivision without a termination theorem is a systematic search, rather than a guaranteed finite all-roots procedure for every smooth function.

Ensemble starts help discovery but cannot replace coverage. If independent trajectories each find a particular root with probability q, the chance all n miss it is (1-q)^n. That statement needs an actual q and independence model. Deterministic dispersed starts do not automatically satisfy it. Similarly, clustering candidate points by distance does not establish multiplicity or uniqueness. Averaging two exact roots +a and -a of x^2-a^2 yields zero, a nonroot. Representatives require fresh verification, and close distinct roots require separate isolating certificates.

## C2.7 An executable numerical contract

A hybrid scalar solver can state its obligations without tying correctness to one proposal formula:

```text
Input: original evaluator, guarded interval, target width, budget.
Require trustworthy endpoint signs and continuity on the interval.
Store old interval and old point before producing a trial.
Propose an admissible Newton, Halley, or interpolation point.
If the trial is undefined or cannot reduce the bracket sufficiently,
    replace it with the midpoint.
If a reliable sign is unavailable, increase evaluation precision
    or return UNKNOWN with the preserved interval.
Otherwise retain the sign-changing subinterval.
Stop with a certified enclosure once its width meets the target.
```

The ordering matters. Computing a step after overwriting the old point makes its measured length identically zero, a historical control-flow error. A small step may mean stagnation; it is not a root proof. Nonfinite values, cancellation, domain violations, and underflow require explicit outcomes. In particular, a positive exponential that rounds to zero should not be accepted as an exact zero of the mathematical exponential.

A multivariate proposal route has comparable responsibilities. Derivative samples require defined neighborhoods, and a proposed path must respect original guards. Two finite endpoint evaluations of 1/x do not make a path across zero admissible. A guard interval excluding zero certifies safety for a polynomial denominator throughout the box; an interval containing zero is inconclusive. It can justify rejecting that numerical path, while the mathematical candidates in the region survive for another method.

Residual-qualified numerical output should include each original residual, the arithmetic precision, scaling, and tolerance. The equation 10^(-12)*(x-1)=0 accepts x=0 under a raw 10^(-9) residual threshold, even though its coordinate error is one. A derivative lower bound or a validated system certificate addresses that discrepancy. Empty numerical output retains UNKNOWN unless the whole declared domain has an independent exclusion certificate.

C-EXERCISE3: for f=x^2-2 on [1,2], derive the residual error bound and the width after ten bisections. The derivative is at least two; |x-alpha|<=|f(x)|/2 and the width is 1/1024. C-EXERCISE4: determine whether 1/x can be bracketed across zero. It cannot: the original function is undefined on the proposed interval. These tests establish which theorem is applicable before the iteration begins.

# C3. Descent, optimization, and controlled adaptation

The solver work contains a second important theme: a method can adapt its own probes, damping, gains, and restarts. This can improve practical search, provided adaptation remains distinct from mathematical acceptance. A controller decides what to try; the original predicate and certificate decide what has been established. That division supports experimentation with quadratic models, oscillatory estimates, memory, and scheduling without making their behavior a proof of root existence.

## C3.1 Root loss and its stationary points

For a real residual vector F and positive residual scales s_j, define J(theta)=sum_j(F_j(theta)/s_j)^2/2. Exact nonnegativity gives J=0 iff F=0. Each row must be squared separately: squaring their sum permits residuals 1 and -1 to cancel. Fixed scales preserve the exact zero set, while changing numerical conditioning and tolerance meaning.

With unit scales and A=DF, differentiation gives

```text
grad J=A^T*F;
Hess J=A^T*A+sum_j F_j*Hess F_j.
```

The product and chain rules prove these identities. They show both the usefulness and the limitation of least squares. F=0 implies stationarity; stationarity need not imply F=0, because F may lie in the nullspace of A^T. For f=x^2+1, the loss has a positive global minimum at zero and no real root. For f=x^2-1, zero is a stationary nonroot even though two roots exist elsewhere.

The distinction persists when the nonsolution is a strict local minimum. Set f=(x^2+1)*(x-3). At a=1-sqrt(6)/3, f'=0 but f(a)=-4+4*sqrt(6)/9!=0. The squared residual has curvature J''(a)=8*sqrt(6)-16/3>0. Adding residuals y and z makes (a,0,0) a strict local minimum in three dimensions, while the exact root (3,0,0) lies elsewhere. Local descent can correctly converge to that nonzero minimum. Restarts offer another opportunity; they do not supply a universal convergence theorem.

## C3.2 Quadratic solving and least-squares models

For q(p)=J_0+g^T*p+p^T*H*p/2, with H symmetric positive definite, the unique minimizer is p_star=-H^(-1)*g. Differentiation finds its stationarity, and completing the square proves global minimality:

```text
q(p)=J_0-g^T*H^(-1)*g/2
     +(p+H^(-1)*g)^T*H*(p+H^(-1)*g)/2.
```

Invertibility alone is insufficient: a negative definite H gives a maximum and an indefinite H gives a saddle. If H is positive semidefinite and singular, a minimizer exists precisely when g is orthogonal to ker(H); then minimizers differ by null vectors. Otherwise the linear term drives q unbounded below along a null direction. A local model also needs its proposed point inside the region where the model and original domain are valid.

### C-EX8. An exact least-squares snap

For A=[[1,2],[1,-1]], b=[5,-1], and J(theta)=||A*theta-b||^2/2, the gradient at zero is (-4,-11), and H=A^T*A=[[2,1],[1,5]]. Its determinant is 9, and its leading diagonal entry is positive, so H is positive definite. Solving H*p=(4,11) gives p=(1,2). Direct substitution gives A*p=b. The model minimizer is consequently an exact root as well as a global least-squares minimizer.

The latter conclusion would fail with inconsistent data. A=[1;1], b=[0;1] has full column rank and unique minimizer theta=1/2, but no exact root. Rank gives uniqueness of the minimizer; compatibility b in image(A) gives exact fitting. These obligations remain distinct even in very small dimensions.

For nonlinear F, Gauss-Newton minimizes ||F+A*p||^2/2, producing A^T*A*p=-A^T*F. It omits the residual-curvature term in the full Hessian. Positive damping yields the Levenberg-Marquardt model

```text
(A^T*A+mu*W)*p=-A^T*F;
mu>0; W symmetric positive definite.
```

For any nonzero v, its quadratic form is ||A*v||^2+mu*v^T*W*v>0. The model therefore has a unique solution even when A is rank deficient. This proves solvability of the proposal system, rather than nonlinear descent or a zero residual. Solving the linear system directly is preferable to explicitly forming an inverse. QR or singular-value methods also avoid the conditioning amplification of normal equations, whose spectral condition number squares that of a full-rank A.

## C3.3 A precise descent contract

Let grad J be L-Lipschitz along the complete segment of a proposed displacement p. Integration along that segment gives

```text
J(theta+p)<=J(theta)+g^T*p+L*||p||^2/2.
```

To prove it, subtract g from the gradient inside the line integral and bound the remainder by L*t*||p||^2; integration of t over [0,1] gives 1/2. For p=-eta*g, strict descent follows when 0<eta<2/L and g!=0. With J=x^2, taking eta=2 sends x to -3*x and multiplies loss by nine. A gradient direction alone therefore does not license every step length.

An estimated gradient g_hat=g+e, ||e||<=delta, gives the usable bound

```text
J(theta-eta*g_hat)-J(theta)
 <=-eta*(1-L*eta/2)*||g_hat||^2+eta*delta*||g_hat||.
```

The same integration followed by Cauchy-Schwarz proves it. If (1-L*eta/2)*||g_hat||>delta, the bound certifies decrease. This is the correct connection between probe accuracy and accepted descent. Near a stationary point, estimation error may dominate. Measured objective reevaluation or tighter error bounds must then decide acceptance.

Backtracking provides another contract. For a direction d with g^T*d<0, choose c in (0,1) and test J(theta+t*d)<=J(theta)+c*t*g^T*d. Differentiability gives J(theta+t*d)=J(theta)+t*g^T*d+o(t), so sufficiently small positive t satisfy the inequality. Domain guards must hold along the admitted trial, and practical code uses a finite budget. The checked Boyd-Vandenberghe text states the corresponding descent-direction backtracking procedure. [C-R5]

Monotone loss values alone do not prove stationary convergence. For J=x^2/2, steps alpha_k=2^(-k-2) produce x_(k+1)=(1-alpha_k)*x_k. They satisfy strict decrease and an Armijo test with c=1/2. Yet sum alpha_k=1/2, and finite products satisfy product(1-alpha_k)>=1-sum alpha_k>=1/2. The nonzero sequence cannot reach zero or converge to stationarity from x_0=1. This explicit example shows why infinitely many small successful moves still need a quantitative progress condition.

## C3.4 Curvature uncertainty and a trust radius

Suppose a true positive definite Hessian H has smallest eigenvalue lambda, and H_hat=H+E with ||E||<=eta_H<lambda. Let g_hat=g+e with ||e||<=eta_g. The ideal and fitted steps solve H*p_N=-g and H_hat*p=-g_hat. Subtraction yields

```text
H_hat*(p-p_N)=-e-E*p_N;
||p-p_N||<=(eta_g+eta_H*||p_N||)/(lambda-eta_H).
```

The denominator follows because every unit v obeys v^T*H_hat*v>=lambda-eta_H. This proves a model sensitivity bound and exposes the danger near singular curvature. More samples may reduce eta_H, but do not automatically increase the underlying lambda.

If the true Hessian is L_H-Lipschitz on the segment, the integral Taylor remainder is at most L_H*||p||^3/6. Combining this with gradient and Hessian uncertainty gives

```text
|J(theta+p)-q_hat(p)|
 <=eta_g*||p||+eta_H*||p||^2/2+L_H*||p||^3/6.
```

The integral weight t*(1-t) has total 1/6, proving the cubic term without assuming an everywhere defined third derivative. Predicted reduction larger than this bound proves actual decrease. Alternatively, two objective evaluations each uncertain by eta_J need a measured decrease exceeding 2*eta_J. Either certificate concerns descent; original root verification remains separate.

A trust region limits the model displacement to ||p||<=Delta. A sufficient certificate that p globally minimizes its quadratic subproblem is

```text
(H+lambda_t*I)*p=-g;
H+lambda_t*I positive semidefinite;
lambda_t>=0; ||p||<=Delta;
lambda_t*(||p||-Delta)=0.
```

For any feasible d, stationarity rewrites q(d)-q(p) as
(d-p)^T*(H+lambda_t*I)*(d-p)/2
+lambda_t*(||p||^2-||d||^2)/2. The first term is nonnegative. The second vanishes when lambda_t=0 and is nonnegative when lambda_t>0 because p then lies on the boundary. This proves sufficiency. It does not assert that an arbitrary damping choice finds those conditions or that the model minimum solves the nonlinear problem.

## C3.5 Inexact Newton rates depend on relative error

Probe amplitudes and regularization are sometimes said to vanish, with fast convergence then assumed. A useful local calculation states the missing rates. Let theta_star be a simple root, e=theta-theta_star, and A=DF(theta). Assume A is locally invertible with bounded inverse, its variation is Lipschitz, and the proposed step uses an approximate residual F+b and matrix A+E. Let s solve (A+E)*s=-(F+b) exactly. The residual expansion along the segment to the root gives A*e-F=r with ||r||<=K*||e||^2. Consequently

```text
(A+E)*(e+s)=r+E*e-b.
||e_new||<=K_0*(K*||e||^2+||E||*||e||+||b||),
```

where K_0 bounds the approximate inverse. This estimate is proved by substitution and a norm bound. An inexact linear solve adds its residual to the right side. Fixed damping adds a term proportional to e, as in the scalar calculation. These are distinct sources of error even if one user-facing routine manages all of them.

Quadratic convergence is preserved under sufficient controls ||E||=O(||e||), ||b||=O(||e||^2), and comparable solve/damping error. Sending an amplitude to zero geometrically does not establish those relations to the current unknown error. If an uncorrected probe has residual bias O(a^2), that bias can dominate the Newton correction and determine the observed rate. A trustworthy residual or enclosure is needed to govern further shrinking.

The same calculation explains when derivative measurements are useful. A measured model that is accurate relative to the current residual can provide a good inverse correction. A model with a tiny absolute error may still be inadequate near singularity or when the desired error is much smaller. Recording amplitude, estimator error, inverse bounds, and linear-solve residual makes the proposal assessable. It also supplies a concrete future experiment: compare exact derivatives, central differences, and paired oscillatory estimates under the same coordinate and evaluation budgets, checking whether their errors obey these rates.

## C3.6 Controller adaptation needs its own invariant

A numerical controller M can alter amplitude, damping, restart policy, or scheduling. A plant state y evolves under its actions. An observer O records the resulting measurements. A checker V assesses a candidate controller against an immutable contract epoch. Keeping these roles separate prevents measurements under the old controller from being treated as tests of a new controller's future behavior.

A corrected transition accepts a proposed controller only after checking finiteness, membership in an allowed set, displacement, cost, behavior, and the agreed objective bound. Every fallback passes the same gate. If no candidate passes, a hold is allowed only while the old certificate remains valid. A changed objective, measurement model, observer, or allowed set requires a new epoch and rechecking affected claims.

C-TH8, PROVED: with a sound checker and valid initial state, every committed controller remains valid in an unchanged epoch. Induction gives the proof. An accepted branch supplies the invariant directly; the hold branch repeats an already valid state. The proposal method can be sophisticated, random, or ineffective without changing this logical argument. Correctness of adaptation rests on the gate, rather than on a name such as cybernetic, Bayesian, or self-aware.

The historical ungated fallback fails a simple example. Let the allowed set be [0,1], the current controller 0, and V(M)=M with no allowed increase. A trial 1 is rejected. A smaller fallback 1/2 is feasible but still increases V. Backoff and clipping do not preserve the missing energy condition. The same checker must assess both trials.

Bounded increments also do not bound the state: M_k=k*delta has a fixed small change at every step and drifts indefinitely. If each accepted change obeys V(M_(k+1))<=V(M_k)+epsilon_k, summation gives V(M_n)<=V(M_0)+sum epsilon_k. Summable allowances bound energy above. With a lower bound and zero allowances, its scalar values converge. The states need not converge: M_k=(-1)^k with V=M^2 has constant energy. Controller boundedness and plant stability require their own conclusions.

For a nonempty closed convex allowed set, Euclidean projection gives a useful displacement property. If M is already allowed, N=projection(M+alpha*delta) satisfies ||N-M||<=alpha*||delta||. The projection variational inequality gives ||N-M||^2<=alpha*delta dot (N-M), followed by Cauchy-Schwarz. A nonconvex repair does not automatically have this property, so a separate displacement gate is then needed.

### C-EX9. A gain envelope proves a specific plant stable

Take an undisturbed scalar integrator with target 10,

```text
e=10-y; u=clip(K*e,-20,20); y_new=y+u.
Allowed gains: 1/20<=K<=6/5.
Overshoot: e*e_new<0.
```

An illustrative adaptation decreases K by 0.2 after overshoot, increases it by 0.1 after improvement, decreases it by 0.1 otherwise, and holds it when both old and new errors are within 0.02. Projection enforces the gain interval. Starting at y=0,K=1.1 gives (y,K)=(11,0.9), then (10.1,1.0), then (10,1.1). Arrival at exact zero is not an overshoot. Defining it by a change in a sign function instead would alter this trace.

For an unsaturated step, e_new=(1-K)*e. The envelope gives |e_new|<=0.95*|e|, so the squared error contracts by at most 0.9025. This holds for any gain schedule inside the envelope, independent of the illustrative adaptation rule.

For saturation, write E=|e| and q=min(K*E,20). Every nonzero state has 0<q<2*E, so |E-q|<E. If E>=20 during saturation, the magnitude drops by 20; if E lies between 50/3 and 20, the new magnitude is below 10/3. Hence finitely many saturated steps enter E<=50/3, where all allowed gains are unsaturated. Geometric convergence then follows. There is no uniform 0.95 factor for arbitrarily large saturated errors. The theorem applies to this stated plant, not every controlled system.

## C3.7 Evidence and useful performance questions

The new exact checks verify 2940 quadratic reconstruction instances, each at six additional trial coordinates, and 38424 gain/error transitions. They also reproduce the nonlinear integer and rational-grid examples, denominator exclusions, Newton cycle, Halley identities, exact real bracket, contraction box, and corrected gain trace. These FINITE records corroborate implementation of named contracts. The self-contained proofs carry their general conclusions. No speed comparison or general V4 package execution is inferred from the check count.

A fair performance comparison fixes equations, domain, coefficient semantics, starting policy, evaluation budget, and answer grade. Time to one approximate point differs from time to all exact grid roots. Count initial snapping, descent discoveries, arithmetic pruning, and exhaustive fallback separately. Otherwise an answer found by a first neighborhood scan may be wrongly credited to an elaborate optimizer. A seven-value central model and a thousand-value lock-in model cannot be compared solely by iteration count.

Adaptive scheduling is useful within this contract. It can choose another prime, a deeper precision, a fresh seed, a smaller trust radius, or immediate exact evaluation according to estimated cost. Failure memory can avoid duplicate attempts. None of those policies may delete an admissible solution merely because a local solve failed, a hash collided, or a score was poor. Saved failures should distinguish proved infeasibility from numerical non-discovery.

C-EXERCISE5: explain why positive damping makes A^T*A+mu*I invertible but cannot prove F=0. Its quadratic form is strictly positive; the solved model is only a local residual approximation. C-EXERCISE6: explain why P and -P do not create a second independent search axis. Their integer combinations reduce to multiples of P. These exercises connect the same core lesson across numerical and arithmetic search: a valid proposal mechanism and a complete mathematical answer have different proof obligations.

## C references and attribution

The polynomial identities, finite-grid arguments, derivative bounds, contraction proof, quadratic certificates, and stated controller theorem are proved above. Newton, interpolation, Halley, least squares, interval arithmetic, and projection are established methods. Stefan's contribution represented here is the project's combination of these methods into explicit solver contracts and its motivating examples; no mathematical novelty or universal efficiency claim is made.

[C-R1] SymPy developers, Solvers, SymPy 1.14.0 documentation, Systems of Polynomial Equations: solve_poly_system strict handling and solve_triangulated algebraic extensions. Checked 2026-10-13. https://docs.sympy.org/latest/modules/solvers/solvers.html

[C-R2] SymPy developers, Solveset, SymPy 1.14.0 documentation: unresolved sets, nonlinsolve, finite and parameterized output contracts. Checked 2026-10-13. https://docs.sympy.org/latest/modules/solvers/solveset.html

[C-R3] NIST Digital Library of Mathematical Functions, Section 3.8, Nonlinear Equations, Newton iteration and local simple/multiple-root distinctions. Checked 2026-10-13. https://dlmf.nist.gov/3.8

[C-R4] GNU Octave Interval Package, Root Finding, Sections 3.4.1-3.4.2, interval Newton and bisection documentation. Checked 2026-10-13. https://octave.sourceforge.io/interval/package_doc/Root-Finding.html

[C-R5] Stephen Boyd and Lieven Vandenberghe, Convex Optimization, Section 9.2, Algorithm 9.2, printed pp.464-466: descent-direction backtracking and admitted domain. Checked 2026-10-13 in the author PDF. https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf

# Fourier coordinates, rotating channels, and measured derivatives

Stefan's recurring use of clocks, waves, and rotating components has a precise common basis: a complicated record can become easier to inspect after its components are expressed in a suitable basis. A rotating vector provides two real coordinates; a family of distinct harmonics provides several distinguishable coordinates over an observation interval. Orthogonality then supplies a decoder. These ideas support waveform transmission, geometric drawing, modular filters, and derivative measurements. The object being decoded must be specified separately in every application.

The standard mathematics here is complex arithmetic, finite Fourier analysis, and linear measurement. Stefan's organizing proposal is to use these representations as cooperating instruments inside a numerical reconstruction process. The usefulness lies in selecting channels that expose constraints or coefficients, attaching their inversion conditions, and checking reconstructed values against the original observations. The chapters retain that practical architecture while repairing claims that rotations or phases automatically create information.

## D1. Complex coordinates and the exact meaning of 120 degrees

A complex number z=x+i*y packages two real numbers. Its conjugate is conj(z)=x-i*y, and |z|^2=z*conj(z)=x^2+y^2. For z!=0, polar form is z=r*exp(i*theta), where r=|z|>0 and theta is specified modulo 2*pi. Euler's identity exp(i*theta)=cos(theta)+i*sin(theta) converts multiplication by a unit complex number into a planar rotation. Multiplication by a general nonzero complex number combines rotation with uniform scaling. The zero record has no direction, so its phase is undefined.

PROVED D-P1. Let omega=exp(2*pi*i/3). Then

```text
omega^3=1; omega!=1; omega^2+omega+1=0.
omega=-1/2+i*sqrt(3)/2.
omega^2=conj(omega)=-1/2-i*sqrt(3)/2.
1+omega+omega^2=0.
```

The factorization u^3-1=(u-1)(u^2+u+1) proves the polynomial identity because omega is a nontrivial cube root of one. Alternatively, summing the displayed real and imaginary coordinates gives zero directly. The three vectors point 120 degrees apart. They are not three orthogonal directions: the dot product of any two distinct unit vectors is -1/2. Their sum-zero relation also makes them linearly dependent over the real numbers.

This distinction explains the useful two-coordinate interpretation of a three-direction drawing. Any two of 1, omega, omega^2 are a real basis of the plane, and the third equals minus their sum. Three coefficients therefore need one constraint or one extra observation before they can be recovered from their complex sum. The word binary in such a construction can refer to choosing two independent directions. It does not establish binary arithmetic, independent bits, or a third orthogonal axis.

Worked example D-E1. Take z=2+3*omega. Cartesian form is 1/2+(3*sqrt(3)/2)*i, and |z|^2=7. More generally,

```text
|a+b*omega|^2=a^2-a*b+b^2, for real a,b.
Re(a+b*omega)=a-b/2; Im(a+b*omega)=sqrt(3)*b/2.
b=2*Im(z)/sqrt(3); a=Re(z)+Im(z)/sqrt(3).
```

The inverse follows by solving these two real equations. In contrast, if three unrestricted coefficients are used, then (a,b,c) and (a+t,b+t,c+t) have the same value a+b*omega+c*omega^2. A third scalar anchor, such as a+b+c, removes this particular ambiguity. A 120-degree display is therefore useful for constrained three-channel data, triangular lattices, or residue classes modulo three, with its one-dimensional kernel kept explicit.

## D2. Finite Fourier inversion and aliasing

Fix an integer N>=1 and zeta=exp(2*pi*i/N). A sample vector x=(x_0,...,x_(N-1)) has the finite Fourier coordinates

```text
X_k=sum_(n=0)^(N-1) x_n*zeta^(-k*n), 0<=k<N.
x_n=(1/N)*sum_(k=0)^(N-1) X_k*zeta^(k*n).
```

PROVED D-P2. These maps are inverses on C^N. The load-bearing identity is

```text
sum_(k=0)^(N-1) zeta^(k*u) = N if u == 0 (mod N), otherwise 0.
```

If zeta^u=1, every summand equals one. Otherwise the finite geometric sum is (1-(zeta^u)^N)/(1-zeta^u)=0. Substitute the definition of X into the inverse and interchange the two finite sums. The coefficient of x_m becomes the character sum for u=n-m divided by N. Only m=n survives. The normalized Fourier matrix is consequently unitary, and the same calculation gives

```text
sum_n |x_n|^2=(1/N)*sum_k |X_k|^2.
```

This is Parseval's identity in the present normalization. A different choice of normalization can place sqrt(N) factors in both maps; changing conventions is harmless when both directions change consistently.

Worked example D-E2. For N=4 and x=(1,2,3,4), the relevant roots are 1,i,-1,-i. Direct calculation gives X=(10,-2+2i,-2,-2-2i). The first inverse sample is [10+(-2+2i)-2+(-2-2i)]/4=1. At n=1, multiplication by (1,i,-1,-i) gives 8/4=2. The remaining samples return 3 and 4. The input energy is 30, while the sum of squared coefficient magnitudes is 100+8+4+8=120; division by four again gives 30. This example is checked with exact rational complex arithmetic, rather than rounded trigonometric values.

The same character sum expresses modular membership:

```text
delta_N(u)=(1/N)*sum_k zeta^(k*u).
delta_N(u)=1 exactly when N divides u, and otherwise 0.
```

It can replace an integer congruence test with an exact finite phase identity. It does not make a dense sum cheap merely because the answer is zero or one. Efficiency needs sparse structure, reusable transforms, or another independently proved reduction. For exact computation, algebraic roots of unity or direct residue tests avoid treating a tiny floating residual as an exact zero.

Sampling identifies frequencies modulo N: exp(2*pi*i*(k+N)*n/N)=exp(2*pi*i*k*n/N). A physical frequency and another frequency shifted by the sample rate can therefore produce identical sampled phases. With real cosine channels, k and N-k also give identical columns. Sine channels distinguish orientation except at DC and, for even N, the Nyquist bin, where the sampled sine is identically zero. Those exceptional cosine columns have squared norm N; an ordinary nonexceptional cosine has squared norm N/2.

A complete sample vector has an exact finite inverse. Reconstruction of an arbitrary continuous signal from that vector requires an additional bandlimit or finite-model assumption. Infinitely many continuous curves agree at the same finite sample points. Calling the finite inverse a universal continuous inverse would change the problem's domain without providing observations that distinguish those curves.

## D3. Epicycles as geometric synthesis

Let a closed parameterized planar curve be represented by complex coordinates z(t), with t running from zero to 2*pi. A finite trigonometric representation has the form

```text
z_K(t)=sum_(k in K) c_k*exp(i*k*t).
c_k=radius_k*exp(i*initial_phase_k).
```

Each term is a vector rotating at signed angular rate k. Placing the start of each vector at the end of its predecessor produces the familiar epicycle picture. The endpoint is their sum, so vector order changes the intermediate chain but not the final point. The k=0 term is a translation of the entire drawing. Positive and negative k rotate in opposite directions. A planar curve is generally a complex-valued signal; its coefficients need not have the conjugate symmetry imposed on a real voltage signal.

For N sampled boundary points z_n, coefficients c_k=X_k/N and the inverse finite transform recover those points exactly. Between samples the chosen trigonometric polynomial supplies an interpolation. The interpolation depends on the chosen frequency representatives and the parameterization of the boundary. Uniform time samples, uniform arc-length samples, and a parameterization that dwells near a corner produce different coefficients even when the visible outline is similar.

PROVED D-P3. For any finite complete coefficient list and retained subset K,

```text
|z(t)-z_K(t)| <= sum_(k not in K) |c_k|, for every real t.
```

The triangle inequality proves the bound because every exponential has modulus one. On a sample grid, orthogonality also gives the mean squared omitted error as the sum of omitted squared coefficient magnitudes when the bins are distinct modulo N. A largest-magnitude-first display minimizes that discrete squared error among subsets of the same size. It need not minimize maximum geometric deviation, preserve a sharp corner, or maintain the ordering of self-intersections. Those are different objectives.

Worked example D-E3. The four sampled points (1,i,-1,-i) form one counterclockwise circular mode: c_1=1 and every other coefficient is zero. A constant displacement 2-i adds c_0=2-i. An ellipse z(t)=3*cos(t)+i*sin(t) becomes 2*exp(i*t)+exp(-i*t). Two counter-rotating vectors of radii two and one reproduce it exactly. At t=0 their sum is 3; at t=pi/2 it is i. Removing the radius-one term leaves a circle and has maximum error exactly one, matching the omitted-coefficient bound.

The recovered airplane demonstration contains 2,048 stored coefficients but only 1,024 stored reference points. An independent check reconstructs every reference point from the complete list with maximum binary64 discrepancy about 5.1e-15. Individual coefficients must not be compared directly with the 1,024-point DFT: coefficients whose frequencies agree modulo 1,024 fold into the same observed bin. Comparing the folded sums gives maximum discrepancy below 3.7e-14. The reference samples alone therefore do not identify 2,048 independently writable frequency coordinates.

At its default 129 retained terms, the sum of stored omitted magnitudes is approximately 0.07255 in normalized drawing units. This is a uniform bound relative to the complete stored trigonometric representation. It is not an authenticated bound relative to an unavailable original aircraft photograph or an independently defined continuous contour. The result still gives a concrete, useful demonstration of progressive geometric approximation, with reproducible error accounting instead of a visual claim that every added circle is exact new information.

## D4. Six complex channels in one real waveform

A signal block can preserve twelve real coordinates although each instantaneous voltage is one real number. The block supplies many observations at known times. Set N=192, choose distinct positive bins k_j=4,5,6,7,8,9, and let c_j=I_j+i*Q_j. Define

```text
x_n=sqrt(2)*Re(sum_(j=1)^6 c_j*exp(2*pi*i*k_j*n/N)).
c_hat_j=(sqrt(2)/N)*sum_(n=0)^(N-1)
                 x_n*exp(-2*pi*i*k_j*n/N).
```

PROVED D-P4. In the ideal mathematical model c_hat_j=c_j. Expanding the real part creates a positive term c_j/sqrt(2) and a negative term conj(c_j)/sqrt(2). During decoding, frequency differences k_l-k_j vanish modulo N only when l=j; sums k_l+k_j never vanish modulo N. Character orthogonality removes every other term. The decoder factor sqrt(2) then restores c_j.

An equivalent real synthesis matrix has columns sqrt(2)*cos(2*pi*k_j*n/N) and -sqrt(2)*sin(2*pi*k_j*n/N). Its Gram matrix is N times the 12-by-12 identity. This proves rank twelve, gives the left inverse A^T/N, and supplies the energy identity

```text
(1/N)*sum_n x_n^2=sum_j |c_j|^2.
```

The conjugate negative-frequency coefficients are determined by real-valuedness, so they are not six additional independently assigned channels. If all six tones share one frequency, the waveform depends only on sum_j c_j; its real-linear rank drops from twelve to two. Increasing a numerical coefficient's precision does not remove that kernel.

Worked example D-E4. Assign c=(1+2i,-2+i/2,1/4-i,3-2i,-3/4+i/8,3/8-5i/8). Their squared magnitudes sum to 1563/64=24.421875. The 192 synthesized samples have that same mean squared voltage, and all six coefficients are recovered. A direct binary64 implementation gives coefficient errors below 1.8e-15. The proof establishes the exact identity; this finite run checks the normalization and code path.

To turn coefficients into bits, choose a finite constellation. Six independent 16-point complex constellations provide 16^6=2^24 distinct symbol choices, or 24 bits per data symbol. Higher constellation order reduces nearest-point separation at fixed power. For square M-QAM normalized to mean squared magnitude one, adjacent complex points are separated by sqrt(6/(M-1)); channel power weight w_j and voltage scale V_ref multiply this by V_ref*sqrt(w_j).

In the supplied packet model the sample rate is 48,000 samples per second. A 192-sample useful interval lasts 4 ms; a copied 24-sample prefix adds 0.5 ms. Twenty-four bits per 4.5-ms data symbol give approximately 5,333.33 gross bit/s. A 512-bit payload plus a 64-bit header and 32-bit checksum requires ceiling(608/24)=26 data symbols. Two training symbols bring the packet to 28 symbols, lasting 126 ms and carrying approximately 4,063.49 payload bit/s.

For a single echo r_n=x_n+g*x_(n-d), a prefix of at least d samples turns the useful-window operation into circular convolution when the specified packet timing and finite memory assumptions hold. Fourier coordinates then give R_k=H_k*X_k with H_k=1+g*exp(-2*pi*i*k*d/N). This follows by shifting the DFT summation index. A nonzero H_k can be inverted; a small H_k amplifies measurement error. Training estimates those gains. Unknown timing, clipping, drift, and insufficient prefixes remain separate measurement problems.

The actual recovered modem core was tested on all 340 supported QAM points in each of six bins, giving 2,040 projection checks. Six clean or compensated-echo packet cases also recovered their payloads. These are software checks of the finite model. The nominal allocation 6*250=1,500 Hz is a bin-allocation count; rectangular time windows have sidelobes, so it is not a strict occupied-bandwidth certificate. Checksums detect many corruptions and do not authenticate the sender. The model is useful for teaching signal dimensions, power allocation, and reversible data transport with explicit assumptions.

## D5. Harmonic probing of an unknown local quadratic

The same orthogonality can recover derivatives when an objective is evaluated along known displacements. Fix a real base point theta_0 and an exact local quadratic

```text
J(theta_0+d)=J0+g^T*d+(1/2)*d^T*H*d, H=H^T.
d_j(t)=a_j*cos(w_j*t+phi_j), a_j>0.
```

Substitution gives linear channels at w_j, diagonal-curvature channels at 2*w_j, and mixed-curvature channels at w_j+w_k and |w_j-w_k|. Specifically,

```text
C0=J0+sum_j a_j^2*H_jj/4.
linear cosine amplitude:       a_j*g_j.
diagonal doubled amplitude:    a_j^2*H_jj/4.
mixed sum/difference amplitude:a_j*a_k*H_jk/2.
```

These factors follow from cos(alpha)^2=(1+cos(2*alpha))/2 and cos(alpha)*cos(beta)=[cos(alpha+beta)+cos(alpha-beta)]/2. They also follow by multiplying positive and negative exponential terms. Both derivations retain the half in the quadratic definition; its omission would double curvature estimates.

Let avg denote averaging over complete common periods, and define L(w,phi;y)=2*avg[y*cos(w*t+phi)]. If every labelled first- and second-order frequency is nonzero and distinct, PROVED D-P5 gives

```text
g_j=L(w_j,phi_j;y)/a_j.
H_jj=4*L(2*w_j,2*phi_j;y)/a_j^2.
H_jk=2*L(w_j+w_k,phi_j+phi_k;y)/(a_j*a_k).
```

Orthogonality selects the displayed amplitudes, after which these rescalings recover the coefficients. Difference channels give redundant estimates when their signed frequency and phase are handled consistently. For uniformly sampled coherent data, modular aliasing must also be excluded. More than twice the highest output bin is a simple sufficient sampling condition.

Worked example D-E5. Take H=[[4,1],[1,3]], theta_0=(0,0), and J(theta)=(1/2)*(theta-(2,-1))^T*H*(theta-(2,-1)). Then J0=15/2 and g=(-7,1). Amplitudes (1/10,1/5) and bins (1,4) give

```text
y(t)=377/50-(7/10)*cos(t)+(1/5)*cos(4t)
     +(1/100)*cos(2t)+(3/100)*cos(8t)
     +(1/100)*cos(3t)+(1/100)*cos(5t).
```

The six nonzero bins are distinct. Decoding returns g=(-7,1), H_11=4, H_22=3, and H_12=1. Since det(H)=11 and H_11>0, H is positive definite. Solving H*p=-g gives p=(2,-1), and direct evaluation of the original objective gives zero. Thus this exact quadratic supports an exact recovered coefficient model and an exact minimizer. The polynomial degree, domain, positivity, and original substitution establish the result; a spiral drawing supplies none of those conditions.

Distinct carriers alone are insufficient. With J=(1/2)*theta_1^2, bins (1,2), and amplitudes a_1,a_2, the doubled first-coordinate harmonic falls on the second carrier. Its false second-gradient estimate is a_1^2/(4*a_2), although the true gradient is zero. Common-period averaging and longer windows cannot separate identical frequencies generated by different causes.

One sufficient all-dimension design is w_j=B^(j-1) with integer B>=5. Equality of two different labelled quadratic frequencies would give sum_j z_j*B^(j-1)=0 with |z_j|<=4. At the largest nonzero index h, the leading term has magnitude at least B^(h-1), whereas all lower terms have combined magnitude at most 4*(B^(h-1)-1)/(B-1), which is smaller. This contradiction proves separation. The design requires exponentially increasing bandwidth; practical schedules should be checked against the actual channel list.

## D6. Paired probes, circular probes, and finite-amplitude error

Paired evaluations improve the gradient contract. For displacements d_n at coherent sample times, set deltaJ_n=J(theta_0+d_n)-J(theta_0-d_n). On every quadratic this equals 2*g^T*d_n, because constant and even terms cancel. If the cosine carrier columns have Gram matrix (N/2)*I,

```text
g_hat_j=(1/(N*a_j))*sum_n deltaJ_n*cos(2*pi*b_j*n/N)=g_j.
```

PROVED D-P6 follows by substitution and discrete orthogonality. It needs distinct, nonexceptional fundamental bins, rather than complete separation of all quadratic mixing channels. Curvature recovery still needs the stronger separation condition. In particular, paired bins (1,2,3) can recover the exact quadratic gradient although their doubled curvature channels collide with mixed products.

For a smooth nonquadratic objective, pairing cancels even powers but retains cubic and higher odd terms. If the third derivative's trilinear operator norm is bounded by B_3 on the full probe neighborhood and rho^2=sum_j a_j^2, Taylor's remainder gives |g_hat_j-g_j|<=B_3*rho^3/(3*a_j). With comparable amplitudes a, this is O(a^2). Error of magnitude at most sigma in each response adds the conservative term 2*sigma/a_j. Shrinking amplitudes reduces the first contribution while increasing the second.

A scalar cubic J(x)=x^3 illustrates the bias without any measurement noise. At x=0, a*cos(t) produces a^3*(3*cos(t)+cos(3t))/4. The decoded first derivative is 3*a^2/4, although J'(0)=0. Pairing retains that odd contribution. At a=1/10 the false value is 3/400; at a/2 it is 3/1600. The Richardson combination [4*g_hat(a/2)-g_hat(a)]/3 cancels it exactly for this cubic. A general O(a^4) claim needs sufficient regularity and a bound on the remaining fifth-order terms. Disagreement between two amplitudes is a useful diagnostic but not itself a certified remainder bound.

Circular probing uses d=r*(u*cos(phi)+v*sin(phi)) for orthonormal plane directions u,v. For an exact quadratic,

```text
J_circle=C0+A1*cos(phi)+B1*sin(phi)+A2*cos(2phi)+B2*sin(2phi).
A1=r*g_1; B1=r*g_2.
A2=r^2*(h_11-h_22)/4; B2=r^2*h_12/2.
C0=J0+r^2*(h_11+h_22)/4.
```

Worked example D-E6. Set r=1, J0=5, g=(2,-1), and H=[[4,2],[2,6]]. The circle coefficients are C0=15/2, A1=2, B1=-1, A2=-1/2, B2=1. The mixed coefficient returns h_12=2. A separate center measurement J0=5 returns trace(H)=10, and trace together with h_11-h_22=-2 gives diagonal entries four and six.

Without center data, replacing H by H+3*I and J0 by 7/2 leaves every unit-circle value unchanged. More generally, H+c*I and J0-c*r^2/2 give the same scan. This is an exact unresolved fiber, not poor numerical resolution. Measuring a second radius also removes it. The first-harmonic minimum gives the negative-gradient direction; the complete circular objective can have a different minimum because its curvature harmonics also contribute.

Phase decoding has its own convention. For y=A*cos(w*t+phi), A>0, define I=2*avg(y*cos(w*t)) and Q=2*avg(y*sin(w*t)). Then I=A*cos(phi), Q=-A*sin(phi), so A=sqrt(I^2+Q^2) and phi=atan2(-Q,I) modulo 2*pi. Principal arcsine or a single arctangent ratio loses quadrant information. A memoryless objective J(theta_0+a*cos(t)) is even in t and has no sine quadrature. Its first-harmonic phase is normally zero or pi, determined by the sign of its amplitude. A generic proportionality between phase lag and derivative requires a separately calibrated dynamic plant.

The resulting instrument contract is concrete: declare the observation model, keep every probe in its defined neighborhood, check rank or frequency separation, record amplitude and noise bounds, reconstruct coefficients, and pass a proposal to an original-problem verifier. Fourier recovery identifies the admitted coefficient model. The optimization chapter supplies the separate conditions under which its proposed step decreases the actual objective or solves an equation.

# Inverse transforms, derivative coordinates, and geometry at infinity

The mathematical word inverse names a map that undoes a particular forward map. A derivative, a cumulative transform, an arithmetic divisor transform, and a fractional-linear coordinate change have different domains and different inverse conditions. Standardizing those distinctions turns several repeated project speculations into a useful collection of reconstruction methods. It also prevents an apparent analogy between two diagrams from silently replacing an algebraic identity.

## D7. Finite increments and linear coefficient extraction

For y=u*z, independent finite increments a,b give

```text
Delta y=(u+a)*(z+b)-u*z=u*b+z*a+a*b.
```

The product a*b is part of the exact finite change. At u=z=a=b=1, the output changes from one to four, a change of three. The first-order terms alone give two. If u and z depend differentiably on a real parameter t, divide their exact increment identity by a nonzero step h. The remaining cross term is [Delta_h u/h]*Delta_h z. Differentiability makes the first factor bounded near zero and the second tend to zero. Taking the limit gives (u*z)'=u*z'+z*u'. No value is assigned to an undefined quotient 0/0.

For f(x)=x^2, [f(x+h)-f(x)]/h=2*x+h whenever h!=0. The reduced expression has a continuous extension to h=0, with value 2*x. The derivative is that limit, while the exact finite change is 2*x*h+h^2. At x=0 the derivative is zero and the finite change remains h^2. Comparing h^2 to an allegedly nonzero first-order term would fail at precisely that legitimate point.

A related exact coefficient device uses dual numbers a+b*epsilon with epsilon^2=0. Their multiplication is

```text
(a+b*epsilon)*(c+d*epsilon)=a*c+(a*d+b*c)*epsilon.
```

PROVED D-P7. For a polynomial f over a characteristic-zero field,

```text
f(x+h*epsilon)=f(x)+h*f'(x)*epsilon.
```

For a monomial, the binomial theorem leaves only the constant term and the term containing one epsilon. Linearity then gives the polynomial formula. This is an exact identity in a different ring, not an equality that deletes h^2 from ordinary real arithmetic. Propagating value-and-derivative pairs through specified differentiable primitives gives forward automatic differentiation. General branch choices, non-smooth operations, and divisions still need their own rules.

Worked example D-E7. For f(x)=x^3-2*x+1 at x=2, substitute 2+epsilon. The cubic becomes 8+12*epsilon, the linear term becomes -4-2*epsilon, and the constant is one. The result is 5+10*epsilon, recording f(2)=5 and f'(2)=10. With an ordinary finite step h=1/10, the exact change is 1+6/100+1/1000=1.061, rather than the first-order prediction one. Both computations are correct because they answer different typed questions.

## D8. Difference kernels, anchors, and chain inversion

For x=(x_0,...,x_n), let d_t=x_t-x_(t-1), 1<=t<=n. Two sequences with the same differences differ by a constant. Subtracting their difference equations shows equal successive discrepancies, and induction makes the discrepancy constant at every index. Thus the difference observation has a one-dimensional kernel. An independently observed anchor x_0=b gives

```text
x_t=b+sum_(k=1)^t d_k.
```

The sum telescopes, proving both reconstruction and its uniqueness after anchoring. A terminal anchor works as well: b=x_n-sum_k d_k. Declaring b=0 chooses a representative; measuring b identifies a missing datum. A complex record can store that anchor on an imaginary axis, but cannot discover it from unchanged differences.

Worked example D-E8. Differences (3,4,5) have cumulative displacements (3,7,12). A terminal measurement x_3=20 gives x_0=8 and the full sequence (8,11,15,20). The carrier z_t=(x_t-x_0)+i*x_0 is reversible through x_t=Re(z_t)+Im(z_t). The final carrier 12+8i records displacement and anchor separately. Removing the imaginary coordinate leaves every translated sequence observationally equivalent.

The anchored cumulative transform is a different map. For u=(u_0,...,u_n), define Y_t=sum_(k=0)^t u_k. Its inverse is u_0=Y_0 and u_t=Y_t-Y_(t-1) for t>=1. Both round trips telescope. Its matrix is lower triangular with ones on the diagonal, so its determinant is one and its kernel is zero. A constant cumulative sequence (c,c,...,c) decodes to (c,0,...,0), not to zero.

This inverse is the incidence-algebra Mobius inverse on a finite ordered chain. The conventional boundary Y_(-1)=0 makes the difference formula uniform, but it does not supply a new physical observation. Omitting Y_0 or omitting an external physical offset defines a different observation map and changes the kernel. The distinction is essential whenever initial-state recovery is discussed.

For a differentiable function on a connected interval, derivative observations similarly determine the function up to a constant; an initial value supplies an integral reconstruction. Once dynamics are imposed, the admissible family can be smaller. If x'=a*x with known a!=0, an observed derivative identifies x=x'/a; if x'=0, it does not. Identifiability concerns the observation map restricted to the declared dynamics, not a slogan about all derivatives losing the same information.

## D9. Arithmetic Mobius inversion and genuine filters

The arithmetic Mobius function is mu(1)=1, mu(n)=0 if n contains a squared prime factor, and mu(n)=(-1)^s for a product of s distinct primes. For n>1, square-free divisors correspond to subsets of its distinct prime factors, giving sum_(d|n) mu(d)=(1-1)^s=0. For n=1 the sum is one.

PROVED D-P8. If A(n)=sum_(d|n) a(d), then

```text
a(n)=sum_(d|n) mu(d)*A(n/d).
```

Substitute A and collect the coefficient of a(k). It is zero unless k divides n, and in that case it equals sum_(d|(n/k)) mu(d). The preceding cancellation leaves only k=n. Every sum is finite, so no convergence hypothesis enters. On indices 1,...,L, the forward divisor matrix is triangular with diagonal one and the Mobius formula supplies its inverse. This proves both possible round trips.

Worked example D-E9. Let a(n)=n. Then A(1)=1, A(2)=3, A(3)=4, and A(6)=12. Reconstruction at six gives 12-4-3+1=6. For a(n)=x^(-n), the same formula gives

```text
(x^-1+x^-2+x^-3+x^-6)-(x^-1+x^-3)
 -(x^-1+x^-2)+x^-1=x^-6.
```

The intermediate representation includes lower powers that cancel. The fact mu(4)=0 does not erase the fourth output mode: the inverse still reconstructs x^-4. Applying a transform and its exact inverse is a representation change, not a newly created spectral mask.

A genuine modified filter can be defined by inserting an operator B between transform T and inverse U=T^-1, giving a_new=U*B*T*a. If B=I, this is exactly a. If B deletes selected transformed coordinates, then the kernel and reconstruction error of U*B*T must be analyzed. The filter can be useful, but it receives a new definition and cannot inherit the original round-trip certificate. The same principle applies to truncated Fourier synthesis, derivative channels, and partial geometric observations.

Chain incidence inversion and arithmetic divisor inversion are related as inverses of cumulative incidence operators on different partially ordered sets. Their index relations differ: one sums over earlier chain positions, the other over divisors. Fractional-linear Mobius coordinates are a third use of the name and are unrelated to the integer weights mu(n). Standard notation should identify which map is intended before any inverse is used.

## D10. Reciprocal exponentials, repeated derivatives, and phase paths

Consider E(t)=exp(t)-1=sum_(n>=1) t^n/n!, and F(x)=E(1/x) for nonzero complex x. E is entire in t. F is holomorphic away from zero and has an essential singularity at zero: its Laurent series contains infinitely many nonzero negative-power coefficients. A coordinate reciprocal does not transport entirety through its excluded point.

Mobius inversion can rewrite every x^-n inside F as a finite divisor expression. It reconstructs the same F. To justify manipulating the resulting infinite triple sum, fix a compact set with |x|>=delta>0 and derivative order m>=0. Put Q=max(1,delta^-1). There are at most n^2 divisor pairs, every contributing power k is at most n, and its m-th derivative is bounded by (n+m)^m*delta^-m*Q^n. Consequently the entire n-th contribution is bounded by

```text
n^2*(n+m)^m*delta^-m*Q^n/n!.
```

The ratio of successive bounds tends to zero. Their sum therefore converges, yielding absolute locally uniform convergence for each fixed derivative order. Termwise differentiation is justified on a compact neighborhood avoiding zero, either through the derivative-series bound and integration or the holomorphic Cauchy formula. This is not a uniform statement over all orders m and all radii.

For integers k>=1 and m>=0, with the empty product (k)_0=1,

```text
(k)_m=k*(k+1)*...*(k+m-1).
D_x^m(x^-k)=(-1)^m*(k)_m*x^(-k-m).
```

Induction proves this: one more derivative multiplies by -(k+m) and increases the negative exponent by one. At fixed m, (k)_m is a degree-m polynomial in k. At fixed k and growing m, its growth is factorial in m. Describing both regimes as the same damping process hides their different magnitudes. With x=r*exp(i*theta), the derivative modulus is (k)_m*r^(-k-m), independent of theta, while

```text
Im(D_x^m x^-k)=(-1)^(m+1)*(k)_m*r^(-k-m)*sin((k+m)*theta).
```

Worked example D-E10. For k=3,m=2,r=2, the derivative is (3/8)*exp(-5i*theta). At theta=pi/10 its imaginary part is -3/8. At theta=pi/5 the derivative is -3/8, with imaginary part zero. The mode survives; only one observation coordinate vanishes. One angle also changes all harmonic gains together. The gains sin(theta) and sin(2*theta) cannot both equal one, since sin(theta)=1 forces sin(2*theta)=0.

Phase rates must be differentiated along a real path. Let x=x(s) be C^1, with x!=0 and F(x)!=0. Write F(x(s))=R(s)*exp(i*phi(s)) locally, R>0. Differentiate and divide by F to obtain

```text
(log R)'=Re[(F'/F)(x(s))*x'(s)].
phi'=Im[(F'/F)(x(s))*x'(s)].
F'/F=-exp(1/x)/[x^2*(exp(1/x)-1)].
```

These are PROVED D-P9 under the stated path and nonzero conditions. Writing F=U+i*V gives the independent real formula phi'=(U*V'-V*U')/(U^2+V^2). A nonconstant real modulus is not a holomorphic function of a complex variable; using its supposed complex derivative is ill-typed. The tangent x'(s) cannot be omitted when the observation path changes.

For the simpler signal G(x)=x, the path x(s)=exp(i*s) gives (G'/G)*x'=i and phase rate one. A horizontal path x(s)=s+i gives Im[1/(s+i)]=-1/(s^2+1), a different rate. The quotient G'/G is the same analytic expression, but the paths and phases differ.

For F=exp(1/x)-1, the zeros are x=1/(2*pi*i*j), j any nonzero integer. Taking modulus in exp(1/x)=1 forces Re(1/x)=0, and the sine/cosine equations force Im(1/x)=2*pi*j; these conditions are also sufficient. Each zero is simple because F'=-1/x^2 there. The logarithmic derivative is undefined at these zeros and amplifies uncertainty near them. Phase can be chosen continuously along an admitted path, but a single-valued global logarithm cannot cover loops around those simple zeros.

## D11. Fractional-linear coordinates and their poles

A fractional-linear coordinate map has the form

```text
y=T(x)=(a*x+b)/(c*x+d), a*d-b*c!=0.
x=(d*y-b)/(a-c*y).
```

The forward and inverse denominators must be nonzero on their declared charts. Cross multiplication derives the inverse, and substitution proves the round trip. The derivative is (a*d-b*c)/(c*x+d)^2 where defined. The determinant condition prevents the map from collapsing to a constant. On a chosen real interval avoiding its pole, it is monotone and provides a legitimate coordinate adapter.

Worked example D-E11. Let g(x)=x^3-x-1 on [1,2], and choose z=1-1/x. Then z ranges bijectively over [0,1/2], with x=1/(1-z). Multiplication by the nonzero factor (1-z)^3 gives

```text
h(z)=z^3-4*z^2+5*z-1=(1-z)^3*g(1/(1-z)).
```

Expanding 1-(1-z)^2-(1-z)^3 proves the polynomial identity. An admitted root of h maps to a root of g and conversely. The pole z=1 is outside the transformed interval. The substitution reorganizes the cubic; it does not make its additive terms linear. An interval or exact original-equation verifier remains the final certificate.

Multiplying a rational equation by a denominator without retaining its exclusions is a different operation. For (x-1)/(x-1)=1, the cleared polynomial is zero but x=1 remains excluded from the original domain. A coordinate adapter therefore stores its forward map, inverse map, guards, and correspondence of solution sets together.

## D12. Projective directions and affine asymptotes

An exact conic F(x,y)=A*x^2+B*x*y+C*y^2+D*x+E*y+F0 has homogeneous form

```text
Fh(X,Y,Z)=A*X^2+B*X*Y+C*Y^2+D*X*Z+E*Y*Z+F0*Z^2.
Fh(X,Y,Z)=Z^2*F(X/Z,Y/Z), Z!=0.
```

The identity follows by substitution. Nonzero common scaling preserves its zero set and multiplies its value by the square of the scale. It does not selectively suppress terms involving Z. Infinity is examined after projective normalization when affine coordinates escape, not by multiplying every coordinate by the same factor.

At Z=0, finite candidate slopes m=Y/X satisfy A+B*m+C*m^2=0. For a nonzero quadratic block, B^2-4*A*C distinguishes two real directions, one repeated real direction, or no real direction. A direction is not yet an affine line asymptote. For y^2=x, the infinity equation Y^2=0 gives horizontal direction, but y=+/-sqrt(x) moves arbitrarily far from every horizontal line. For y^2+1=0, a real projective point at infinity coexists with no real affine points at all.

PROVED D-P10. For a simple finite direction m, set k=B+2*C*m!=0 and b=-(D+E*m)/k. Substitute y=m*x+b+epsilon. The exact remaining equation is

```text
C*epsilon^2+(k*x+2*C*b+E)*epsilon+R0=0.
R0=C*b^2+E*b+F0.
```

If C=0, its small solution is -R0/(k*x+E). If C!=0, for sufficiently large |x| its discriminant is positive and the small solution is

```text
epsilon=-2*R0/[H+sgn(H)*sqrt(H^2-4*C*R0)],
H=k*x+2*C*b+E.
```

The denominator is asymptotic to 2*k*x, proving epsilon=O(1/x) and y=m*x+b+O(1/x). This establishes an actual branch and its line under an exact conic hypothesis. At k=0 the direction is repeated and the intercept division is unavailable; it does not mean the asymptote is vertical. Vertical directions require a separate slope chart.

Worked example D-E12. The upper hyperbola branch y=2+2*sqrt(1+(x-1)^2/9) has line y=(2/3)*x+4/3 as x tends positively to infinity. Put t=x-1>0. Its exact line error is

```text
epsilon=(2/3)*(sqrt(t^2+9)-t)
       =6/(sqrt(t^2+9)+t), 0<epsilon<=3/t.
```

At x=10, t=9 and the error is 6/(sqrt(90)+9), approximately 0.3246; the bound is 1/3. Rationalization proves the decay without a fitted extrapolation. Conversely, y=x+sqrt(x) has y/x tending to one but y-x diverging. A relative direction limit cannot be promoted to bounded absolute distance from a line.

A conic fitted to finitely many points yields a model-conditional prediction. Its coefficient vector needs a nonzero normalization, because unconstrained algebraic-residual minimization chooses the zero polynomial. Rank, singular-value separation, and the distinction between algebraic residual and perpendicular distance control stability. Adding a multiple of product_i(x-x_i)^2 leaves every sampled value unchanged while altering the distant tail. No finite fit alone proves an arbitrary unknown function's asymptote.

# Projections, quaternion rotations, and the dual-funnel boundary

Geometry becomes a solver component when its coordinates, metric, and state evolution are explicitly connected to the original problem. Three-dimensional orientation is a legitimate use of quaternions. Log-polar coordinates organize scale changes. Orthographic views expose selected components. None of these operations automatically preserves every metric, supplies missing constraints, or changes a contracting trajectory into a chaotic attractor. The following constructions give useful exact forms while retaining those distinctions.

## D13. Projection kernels and 120-degree lattice pictures

For a unit normal n in R^3, orthographic projection onto its perpendicular plane is P=I-n*n^T. Direct multiplication gives P^2=P and P*n=0. If v=v_perp+alpha*n, its image is v_perp. Thus an entire line of spatial points has the same image. Projection preserves lengths only for displacements already in the plane; in general |P*v|<=|v|.

Worked example D-E13. Choose n=(1,1,1)/sqrt(3). The projected coordinate axes are

```text
p1=(2,-1,-1)/3; p2=(-1,2,-1)/3; p3=(-1,-1,2)/3.
p1+p2+p3=0.
|p_j|^2=2/3; p_j dot p_k=-1/3 for j!=k.
```

Their mutual cosine is (-1/3)/(2/3)=-1/2, so the originally perpendicular axes appear 120 degrees apart. This explains a triangular lattice projection through an exact metric calculation. It does not make the projected axes orthogonal. The points (0,0,0) and (3,3,3) both project to zero. Recovering depth needs another observation or a justified constraint selecting one point from each line.

For an orthonormal complete basis u_1,...,u_d, sum_j u_j*u_j^T=I and |x|^2=sum_j(u_j^T*x)^2. An incomplete family gives a projection and an inequality. These identities distinguish complete coordinate recovery from a useful lower-dimensional view. Multiple projections can jointly become injective: stacked observation matrices recover x exactly when their common kernel is zero. A second camera or a known plane can supply depth; repainting the first projection cannot.

Diagram meaning also depends on embedding. On residue-clock coordinates iota(x)=exp(2*pi*i*x/9), arithmetic negation x->-x becomes conjugation, a reflection. A regular nine-gon has no diametrically opposite vertex pair. On unit-orbit coordinates eta(2^j mod 9)=exp(2*pi*i*j/6), doubling becomes a 60-degree rotation and negation becomes a half-turn, because 2^3 == -1 (mod 9). These are representations of different labelled structures. In the six-dimensional permutation representation, the third iterate sends basis vector e_x to e_(-x); it is not the scalar matrix -I. A geometric assertion must name its embedding before identifying reflection, label negation, and coefficient negation.

## D14. Log-polar scale coordinates retain a metric

For r>0, use u=theta modulo 2*pi and v=log(r/r_ref). The punctured plane is identified with S^1 times R, with inverse r=r_ref*exp(v). Uniform dilation r->lambda*r becomes v->v+log(lambda). A logarithmic spiral r=r0*exp(b*theta) becomes a straight relation v=b*theta+log(r0/r_ref) on an unwrapped angular coordinate. When b!=0, each turn changes v by 2*pi*b, so it is not a single-valued graph over theta modulo 2*pi.

The Euclidean metric and area become

```text
ds^2=r_ref^2*exp(2*v)*(dv^2+du^2).
dArea=r_ref^2*exp(2*v)*du*dv.
```

Substitute dr=r*dv into dr^2+r^2*dtheta^2 to prove the first identity; the Cartesian inverse's Jacobian proves the second. Dropping the factor exp(2*v) changes length and geodesic optimization. Conformal coordinates preserve angles locally, not arbitrary distances or curvature values.

For a concrete distance comparison, take r_ref=1 and a radial move from r=1 to r=2 at fixed angle. Its Euclidean length is one. Its coordinate difference is log(2), approximately 0.6931. Integrating the transformed metric gives integral_0^log(2) exp(v) dv=1; treating the coordinates as an ordinary Euclidean plane gives the wrong length. The coordinate map is useful precisely because the metric is carried along with it.

Discrete scale invariance has an equally precise form. If lambda>1 and f(lambda*r)=lambda^a*f(r), put P(t)=lambda^(-a*t)*f(lambda^t). Substitution gives P(t+1)=P(t), so f(r)=r^a*P(log_lambda(r)). A periodic factor may be Fourier-expanded when its regularity supports that expansion. Its fundamental angular log-frequency is 2*pi/log(lambda), not log(lambda). For lambda=2 and P(t)=cos(2*pi*t), equal-phase radii repeat by factors of two. This prescribed spatial scaling law is not automatically a temporal oscillation or an orbital stability theorem.

## D15. Quaternion packages and actual rotations

Hamilton quaternions have the form q=s+x*i+y*j+z*k, with i^2=j^2=k^2=i*j*k=-1. In scalar-vector notation q=(s,v), multiplication is

```text
(s,v)*(t,w)=(s*t-v dot w, s*w+t*v+v cross w).
conj(q)=(s,-v); q*conj(q)=s^2+|v|^2.
```

Their multiplication is noncommutative: i*j=k while j*i=-k. A pure quaternion (0,v) is a reversible record of three real coordinates. It is not generally a unit quaternion and should not be normalized if the magnitude of those coordinates matters. Extracting its components before evaluating ordinary equations preserves their intended real arithmetic. Replacing real variables by i,j,k inside a polynomial changes the multiplication law and changes the problem.

For a unit quaternion q, define a rotation by v' as the vector part of q*(0,v)*conj(q). PROVED D-P11 states that it preserves |v| and has inverse conjugation by conj(q). Norm multiplicativity follows from conjugating products in reverse order and using q*conj(q)=|q|^2; the unit factors leave the pure quaternion's norm unchanged. Direct expansion shows its scalar part remains zero. Thus the map is real-linear and orthogonal.

For a unit axis a and angle alpha, q=cos(alpha/2)+a*sin(alpha/2). Expansion gives Rodrigues' formula

```text
v'=cos(alpha)*v+(1-cos(alpha))*(a dot v)*a
                    +sin(alpha)*(a cross v).
```

The component parallel to a is fixed; perpendicular components rotate through alpha. The half-angle is required because conjugation applies q on both sides. Quaternions q and -q give the same rotation. Composition order remains significant: q2*q1 represents the rotation by q1 followed by q2 in this active-vector convention. Frame-coordinate conventions can reverse signs or order, so a code adapter must declare them.

Worked example D-E14. A positive 90-degree rotation about the x-axis uses q=(1+i)/sqrt(2). It sends (x,y,z) to (x,-z,y), hence e_y to e_z and e_z to -e_y. The normal e_z of the xy-plane becomes -e_y, so the plane becomes the xz-plane. The inverse is the negative 90-degree x rotation. A separate rational quaternion q=(3/5,4/5,0,0) gives an exact algebraic test of norm preservation without approximating sqrt(2); all 125 integer vectors in {-2,...,2}^3 were rotated and inverted exactly.

In the recovered three-variable solver, q=k_x*i+k_y*j+k_z*k stores chart coordinates X_i=r_i+M*k_i and physical coordinates theta_i=X_i/D_i. Its actual loss is evaluated on those extracted real components. The chain rule gives dJ/dk_i=(M/D_i)*dJ/dtheta_i; applying that factor twice would corrupt a gradient. Paired lock-in estimates proposals inside this chart. Quaternion multiplication is unnecessary for that storage-and-probing task, and a real vector implements the same updates.

The useful division of work is operational: residue methods produce sound retained lattice charts; continuous probing proposes promising nearby points; exact original-equation checks validate snapped points; exhaustive checking of all retained finite candidates supplies completeness. The quaternion package does not prove global numerical convergence or completeness. It provides clean three-axis bookkeeping and, when conjugation is actually used, a verified spatial rotation.

## D16. Mirror-conjugate contracting flows

The supplemental Dual-Funnel Projection Theorem is a document by Griff Gurwell, dated October 2026. Its elementary geometric theorem is separate from Stefan's later proposal to orient one spiral orthogonally to the other. The source's domain assumptions must be retained when its result is reused.

Let kappa>0 and w>0. The two complex flows are

```text
z_plus(t)=z0*exp((-kappa+i*w)*t).
z_minus(t)=z0*exp((-kappa-i*w)*t).
```

Orientation reflection M(z)=conj(z) satisfies M*Phi_plus(t)*M=Phi_minus(t). Conjugating exp((-kappa+i*w)*t) reverses the imaginary exponent and preserves the real one. Both flows contract in radius as r0*exp(-kappa*t), while their angles advance in opposite directions. This is PROVED D-P12. Replacing t by -t instead causes expansion, so mirror reversal and time reversal are different operations.

On unwrapped polar coordinates, log(r/r0)=-kappa*t and theta=theta0+/-w*t. Eliminating t gives a logarithmic spiral. A three-dimensional funnel interpretation requires an additional axial coordinate, surface definition, or vector field. The complex flow alone specifies a planar trajectory. Appending height h(t) produces a spatial curve, but its height law is an added modeling choice.

A known-target discrete spiral z_(n+1)=z_star+rho*exp(i*alpha)*(z_n-z_star), 0<rho<1, has error e_n=rho^n*exp(i*n*alpha)*e_0 and converges to z_star. The proof is direct iteration. It illustrates convergence only because z_star is already supplied. Rotating a projected answer can change that answer: the map z_new=(z+i)/2 converges to i, even if the intended constant consistency projection returns one. A contraction proves approach to its own fixed point; a separate fixed-point correspondence must identify that point with the original solution.

## D17. The half-radius projection theorem and the 90-degree change

The source projection class imposes four conditions. Two projected mouth circles have equal radius a; their centers are opposite points (0,c) and (0,-c); both circles pass through the origin; and they are internally tangent to an outer circle of radius R at opposite poles. Here R>0 and c>0 describe the nondegenerate construction.

PROVED D-P13. The common-origin condition gives a=c. Internal tangency gives a+c=R. Solving these two equations yields a=c=R/2. Conversely these values satisfy both conditions. The mouth circles are therefore

```text
x^2+(y-R/2)^2=R^2/4.
x^2+(y+R/2)^2=R^2/4.
```

Alternating inward semicircles produce the bicircular S-divider, with the two reflection-related orientation choices. Each arc has radius R/2 and length pi*R/2, so the full divider length is pi*R. Its curvature magnitude on either arc is 2/R. A half-turn exchanges the two complementary regions and preserves area; their areas are therefore equal, each pi*R^2/2. These conclusions are forced by the circular projection assumptions, not by mirror conjugacy alone.

Worked example D-E15. For R=10, the mouth radius and center displacement are both five. The divider length is 10*pi, approximately 31.416, and each complementary area is 50*pi, approximately 157.080. No secondary nested radius follows from the two equations. Choosing smaller copies is a recursion rule requiring its own scale and nonintersection conditions.

A 90-degree x-axis rotation creates a legitimate orthogonal-plane model, but changes the projection hypothesis. Consider

```text
gamma_1(t)=exp(-kappa*t)*(cos(w*t),sin(w*t),0).
gamma_2(t)=exp(-kappa*t)*(cos(w*t),0,sin(w*t)).
```

The second curve is the positive 90-degree x rotation of the first. Their planes have perpendicular normals e_z and -e_y. Their position vectors are not generally perpendicular: their dot product is exp(-2*kappa*t)*cos(w*t)^2. Perpendicular planes intersect along the x-axis, so orthogonal planes do not imply orthogonal corresponding points or tangent vectors.

Top-down orthographic projection discards z. A circular mouth in the xy-plane projects to a circle. After a 90-degree x rotation it lies in the xz-plane and projects to a line segment. More generally, a circular mouth tilted by angle beta has projected semiaxes a and a*|cos(beta)|. At beta=pi/2 the second semiaxis vanishes. Thus the rotated pair fails the original congruent-circle condition. The half-radius S-partition theorem cannot be transferred unchanged to this orthogonal-funnel view.

The useful repaired objects are explicit: the original mirror pair retains its exact planar bicircular theorem under its mouth assumptions; the rotated pair is a three-dimensional orthogonal-plane spiral model, with a different projection and no inherited S-divider guarantee. Quaternion conjugation provides the rotation certificate. Any proposed new projection theorem must start from its changed mouth geometry rather than from the familiar appearance of the original diagram.

## D18. Contracting spirals are not evidence of chaos

The displayed flows have an attracting equilibrium at the origin. For any two initial states z0,z1, their separation at time t is exp(-kappa*t)*|z0-z1|. It decreases exponentially. The largest linear Lyapunov rate is therefore -kappa. Every trajectory tends to zero. For independent products of these flows, the Euclidean separation of the combined state also contracts at that rate. A fixed spatial rotation preserves these facts because it preserves distances.

PROVED D-P14 therefore refutes a chaotic-attractor interpretation for this particular linear contraction model. Crossing projected traces, two apparent lobes, opposite winding, or a rotated plane does not establish recurrent chaotic dynamics. A point equilibrium is an attractor, but the adjective strange requires a different dynamical claim.

An actual investigation of a proposed strange attractor needs an autonomous map or vector field, an admissible state domain, a bounded invariant or trapping region, and a definition of the claimed recurrent set. Lyapunov calculations must be tied to that model and checked for step-size and trajectory-length dependence. A positive finite-time numerical exponent would be approximate evidence, not a theorem by itself. The present source supplies neither a nonlinear coupling law nor such evidence. The corrected orthogonal construction remains useful as an orientation test, a contraction visualization, and a controlled geometric seed.

Equal-phase sampling also needs a quotient distinction. Sampling theta in increments 2*pi/n gives angular labels in C_n. Reflection sends the phase generator to its inverse, yielding the usual dihedral completion of order 2*n. The full contracting state does not return after n samples because its radius has decreased. C_n describes the angular quotient or a separately defined phase register. It is not the complete state group of a contracting flow.

## D19. Icosahedral flags, routes, and a separate 120-state register

The recovered doubling-vortex report introduces an icosahedral model as an additional geometric state space. Twelve spherical sites are a new premise; they are not forced by the six units modulo nine. A regular icosahedron can be defined by vertices proportional to

```text
(0,+/-1,+/-tau), (+/-1,+/-tau,0), (+/-tau,0,+/-1),
tau=(1+sqrt(5))/2, tau^2=tau+1.
```

In these unnormalized coordinates, nearest neighbors have squared separation four. There are twelve vertices, thirty edges, and twenty triangular faces. Each vertex has five neighbors, so the edge count is 12*5/2=30; each edge belongs to two triangles, so the face count is 2*30/3=20. A flag is an incident vertex-edge-face triple. Every triangle has three edges and each edge two endpoints, giving 20*3*2=120 flags.

Changing just the vertex, edge, or face of a flag gives involutions r0,r1,r2. Moving around a triangular face gives (r0*r1)^3=1; moving around a five-face vertex gives (r1*r2)^5=1; the independent endpoint and face changes at a fixed edge commute, giving (r0*r2)^2=1. These global adjacent-flag toggles form the monodromy action, isomorphic to the full symmetry group's opposite regular action. A toggle need not be one fixed spatial isometry on every flag. This is the standard H3 Coxeter flag structure. Vogan's primary slides identify the corresponding icosahedral symmetry group of order 120. The accompanying exact enumeration constructs these 120 flags from the coordinates, generates exactly 120 permutations, and checks the relations.

FINITE D-F1. That specific finite action has element orders 1,2,3,5,6,10. In particular it is not cyclic and has no element of order 120. Merely arranging its flags in a list of length 120 creates an indexing cycle; it does not create an order-120 rigid spatial rotation.

Another 120-element set consists of all directed non-antipodal routes between the twelve vertices: each start has ten eligible destinations. It includes both adjacent and more distant vertex pairs, so it is not the thirty-edge nearest-neighbor graph. Its equal cardinality does not make it the same symmetry action as the flag set. A traversal ordering of routes is a routing rule, with its own state and transition contracts.

A genuine cyclic 120-state register can be specified as C_24 times C_5 with simultaneous update (a,b)->(a+1,b+1). Its first return occurs when both 24 and five divide the step count, hence at lcm(24,5)=120. This is a proof about explicitly supplied registers. Their counts do not follow from the icosahedral flags or the 3-adic unit tower.

For class-I icosahedral subdivision frequency f, the face count is 20*f^2, the edge count is 30*f^2, and the vertex count is 10*f^2+2 by Euler's sphere identity. At f=120, the vertex count is 144,002, not 144,000. The latter equals the count minus the Euler characteristic two. If a separately chosen phase generator g has order 120 and one cell advances phase by g, endpoint closure says 120 divides f. Only an additional first-return requirement selects f=120 rather than a larger multiple. These exact models make arithmetic, geometry, and synchronization usable together while keeping their additional coupling assumptions visible.

## D20. Practical contracts and exercises

The spectral-and-geometric component accepts a domain D, an observation map O, a coordinate map T where genuinely invertible, and a verifier V. A finite Fourier block supplies a matrix and a rank certificate. A discarded projection supplies a kernel and the anchors needed for recovery. An oscillatory probe supplies frequencies, amplitude, domain guards, and coefficient error bounds. A quaternion supplies an orientation convention and an inverse. A fitted curve supplies a model assumption and a residual metric. The output remains a coefficient record, geometric reconstruction, certified correspondence, or numerical proposal according to that contract.

These components serve concrete tasks: drawing compressed outlines; transmitting finite constellations over measured waveforms; estimating derivatives of costly experimental responses; checking whether boundary data identify a state; moving an algebraic search to a better interval; separating projective direction from actual tail distance; and testing a three-dimensional orientation before asserting properties of its projection. Their shared advantage is structured access to information already present in the model, together with transparent accounting for information lost.

Exercise D-X1. A record a+b*omega+c*omega^2 equals zero and its anchor is a+b+c=9. Determine all real coefficients. Answer: the complex equation has kernel (t,t,t), so the anchor gives a=b=c=3. Without the anchor there is an entire line of solutions.

Exercise D-X2. On an eight-sample grid, compare cosine bins one and seven, and decide whether two unrestricted amplitudes are identifiable. Answer: cos(2*pi*7*n/8)=cos(2*pi*n/8), so only their sum is observed. Adding a sine channel with a declared sign convention changes the design; relabelling the two cosine columns does not.

Exercise D-X3. A unit-circle scan has C0=9, A2=1, B2=-2 and an independently measured center J0=6. Recover its plane Hessian. Answer: trace=4*(9-6)=12, difference=4, and mixed entry=2*(-2)=-4. Thus H=[[8,-4],[-4,4]]. Omitting J0 leaves the trace free.

Exercise D-X4. A cumulative array is (7,7,7). Compare its anchored chain inverse with ordinary adjacent differences. Answer: the inverse is (7,0,0), while adjacent differences are (0,0). Their domains have different dimensions and their kernels differ.

Exercise D-X5. Rotate a circle of radius three in the xy-plane through 60 degrees about x, then project top-down. Answer: its image is an ellipse with semiaxes three and 3*cos(60 degrees)=3/2. A 90-degree tilt produces a segment. The circular-mouth projection theorem requires renewed hypotheses after either tilt.

Exercise D-X6. A phase has 120-state generator g, but each spatial cell advances by g^8. Find the first closure frequency. Answer: 120/gcd(120,8)=15. A group order does not determine the physical update step.

The local check scripts separate exact rational identities from binary64 experiments. They preserve input hashes, tested ranges, and regeneration commands. Original source titles containing audited or certified are not substitutes for those checks. The chapter proofs establish the stated general implications; the recorded finite runs verify selected formulas, data, and implementations within their declared scope.

## D21. Primary references and dependency boundaries

D-R1. MathWorks, Discrete Fourier Transform, R2026b, inspected 13 October 2026. The documented transform signs and inverse factor are translated to zero-based indexing here. URL: https://www.mathworks.com/help/signal/ug/discrete-fourier-transform.html . The chapter gives its own finite character proof and does not infer a continuous reconstruction theorem from the finite inverse.

D-R2. Stanford Research Systems, About Lock-In Amplifiers, Application Note 3, pages 1-2, inspected 13 October 2026. This primary manufacturer source explains reference multiplication, averaging, and quadrature. URL: https://www.thinksrs.com/downloads/pdfs/applicationnotes/AboutLIAs.pdf . Its sine-reference convention is translated explicitly; it supplies no universal optimization theorem.

D-R3. NIST Digital Library of Mathematical Functions, version 1.2.8, released 15 September 2026, Sections 27.5 and 1.9, inspected 13 October 2026. Formulas 27.5.2-3 identify arithmetic Mobius inversion; Section 1.9 supplies complex polar and analytic conventions. URLs: https://dlmf.nist.gov/27.5 and https://dlmf.nist.gov/1.9 . Self-contained finite cancellation and pathwise phase derivations appear above.

D-R4. NASA/JPL NAIF, CSPICE Required Reading: Rotation, quaternion and composition sections, inspected 13 October 2026. The scalar-first Hamilton convention, conjugation, and composition order match the declared active-vector convention. URL: https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/rotation.html . A pure coordinate package and a unit orientation quaternion remain distinct objects.

D-R5. David Vogan, Regular polyhedra and Coxeter groups, Tufts lecture 25 January 2019, corrected version 26 January 2019, slides 9-12 and 21-22, inspected 13 October 2026. Flags, adjacent-flag generators, and the H3 icosahedral group of order 120 are the checked source scope. URL: https://math.mit.edu/~dav/regpolyTUFTSHO2.pdf . The exact finite action is also independently enumerated in D_verify.py.

D-R6. Griff Gurwell, The Dual-Funnel Projection Theorem, October 2026, supplied local PDF, full seven-sheet document including cover read. This is source material provided for review, rather than an independently peer-reviewed dynamical theorem. Its elementary P1-P4 radius calculation is reconstructed above. Its circular projection result does not supply a strange-attractor theorem or the changed projection of an orthogonal funnel.

# E1. Patterns as inspectable constructions

Stefan's pattern work begins with a practical question: which useful relationships can be exposed by reading the same objects in different ways? Residues reveal divisibility; differences reveal changes; windows reveal repeated local structure; array walks reveal relationships that an ordinary row scan misses. The useful unifying idea is a pattern construct. A construct specifies the observations, the reading order, the retained representation, the allowed relationship and the finite search domain. It is a reproducible mathematical question rather than an impression that two displays look alike.

Standard matching, automata, group actions and experimental design provide the established mathematics. Stefan's contribution to this compilation is the organizing approach: preserve several views of an object, search for relationships between them, and carry a witness back to the original observations. A transformation that simplifies recognition is valuable even when it loses information, provided that the lost distinctions remain explicit.

## E1.1 Observations, windows and relationships

Let x_c(n) be channel c at integer index n. A sampled window is

```text
W(i,w,s,c) = (x_c(i), x_c(i+s), ..., x_c(i+(w-1)s)).
```

Here i is the start, w is the number of samples and s is the sampling stride. A movement step changes i between comparisons; it does not change s. For finite data of length L, a legal window requires i>=0 and i+(w-1)s<L when s>0. Missing values are marked as missing and never silently converted into zeros. Every retained sample has a source identity: dataset revision, channel and physical index, or another declared event identifier.

A representation O may retain the raw word, its differences, centered values, ranks with ties, residues modulo M or valuations v_p. A relationship then compares O(W_A) and O(W_B). Literal equality preserves every typed value. Translation asks for y_j=x_j+delta. Affine matching asks for y_j=a*x_j+b. Equal totals preserve only one aggregate. Equal ranks preserve order and ties while discarding distances. These are distinct statements about the original data.

Example E1-A uses X=(3,1,4,1,5), Y=(13,11,14,11,15) and Z=(6,2,8,2,10). X and Y match by translation delta=10; X and Z match by scale a=2,b=0. Their common rank pattern does not distinguish translation from scaling. The sequence (3,2,1) has the same total as (1,2,3), but the opposite order. A claim about equal sums cannot be promoted into equal ordered windows.

PROVED E1-P1: two nonempty equal-width integer windows differ by one constant exactly when their successive differences agree. Translation cancels in subtraction. Conversely, if y_(j+1)-y_j=x_(j+1)-x_j, then y_(j+1)-x_(j+1)=y_j-x_j; induction makes every difference equal to y_0-x_0. Thus a translation matcher can index difference words, then retain the offset as its witness. At width one the condition is automatic and supplies no structural evidence.

Exact integer or rational calculations should decide exact relations. Numerical affine fitting instead has an APPROXIMATE contract: a stated residual norm, tolerance, support size and degeneracy policy. A constant source window cannot identify an affine slope. Allowing a=0 also makes affine matching directional: every window can map to a constant target, while the inverse relation need not exist. Calling every such fit an equivalence class would be mathematically wrong.

Example E1-B concerns sampling. The tape 2,7,2,7,... yields the constant word 2,2,2,... when read from index zero with stride two. The observed word is constant; the tape is not. An observation map can erase a period component. The construct must therefore retain its stride before a statement is translated back to the tape.

## E1.2 Two moving heads and a comparison map

For equal contiguous widths define D_w(i,j) as the Hamming distance between W(i,w,1,c) and W(j,w,1,c). It counts unequal aligned symbols. On binary words it also equals the squared raw Euclidean distance. The matrix of these distances organizes several familiar tasks. Fixing i gives a distance profile. Keeping j-i fixed follows a diagonal. Recording the least permitted entry in each row gives a nearest-window profile. Thresholding the entries gives a recurrence map.

The matrix-profile literature uses this same all-pairs organization with z-normalized Euclidean windows [E-R1]. The present Hamming version changes the metric deliberately. A constant binary window has zero standard deviation, so its z-normalization needs an explicit convention. An exclusion zone can remove self-matches and near-overlap matches, but it is a search rule, not a statistical independence certificate.

PROVED E1-P2 is the diagonal update

```text
D_w(i+1,j+1) = D_w(i,j)
                 - 1[x(i)!=x(j)] + 1[x(i+w)!=x(j+w)].
```

Every old interior alignment remains; one old pair departs and one new pair enters. The same argument updates an aligned product sum by subtracting its departing product and adding its entering product. This avoids rescanning w pairs for each common one-step movement.

Example E1-C uses the tape (1,0,1,1,0,0,1). Width-three windows at starts zero and three are (1,0,1) and (1,0,0), giving distance one. Moving both starts one step gives (0,1,1) and (0,0,1), also distance one. The departing comparison is 1 versus 1 and the entering comparison is 1 versus 1, so both boundary contributions are zero. If only one head moves, interior alignments change and the recurrence no longer applies. Independent movements need recomputation or a separately proved update.

Widths, strides, channels and allowed transformations enlarge the hypothesis search. A smallest distance selected from thousands of comparisons is still a descriptive optimum. Dividing by width changes units; it supplies no probability calibration. A complete comparison report records the number of visited constructs, the exclusions, ties and any unsearched scope caused by a resource budget.

## E1.3 The state must retain the information that affects the future

A state machine is useful when the retained state determines legal next states or their declared probabilities. Under independent identically distributed fair incoming bits, an ordered width-w trailing word is a first-order Markov state: remove its oldest bit and append one fresh bit. A graph alone identifies possible transitions. A probabilistic transition law requires the incoming-bit assumption as well.

Example E1-D explains why a count is often inadequate. Both words 01 and 10 contain one 1. From 01, appending a fair bit produces counts one or two with probabilities one half each. From 10 it produces counts zero or one. The two hidden words were merged, but their successor laws differ. The count process cannot inherit a first-order Markov law merely because the ordered word has one.

The stationary width-two count process actually has no finite Markov order. For any proposed memory length m, consider a count history beginning at zero followed by m counts of one, and another beginning at two followed by the same suffix of ones. Count zero forces terminal bit zero; count two forces terminal bit one. Each subsequent count one forces the terminal bit to flip. The terminal bits therefore remain opposite despite the arbitrarily long identical observed suffix. Their next-count probabilities differ, and both histories have positive probability under fair bits. No fixed m suffices.

This is an observation-memory issue rather than a need for infinitely many hidden physical states. Let u be the conditional probability that the latest hidden bit is one given the entire count history. The next counts zero, one and two have probabilities ((1-u)/2,1/2,u/2). After observing them, u becomes zero, 1-u or one respectively. With stationary initialization the belief state takes only the values zero, one half and one. A small recursively updated belief can retain information that no fixed recent count suffix retains.

Two heads reading one unknown fixed tape introduce another memory requirement. Revisiting an old physical index reveals a value already known. Even if that index has left both current windows, its value is not a fresh independent bit. A revealed-index cache or equivalent sufficient state is required. For a fully specified deterministic arithmetic tape, positions and settings can determine the output exactly; that is a different model from an unknown random tape.

## E1.4 Coordinate walks, symmetries and exact indexing

An array walk maps an ordered visit number to a row and column. A row, column, diagonal, serpentine path or custom step word can all feed the same window machinery. The coordinate map remains part of the result. A repeated symbol word on a diagonal and a repeated square patch are different relationships: the latter verifies the complete two-dimensional arrangement.

For an R-by-C wrapped grid, a repeating step word of length L has augmented state (row,column,next-step phase). Let its total displacement be (a,b). After L moves the phase returns and the coordinates translate by (a,b) in Z/RZ times Z/CZ. PROVED E1-P3 gives the exact augmented period

```text
T = L*lcm(R/gcd(R,a), C/gcd(C,b)).
```

Returning the phase requires a multiple of L, and the remaining factor is the order of the total translation. Example E1-E uses one row, two columns and steps right,right,stay. The starting cell is revisited after two moves, but the step phase differs. The full state returns after three moves. A cell-only repeat detector stops too soon.

A square patch has eight rigid orientations, forming the standard group D4. Taking the least complete serialization over its eight orientations defines an exact canonical representative. Equal representatives mean equal orbits: transformations taking the two patches to their common representative compose to a transformation between them. The result should retain that orientation witness. A symmetric patch may have fewer than eight distinct images, so it must not be counted eight times automatically.

Example E1-F has patch rows (1,2) and (3,4). Its clockwise rotation has rows (3,1) and (4,2). They share the same D4 representative while their row words differ. A diagonal word agreement alone would not verify this patch relation. Canonicalization intentionally identifies permitted symmetries. A hash collision is an unintended information loss and has a different role.

A rolling fingerprint of a token word is

```text
h = sum_(j=0)^(w-1) token_j * B^(w-1-j) mod M.
h_next = ((h-token_out*B^(w-1))*B+token_in) mod M.
```

Equal words have equal fingerprints; the reverse implication fails. The safe matcher indexes by fingerprint, then compares complete typed values. If every fingerprint is deliberately forced to zero, all candidates enter one bucket and the accepted match set must remain unchanged. This tests correctness under total loss of filtering power. A fixed polynomial hash can improve a workload while supplying no randomized collision bound and no cryptographic authentication.

Dictionary matching reuses a prefix automaton and suffix fallback links to recognize many literal patterns in one traversal. Walk boundaries and missing cells reset its state unless concatenation is explicitly part of the input. Inserting the final value of one row beside the first value of an unrelated column would otherwise manufacture a match. Correctness means reproducing the declared direct match set, including overlaps; speed is a separate measured claim.

## E1.5 Repairing the modular multiscale hash proposal

The supplemental hashing proposal constructs a sampled carrier R(k)=sum a_j*cos(2*pi*lambda_j*k/N+theta_j), quantizes it as floor(C*R(k)), folds it modulo m and adds a small arithmetic perturbation. This is a well-defined candidate address map once all parameters and numerical conventions are fixed. It is not automatically uniform, independent across salts, hard to invert or efficient. Those conclusions require a model or benchmark beyond the compositional formula.

REFUTED E1-C1 concerns the full-cycle probe claim. A linear probe a_t=a_0+t*g modulo m visits every bucket when gcd(g,m)=1. An arbitrary added perturbation can destroy this property: adding -t*g makes every address equal a_0. Even a periodic perturbation with a period coprime to m can repeat heavily in its first m steps. With m=5,g=1,a_0=0 and period-four offsets (0,4,3,2), the first five addresses are 0,0,0,0,4. Three buckets have not been visited.

A repaired full-cycle design uses a proved permutation pi of the bucket set:

```text
a_t = pi((a_0+t*g) mod m), gcd(g,m)=1.
```

The inner sequence visits every residue once, and a permutation preserves that coverage. A multiscale field can rank or propose such a permutation during construction; duplicate proposed addresses must be resolved before the permutation is accepted. If an offset has period N and gcd(N*g,m)=1, a longer contract is also possible: holding its phase fixed while t advances by N visits all m buckets, so m*N steps suffice. That does not prove coverage in the first m probes or make a small fixed probe cap complete.

REFUTED E1-C2 concerns the specified high-frequency lattice. At N=2^16,b=2,lambda_j=2^(j^2), every j>=4 has lambda_j divisible by N. At integer k its cosine becomes cos(theta_j), constant over the whole lattice. Adding more such terms changes the offset but supplies no finer sampled oscillation. Frequencies should be reduced modulo N before assessing distinct modes. A finite cosine sum is smooth in its continuous argument; an infinite fractal regularity claim needs separate hypotheses and proof.

Quantization introduces a further reproducibility obligation. Tiny numerical errors near an integer boundary can change floor(C*R(k)) and therefore a bucket address. Persisting the final integer lookup table and its checksum makes the operational map exact after construction. Cross-platform regeneration requires specified arithmetic or certified distance from every quantization threshold. This is a useful engineering repair, not evidence that the map is cryptographically secure.

The experiment contract compares the same key sets, loads and operation histories against a baseline. It includes sequential keys, arithmetic progressions, common-prefix strings, repeated keys, deletions, tombstones and deliberately colliding encodings. It measures cold build cost, warm query cost, memory, probe distribution, stash use and complete key equality. The source prehash can already dominate dispersion; removing the new layer is therefore a necessary control. A short fingerprint never replaces the full key comparison.

## E1.6 A reusable pattern-search contract

An investigation begins by freezing the dataset revision and construct grammar. It enumerates legal windows or paths, computes the chosen representation, proposes relationships and verifies each accepted witness against the underlying samples. An index may reduce comparisons, but cannot silently remove candidates unless its exclusion is proved sound. A bounded run returns both results and unfinished scope. Its descriptive best match stays HEURISTIC as a predictor until tested under a separate prediction contract.

Exercise E1-X1 asks whether equal differences imply equal raw words. They imply translation, not literal equality; one initial aligned value is additionally sufficient. Exercise E1-X2 asks whether visiting every lag modulo M visits every pair of two absolute head phases. It does not: one constant-stride trajectory has at most M states, while the pair space has M^2 states. Exercise E1-X3 asks whether a row match and a serpentine match reading the same cells count as two independent discoveries. They are two descriptions of the same physical support. These answers give operational tests for the most common representation and provenance mistakes.

# E2. Arithmetic regularity, prime filters and discrepancy

Arithmetic often produces strong nonrandom-looking patterns for elementary reasons. Parity forbids some offsets. Residue classes synchronize divisibility. Carries synchronize digit signs. A graph can favor long surviving regions because short regions are killed sooner. These are useful structures to find and explain. Their interpretation depends on the object being counted: allowed residue classes, actual primes, sign correlations or admissible paths. The same attractive plot can represent very different mathematical claims.

Stefan's prime investigations become most useful as exact filters and organized tests of arithmetic explanations. Prime generation means producing a number with a complete primality certificate. A residue survivor is a candidate until all required divisibility checks or another complete test have been performed. A finite local density is an exact counting theorem on its declared wheel. Predicting an ordinary prime interval from that density is a separate HEURISTIC step.

## E2.1 Prime wheels and the support of an offset

For the pair n,n+h, a prime p excludes n==0 and n==-h modulo p. These classes coincide if p divides h; otherwise they are distinct. Hence the number of allowed classes is p-1 or p-2 respectively. The Chinese remainder theorem gives the exact product of these counts over a finite collection of distinct primes. Independence here is a property of the uniform distribution over the complete CRT period, not a claim about arbitrary short intervals.

Example E2-A uses M=2*3*5*7*11=2310. At h=2 the allowed count is 1*1*3*5*9=135. At h=6 it is 1*2*3*5*9=270. At h=30 it is 1*2*4*5*9=360. Offsets 2,4,8,32 and 64 have the same prime support within this wheel and the same count 135. Increasing a prime exponent already present in h changes no first-level wheel factor. An odd h has zero allowed classes at p=2. Actual odd-gap prime pairs remain possible when one endpoint is the exceptional prime 2, which the raw wheel removes.

The original primorial-center construction instead fixes W=210 and examines L(k)=210k-1,R(k)=210k+1 for k>=1. Both endpoints escape the wheel primes 2,3,5 and 7. For an external prime p>7, the forbidden k classes are +/-210^(-1) modulo p. A finite external wheel therefore has product (p-2) survivors. This searches a particular center subfamily; most twin-prime centers need not be divisible by 210.

Example E2-B has k=1, giving 209=11*19 and 211. Modulo 11,210==1, so k==1 is an immediate left obstruction. Modulo 13,210==2 and 2^(-1)==7, so forbidden parameters are 7 and 6. Every prime through floor(sqrt(211))=14 is now accounted for: 211 is prime, while its partner is composite. At k=2 the endpoints are 419 and 421; trial divisibility through 20 certifies both prime. This is a functioning sieve, not an infinite twin-prime theorem.

The split algebra F_p[e]/(e^2-1) packages the two branches. Because p is odd, evaluation at e=1 and e=-1 identifies it with F_p times F_p. The element 1+210k*e has norm 1-(210k)^2, the negative endpoint product. Its norm vanishes precisely when an endpoint is divisible by p. This is a split algebra, not a quadratic field. Multiplicative exponent coordinates can organize the nonzero k residues, but require a separate zero state and do not make integer addition into exponent addition.

## E2.2 A square shell and higher-root filters

The original resonator notes choose a known prime p and the shell D={n:p<n<=p^2}. Knowledge of every prime q<=p suffices to classify this shell exactly. PROVED E2-P1: if n is composite, write n=a*b with 1<a<=b, so a<=sqrt(n). Some prime divisor of a is at most sqrt(n)<=p. Conversely a prime n>p has no divisor q<=p. Thus survival of all those divisibility tests is exactly primality on D. The shell is a finite integer set; it has no automatically inherited finite-field structure.

The roots-of-unity projector gives an exact identity

```text
D_d(n) = (1/d)*sum_(j=0)^(d-1) exp(2*pi*i*j*n/d)
       = 1[d divides n], for integer n.
T_p(n) = product_(q prime,q<=p) (1-D_q(n)).
```

If d does not divide n, the geometric ratio z=exp(2*pi*i*n/d) is not one, while z^d=1, so the sum is (1-z^d)/(1-z)=0. This proof does not require the phases to be all distinct: when gcd(n,d)>1, some roots repeat. Integer remainder tests implement the same Boolean decision exactly without numerical cancellation.

Example E2-C uses p=11,X=121. Prime 97 passes the complete list 2,3,5,7,11. Number 77 passes the cube-root list 2,3 because X^(1/3)<5, but 77=7*11 fails the square-root layer. Number 121 fails at 11 and activates the prime-square channel. Number 64 activates the divisibility channels 2,4,8,16,32 and 64; subtracting consecutive cumulative detectors isolates its exact valuation v_2(64)=6.

PROVED E2-P2 is the higher-root roughness bound. Suppose 1<n<=X and n avoids every prime q with q^k<=X. Every prime factor of n exceeds X^(1/k). If n had at least k prime factors counted with multiplicity, their product would exceed X, a contradiction. Therefore n has at most k-1 factors. The converse fails: the semiprime 6 has only two factors but fails many cube-root filters at larger X. Higher k gives a weaker filter, because it tests fewer primes. Using the exact integer comparison q^k<=X avoids rounding at a root boundary.

The zeta-related layer has a different job. At x>=2 define the finite weighted prime-power count J(x)=sum_(e>=1) pi(x^(1/e))/e. Only e<=log_2(x) contribute. Ordinary prime counting is recovered by the finite identity pi(x)=sum_(m>=1) mu(m)*J(x^(1/m))/m. Substitution groups the coefficient of pi(x^(1/r)) as (1/r)*sum_(m divides r)mu(m); it is one at r=1 and zero otherwise. This is the exact algebra behind removing prime-power repetitions.

Example E2-D has J(16)=6+1+1/3+1/4=91/12. The six primes contribute six, the squares 4 and 9 contribute one, 8 contributes one third and 16 one quarter. The inversion subtracts J(4)/2=5/4 and J(16^(1/3))/3=1/3, yielding six. No numerical zeta zeros are needed. A finite sum of zero modes can visualize an approximate global fluctuation, but supplies no exact integer prime indicator without an independently proved remainder bound and endpoint conventions. The complete divisibility layer remains the verifier.

## E2.3 Euler's quadratic and shifted exclusions

For F(n)=n^2+n+41,

```text
4F(n)=(2n+1)^2+163,
F(-n-1)=F(n),
F(n+h)-F(n)=h*(2n+h+1).
```

Direct reduction at every prime below 41 gives no root. Consequently none of those primes divides any F(n), for all integer n. At n=0,...,39, the values lie between 41 and 1601, below 41^2. A composite there would require a prime divisor below 41, which is impossible. These forty values are therefore prime. At n=40 the value is 41^2. Reflection gives eighty input positions from -40 to 39 but only forty distinct prime values.

For odd p not dividing h, common roots of F(n) and F(n+h) modulo p^k are forced by subtraction to n==-(h+1)/2. Substituting gives 4F(n)==h^2+163. PROVED E2-P3: there is exactly one common residue if p^k divides h^2+163, and none otherwise. Division by 2h is legitimate under the hypotheses; it must not be imported when p divides h.

Example E2-E takes h=2 and p=167, since h^2+163=167. The common residue is -(3)/2==82 modulo 167. Indeed F(82)=41*167 and F(84)=43*167. At h=81, h^2+163=4*41^2, so the common-root overlap at p=41 persists through precision two but stops at three. First-level prime survival is unchanged by that extra depth; it describes the interior structure of a class already excluded for divisibility.

Let R_p be the roots of F modulo p, rho_p their number and c_p(h)=|R_p intersect (R_p-h)|. The pair filter allows p-2*rho_p+c_p(h) classes, by inclusion-exclusion. Multiplying these counts over a finite CRT wheel is exact. Peaks at selected offsets can therefore have ordinary explanations in overlapping forbidden classes. A local factor computed from only two primes can miss an advantage caused by a third prime. The factor must be interpreted as a finite filter statistic before any prime-density prediction is fitted.

The mask A(n)=1[gcd(F(n),1763)=1],1763=41*43, illustrates the difference. It has 1599 allowed phases. Many are composite-valued: F(49)=47*53 survives both filters. Treating A as a prime label would fail even at this small input. Prime-preserving sieves also retain equality cases: F(0)=41 and F(1)=43 are prime although their corresponding divisibility bits fire.

## E2.4 Precision trees can expand and terminate

Prime-power lifting refines divisibility, not primality. A product root modulo p^k means v_p(F(n))+v_p(F(n+h))>=k. It need not mean either factor individually vanishes modulo p^k. Common roots, union roots and product roots are separate sets.

Example E2-F has p=h=41,n=0. The two factors are 41 and 41*43, neither divisible by 41^2, while their product is divisible by 41^2. No field-style inference from a zero product is valid in the residue ring Z/41^2 Z.

A sharper example uses p=h=163. The only first-level root is n==81, and

```text
F(81+163t)=163*(41+163*(t+t^2)).
```

The factor in parentheses is 41 modulo 163, so its valuation is exactly one. The shifted factor has the same property. Their product has one root modulo 163,163 roots modulo 163^2, and no roots modulo 163^3. Every apparently abundant second-level branch dies. The identity proves there are no later branches. A precision ratchet requires compatible survival through later levels; a wide finite layer alone is no convergence certificate.

## E2.5 Digits, carries and exact imbalance

The binary digit sign t(n)=(-1)^(s_2(n)), where s_2 counts one bits, is the standard Thue-Morse sign sequence. Reading digits requires only a parity state; its values satisfy t(2n)=t(n),t(2n+1)=-t(n). Addition can nevertheless create a structured signal. Adding one changes a run of trailing ones and the preceding zero; the run length is v_2(n+1). Thus

```text
t(n)*t(n+1) = -(-1)^v_2(n+1).
```

Example E2-G compares n=7 and n=8. Binary 111 has three ones, so t(7)=-1; 1000 has one, so t(8)=-1. Their product is +1, matching -(-1)^3. At n=8 the increment to 9 changes one zero to one, giving product -1. A deterministic carry rule creates correlation without any randomness assumption.

In every odd base b, s_b(n)==n modulo 2 because all powers of b are odd. Consequently odd-base digit parity is simply ordinary parity. A ternary sign scan that puts every odd prime in one channel has found this identity, not a new prime law. Grouping binary digits into base four preserves the binary digit parity; changing to ternary parity defines another sequence.

For an odd prime p, the completed quadratic-character sequence strips powers of p: f(n)=epsilon^(v_p(n))*chi_p(n/p^(v_p(n))),epsilon in {-1,+1}. Here chi_p is +1 on nonzero squares and -1 on nonsquares. Full blocks of nonmultiples cancel, while multiples provide a smaller signed copy. If B(r)=sum_(a=1)^r chi_p(a), then

```text
S(pm+r)=epsilon*S(m)+B(r), 0<=r<p.
```

At p=3,epsilon=+1,B(0)=B(2)=0,B(1)=1, so S(N) equals the number of ternary digits equal to one. Example E2-H gives N=1,4,13,40,121, with sums 1,2,3,4,5. Slow growth is still unbounded. A finite-state sign generator does not imply a bounded accumulated sum.

## E2.6 Shared progression constraints and exact finite search

For a sign sequence f on positive integers define S_d(k)=sum_(j=1)^k f(dj) and D_N=max_(dk<=N)|S_d(k)|. Ordinary prefix balance concerns d=1; discrepancy concerns every homogeneous progression. The alternating sequence f(n)=(-1)^(n+1) has ordinary partial sums bounded by one, but S_2(k)=-k. Local balance can hide arbitrarily large drift on another sampling pattern.

A finite search assigns f(t+1) and updates exactly the counters whose spacing d divides t+1. Rejecting a branch when any updated counter exceeds a declared bound C is sound. Every old progression prefix was checked earlier, and every newly completed prefix is one of those updated counters. Induction proves that surviving words satisfy all original constraints. At a fixed depth the complete counter vector determines future legality in the unrestricted model. A multiplicative model must additionally enforce prime-factor choices.

Example E2-I gives the length-eleven word (+,-,-,+,-,+,+,-,-,+,+), valid at C=1. Before position twelve its spacing-one sum is +1 and needs a negative next sign; its spacing-three sum is -1 and needs a positive next sign. The shared position cannot satisfy both. Complete enumeration gives four valid words at length eleven and none at twelve, proving the finite impossibility. This is a compatibility contradiction, not a statistical rarity argument.

Complete multiplicativity is an additional condition f(ab)=f(a)f(b). Choosing prime signs determines composite signs by unique factorization, gives f(n^2)=1 and S_d(k)=f(d)S_1(k). Under independent fair prime choices, E[f(n)] is one for squares and zero otherwise; E[f(a)f(b)] is one when ab is a square. At N=20 the complete 256-assignment ensemble has final-sum mean four, second moment 42 and variance 26. Independent fair signs at integer positions instead have mean zero and variance 20. The two meanings of random signs are measurably different.

Tao's Erdos discrepancy theorem establishes unbounded discrepancy for every infinite +/-1 sequence [E-R2]. The custom digit examples and finite search above illustrate particular mechanisms; they are not a replacement proof of that general result. Exercise E2-X1 asks why zeros in a raw character sequence matter. Its values are not all +/-1, so the theorem's hypothesis fails. Exercise E2-X2 asks whether survival of a cube-root filter certifies prime. It permits semiprimes, as 77 demonstrates. Exercise E2-X3 asks whether addition is entropy. Addition changes a quantity; entropy requires a probability distribution and a specified random variable.

# E3. Useful inference with explicit evidence contracts

Pattern search suggests hypotheses; exact verification eliminates impossible states; statistics compares uncertain explanations under a declared model. These activities can cooperate, but their conclusions have different meanings. A sound exact filter preserves the solution set S inside its candidate enclosure C. A probability model assigns weights to states in C. A statistical confidence procedure controls a repeated-sampling error event. A fitted score ranks relationships in observed data. Converting one of these objects into another without an additional argument is a central source of mistakes.

Stefan's incomplete-information proposal becomes operational when the hidden state, transition, observation, dependence and evidence goal are specified together. A useful result can be a small exact candidate set, a noisy posterior with unresolved aliases, a selected probe that breaks a symmetry or an alarm process with a stated false-alarm bound. A sharply concentrated number alone does not certify that the assumptions producing it are true.

## E3.1 Hard support, likelihood and state evolution

For a finite hidden state x_t, fixed parameter theta, transition K_theta and observation likelihood L_t, an unnormalized filtering step is

```text
w_t(x,theta) = 1_C_t(x,theta)*L_t(y_t|x,theta)
               *sum_u K_theta(u,x)*w_(t-1)(u,theta).
```

Normalize by the total weight when it is positive. The equation follows by summing over the previous state and applying Bayes' rule. It assumes that the chosen state retains every variable needed for this factorization. Unknown timing, correlated errors and revisited physical sources may require extra state components or a joint likelihood.

A hard support bound excludes an impossible state. A small positive likelihood leaves it possible under the model. If every weight becomes zero, the hard assumptions and observations are inconsistent; this diagnoses the contract, not the absence of reality. A noisy report outside a state's physical range can still be possible if the sensor channel permits that report.

Example E3-A uses three candidate integers {2,5,8}, uniform prior, and a noisy modulo-three sensor. It reports the correct residue with probability 4/5 and each wrong residue with probability 1/10. All three candidates predict residue two. Observing two multiplies each weight by eight relative to a mismatch, but preserves their equal odds. Repeating the same precision with independent sensor errors strengthens evidence for the shared residue class while adding no information inside it. A new modulo-five reading predicts three distinct symbols and can change their relative weights.

If a modulo-five channel is correct with probability 4/5 and distributes its remaining probability equally among the four wrong symbols, a favorable independent reading supplies likelihood odds 16:1 against a particular incorrect candidate. Four independent reports supply 16^4=65536:1. Four copies of one source event supply 16:1. Once the first report is known, its copies have conditional probability one under either state and contribute no new likelihood ratio.

This extends to coordinate transforms. A residue, a logarithm and a Fourier representation derived from one observation are three descriptions of that observation. They can reveal useful structure to the solver but cannot be multiplied as three independent sensor events. Source lineage is part of the mathematical likelihood, not merely an archival convenience.

## E3.2 Symmetry proves when another kind of observation is needed

Let sigma be a permutation of the finite hidden-state domain. Require pointwise prior invariance pi_0(sigma(x))=pi_0(x), invariant hard support sigma(C_t)=C_t, transition equivariance K(sigma(u),sigma(x))=K(u,x), and likelihood invariance L_t(y|sigma(x))=L_t(y|x). Reindexing the predecessor sum by the permutation proves by induction that x and sigma(x) retain equal weights after every observation. A policy selecting its next action only from past invariant observations has the same action law in both cases. If every chosen action's transitions, likelihoods and hard-support updates preserve the same symmetry, induction after each action preserves the alias. More measurements of the same invariant kind cannot identify its members.

The hard-support condition is essential. Candidates two and five give identical modulo-three observations. A separately justified bound x<3 selects two and destroys their exchange symmetry. Thus an independent exact constraint can distinguish an observation alias just as a new sensor channel can. The theorem forbids identification only while every applied part of the model preserves that alias.

Example E3-B uses F_9=F_3[u]/(u^2+1). The polynomial has no root in F_3, so this quotient is a field. Write z=a+b*u. Its Frobenius conjugate is a-b*u, its trace is 2a and its norm is a^2+b^2. The elements 1+u and 1-u both have trace two and norm two. Dynamics z_t=z_0+t satisfy

```text
Tr(z+t)=Tr(z)+2t,
N(z+t)=N(z)+t*Tr(z)+t^2.
```

Every invariant time record is determined by the initial pair. A basis-sensitive observation of b breaks the ambiguity. The field F_9 is distinct from Z/9Z; the latter contains nonzero zero divisors. Integer labels attached to field elements introduce no intrinsic interval order.

The same time record can protect the information that it does contain. For t=0,1,2, interleave trace and norm to form a six-symbol ternary codeword. There are six conjugacy orbits. Different traces differ in all three trace coordinates and two norm coordinates, giving distance five. With equal trace and different norm, all three norm coordinates differ, giving distance three. Minimum distance three means one arbitrary symbol error can be corrected to the orbit. It does not resolve the two-member orbit, nor guarantee correction of two errors.

For a uniform prior on all nine field elements, perfect invariant information leaves average uncertainty 2/3 bit: six elements belong to pairs, each contributing one conditional bit, while three singletons contribute zero. Conditioning on one selected pair instead leaves exactly one bit. These are different averaging questions. Entropy is H=-sum p_x*log_2(p_x), with 0*log(0)=0 by continuity; it is not a count difference or an arithmetic operation itself.

## E3.3 Candidate partitions and active probes

For a finite hypothesis family H and exact observation map O_q at query q, the response partitions H into fibers H_j. Under a uniform prior, the probability of response j is |H_j|/|H| and the surviving count is |H_j|. Therefore the expected surviving count is sum_j |H_j|^2/|H|. Dividing expected elimination by a positive query cost is a defensible experiment objective. It is different from maximizing Shannon information, and the two need not rank queries identically.

Example E3-C uses f_d(n)=n+d*n*(n-1)/2 for d=-2,-1,0,1,2. Every rule gives zero at n=0 and one at n=1. Querying n=2 gives the distinct predictions 0,1,2,3,4. Under the uniform five-rule prior, expected survivors fall from five to one, an elimination gain of four. A rule outside this grammar can still agree at all three positions. Exact identification within H is not a proof that H contains the true rule.

A version-space algorithm fits only on designated training observations, retains candidates consistent with them, then checks additional unrevealed observations without refitting. A falsified candidate remains falsified. Missing values supply no contradiction. Duplicate syntactic formulas with identical predictions on the declared query pool should not acquire extra default weight merely because they have several descriptions.

Positive tolerance changes this partition logic. If two predictions are 10 and 11 with acceptance tolerance one, an observation of 10.5 is compatible with both. Distinct predicted means do not define disjoint response fibers. A noisy active design needs an explicit likelihood and expected posterior calculation, or a worst-case compatible-set objective. The exact partition formula cannot be borrowed unchanged.

The periodic mask A(n)=1[gcd(F(n),1763)=1] supplies a concrete finite phase problem. Ordered width-42 cyclic words leave five two-member collision fibers; width 43 distinguishes all 1763 phases. Prefix refinement means shorter words cannot distinguish a pair still colliding at width 42. Thus the minimum identifying width is 43 for this fixed known mask. Its equality with a filter prime is a property of this example, not a universal rule about identifying lengths.

A different structural reconstruction result concerns all M-periodic rational tapes, with positive integers M and w. For C_w(n)=sum_(r=0)^(w-1)x(n+r), PROVED E3-P1 gives kernel dimension gcd(M,w)-1. If C_w is zero, adjacent differences imply x(n+w)=x(n). Together with M-periodicity this forces d-periodicity for d=gcd(M,w). Each window consists of w/d copies of its d entries, whose sum must be zero. Conversely every zero-sum d-periodic tape gives zero C_w. There are d-1 free coordinates over Q. Hence C_w is invertible exactly when gcd(M,w)=1.

Example E3-D uses M=6,w=2. The nonzero tape (1,-1,1,-1,1,-1) has every window sum zero, proving information loss. At w=5 the gcd is one and the operator is invertible over Q. One count remains ambiguous; the complete count record can identify the tape. Changing the coefficient characteristic can change the rank and must be checked separately.

## E3.4 Conditioning can create a peak without a new physical mechanism

Consider a lazy walk on positions 1,...,9 with left/right probability one quarter and hold probability one half, killed on exit. Multiplying its substochastic transition matrix Q by four gives an integer matrix W counting four equally likely move labels, including two hold labels. If H_r=W^r*1 counts future surviving continuations, then conditional on survival for r further steps,

```text
P_r(i,j)=W(i,j)*H_(r-1)(j)/H_r(i).
```

Its row sum is one by the recurrence. Products along a path telescope, so it is exactly the original path law conditioned on the specified finite survival horizon.

Example E3-E begins at position one. Survival for one step leaves two hold labels and one inward label, so the conditional inward probability is one third rather than one quarter. Paths escaping left have been removed. This apparent inward preference requires no new force. Reflecting a forbidden move into a hold would define a different process.

For a component of L consecutive allowed sites, h_i=sin(i*pi/(L+1)) is a positive eigenvector of Q. The sine addition identity gives eigenvalue lambda_L=(1+cos(pi/(L+1)))/2. It grows strictly with L. Thus, from an initial mixture placing positive mass in all components, long survival eventually favors a unique longest component. A fixed starting point in another disconnected component cannot travel to it.

For completeness, the other sine modes use k*pi/(L+1),k=2,...,L, and have strictly smaller eigenvalues. Orthogonality gives a full eigenbasis because Q is symmetric. A nonnegative nonzero starting distribution has positive inner product with the positive first mode. Its surviving mass is therefore a positive constant times lambda_L^t plus lower-order modes. Comparing these exponential rates proves the component-selection statement. Conditioning on zero-probability eternal survival is not used; the construction takes the limit of specified finite survival horizons.

The 1763-phase arithmetic mask splits into 117 nearest-neighbor components; the unique longest consists of phases 862 through 900. Its center is 881, and F(881)=777083=853*911, composite. A survival peak at that location is an exact consequence of mask geometry and the added walk model. It is not prime-generation evidence. The conditional endpoint law on a long component is proportional to h_i; the stationary law of the limiting conditioned process is proportional to h_i^2. Distinguishing these laws prevents a second misinterpretation of the same plot.

Indeed its limiting transition is P*(i,j)=Q(i,j)*h_j/(lambda_L*h_i). Its row sum is one by the eigenvector equation. Since Q is symmetric, h_i^2*P*(i,j)=h_j^2*P*(j,i), proving the stated stationary law by detailed balance. This supplies the exact distinction between where long surviving paths end and how the limiting conditioned chain spends its time.

## E3.5 Overlap and multiple searches change error probabilities

Under independent Bernoulli(p) source bits with 0<p<1, sums over index sets A and B have covariance p*(1-p)*|A intersect B|. Expanding the covariance leaves only identical source indices, since distinct inputs are independent. Equal width-w windows at lag h therefore have correlation max(1-|h|/w,0). High adjacent-window correlation occurs even in independent input.

In the difference of the two window sums, shared bits cancel. At nonnegative lag h there are m=min(w,h) exclusive bits on either side, so the absolute difference is at most m. With fair bits, complementing each subtracted bit shows that difference+m has Binomial(2m,1/2) distribution. Its variance is m/2. This is a hard range and an exact distribution under the fair-input model, respectively.

Example E3-F has w=5,h=2,m=2. The difference probabilities at -2,-1,0,1,2 are 1,4,6,4,1 divided by 16. Treating the ten displayed window entries as ten independent sources would give the wrong variance: six displayed positions are duplicate readings of the three shared physical indices. Source provenance determines the distribution.

A correct local test can still give incorrect whole-search error control. Testing many widths, lags and starts and reporting the smallest p-value changes the statistic being tested. Complete finite-null enumeration can calibrate the whole scan, including its selection rule. Alternatively a union bound controls a prespecified finite family without requiring independence, though it can be conservative. A held-out block avoids refitting on the same targets, but a deterministic arithmetic interval is not automatically an independent identically distributed sample. Changing size-dependent prime density must be accounted for in its interpretation.

## E3.6 Sequential evidence with a proof of the monitoring guarantee

Let X_t be a fresh bit whose conditional probability is one half given the complete past information F_(t-1). Choose q_t between zero and one using only that past. Multiply E_(t-1) by 2q_t for X_t=1 and by 2(1-q_t) for X_t=0. The conditional average factor is q_t+(1-q_t)=1. Starting at E_0=1 gives a nonnegative martingale. Adaptive window rules are allowed to choose the next prediction; peeking at the target bit is not.

PROVED E3-P2 gives the threshold guarantee. Let tau be the first time E_t>=1/alpha and stop at tau or a finite horizon T. The stopped process has expected value at most one. On tau<=T it is at least 1/alpha, so P(tau<=T)<=alpha. Letting T increase gives P(ever cross)<=alpha. This is the discrete-time specialization of Ville's inequality; the exact source hypothesis and formula were checked in Howard et al., Lemma 1 [E-R3]. The proof requires the conditional fair-bit model, not merely a balanced final count.

A fixed weighted average of valid evidence processes remains valid by linearity of conditional expectation, even when the strategies share all observations. Selecting a strategy for the next bet from its past performance can also be valid. Taking the retrospective maximum of their final capitals is a different process and has no automatic threshold guarantee. Re-reading a known bit contributes no fresh factor.

Example E3-G mixes alternative Bernoulli probabilities one quarter and three quarters with equal weights. After t observations with k ones,

```text
E_t=(3^k+3^(t-k))/2^(t+1).
```

Under fair bits its average next value equals its present value. Threshold 20 gives an anytime false-alarm bound of 5%. Fresh exact dynamic programming gives crossing probabilities about 1.8919% by t=20 and 4.166676% by t=512. An initially plausible limit 1/24 is refuted because the exact 512-step probability already exceeds 1/24 and crossing probabilities cannot decrease with the horizon.

Repeatedly using an ordinary fixed-time two-sided binomial 5% test is different. Exact enumeration by count and prior-alarm status gives an ever-alarm probability about 10.6617% by 20 observations and 35.7797% by 512. The single fixed-time test remains valid at its specified time. The increase concerns the probability of at least one selected crossing over the timeline.

Example E3-H duplicates each of five independent fair bits. If all original bits agree, probability 1/16=6.25%, the incorrect ten-independent-bit calculation yields E=29525/1024>20. The correct five-source calculation gives E=61/16<4. This event alone violates a claimed 5% guarantee for the duplicated-data calculation. No larger simulation is needed to establish the counterexample.

## E3.7 Learned parameter ranges and an operational research loop

For a Bernoulli success probability 0<p<1, integrate one common alternative parameter q uniformly over [0,1]. The beta integral yields the likelihood-ratio process

```text
E_t(p)=1/((t+1)*binom(t,k)*p^k*(1-p)^(t-k)).
```

For each fixed true p it is a nonnegative martingale under independent Bernoulli(p) input. Retaining p only if E_s(p)<20 for every time s so far gives a nested confidence set with at least 95% simultaneous coverage. The guarantee concerns the one true parameter; computing many candidate p values does not require dividing alpha by their count. The method-of-mixtures connection and inversion semantics were checked against Howard et al. [E-R4]; the particular formula is derived here.

Example E3-I uses the 99-point grid p=r/100,r=1,...,99 and the selected record 1110 repeated. Exact rational arithmetic gives retained ranges 0.43 through 0.95 at t=16,0.58 through 0.89 at t=64 and 0.66 through 0.83 at t=256. Coverage applies when the true parameter is on the grid and the stated sampling model holds. The periodic illustrative record demonstrates calculation; it does not validate an independent-data model. A real off-grid parameter has no membership guarantee from this finite grid alone.

The reusable research loop freezes the observation identities, declares the exact target and separates exploratory score from tested prediction. It fits the finite grammar on designated training data, records the candidate enclosure, chooses an informative unrevealed observation and checks the resulting witness or likelihood. Exact rejection preserves the original domain and all surviving branches. Statistical rejection records its model and error event. A failed prediction stays in the record; it is not repaired by silently refitting on its own counterexample.

A successful report states what was reconstructed, what remained aliased, what was checked finitely and which source assumption made the probability meaningful. A resource-limited search records unvisited scope. A finite execution may falsify a universal conjecture by a valid counterexample; success over its range supports only that range unless a separate proof supplies the reduction. This lets the pattern machinery remain exploratory while its accepted claims remain inspectable.

Exercise E3-X1 asks whether a hard residue constraint and a noisy residue report use the same update. The former can delete incompatible candidates; the latter ordinarily reweights them. Exercise E3-X2 asks why repeating trace and norm does not distinguish conjugates. Their likelihoods are invariant under the same symmetry. Exercise E3-X3 asks whether threshold 20 means that a hypothesis is 95% true. It bounds a false-alarm event under a specified null process; it is not a posterior probability of truth.

## E references and verification boundary

E-R1. C.-C. M. Yeh et al., Time series joins, motifs, discords and shapelets: a unifying view that exploits the matrix profile, Data Mining and Knowledge Discovery, 2017, DOI 10.1007/s10618-017-0519-9. Author-hosted journal PDF, definitions 2-7 inspected 2026-10-13. https://www.cs.ucr.edu/~eamonn/MP_journal.pdf . The Hamming metric and exact diagonal update in this chapter are explicit adaptations with their own proofs.

E-R2. Terence Tao, The Erdos discrepancy problem, Discrete Analysis 2016:1, DOI 10.19086/da.609; arXiv:1509.05363v6, 2017-01-13. Corollary 1.2 and the distinction between raw and completed characters inspected 2026-10-13. https://arxiv.org/pdf/1509.05363v6 . The general theorem is attributed; the local finite search is independently specified here.

E-R3. Steven R. Howard, Aaditya Ramdas, Jon McAuliffe and Jasjeet Sekhon, Time-uniform Chernoff bounds via nonnegative supermartingales, Probability Surveys 17, 2020,257-317, DOI 10.1214/18-PS321; arXiv:1808.03204v8, 2025-12-17. Lemma 1, equation 2.11 and section 6.1 inspected 2026-10-13. https://arxiv.org/html/1808.03204v8 . The finite-bit construction directly verifies its nonnegative martingale hypothesis.

E-R4. The same authors, Time-uniform, nonparametric, nonasymptotic confidence sequences, Annals of Statistics 49(2),2021,1055-1080, DOI 10.1214/20-AOS1991; arXiv:1810.08240v9, 2022-08-06. Method-of-mixtures and inversion discussion inspected 2026-10-13. https://arxiv.org/pdf/1810.08240v9 . The finite Bernoulli grid is a restricted implementation, not a claim of continuum coverage.

The accompanying E_verify.py and E_results.json rerun declared finite instances using integers and rational arithmetic. They include complete small binary tapes, wrapped walks, rational window ranks, residue wheels, dying product roots, mask components, phase identification, discrepancy words, prime-sign ensembles and sequential crossing probabilities. Historical reports' larger workloads and browser benchmarks are preserved as source claims but are not silently counted as new executions. No global novelty search or universal complexity improvement is asserted.

# Observation, reconstruction, and the information that survives

## F.1. A precise question before a method

Many of Stefan's proposals begin with an object that is difficult to obtain directly, followed by easier measurements, modular projections, differences, tables, or changes of coordinates. Their common mathematical problem is reconstruction. The useful first question is which original objects remain possible after the supplied information has been used. That question gives a reliable meaning to narrowing, collision, recovery, and uniqueness without requiring a particular algebraic technique.

Let D be the original domain, O:D->Y an observation map, and y an observed value. The exact observation fiber is the set of original objects producing that observation. If a further original predicate P is imposed, the target solution set S is obtained by intersecting the fiber with that predicate:

```text
Fiber_O(y) = {x in D : O(x)=y}.
S = {x in D : O(x)=y AND P(x)}.
C = a represented candidate enclosure satisfying S subset C.
```

The enclosure C can contain false candidates. That is acceptable during search. A final verifier V checks the original requirements on an original-domain object. A proposal, a candidate enclosure, and a verified answer therefore have different roles. These definitions standardize the recurring source language of carriers, constraints, and residual states while retaining the central organizing idea: exploit convenient representations and preserve the information needed to return to the original problem.

**F-P1, exact decoder criterion; PROVED.** A function Q on the actual image O(D) can satisfy Q(O(x))=x for every x in D exactly when O is injective on D. If O(x1)=O(x2), applying Q gives x1=x2, proving necessity. If O is injective, each actual observation has one preimage, which defines Q and proves sufficiency. This establishes existence of an inverse function. It supplies no bound on the cost of computing that inverse.

A quotient formulation gives the same distinction. Define x1~x2 when O(x1)=O(x2). An observation identifies one equivalence class in D/~. If that class has several members, choosing one representative is a convention or a search decision. It does not establish that the representative was the original object. A good operational interface can report the whole class, a bounded list, or a symbolic family rather than making an unsupported choice.

## F.2. Worked example: a correct set can still have a collision

**F-E1.** Consider ordered integer pairs with x+y=10 and xy=21. Substitution produces x(10-x)=21, so x^2-10x+21=(x-3)(x-7)=0. The ordered solution set is {(3,7),(7,3)}. Both solutions pass the original sum and product tests. A sum-product observation does not distinguish their order.

If the intended objects are unordered pairs, both ordered solutions represent the same object {3,7}, and uniqueness holds in that quotient domain. If the intended objects are ordered, the independent condition x<y selects (3,7). Changing the domain and adding a measurement are different repairs. The first changes what counts as the object; the second provides distinguishing information about the original object.

The example is useful for symbol puzzles, database records, and inverse numerical experiments. Two correct answers need not indicate a computational mistake. They can indicate that the stated observation omits order, sign, orientation, or another coordinate. Before demanding one answer, a reconstruction problem must say which of those distinctions matter.

## F.3. Coordinate transformations reorganize information

Suppose T:Y->Z transforms already available observations. Equal observations remain equal after transformation:

```text
O(x1)=O(x2) => T(O(x1))=T(O(x2)).
Fiber_O(y) subset Fiber_(T o O)(T(y)).
```

**F-P2; PROVED.** Every x in the original fiber has O(x)=y. Substitution gives T(O(x))=T(y), placing x in the transformed fiber. Therefore transforming the observation cannot remove an ambiguity between states that already gave identical observations. If T is injective on O(D), the fibers are equal. Otherwise the transformation can merge previously distinguishable observations.

This fact explains both the usefulness and the limits of Fourier channels, residue coordinates, complex carriers, and hashing. A reversible transform can expose cancellation or sparse structure and make decoding cheaper. A lossy transform can give a convenient necessary condition. Neither operation supplies an unmeasured distinguishing fact. A copied record, a plot of that record, and a different coordinate expression remain representations of the same observation.

An exact round trip is an appropriate certificate for a claimed coordinate equivalence: decode(T(y))=y on the declared domain. A projection instead needs a fiber coordinate. For integers, storing x modulo M together with an integer quotient t in x=r+Mt preserves the original value. Storing r alone preserves only the residue class. The quotient may be bounded, searched, or solved elsewhere, but it cannot silently disappear from the proof.

## F.4. Anchors restore missing coordinates

For observations Ax=y over a field, assume a consistent solution x0 exists. Every solution is x0+h with h in ker(A). Subtracting two solutions proves the forward assertion; adding a kernel vector proves the converse. Extra observations Bx=b identify the state uniquely precisely when the common kernel is zero:

```text
ker(A) intersection ker(B) = {0}.
Equivalently rank([A;B]) = the number of unknown coordinates.
```

**F-P3; PROVED.** Differences between solutions belong to both kernels, so a zero intersection forces equality. A nonzero common-kernel vector creates a second solution by addition. The equivalent rank assertion follows from rank-nullity for the stacked linear map. This statement concerns a field and consistent data. A real rank test cannot establish invertibility over a composite residue ring, where nonzero coefficients can fail to be units.

An anchor is useful only if it detects a remaining ambiguity. Repeating a linear combination of existing observations adds no independent row direction. A one-dimensional ambiguity may need one suitable scalar measurement. A two-dimensional ambiguity normally needs two independent scalar constraints for unrestricted linear recovery. Uniqueness also differs from stability: a nearly singular measurement matrix can have a unique inverse that greatly amplifies small errors.

**F-E2.** Suppose a path has observed increments 3,4,5. Its possible states are

```text
(b, b+3, b+7, b+12), with b arbitrary.
```

The independently measured terminal state 20 gives b+12=20 and hence b=8. The reconstructed path is (8,11,15,20). Its differences and terminal value verify the answer directly. A complex carrier such as Z_t=(x_t-b)+i*b can store the displacement and the recovered boundary separately. Reading its real and imaginary parts reconstructs x_t. The carrier stores the anchor result; it does not discover b from increments alone.

Declaring b=0 would select a reference path. Measuring b=8 identifies a path in the original problem. This is the distinction between fixing a gauge and observing a missing constant. It prevents a convenient zero convention from becoming an accidental factual claim.

## F.5. The boundary changes the inverse

Ordinary differencing D maps (x0,...,xn) to (x1-x0,...,xn-x_(n-1)). Its kernel consists of constant arrays: adjacent equality propagates across the whole chain. The cumulative transform is a different map, and its inverse includes a boundary component:

```text
Y_t = SUM_(j=0)^t u_j.
M(Y)_0 = Y_0.
M(Y)_t = Y_t-Y_(t-1), t>=1.
```

**F-P4; PROVED.** Telescoping gives M(Y)=u and cumulative summation gives Y back from M(Y). Therefore this anchored inverse has zero kernel. In particular, M(c,c,...,c)=(c,0,...,0), which is nonzero when c is nonzero. The source speculation that every difference-like inverse erases constants is repaired by naming the actual source, target, and boundary convention.

Multiplicative cumulative products need another guard. If P_t=PRODUCT_(j=0)^t u_j in a multiplicative group, then u_t=P_t/P_(t-1), with P_(-1)=1. If zero is allowed, later factors can disappear: u0=0 makes every P_t zero regardless of the remaining factors. The additive and multiplicative constructions resemble each other, but their inverse contracts differ.

This boundary discipline is practical for logs, cumulative counters, inventory changes, and sensor streams. A stream of absolute states is different from a stream of changes. A timestamp labeled zero is different from a zero sampling interval. Subtracting adjacent height measurements over a positive interval is well defined at the initial sample even when its index is zero.

## F.6. Worked example: a modulus can remain unidentified

**F-E3.** Let the known recurrence be f(x)=13-x, and let canonical recorded states be 1,0,1,0,... . Each transition residual x_(t+1)-f(x_t) equals -12. Thus every compatible positive modulus must divide 12. Canonical representatives require m>1, leaving m in {2,3,4,6,12}. Each of those moduli produces the same recorded orbit.

The calculation identifies a candidate set. It does not identify whether the generating modulus was 6 or 12. A temporal spectrum, a finite difference stream, and a hash computed solely from these observations have identical inputs in both histories. They cannot distinguish the histories by F-P2. An additional independent measurement, a justified modulus bound, or an explicit generating-model restriction is needed.

In general, for exact recurrence residuals r1,...,rt and G=gcd(|r1|,...,|rt|)>0, the compatible positive moduli are exactly the divisors of G before other constraints. A common divisor divides G by Bezout's identity, and a divisor of G divides each residual. If the true modulus is m and r_j=m*q_j, then G=m*gcd(|q_j|). Equality G=m requires the quotient gcd to equal one. When every residual is zero, the observations give no finite divisor list at all.

The example also separates internal verification from independent validation. Checking the same recurrence modulo a proposed m verifies compatibility with the data. It does not rule out other compatible moduli. Several mathematically equivalent checks can prevent coding mistakes without becoming several independent observations.

## F.7. Exact interfaces compose; missing hypotheses remain missing

A multi-stage reconstruction can use relations rather than insisting every intermediate representation be bijective. Suppose a stage connects an original solution set S0 to a transformed solution set S1 through R01. Forward coverage requires every original solution to have at least one related transformed solution. Backward correctness requires every related transformed solution to decode only to original solutions. Store every branch needed by these two obligations.

**F-P5; PROVED.** If R01 and R12 each have coverage and backward correctness, their composite R02(x,z), defined by existence of y with R01(x,y) and R12(y,z), has both properties. Coverage follows by selecting the two guaranteed witnesses in order. Backward correctness follows by applying the second stage's implication and then the first stage's implication to the shared intermediate witness. For deterministic decoders, the same statement is the set equality decode01(decode12(S2))=S0.

Sound pruning is a weaker and useful interface. If every x in S satisfies E, then

```text
S subset C  =>  S subset {x in C:E(x)} subset C.
```

Membership proves the assertion, and induction proves it for any finite chain of certified filters. Repeating the same filter is idempotent. A heuristic can reorder candidates or propose a witness; deleting candidates on its authority would require a separate soundness theorem. Complete finite enumeration of the remaining enclosure followed by V returns exactly S. An incomplete unsuccessful search returns unresolved.

## F.7a. Category language requires commuting interfaces

Some source proposals package the same operational chain with category, functor, natural-transformation, or monad terminology. Those terms are useful when their extra structure is supplied. Naming a sequence of functions does not by itself supply that structure. A precise finite example gives a reusable interpretation without making the notation carry an unsupported theorem.

Consider a record system with sets People and Tasks and an assignment function owner:Tasks->People. A second version has People_prime, Tasks_prime, and owner_prime. An update uses maps u:People->People_prime and v:Tasks->Tasks_prime. It preserves the assignment interface exactly when

```text
u(owner(task)) = owner_prime(v(task)) for every task.
```

This is a commuting-square contract: following the old assignment and then updating the person gives the same answer as updating the task and following the new assignment. A schema can represent the sets as objects, the assignment as an arrow, and their compositions and identities explicitly. A database instance then maps that schema to sets and functions. The pair (u,v) is a natural transformation for this simple schema precisely when the displayed equality holds. The abstract terminology earns its use by making every preserved relationship an obligation.

**F-E3a.** Tasks t1,t2 belong to people p1,p2 respectively. An update renames p1 to q1 and p2 to q2, and renames tasks to t1_prime,t2_prime. If their new owners are q1,q2 in the same order, the square commutes. Swapping the new task owners violates it. Both updates are ordinary functions; only the first preserves the declared assignment interface. A diagram with four matching box labels cannot distinguish them unless its arrows and equations are retained.

A stateful computation has an equally explicit construction. Let K be the state set. A computation producing a value in X is a function f:K->X times K. A value x is injected by returning (x,s) at incoming state s. Sequencing f with g:X->(K->Y times K) means first calculate f(s)=(x,s1), then calculate g(x)(s1). Both returned value and returned state are threaded into the next stage.

The unit laws follow by substitution: injecting x and then g evaluates g(x) on the original state, while sequencing f with value injection returns exactly f's value and state. Associativity follows because either parenthesization runs the same three calculations with the same intermediate states. This standard state-monad construction explains the structure that a source's memory/controller analogy can legitimately mean. Merely storing a log does not establish these laws.

The practical benefit is a contract for composing software modules. A residue-decoding stage and its verifier must agree on modulus, precision, branch, and coefficient revision. A state update that changes one of these fields must thread the new field into every dependent stage. A numerical gradient also requires declared coordinates and an inner product when a differential is converted into a vector. Integer modulus choices require a discrete search contract rather than an ordinary tangent direction.

Such packaging can make interface mistakes easier to detect. It does not strengthen the underlying mathematical result unless the extra commuting equations, domains, and preservation conditions are proved. A well-typed false empirical premise remains a false premise. A commuting pair of programs can preserve an incorrect model perfectly. Correct composition and correct interpretation of the input evidence therefore remain separate obligations throughout the book.

## F.8. Practical exercises and answers

**F-X1.** Differences are (2,-1,4), and the final state is 13. The cumulative displacement is 5, so the initial state is 8 and the path is (8,10,9,13). Recomputing all differences checks the reconstruction. Without the final observation, all constant translations remain possible.

**F-X2.** O(x)=x^2 on the real domain. The derivative is nonzero at x=2, but O is not globally injective because O(2)=O(-2). Restricting to nonnegative reals removes the sign ambiguity. A local nondegeneracy argument should not be promoted into global uniqueness without that restriction.

**F-X3.** An enclosure contains integers 0 through 20, and the proved condition is x==1 (mod 3). The safe retained set is {1,4,7,10,13,16,19}. A ranking procedure preferring 10 can propose 10; it cannot certify that the other six values are impossible. A final exact predicate must supply that conclusion.

# Logic arrays, temporal scope, and grounded evidence

## F.9. Cases, propositions, and layout coordinates

Stefan's three-dimensional logic array becomes precise when its geometry is a view of an underlying semantic store. The store names formulas, contexts, sources, constraints, and witnesses. The layout map assigns display locations to persistent record IDs. Moving a record can improve navigation, but its truth conditions and dependencies remain attached to its identity.

For a finite classical vocabulary and hard theory Gamma, let Omega be the satisfying assignments. An ordinary substantive verdict requires Omega to be nonempty. A formula Q denotes the region [[Q]] of assignments where Q is true. Evidence selects a region E subset Omega. The query is established when E is nonempty and E subset [[Q]], excluded when E is nonempty and E intersection [[Q]] is empty, and undetermined when both truth sides survive. An empty E is model conflict. An unfinished search adds the operational status unresolved.

The source's signed z display can show Q and its complement. The witness wing stores choices and their dependencies. The provenance wing stores where claims originated. The diagnostic wing records consistency, coverage, counterexamples, and certificates. These are record roles; a geometric axis is not an additional logical operator. The semantic algebra can have many more than three independent dimensions even when the display occupies three-dimensional space.

## F.10. Atomization gives the intended orthogonality

Choose interpreted classical generators P1,...,Pt. For every Boolean signature sigma, form the region where each Pi has its specified value, retaining only nonempty regions. These are complete observable cases rather than merely individual propositions:

```text
A_sigma = INTERSECTION_i
  ([[P_i]] if sigma_i=1, otherwise Omega minus [[P_i]]).
```

**F-P6; PROVED.** Every assignment has exactly one signature, establishing coverage. Two different signatures disagree on at least one generator, so their regions are disjoint. Each generator is the union of regions whose corresponding signature bit is one. Boolean combinations are reconstructed from these unions by structural induction. Thus atomization gives a disjoint partition together with exact maps back to the original propositions.

The construction can be performed one generator at a time: replace each region A by A intersection [[Pi]] and A minus [[Pi]]. Their union is A and their intersection is empty. Children of different parents stay disjoint. Processing the same generators in another order produces the same denoted regions because intersection commutes, although their printed signatures can be reordered.

Permutation of overlapping proposition labels does not perform this operation. If two original propositions overlap, permuting their matrix rows and columns preserves the nonempty intersection. Gram-Schmidt is also a different operation: it can produce negative vector coefficients that are no longer truth regions. In a finite indicator-vector model with strictly positive weights, disjoint regions have zero inner product and conversely. The logical partition supplies that interpretation; physically perpendicular display directions do not supply the partition.

**F-E4.** Let Omega contain all four assignments to P and Q. The complete regions are 00,01,10,11. P is the union {10,11}; Q is {01,11}; they overlap at 11. The four cases are mutually exclusive even though P and Q are not. A shared proposition true on all four cases belongs in the common core, and adds no new disjoint case.

## F.11. Pairwise faces can hide the essential relation

**F-E5.** Let R=P XOR Q. The satisfying triples are 000,011,101,110. Every possible assignment to a chosen pair appears in some satisfying triple. Consequently all three pairwise compatibility tables are unrestricted. Nevertheless 111 is excluded by the full relation. Joining the three pairwise projections gives all eight triples and creates four spurious candidates.

The proof is the explicit enumeration. Each pair has four possible values and receives all four; the original relation has only four rows. A display containing every pairwise face is therefore not necessarily a complete representation of joint constraints. The backing store needs the three-way relation, an equivalent formula, or a proved lossless decomposition.

Even pairwise constraints can defeat purely local propagation. Requiring P!=Q, Q!=R, and P!=R over Boolean values is globally impossible. Every variable value nevertheless has a supporting neighbor value in each individual relation. Three pairwise distinct values cannot be drawn from a two-element domain. A propagation fixed point means the selected propagation rules have stopped finding deletions. It does not certify a satisfying global assignment.

For practical logic-puzzle grids, this is a central improvement: preserve constraint scopes as graph or hypergraph records. Local tables make deductions readable, and a complete checker handles the joint relation. Otherwise the visual system can look complete while having lost precisely the interaction that determines its answer.

## F.12. Finite CH profiles remain a conditional application

The recovered CH and choice report tracks H for the continuum hypothesis, L for V=L, and AC for choice. Its finite Boolean kernel assumes AC AND (L implies H). The three retained profiles are (AC,L,H), (AC,not L,H), and (AC,not L,not H). Their Boolean disjointness and coverage relative to that kernel are elementary. Realization by the claimed forcing histories is a separate set-theoretic input.

The chapter uses this example only as a conditional finite adapter. It neither constructs finite models of ZFC nor reproves CH independence. Choice is shared by the three profiles and therefore cannot select the H side. Evidence not L leaves both H and not H profiles. Evidence L leaves the first profile and establishes H within that current-context scope.

With the declared accessibility from the first profile to all three, from the second to the last two, and from the third only to itself, H can hold currently while BOX H fails. Evaluating BOX uses the original declared successor relation; restricting the current evidence does not delete contrary accessible contexts. This is a useful demonstration of scope even without importing the deeper forcing interpretation. The imported infinite theorems remain source dependencies, not finite-table conclusions.

## F.13. Evidence pairs keep ignorance separate from conflict

Reports about an arithmetic fact can disagree even though the fact itself has an ordinary classical truth value. Represent positive and negative support as independent Boolean bits. The four statuses are neither (0,0), positive only (1,0), negative only (0,1), and both (1,1). They are records of support, not probabilities and not permission to contradict an exact equality inside its checked arithmetic domain.

The adopted Dunn-Belnap style operations are explicitly defined:

```text
neg(p,n) = (n,p).
(p,n) AND (q,m) = (p AND q, n OR m).
(p,n) OR  (q,m) = (p OR q, n AND m).
Clean(P) = p(P) AND Boolean-NOT n(P).
```

Double negation and De Morgan identities follow coordinate by coordinate from Boolean identities. Adding support to either channel cannot remove existing support under these operations. Clean acceptance can nevertheless be withdrawn: a positive-only record becomes conflicted when a negative report arrives. Monotone evidence accumulation and a revisable acceptance policy are different processes.

**F-E6.** Let P=(1,1), Q=(0,0), and define a material conditional as neg(P) OR Q. Its value is (1,0). Both P and that conditional have positive support, while Q has none. Material-conditional modus ponens fails for this evidence algebra. A correct forward rule instead explicitly requires the Boolean preservation condition p(P) implies p(Q). Once that condition is admitted or proved, p(P)=1 licenses p(Q)=1.

The failure prevents conflict from generating arbitrary conclusions. Likewise, absence of positive support is not support for a negation. A countermodel to positive entailment needs p(Q)=0; it need not have n(Q)=1. Searching only for a positively supported strong negation can miss an unsupported neither-valued conclusion.

## F.14. A signed compilation preserves both channels

Each evidential atom P can be translated into two independent classical atoms P_plus and P_minus. Define translations tau_plus and tau_minus recursively. Strong negation swaps the translations; positive conjunction keeps AND, negative conjunction uses OR; positive disjunction uses OR, negative disjunction uses AND. Quantifiers fold over the same declared domain:

```text
All_j(p_j,n_j) = (AND_j p_j, OR_j n_j).
Some_j(p_j,n_j) = (OR_j p_j, AND_j n_j).
```

**F-P7; PROVED.** Structural induction shows that the classical truth values of the two translations equal the two support coordinates. The atomic case is the definition of the doubled interpretation. Each connective case substitutes the inductive hypotheses into its coordinate equations. Quantifier cases substitute them into the corresponding Boolean fold over the identical domain. Modal and finite-state temporal adapters require their additional frame clauses, rather than acquiring them from the propositional proof automatically.

When every atomic instance has exactly one support bit, complementarity is preserved by the same induction, and the positive channel agrees with ordinary classical interpretation. This gives a justified classical subproblem when complementarity has actually been established. It does not permit arbitrary classical simplifications in a conflicted database. Negation normal form must preserve both bits and every variable scope, time index, and modality label.

## F.15. Time, revision, causation, and alternatives have separate indexes

A temporal transition says which state can follow another. A modal accessibility relation says which alternatives are considered by a named modality. A causal mechanism specifies how variables depend under equations and interventions. A revision index records changes in available information. These roles can coincide in a particular model, but no such coincidence is assumed.

Event time and receipt revision are especially important. A later report about an earlier event changes the current evidence description of that event. It does not put that report into an earlier decision maker's information set. A finite state can also be revisited while occurrence time advances. Assigning one strictly increasing timestamp to each reusable state would incorrectly forbid ordinary loops.

A practical claim context stores domain, object identity, event interval, branch, coefficient revision, assumptions, and precision. Two records with the same printed formula can concern different contexts. A fact at precision p^(k+1) can be reduced to precision p^k through a proved bridge. A fact about one polynomial revision cannot certify a different coefficient revision merely because the solver retained the same variable name.

The source's natural-language certificate proposals supply a useful engineering checklist: lexical sense, argument types, asserted versus reported content, quantifier scope, and premise dependencies. These fields make particular equivocations detectable when the formalization captures them. They do not prove that language has been interpreted uniquely, that all manipulation is detectable, or that a chosen ontology is correct.

## F.16. Witness order is an operational dependency

**F-E7.** Two admissible contexts contain objects a and b. The first permits only a as a successful witness, and the second permits only b. Every context has some witness:

```text
FOR ALL contexts w, EXISTS x, Success(w,x).
```

No one constant witness works everywhere:

```text
NOT [EXISTS x, FOR ALL contexts w, Success(w,x)].
```

The two statements differ because the first selection can depend on the already chosen context. A case-dependent function selecting a in the first context and b in the second succeeds semantically. Executing it additionally requires enough observation to identify the context. If the available observations are identical, one observation-based decision cannot choose the two different required values.

The same distinction governs game strategies, task planning, future existence, and inverse arithmetic branches. A future witness need not exist now. A witness in one residue branch need not solve another branch. A statement that every branch has some solution does not imply that one object solves every branch. Exporting a local witness requires a persistence or compatibility theorem, not deletion of its context subscript.

## F.17. Grounded closure excludes circular corroboration

Let the finite signed atoms form a set L. A rule has a finite premise set A subset L and conclusion q in L. With admitted seed evidence E, define

```text
F_E(X) = E union X union {q : rule A->q exists AND A subset X}.
X_0 = empty; X_(j+1)=F_E(X_j).
```

**F-P8; PROVED.** The operator is monotone and inflationary. Every iterate is contained in every rule-closed superset of E, by induction. Since L is finite, the chain stabilizes after at most |L| strict growth steps. The stabilized set is closed and contains E, so it is exactly the least closed superset. Every newly admitted atom has a finite derivation rooted in seed evidence or a declared empty-body axiom.

**F-E8.** Rules P->Q and Q->P with no seeds derive neither atom. Their equations admit an all-supported assignment, but that assignment is not grounded evidence. Adding seed P produces closure {P,Q}. Rewriting the resulting Q report three times preserves the same original seed ancestry. Several renderings can be useful cross-checks without becoming several independent sources.

Provenance can retain alternative root sets. If Q has one derivation jointly using e1 and e2 and another using e3, the schematic expression e1*e2+e3 records joint versus alternative use. It supplies no probability multiplication rule. The primary provenance-semiring paper identifies this distinction in database annotations; the elementary root-set discipline here is explicitly defined and separately proved.

## F.18. Temporal reachability, inevitability, and fixed points

On a finite serial transition graph, let Goal be the goal states. Define Pre_some(Z) as states with at least one successor in Z, and Pre_all(Z) as states whose every successor lies in Z. Existential reachability EF Goal is the least fixed point of Goal union Pre_some(Z). Universal eventuality AF Goal is the least fixed point of Goal union Pre_all(Z).

**F-P9; PROVED.** Starting from the empty set, EF iteration adds goals and then states reaching a previously added state. Induction identifies finite-path reachability. For AF, induction identifies states whose every continuation reaches the goal within a uniform finite bound. In a finite graph, if every path eventually reaches the goal but no such bound exists, arbitrarily long avoiding prefixes contain an avoiding cycle, creating an infinite counterexample. Therefore the finite iteration characterizes AF as well. Each increasing chain has at most the number of states strict additions.

**F-E9.** A state s has a self-loop and an edge to an absorbing goal g. EF Goal includes both states. AF Goal includes only g because the self-loop permits indefinite postponement. The goal remains reachable at every reachable state, so AG EF Goal holds at s while AF Goal fails. Continuing possibility does not establish inevitability.

For safety set H, AG H is the greatest fixed point of H intersection Pre_all(Z). Starting from all states deletes those violating H or reaching a deleted state. Inductive invariance gives a compact certificate: initial states lie in I, I subset H, and every successor of I remains in I. A safe loop can satisfy safety while failing progress. Fairness restrictions, terminal self-loops, and finite-trace next operators change the model and need explicit conventions.

## F.19. Causal cycles do not certify their own existence

Boolean equations x=y and y=x have solutions 00 and 11. They permit a populated cycle without forcing it. The update F(x,y)=(y,x) has those fixed points, yet iteration from 01 oscillates through 10 forever. Existence of a fixed point, convergence of a dynamical procedure, and grounded inference are different questions. The recovered Terminator report is usable as finite dependency examples under this distinction; it is not a physical time-travel theorem.

For a declared mechanism Y=(A AND G) OR O, disabling route A leaves Y=O. Eliminating the named route prevents Y only when the residual alternatives O are also excluded. The local inference from A implies Y and not A to not Y is invalid: A=0,Y=1 is a counterexample. An intervention replaces the selected equation; an observation constrains the existing equations. These are separate operations even if the same variable value is printed.

## F.20. Exercises and answers

**F-X4.** A logic array stores only pairwise tables for R=P XOR Q. The tables admit 111, but the original relation rejects it. The repair is to retain the three-argument factor or an equivalent exact formula.

**F-X5.** Evidence P=(1,0) later receives negative support. Its new status is (1,1). Positive support remains; clean acceptance fails. Removing a clean certificate therefore need not assert that P is false.

**F-X6.** A three-state serial graph has s->t, t->t and t->g, g->g. Goal={g}. EF includes all states. AF includes only g because s can reach t and remain there forever. A progress or fairness premise would be needed to establish universal completion.

# Tables, circuits, and finite computational machines

## F.21. Exact indexing turns quantities into usable coordinates

An array address is a coordinate map with an explicit inverse. For r rows and c columns, row-major indexing is i=c*a+b, with 0<=a<r and 0<=b<c. Division with remainder gives a=floor(i/c) and b=i modulo c for 0<=i<rc. These formulas prove a bijection; neither primality nor coprimality of r and c is needed.

**F-E10.** Forty objects fit exactly in five rows of eight. Object index 29 has row 3 and column 5 because 29=8*3+5. The last index 39 has coordinates (4,7). Every pair in {0,...,4} times {0,...,7} decodes to exactly one index from 0 through 39. Transposing the array uses new index i'=5*b+a and preserves the object through the two coordinate maps.

This array factorization differs from Chinese remainder coordinates. Recording i modulo r and i modulo c identifies i modulo rc only when gcd(r,c)=1. In a 4 by 8 layout, row-column division still indexes all 32 objects, but the residue pair (i mod 4,i mod 8) repeats every eight. Memory layout and independent CRT channels are related uses of arithmetic with different inverse hypotheses.

## F.22. The recovered six-operation nibble block

The source logic block stores NOT, AND, OR, XOR, XNOR, and scalar-control IF on four-bit nibbles. Its data region has 96 rows and 32 columns. With operation index op in 0 through 5, inputs a,b in 0 through 15, and control bit cbit in {0,1}, its exact addressing is

```text
row = 16*op+a; column = b+16*cbit.
full_block_address = 34*row+column.
```

Two check columns and two check rows enlarge the block to 98 by 34. There are 3,332 nibbles, occupying 3,332 bytes if stored one per byte or 1,666 bytes under exact nibble packing. The data region contains 3,072 entries. The duplicated control halves for the first five operations are deliberate redundancy; IF selects a when cbit=1 and b when cbit=0.

**F-E11.** XOR has op=3. With a=10 and b=6, row=58 and column=6, giving address 1,978 and output 12. In binary, 1010 XOR 0110=1100. IF has op=5; with the same inputs and cbit=1, row=90 and column=22, giving address 3,082 and output 10. These are exact table semantics, independent of the machine used to store the array.

The source later lets IF accept a nibble mask while retaining the original one-bit-control table. That is a type change. A mask selector is instead (mask AND a) OR ((NOT mask) AND b), with complement restricted to four bits. It can be composed from the existing operations, but it is not one call to the scalar IF table.

Per-bit arithmetic belongs to F_2: NOT x=1+x, AND(x,y)=xy, OR(x,y)=x+y+xy, and XOR(x,y)=x+y. The source's row and column sums modulo 16 belong to Z/16 Z. These two rings play different roles. Packing four bits into a nibble does not turn bitwise XOR into ordinary addition modulo 16.

## F.23. Trusted syndromes correct one fault, not every fault

The block stores each row's and column's nibble XOR and sum modulo 16. Under the precise assumption that one data cell changes from u to v while all stored check values remain correct, both its row and column have nonzero XOR discrepancy u XOR v. Their intersection identifies the changed cell. Its original value is recovered by XORing the corrupted cell with that discrepancy. The sum discrepancy provides an additional consistency check.

**F-P10; PROVED.** Every unchanged row has its original XOR. The changed row's recomputed XOR differs by u XOR v, which is nonzero because u!=v. The same holds for the changed column. Removing the discrepancy reverses the change. This is exact correction under the single-data-cell and trusted-check assumptions. It is not a theorem about arbitrary corruption of the checks themselves.

**F-E12.** In the AND table, rows 16 and 17, columns 0 and 16, contain four zeros. Change all four cells to 8. Each affected row and column receives two XOR changes of 8, which cancel. Its sum increases by 16, which vanishes modulo 16. Every stored row, column, and corner check remains satisfied even though four table outputs are wrong.

This counterexample refutes universal integrity claims based on these syndromes. The correct guarantee is a specified fault model. It also shows why describing the two checks as independent equations must not imply statistical independence or full error correction. Their combination is useful redundancy; correlated structured errors can lie in their common undetected set.

## F.24. NAND builds the arithmetic, with explicit carries

Define NAND(a,b)=1-ab for Boolean inputs. Then NOT a=NAND(a,a), AND(a,b)=NOT NAND(a,b), and OR(a,b)=NAND(NOT a,NOT b). A finite Boolean function can be expressed as a disjunction of conjunctions describing its satisfying rows. These three identities therefore give a NAND implementation of every finite Boolean function, with a circuit size that may be large.

A concrete nine-NAND full adder supplies sum and carry for bits a,b,c:

```text
t=NAND(a,b); u=NAND(a,t); v=NAND(b,t); p=NAND(u,v).
q=NAND(p,c); r=NAND(p,q); s=NAND(c,q).
sum_bit=NAND(r,s); carry_bit=NAND(t,q).
```

**F-P11; PROVED.** The first four gates compute p=a XOR b; checking the four input pairs or substituting the definitions establishes that identity. The next four gates apply the same construction to p,c and produce p XOR c. The last gate produces (a AND b) OR (p AND c) by De Morgan's law. Exactly one of these carry routes applies when the integer sum needs a carry. Hence a+b+c=sum_bit+2*carry_bit on all eight input triples.

**F-E13.** Four-bit inputs 13=1101 and 7=0111 add from low to high. The bit triples with incoming carry are (1,1,0), (0,1,1), (1,1,1), (1,0,1). Their output sum bits are 0,0,1,0, with final carry 1. Reading high to low gives 10100=20. Four sum bits alone give 0100=4, the answer modulo 16. Exact addition and fixed-width modular addition therefore need different output contracts.

A ripple chain obeys the invariant that processed input bits plus initial carry equal processed output bits plus the outgoing carry at the next power of two. Summing a+b+c=sum_bit+2*carry_bit with weights 2^i telescopes the carries and proves the word result. The naive construction uses at most nine NAND gates per bit with available fan-out. This is a constructive bound, not a minimum or a universal twelve-gate arithmetic theorem.

Lane-wise nibble gates act independently at each bit position. Their composition alone cannot make a higher output bit depend on a lower input bit. Arithmetic therefore also needs declared extraction, shifts, routing, or carry connections. Calling the block a universal Boolean basis is justified once those interconnections are supplied. It is too strong for a fixed lane-isolated array without them.

## F.25. Squaring is self-convolution followed by carry normalization

For an unsigned W-bit integer x=SUM_i x_i*2^i, expansion gives

```text
x^2 = SUM_i x_i*2^(2i)
    + SUM_(i<j) (x_i AND x_j)*2^(i+j+1).
```

**F-P12; PROVED.** Multiplying the two bit expansions gives diagonal terms x_i^2*2^(2i) and two equal cross terms for each pair i<j. Since a Boolean bit satisfies x_i^2=x_i, the displayed expression follows. Equal-weight terms must then be added with carries. They cannot be combined by XOR alone.

**F-E14.** For x=3, active bits 0 and 1 produce diagonal weights 1 and 4 and a cross weight 4. The two fours carry to 8, giving 9. For x=5, the active bits 0 and 2 produce 1,16,8, giving 25. Thus merely doubling active bit indexes squares powers of two but fails on general integers unless the cross terms and carries are retained.

Unsigned squaring maps 0 through 2^W-1 into values below 2^(2W). It is injective on this nonnegative integer domain because x<y implies y^2-x^2=(y-x)(y+x)>0. It is not a surjection onto every 2W-bit value. A root request can therefore return one exact root or none. Signed integers add the sign ambiguity, and modular squaring can have several roots.

A complete finite root procedure can intersect the original W-bit domain with x^2==N modulo 2^k for k=1 through 2W, retaining every branch. If 0<=N<2^(2W), the final congruence is equivalent to exact equality because both values lie in that interval. The intermediate filters are necessary conditions. Singular low-bit behavior can retain several branches, so a guessed partial root should not be called uniquely forced.

## F.26. Triangle circuits need a width contract

The source builds a right-triangle verifier by squaring a,b,c, adding the first two squares, and comparing to c^2. Each individual W-bit square fits in 2W bits. Their sum can require 2W+1 bits. Exact computation of that sum must retain the extra bit or establish the guard a^2+b^2<2^(2W). A bare modular equality circuit without further guards can accept false integer equalities: with W=3, 4^2+7^2=65 becomes 1 modulo 64 and falsely matches 1^2.

An independently checked largest-side condition gives another valid equality-verification repair. If c>=a,b and all three inputs are W-bit, then -2^(2W)<a^2+b^2-c^2<2^(2W), because the positive difference is at most c^2 and the negative difference is at least -c^2. A difference divisible by 2^(2W) must therefore be zero. This certifies the comparison under that additional guard, even though its internal wrapped sum is not the exact integer sum.

**F-E15.** The (3,4,5) trace gives 9+16=25, so an exact root of the sum is 5. The missing-leg trace gives 25-9=16 and root 4. With positive sorted sides x<=y<=z, triangle existence reduces to x+y>z. The sign of x^2+y^2-z^2 then classifies the largest angle as acute, right, or obtuse. For (4,5,6), the difference is 41-36=5, so the triangle is acute. For (2,3,4), it is 13-16=-3, so the triangle is obtuse.

This classifier handles exact integer side data without angle encoding. A general angle-based law of cosines needs a declared real, rational, or fixed-point cosine representation and an error contract. Replacing cos(C) by floor(S*cos(C))/S creates an approximation, with absolute cosine error below 1/S and corresponding squared-side error below 2ab/S. The resulting integer equality is not automatically the original exact geometric equality.

## F.27. Table lookup exchanges computation for storage

A finite function on k input bits with l output bits can be represented by 2^k rows of l bits. Lookup is one abstract table read when addressing is already available. Constructing, storing, transferring, and checking the table remain costs. The same function may have a much smaller circuit or formula.

**F-E16.** Four-bit addition has 256 ordered input pairs and five exact output bits, so its packed answer table uses 1,280 bits, or 160 bytes. Eight-bit addition has 65,536 pairs and nine output bits, requiring 73,728 bytes. The recovered primitive nibble table is larger than the first example because it stores several operations and integrity channels, but it can be reused as a basis for wider circuits.

A single indexed read is not a hardware constant-latency theorem. Real memory systems can depend on cache state, address, alignment, and contention. An instruction-count statement is useful, but timing and performance need a specified implementation and measurements. Likewise, tabulating a finite encoding of a calculator operation does not establish exact handling of arbitrary real inputs, unbounded integers, or every transcendental output.

## F.28. Mechanical and wave implementations share the logical contract

The recovered mechanical simulator tokenizes a finite propositional expression, parses it into an explicit node tape, normalizes its negations, emits gate instructions, and enumerates assignments. Its truth cams are finite Boolean tables. Induction over emitted gate instructions proves that each computed stack value matches its source subformula when the parser and compilation preserve the syntax tree. Complete enumeration of n variables uses 2^n assignments; a satisfying row certifies existence, and evaluating every row certifies the finite classification.

The simulator's token named IF means material implication, with truth table (1,1,0,1) on inputs 00,01,10,11. The nibble block's IF instead means selection with a separate control bit. This volume standardizes material implication as IMP and keeps IF(cbit,a,b) for selection. The archived names remain visible in source records, but their operations are not equated.

An argument check searches premises AND NOT conclusion. No satisfying row establishes classical validity relative to complete enumeration. A separate satisfiability check of the premises distinguishes substantive validity from vacuous validity under inconsistent premises. The simulator's finite capacities, simulated ticks, and gate tables describe an executable model. They do not demonstrate a constructed mechanical apparatus or measured physical speed.

The electronic source encodes bit b as signed phase state s=2b-1. Ideal compensated transport H(L)=exp(-alpha*L)*exp(-i*k*L), with inverse launch compensation, makes the received contribution equal to the intended weight. For an n-input AND detector use z=SUM s_j-(n-1); for OR use z=SUM s_j+(n-1); for NOT use z=-s. Thresholding z>0 gives the exact Boolean gate. All ideal cases are at least one unit from zero.

**F-P13; PROVED.** AND gives z=1 only when all s_j=1; one false input lowers it to -1 or less. OR gives z=-1 only when all inputs are false; one true input raises it to 1 or more. NOT reverses the sign. Thus an additive detector error of magnitude strictly below one preserves every ideal result. This is a bounded-error theorem in the stated mathematical model.

Independent channel averaging reduces variance only for the independent noise component. Common bias and detector noise can leave a nonvanishing floor. Gaussian noise is unbounded, so finite redundancy cannot provide an absolute success guarantee from that model alone. Equalizing a nonzero weak transfer factor can demand a large launch amplitude, and power limits belong in any physical design contract.

The source accepts an attempted physical gate only when its output matches an independently computed logical oracle. Consequently every accepted simulated output is correct by the acceptance definition. The acceptance rate, rejected attempts, and channel cost are meaningful simulation results. They are not independent proof that an unassisted physical device produces correct answers. A physical implementation would need a realizable reference checker, calibrated transfer measurements, and measured error bounds. The logical compiler and the noise experiment should keep those different purposes explicit.

## F.29. Programs as clocks and Hanoi as a verified state graph

A deterministic bounded program can be described by state s_(t+1)=F(s_t) and output O(s_t). If its admissible state set has K elements, some state repeats among K+1 successive states. Determinism makes the subsequent orbit periodic. The state must include every relevant register, memory location, and control position. External inputs require F(s_t,u_t), and unbounded storage invalidates the finite bound.

The clock description standardizes indexed execution. It does not make F easy to invert or identify F from a short output trace. Outputs can merge distinct internal states, returning exactly to the observation-fiber issue. A memory leak can reveal additional coordinates, but its value depends on what it actually observes.

For ordinary three-peg Hanoi, a state assigns each of n ordered disks to one of three pegs; each peg's stack order is fixed by size. All 3^n assignments are legal configurations. A legal edge moves only the smallest present disk on its peg to an empty peg or onto a larger disk. The source mentions Hanoi as a planning application; the following complete example is an editorial standard construction rather than a recovered proprietary algorithm.

**F-P14; PROVED.** Transferring a full tower has minimum length H(n)=2^n-1. The recursive construction transfers n-1 disks aside, moves the largest, and transfers the smaller tower onto it. Hence H(n)<=2H(n-1)+1. For a shortest unrestricted transfer, consider the first and last moves of the largest disk. Before its first move, all smaller disks must form a tower on the third peg, costing at least H(n-1). After its last move onto the destination, all smaller disks must form a tower on the remaining peg and then be transferred to the destination, again costing at least H(n-1). There is at least one largest-disk move. Thus H(n)>=2H(n-1)+1. With H(0)=0, induction gives the formula.

**F-E17.** Three disks move from peg 0 to peg 2 through state vectors, listed smallest disk first:

```text
000 -> 200 -> 210 -> 110 -> 112 -> 012 -> 022 -> 222.
```

Each edge changes one disk and satisfies the top-disk rule. There are seven moves and eight visited states. The entire configuration graph has 27 states. Therefore this shortest transfer is not a Hamiltonian traversal of all configurations. State-graph coverage and optimal point-to-point planning ask different questions.

Caching five levels can reuse a 31-move subroutine for a specified peg transfer. It reduces repeated planning overhead, but cannot reduce the unavoidable number of executed moves. A lookahead policy needs a cost-to-go or graph proof before it can claim shortest paths from arbitrary partial states. Breadth-first search on a bounded state graph supplies an exact oracle for small cases and can expose where a proposed policy fails.

## F.30. Exercises and answers

**F-X7.** Index 23 in a four-by-eight array has row 2, column 7. Its residue pair modulo 4 and 8 is (3,7), also obtained by indices 7 and 15. Division coordinates identify the cell; those noncoprime residue coordinates do not identify the object.

**F-X8.** The scalar-control IF block cannot directly perform a different selection in each bit lane. Compose the mask selector from two AND operations, a restricted NOT, and OR, or create a larger mask-indexed table with its own addressing contract.

**F-X9.** Exact W-bit addition needs W+1 output bits. Exact multiplication needs 2W bits. A sum of two W-bit squares can need 2W+1. These bounds follow from the maximum unsigned inputs, and determine whether a circuit verifies an integer equality or only a modular one.

**F-X10.** A five-disk full transfer requires 31 moves. Reusing a cached optimal sequence can save sequence-generation work, but a machine executing the puzzle still performs 31 legal moves. This is the same distinction between a compact mathematical description and the work required to realize its output.

# Discrete geometry: coordinates, meshes and measurable curvature

## G1. Geometry becomes operational when its objects are realizable

A triangular or simplicial picture becomes a mathematical model after its vertices, edges, metric, and incidence rules have been specified. A simplex is the convex hull of d+1 affinely independent points in d-dimensional Euclidean space. Affine independence is essential: three collinear points do not define a nondegenerate triangle, and four coplanar points do not define a nondegenerate tetrahedron. An appealing list of pairwise distances must first pass a realization test.

Let the vertices be q_0,...,q_d and put B=[q_1-q_0,...,q_d-q_0]. When det(B) != 0, every point x has unique affine coordinates

```text
z = B^(-1)(x-q_0);
lambda_i = z_i, i=1,...,d;
lambda_0 = 1-sum_(i=1)^d z_i;
x = sum_(i=0)^d lambda_i*q_i;
sum_i lambda_i = 1.
```

PROVED G-P1. These formulas are inverse coordinate maps. Substituting z into q_0+Bz gives x. If two sets of coefficients with sum one represent the same x, subtracting the representations gives B(z-z')=0. Invertibility implies z=z' and then lambda_0=lambda'_0. Membership in the simplex additionally requires lambda_i >= 0 for every i, because those are exactly the convex-combination conditions.

For a triangle with vertices (0,0),(2,0),(0,3), B is diagonal with entries 2 and 3. The point (1/2,1) has z=(1/4,1/3), so its coordinates are (5/12,1/4,1/3). All are positive. The point (2,3) instead has coordinates (-1,1,1) and lies outside the triangle. The coordinate transformation still exists outside the simplex; the sign test determines which geometric region is being described.

An affine interpolant with vertex values f_0,...,f_d is f_h(x)=sum lambda_i(x)f_i. It reproduces every affine function because it reproduces constants and coordinates. Its gradient satisfies

```text
B^T * grad(f_h) = (f_1-f_0,...,f_d-f_0)^T;
grad(f_h) = B^(-T)*(f_1-f_0,...,f_d-f_0)^T.
```

For the preceding triangle, values (1,5,7) give f_h(x,y)=1+2x+2y. At (1/2,1) the value is 4, either by direct evaluation or the barycentric weighted sum. The triangle area is |det(B)|/2=3. The average affine value is (1+5+7)/3=13/3, so its integral is 13. This exactness is a property of affine functions; a nonlinear field requires an approximation-error contract.

## G2. Distances must satisfy a positive-definite Gram test

If only edge lengths l_ij are supplied, the candidate Gram matrix is

```text
G_ij = (l_0i^2+l_0j^2-l_ij^2)/2, i,j=1,...,d.
```

PROVED G-P2. A nondegenerate Euclidean simplex with those lengths exists exactly when G is positive definite. If vertices exist, G=B^T B by the polarization identity, so v^T Gv=||Bv||^2>0 for nonzero v. Conversely, a positive-definite G has a factorization G=B^T B. Taking the columns of B as vertex differences realizes the supplied lengths. A positive-semidefinite matrix can describe a degenerate lower-dimensional configuration and must not be presented as a nondegenerate d-simplex.

REFUTED G-R1. Face triangle inequalities alone suffice for a tetrahedron. Consider three edges from q_0 of length 1 and the three edges between the remaining vertices of length 19/10. Every face satisfies strict triangle inequalities. The Gram matrix has diagonal 1 and off-diagonal -161/200. Along the vector (1,1,1), its eigenvalue is 1-322/200=-61/100. A squared Euclidean length cannot be negative. The tetrahedron therefore does not exist despite its individually plausible faces.

Uniform scaling by s>0 sends B to sB, G to s^2G, and d-dimensional volume to s^d times its former value. Angles and barycentric coordinates remain unchanged. A triangular area scales by s^2; a tetrahedral volume scales by s^3. This dimensional bookkeeping is useful for mesh comparison. It does not establish a preferred scaling ratio or a physical law for a galaxy merely because one ratio is visually attractive.

The earlier simplex proposals include discrete scale invariance. Its valid elementary consequence can be stated directly: if a dimensionless function h(r) obeys h(lambda*r)=h(r) for lambda>1, then H(t)=h(exp(t)) is periodic with period ln(lambda). Indeed H(t+ln(lambda))=h(lambda*exp(t))=h(exp(t)). This consequence is conditional on the scale-invariance premise. The premise's emergence from a dynamical model, and the model's agreement with observations, require additional mathematics and data.

## G3. Discrete differentiation is an incidence operation

An oriented edge ij has a start vertex i and end vertex j. A vertex function f induces the edge difference (d0 f)(ij)=f(j)-f(i). An oriented face ijk has boundary edges ij,jk,ki. For an antisymmetric edge quantity w, define (d1 w)(ijk)=w(ij)+w(jk)+w(ki).

PROVED G-P3. Applying these operations successively gives zero:

```text
(d1*d0 f)(ijk)
 = [f(j)-f(i)]+[f(k)-f(j)]+[f(i)-f(k)]
 = 0.
```

The cancellation is exact and independent of edge lengths. The more general identity is that the boundary of a boundary vanishes, and coboundary matrices consequently satisfy d_(k+1)*d_k=0. This is a structural statement about incidence and orientation. A metric enters later when differences are assigned physical norms or converted into an adjoint operator.

For vertex values 2,5,11 on an oriented triangle, the edge differences are 3,6,-9. Their face sum is zero. For an independently supplied edge field (3,6,-8), the face sum is 1. That value detects inconsistency with a pure vertex potential on this face. It does not by itself locate the responsible edge; multiple fault assignments can yield the same sum.

The discrete Stokes identity states that summing a coboundary over a collection of oriented faces equals summing the original edge field over its boundary. Internal edges occur twice with opposite signs and cancel. A pair of adjacent triangles can therefore be checked either through its two face sums or through its outside loop. These are two calculations of the same incidence identity, not two independent measurements of the field.

For the triangle orientation 01,12,20, the matrices are

```text
d0 = [-1  1  0;
       0 -1  1;
       1  0 -1];
d1 = [1 1 1];
d1*d0 = [0 0 0].
```

This example supplies a compact exact implementation check. Changing an edge orientation requires changing its matrix signs consistently. Merely reversing a drawn arrow while retaining the old incidence row changes the model.

## G4. The metric supplies energy and diffusion

Choose positive-definite cochain metric matrices H_k. The weighted inner product is <u,v>_(H_k)=u^T H_k v. The adjoint of d_k is H_k^(-1)d_k^T H_(k+1). The corresponding Laplacian in degree k is

```text
L_k = d_k_adjoint*d_k + d_(k-1)*d_(k-1)_adjoint.
```

PROVED G-P4. Its energy is nonnegative:

```text
<w,L_k w>_(H_k)
 = ||d_k w||_(H_(k+1))^2
   + ||d_(k-1)_adjoint w||_(H_(k-1))^2 >= 0.
```

The formula follows by moving each differential across the inner product using its adjoint definition. A different signed or indefinite metric does not inherit this positive-energy conclusion. Declaring a matrix a Hodge star does not establish positivity or geometric admissibility.

With the identity metric on the preceding triangle, the vertex Laplacian is d0^T d0, with diagonal entries 2 and off-diagonal entries -1. The constant vector has eigenvalue zero. Every vector whose coordinates sum to zero has eigenvalue 3. Under df/dt=-L_0 f, the mean stays fixed and the deviations decay as exp(-3t). Starting from (2,5,11), the mean is 6 and

```text
f(t) = (6,6,6)+exp(-3t)*(-4,-1,5).
```

This is an exactly soluble finite diffusion model. Its monotone energy and conserved mean follow from the stated operator. They are not claims about every numerical time integrator: an explicit Euler step f'=f-hL_0f has deviation multiplier 1-3h. For energy nonincrease in this example, |1-3h|<=1, giving 0<=h<=2/3. A larger step can destabilize an otherwise dissipative continuous equation.

Cotangent weights on a Euclidean triangular mesh arise from integrating squared gradients of affine basis functions. Individual weights can be negative around obtuse triangles, while the assembled stiffness remains positive semidefinite as an integral of nonnegative energy. A Markov-chain interpretation needs stronger sign conditions than an energy interpretation. The familiar phrase graph Laplacian must therefore be accompanied by its actual coefficients and metric.

The relevant established framework is discrete exterior calculus; the primary Desbrun-Hirani-Leok-Marsden paper describes the simplicial and dual-complex setting. This chapter derives its limited incidence and weighted-energy identities directly. It imports no general continuum convergence or physical-gravity theorem from that attribution. [G-S1]

## G5. Angle deficits supply integrated curvature

For a piecewise-Euclidean triangulated two-manifold, let Theta(v) be the sum of incident face angles. At an interior vertex define k(v)=2*pi-Theta(v). At a boundary vertex define k_b(v)=pi-Theta(v). These quantities are integrated curvature or boundary turning angles. A pointwise density requires division by a specified area, and different area conventions can give different densities.

PROVED G-P5. For a finite triangulated two-manifold,

```text
sum_interior k(v)+sum_boundary k_b(v)
 = 2*pi*(V-E+F).
```

Every face contributes pi to the total angle sum. The left side is consequently 2*pi*V_int+pi*V_b-pi*F. For a manifold triangulation, 3F=2E_int+E_b and E_b=V_b. Substituting gives 2*pi*(V-E+F). The manifold and boundary assumptions are part of the proof; arbitrary glued complexes do not automatically satisfy the counting identities.

For a regular tetrahedral surface, three equilateral face angles meet at each vertex. Theta=pi and each deficit is pi. Four vertices give total curvature 4*pi. The combinatorial counts V=4,E=6,F=4 give Euler characteristic 2, so the right side is also 4*pi. A square disk divided into two triangles has V=4,E=5,F=2 and Euler characteristic 1. Its four boundary corner turns are pi/2, summing to 2*pi. A boundary contribution is necessary for that example.

Transport around a vertex can be defined by unfolding its Euclidean faces. With a fixed orientation convention, the frame mismatch is rotation by its deficit modulo 2*pi. Arbitrarily assigning independent edge rotations need not reproduce this metric transport. Moreover, exp(i*k)=1 means only that k is a multiple of 2*pi; it does not identify which multiple without an admissible range. A phase representation retains an angle class, not an unrestricted real angle.

The project curvature ratchet uses a_j=pi/2^(j+3) and repeatedly subtracts the largest permitted multiple of a_j from a positive target angle Theta*. After level N, the accumulated angle is

```text
Theta_N = a_N*floor(Theta*/a_N);
0 <= Theta*-Theta_N < a_N.
```

This is a valid dyadic approximation. For Theta*=5*pi/3, the initial counts are 13,0,1,0,1,0. At N=4 and N=5 the remainder is pi/384, with error bounds pi/128 and pi/256 respectively. Equal successive approximants do not mean the bound failed; a zero digit still increases declared precision.

The arithmetic approximation must be separated from mesh realization. Congruent right-isosceles faces offer angles pi/4 and pi/2. Gluing them cannot automatically realize every dyadic angle such as pi/8. Subdivision or a changed face palette can supply new wedges, but then shared edge lengths, vertex links, and global topology need fresh checks. A numerical angle list is a proposal for a geometry until those conditions pass.

## G6. Useful extension contracts and exercises

A mesh adapter should expose its oriented incidence matrices, its valid geometric realization, and its positive metric before reporting energy or diffusion. A curvature adapter should declare dimension and hinge type: vertices in a triangular surface, edges in a tetrahedral three-dimensional mesh, and triangles in a four-dimensional simplicial mesh play different roles. A scale-model adapter should distinguish an imposed scaling law from one derived from dynamics or measured in data.

Exercise G-E1. On the triangle (0,0),(2,0),(0,3), find coordinates of (1,1). Answer: (1/6,1/2,1/3). Its location is inside because all three coefficients are nonnegative.

Exercise G-E2. Decide whether a four-point distance set with all six lengths 1 is a valid tetrahedron. Answer: its Gram matrix has diagonal 1 and off-diagonal 1/2, with eigenvalues 2,1/2,1/2; it is positive definite and realizable.

Exercise G-E3. For the identity-metric triangle diffusion, compare Euler steps h=1/2 and h=1. Answer: their deviation multipliers are -1/2 and -2; the first decreases squared deviation by a factor 1/4, the second increases it by a factor 4.

Exercise G-E4. An oriented triangular sphere has V vertices and every vertex deficit zero. Can it satisfy the preceding assumptions? Answer: no. Its Euler characteristic is 2, so total deficit must be 4*pi. A claimed flat closed spherical mesh has violated some metric, topological, or deficit condition.

These examples show a useful version of the original geometric ambition. Coordinates, incidence, metric, energy, and topology can be compiled into separate checkable interfaces. Their relations are exact when their hypotheses are stated. The interfaces also identify where an attractive physical speculation still needs a model, an existence argument, or observational evidence.

G-S1. Mathieu Desbrun, Anil N. Hirani, Melvin Leok, Jerrold E. Marsden, Discrete Exterior Calculus, arXiv:math/0508341v2 (2005), https://arxiv.org/abs/math/0508341v2. Attribution to the established framework; chapter proofs are self-contained.

# Integrated practice: turning a representation into a useful solver

## Z1. A common interface that does not erase mathematical differences

The common framework can be specified with an original domain D, a solution predicate V, and the true solution set S={x in D:V(x)}. A candidate state represents an enclosure C with S subset C. A worker may propose an additional condition E, a smaller state C', or a reconstructed witness x. The acceptance rules depend on what is being claimed.

```text
Pruning certificate: every member of S satisfies E.
Accepted enclosure: C' = C intersect {x:E(x)}.
Witness certificate: x in D and V(x) is true.
Completeness certificate: every member of S is represented in output.
Uniqueness certificate: sound complete output represents S={x}.
```

PROVED Z-P1. Any finite sequence of accepted pruning operations preserves all original solutions. Initially S subset C_0. If S subset C_j and all x in S satisfy E_j, then every x in S belongs to C_j intersect E_j=C_(j+1). Induction establishes S subset C_j at every stage. The enclosure also decreases because intersection cannot add elements.

This proof supplies preservation, not automatic progress. A repeated constraint leaves an intersection unchanged. For fixed E, the operation C -> C intersect E is idempotent. Applying it a hundred times gives the same set as applying it once. A working ratchet needs genuinely new constraints, increased precision, smaller verified bounds, or updated constraint propagation whose fixed-point computation has been specified.

A second interface concerns reversible representations. Suppose R(x,z) relates original objects x to transformed objects z. Forward coverage requires every original solution to have a represented transformed state. Backward correctness requires every accepted decoded state to be an original solution. A transform can have many representations per object and still be useful. It need not be a bijective function, but its reconstruction relation must retain the missing choices.

A residue x == a (mod M) illustrates the point. It becomes exact ordinary reconstruction only when the fiber coordinate t is retained in x=a+Mt. A real or complex root can similarly be represented by an isolating interval or region and a polynomial, rather than by a decimal string pretending to be exact. A finite data transform can be stored with its normalization and indexing conventions so that the inverse is defined. The interface states what an object means before a particular engine is selected.

## Z2. A small complete arithmetic reconstruction

Consider the integer equation x^3-x=0 with the declared bound -2<=x<=2. The original verifier evaluates the exact integer polynomial. Modulo 3, every residue is a root, so that initial projection removes nothing. Lifting to modulus 9 gives roots 0,1,8. Modulo 5 the roots are 0,1,4. Every ordinary integer root must satisfy both local equations.

CRT combines each of the three modulus-9 branches with each of the three modulus-5 branches, giving nine classes modulo 45:

```text
{0,1,9,10,19,26,35,36,44} modulo 45.
```

Only classes 44,0,1 meet the integer interval [-2,2], through representatives -1,0,1. Exact substitution accepts all three. The complete output is therefore {-1,0,1}. The method has enumerated every local branch and every bounded representative, so its completeness is justified. The factorization x^3-x=x(x-1)(x+1) supplies a separate hand-check of the mathematical answer.

The example also records the usefulness boundary. The initial modulus 3 supplies no candidate reduction. The modulus-45 classes contain local roots that do not correspond to small ordinary roots; the bound and original verification finish the job. A different problem might make one prime much more selective than another. Testing selectivity is an engineering choice; eliminating an unpromising prime does not permit eliminating actual candidate branches without proof.

A suitable implementation reports the input domain, the primes and precision levels, the complete local root sets, the CRT classes, the interval representatives, and the original residuals. The output need not claim to have solved all cubic equations over every field. It has solved this declared integer problem completely, and it exposes a reusable pattern.

## Z3. Factorization on a hyperbola, in gap coordinates and on a circle

For an integer N>1, the positive real curve xy=N is easy to parameterize: every x>0 gives y=N/x. The factorization problem asks for its positive integer lattice intersections. Taking x<=y bounds the smaller factor by floor(sqrt(N)). This distinction prevents a continuous optimizer from being presented as an integer factorization algorithm merely because it follows the correct curve.

For a lower-factor interval with 0<L<=U and L<=x<=U, every integer cofactor must lie in

```text
ceil(N/U) <= y <= floor(N/L).
```

PROVED Z-P2. The reciprocal function decreases on positive reals, so N/U<=N/x<=N/L. Integer rounding preserves the necessary bounds. This gives a safe enclosing rectangle. It may be loose, and often supplies little pruning by itself; usefulness requires additional incompatible integer, parity, or modular conditions.

Gap coordinates write y=x+h with h>=0. Substitution gives x^2+hx-N=0. There is an integer factor pair with that gap exactly when

```text
h^2+4N=k^2;
k>=h;
k==h (mod 2);
x=(k-h)/2; y=(k+h)/2.
```

For N>0 the positive square-root branch has k>h. The parity guard is essential. Multiplying the reconstructed factors gives (k^2-h^2)/4=N, proving backward correctness. Starting from an integer factor pair gives h=y-x and k=x+y, proving forward coverage.

For odd N, writing m=(x+y)/2 and d=(y-x)/2 gives Fermat's difference of squares N=m^2-d^2. Because odd factor pairs have matching parity, m and d are integers. For N=10403, m_0=ceil(sqrt(N))=102. The difference m_0^2-N=1 gives d=1 and factors 101,103. In gap coordinates h=2 and h^2+4N=41616=204^2, returning the same pair. This is a useful example of exact coordinate transport; two presentations have the same underlying search condition.

A phase coordinate takes an integer candidate k and its Euclidean remainder r=N mod k, with 0<=r<k. Define z=exp(2*pi*i*r/k). Then z=1 exactly when r=0, which is exactly k dividing N. The chord distance and an alignment score are

```text
|1-z| = 2*abs(sin(pi*r/k));
P = (1+Re(z))/2 = cos(pi*r/k)^2.
```

These are exact identities in an exact mathematical complex model. In software, evaluating a floating-point phase is an approximate calculation; N mod k remains the direct exact verifier. Computing every remainder and then drawing every phase has already performed the corresponding divisibility workload. A geometric display does not erase that cost.

For N=77 and k=10, r=7. The phase is exp(1.4*pi*i)=exp(-0.6*pi*i). Its centered angular magnitude is 0.6*pi, but replacing the phase itself by exp(+0.6*pi*i) conjugates it. The magnitude-based score remains the same; a signed phase reconstruction does not. This repairs a small but consequential ambiguity in the phase-search notes.

A harmonic average A_M=(1/M)sum_(j=0)^(M-1)z^j has intensity |A_M|^2. At M=1 its intensity is 1 for every candidate, so it contains no divisor information. For M>=2, exact intensity 1 forces all averaged unit vectors to have the same direction; because the first vector is 1 and the second is z, this forces z=1. Finite tolerance can still produce high scores for nondivisors. A near-aligned phase is a ranking signal rather than an exact witness.

A phase-priority search does not automatically return the factor closest to sqrt(N). All actual divisors attain the maximum exact alignment score, and near misses can attain almost the same approximate score. The closest pair can be certified by monotonically enumerating Fermat centers until the first valid square, or by a complete objective-bound argument. Arbitrary best-first priorities need an independently proved admissible bound before they establish optimality.

## Z4. Exact information and heuristic information can cooperate

The useful hybrid arrangement has an exact candidate ledger and a separate proposal queue. Heuristics rank which branch, box, residue class, or experiment to inspect next. Exact certificates determine what may be removed, accepted, or declared complete. This separation allows a fast experimental method to contribute without weakening mathematical correctness.

For an integer polynomial, a numerical approximation may suggest which residue classes to test first. For a factorization problem, a phase score may suggest a candidate k. For a nonlinear system, an oscillatory probe may propose a local quadratic model. For a pattern finder, a high statistic may propose a walk or state representation. Each becomes an accepted mathematical result only through the corresponding original-domain condition.

There is one qualification: pruning can be probabilistic when the problem itself explicitly permits a statistical guarantee. Then the confidence contract, dependence assumptions, and total error allocation must travel with the candidate state. A 95% confidence statement is not interchangeable with a universal solution-preservation statement. It also does not become 99.75% merely because the same data are reported by two related workers.

The project is especially suitable for inspectable adapters. A modular adapter exposes modulus, representative convention, exact order where required, and a verified congruence. A p-adic adapter exposes prime, precision, valuation, and torsion branch. A real-root adapter exposes an interval and existence or uniqueness certificate. A spectral adapter exposes sample grid, frequency map, normalization, and retained coefficients. A logic adapter exposes context, evidence identity, and inference rule. These fields make a result portable between implementations.

## Z5. Sparse observations: units, averages and inverse models

The recovered flight-reconstruction note supplies a useful application of the observation contract. Its measurements, graph readings, derived quantities and assumptions are separate data types. This edition retains that mathematical method without adopting an accident-cause conclusion or revalidating the historical observation set.

For two altitude observations h_0,h_1 separated by Delta t seconds, the interval-average vertical rate in feet per minute is 60*(h_1-h_0)/Delta t. A change from 31,450 to 36,325 feet over 21 seconds gives 97500/7, approximately 13,929 feet per minute. This average does not identify an instantaneous rate at either endpoint. A derivative estimate from sparse data needs a smoothness and synchronization assumption, especially when different telemetry fields have different delays.

For a planar path modeled as a constant-curvature arc, endpoint chord length d and total angle change theta give radius R=d/(2*sin(abs(theta)/2)) and arc length R*abs(theta). The formula needs 0<abs(theta)<2*pi and an explicitly chosen arc. Endpoint headings alone do not uniquely identify the path between endpoints. A shortest signed angular difference fixes a convention; it does not rule out an additional full turn in unobserved motion.

Ground-relative velocity and air-relative velocity differ by the wind vector. Using a horizontal ground speed as airspeed requires a declared wind assumption. A three-dimensional speed norm additionally needs a synchronized vertical component. A coordinated steady-turn bank formula requires its dynamical assumptions; inserting an observed turn rate does not measure actual bank when the motion violates those assumptions.

An estimated average acceleration from velocity endpoints can be converted to an estimated average specific-force vector by subtracting gravity. The norm of that vector is not the peak force and is not generally the time-average force magnitude. By the triangle inequality, norm(average f)<=average(norm(f)). This distinction limits what sparse observations can establish about load.

Finally, fitting a drag parameter to a descent time is an inverse problem. One fitted effective parameter under a point-mass model need not identify attitude, control state, or a unique physical cause. The reusable result is a discipline for carrying units, synchronization, model assumptions and non-identifiability through a reconstruction. A detailed rendered trajectory remains a visualization of that model until additional observations identify its hidden variables.

## Z6. Directional observations and the missing uniformity in limits

The recovered Math and Limits note offers another instance of incomplete observation coverage. A function of two variables can approach the same value along every fixed straight ray and still fail to have a multivariate limit. Define f(x,y)=x^2*y/(x^4+y^2) away from the origin. Along (x,y)=(a*t,b*t), a fixed direction with b!=0 gives f=a^2*b*t/(a^4*t^2+b^2), which tends to zero. If b=0 the value is identically zero. Yet along the curved path (x,y)=(t,t^2), the value is exactly 1/2 for every nonzero t.

The correct full directional contract requires uniformity: for every epsilon>0 there is one delta>0 such that abs(f(t*v)-L)<epsilon for every unit direction v and every 0<t<delta in the domain. One delta must work across directions. Every nonzero point near the origin can be written t*v with t its norm and v a unit vector, so this uniform directional statement is precisely the ordinary multivariate limit criterion. Separate deltas chosen after each fixed direction do not supply it.

This example repairs the proposed scale/direction bookkeeping without discarding its useful coordinate view. Directions organize observations; uniform control or another complete neighborhood bound provides the missing coverage. A finite set of rays, and even every fixed ray checked separately, can miss a curved approach whose direction changes with scale.

## Z7. A research idea becomes testable through its first uncertain arrow

An open idea should be stated as a specific implication. For example, the assertion that a score identifies the smallest factor has two distinct uncertainties: whether a high score implies divisibility, and whether search order implies optimality. A counterexample to either implication blocks that version of the claim. It may leave a useful ranking heuristic and exact final verifier intact.

A claim that two projections reconstruct an object requires injectivity of their combined observation map, or a declared anchor that reduces each fiber to one admissible point. Testing a few objects can reveal a collision but cannot prove the absence of every collision in an infinite domain. A finite domain can be exhaustively tested, provided the enumerator itself covers that domain and no filter silently excludes the hard cases.

A claim that a local update converges requires a contraction, a descent-and-compactness argument, a bracket invariant, or another precise mechanism. Smaller residual on a few steps is evidence about that trace. A claim that a spiral diagram is a strange attractor additionally requires a dynamical system, an invariant attracting set, and a defensible account of nontrivial dynamics. A ninety-degree rotation of a contracting spiral is a valid geometric transformation and does not supply those additional properties.

These formulations allow speculation to remain productive. An idea can be retained as a model with a stated question, a proposal with a final check, or a theorem after a proof. The correction register preserves what changed and why. A false universal claim need not force the deletion of its useful restricted case.

## Z8. Building on the collection

A useful extension begins by choosing one original problem and one success condition. The next step is to state the computable observations and the missing information in their fibers. An adapter then records its preconditions and proposes a reconstruction or a safe refinement. Small exact examples expose boundary errors. Independent invariants or alternative implementations check the load-bearing calculation. A final write-up records the result and the first unresolved implication.

For a three-variable showcase, a practical extension sequence is guarded rational-polynomial parsing, exact linear families, bounded integer systems, isolated algebraic solutions, certified real boxes, and then carefully declared transcendental or exponent domains. Fractions, variable powers, and nonisolated families change the required adapter. Adding a button does not establish those mathematical interfaces. Adding an interface with explicit certificates does create a dependable extension point.

For a pattern finder, a practical sequence is a transparent finite-state representation, collision-checked hashes, a held-out chronological validation set, and a dependence-aware significance procedure. For a geometric model, it is a realizable metric, oriented incidence, a verified operator, and a bounded simulation contract. For a modular lab, it is exact arithmetic and reconstruction before adding performance optimizations. These are concrete ways to turn the collection into further work.

Exercise Z-E1. A worker repeats x == 2 (mod 3) ten times and reports tenfold information gain. What changes in the exact candidate set? Answer: nothing after the first accepted intersection; the repeated constraint is idempotent.

Exercise Z-E2. A routine returns x=1 for x^3-x=0 in [-2,2]. What is established? Answer: a sound witness. The roots -1 and 0 remain, so completeness and uniqueness are not established by that return value.

Exercise Z-E3. A phase calculation for N=10403 reports a near-zero angle at k=100. Can k be accepted? Answer: no; the exact remainder is 3. The valid nearby pair 101,103 must be verified through exact divisibility or the square-gap identity.

Exercise Z-E4. A real optimizer reaches zero residual for a homogeneous equation in positive real variables. Has an integer solution been found? Answer: only if the coordinates can additionally be reconstructed as admissible integers and verified exactly. A real zero alone has no such implication.

Exercise Z-E5. A mesh satisfies d1*d0=0. Does that establish a valid Euclidean metric? Answer: no. Incidence can be consistent while its assigned distances have an indefinite Gram matrix. The metric and topological contracts are separate.

The useful outcome is a collection of methods with visible interfaces. Arithmetic, numerical analysis, geometry, statistics, and logic can cooperate because their conclusions are declared precisely. The collection remains extendable without relying on an unproved universal solver to make its examples worthwhile.

# Correction register, coverage and reproducibility

## A concise register of consequential repairs

The detailed family audits retain source locators, normalized claims, proof dependencies, finite ranges and review findings. This register identifies the corrections most likely to affect reuse. A correction does not imply that every statement in its source family was false; it identifies the exact condition that must remain visible in the useful construction.

| Earlier inference or ambiguity | Standardized repaired statement |
| --- | --- |
| Repeated fixed constraint intersection keeps producing information | Intersection with a fixed predicate is idempotent. New progress requires new information, increased precision or a specified propagation fixed point. |
| A returned valid answer proves uniqueness | A sound complete solution description with cardinality one establishes uniqueness. A singleton partial output does not. |
| A known multiple of an order can replace the exact order | Projection and exponent periods use the actual cyclic subgroup order or a separately proved order certificate. |
| Every external exponent residue modulus divides the group order | An arbitrary residue modulus M yields a residual generator of order N/gcd(N,M), with bounded representatives and duplicate periodicity accounted for. |
| Division by a nonzero modular element is always valid | Division requires a unit. A linear congruence with a nonunit coefficient has zero, one or multiple branches according to its gcd conditions. |
| Completing a square always preserves modular roots | Multiplication by a nonunit can add roots. Retain the original equation or establish the needed invertibility/precision repair. |
| Principal-unit rank necessity also holds at precision k=1 | The nontrivial rank theorem is stated for k>=2. At k=1 the principal-unit/exponent problem is trivial. |
| A p-adic logarithm gives full-unit coordinates | Retain valuation and torsion coordinates; use log/exp only on their stated convergent principal neighborhoods. |
| Binary units behave exactly like odd-prime units | The scalar binary safe logarithm chart starts at 1+4Z_2. Higher residue-degree binary units need their actual quotient structure. |
| A polynomial product vanishes only when a factor vanishes | Zero divisors invalidate that inference in rings. Root unions, common roots and product roots are different sets. |
| Cyclotomic factorization automatically identifies primitive order in every ring | Primitive-order conclusions need field/unit and characteristic conditions; product identities alone do not supply them. |
| Quotient inversion and subgroup inversion guarantee layered inversion | Every conditional coset fiber needs its own inversion or coverage contract. |
| A small lattice vector is the recovered unknown | The exact observation box and original verifier determine validity. Reduction and nearest-plane methods can propose candidates without complete recovery. |
| A finite p-adic branch is an ordinary integer or rational root | Reconstruction needs ordinary bounds or a rational bridge, all compatible branches, and the original verifier. |
| Singular roots have one next digit | Singular branches can produce all digits or no digits at a level. A complete lift retains those alternatives. |
| A local Newton or quadratic step solves every algebra problem | Local regularity, rank, conditioning and acceptance conditions are needed. Global coverage is supplied separately. |
| Interval Newton permits a pivot outside its derivative enclosure | Put the pivot inside the interval, or enclose derivatives on the entire pivot-root hull. |
| Every fixed-ray limit establishes the multivariate limit | One uniform neighborhood bound across directions is required; a curved approach can contradict every fixed-ray observation. |
| A residual-energy stationary point is an equation root | Zero residual certifies the equations. Nonzero stationary residuals can occur and require rejection as roots. |
| Clearing denominators permits every cleared-polynomial root | Original denominator exclusions survive compilation and final checking. |
| Finite isolated algebraic roots cover every three-variable system | Positive-dimensional families, singular roots, domain distinctions and unsupported function grammars require explicit adapters. |
| One elliptic generator scan is a complete rational search | Completeness needs a generating-set/coset theorem. Negating one generator does not add an independent rank direction. |
| Distinct oscillatory carriers give uncontaminated derivatives | Sums, differences, doubles and sample-grid aliases must also be separated, or included in a full-rank design. |
| One circular quadratic scan determines every Hessian coefficient | An anchor or additional radial data is needed for the trace component; the circle alone loses information. |
| A divisor Mobius round trip creates an additional spectral filter | The forward transform followed by its inverse returns the original data. Any extra effect needs an additional operation. |
| Three directions spaced by 120 degrees are orthogonal | Their pairwise dot products are -1/2 for unit vectors in one plane. They form a dependent zero-sum configuration. |
| Phase exists through a zero without added structure | Phase is undefined at zero; a nonzero path and branch/unwrap convention are required. |
| A rotated funnel preserves the old circular top projection | A 90-degree rotation changes the projection geometry; a circle can project to a segment. |
| Orthogonal contracting spirals prove a strange attractor | Rigid orientation and negative contraction rates do not establish chaotic dynamics or a strange invariant attractor. |
| Triangle face inequalities realize any tetrahedron | A positive-definite Gram matrix is required; the displayed 1/1.9 edge counterexample fails it. |
| Correct incidence establishes a valid metric or continuum limit | Incidence, metric realizability, operator positivity and convergence are separate obligations. |
| Scalar window counts are automatically a Markov state | Ordered memory, position history or a sufficient belief state may be required. Count observations can lose transition-relevant information. |
| Any perturbation of a coprime probe stride keeps full coverage | The perturbation can collapse the orbit. Use a proved permutation or the separately stated longer-period coverage theorem. |
| High-frequency finite cosine sums are automatically fractal | Finite sums are smooth, and a finite lattice can alias high frequencies into constants. |
| A square-shell prime resonator defines a finite field | The shell is a finite integer set. Its exact sieve uses the least-prime-divisor bound; lower-root survivors can remain composite. |
| Repeated or salted deterministic data imply independence | Source identity, dependence and the actual conditional sampling law determine permissible evidence combination. |
| Local p-values remain calibrated after arbitrary adaptive search | Selection, repeated testing and optional stopping need a valid allocation or sequential-evidence contract. |
| Pairwise logic-array projections preserve a complete relation | XOR supplies a counterexample. Retain joint atoms, hyperedges or an equivalent higher-order constraint. |
| Four-valued material implication permits unrestricted detachment | The adopted designation can refute modus ponens. Use explicitly justified support-preserving rules. |
| A cyclic evidence graph proves its own unseeded claims | Grounded least closure introduces support only from declared seeds and rules. A dependency cycle supplies no new source. |
| A nibble selector and mechanical implication are the same IF | The operations have different types and truth tables. The compilation separates controlled selection from implication. |
| XOR/sum table checks detect arbitrary corruption | Trusted checks can correct one data-cell fault; the explicit four-cell change evades those checks. |
| Lane-wise NAND operations alone couple all bit positions | Routing, shifts or extraction are needed for cross-lane dependence and arithmetic carries. |
| Fixed-width square sums preserve ordinary equality automatically | Use sufficient width or proved overflow guards; wrapped arithmetic can admit false equality. |
| A wave simulator checked against its oracle proves physical reliability | Accepted simulation correctness follows from its oracle filter; hardware and noise reliability need an independent measurement contract. |
| A Hanoi shortest transfer is a Hamiltonian traversal of all states | The shortest three-peg transfer uses 2^n-1 moves; the full legal-state graph has 3^n states. These are distinct tasks. |
| A phase-priority factor search proves closest-factor optimality | It certifies returned divisibility. Optimality requires monotone ordering or an admissible objective bound and complete coverage. |
| A fitted sparse trajectory uniquely identifies a physical cause | Units, synchronization, model assumptions and surviving observation fibers remain part of the inverse problem. |

## What the source collection actually covers

The twelve supplied sources comprise approximately 175,390 words before consolidation. Their full source copies and hashes are included in the editable package. Every supplied file was assigned for family inspection. Repeated source proofs and versions were consolidated rather than counted as independent evidence.

| Supplied source family | Principal coverage in the book |
| --- | --- |
| 01 Math Work Exact Operational Formalization | Exact interfaces, cyclic residuals, coupled local units, bounded observations, reconstruction and arithmetic composition |
| 02 Project Mathematics Audited | Observations/anchors, local quadratic and oscillatory models, inverse identification, calculus/phase, conics and proof boundaries |
| 03 Cryptogram Operational Formalization | CRT, cyclic groups, finite coefficient algebras, p-adic and lattice coordinates, cryptogram/constraint semantics |
| 04 Solvers Certified Operationalization | Compiler contracts, numerical and geometric certificates, optimizer governance and cubic completion |
| 05 Cubic Ratchet Formalization | Prime-power root trees, rational scaling, singularity, precision accounting and bounded reconstruction |
| 06 Two Window Mathematical Investigation | Moving-window state, overlapping observations, memory and bounded exact/statistical methods |
| 07 Statistical Algebra State Machines | Symmetries, fields/codes, observation models, confidence and sequential evidence |
| 08 Arithmetic Connections Integrated | Offset/valuation decompositions, digit operations, norms and arithmetic state structure |
| 09 Primes Offsets Padic Machines | Prime masks, carries, residue machines and root-tree distinctions |
| 10 Erdos Primes Parity Quadratic Investigation | Quadratic examples, multiplicative signs, progression discrepancy and finite search |
| 11 Construct Pattern Finder v2 | Collision-checked hashes, array walks, symmetry, patch/state inspection and validation |
| 12 Construct Pattern Finder | Original constructs, comparison relations, model selection and testable pattern claims |

Supplemental records broaden coverage through the actual Mathcrack manuscripts, modular lab and reconstruction whitepapers, hidden-number specification, current solver notes, quaternion/p-adic lock-in algorithm, Dual Funnel manuscript, doubling-cycle geometry, Fourier Six guide and core, airplane epicycles, abstract temporal framework, three-dimensional logic array monograph, CH/cubical finite checker report, Terminator verification, electronic and mechanical logic notebooks, arithmetic logic blocks, logic certificates, prime/resonator notes, fractal hashing, phase/factorization demonstrations, homogeneous cubic controller revisions and sparse-flight reconstruction.

Supplemental records were inspected by the relevant constructions and claims recorded in each family audit. Duplicate bytes are identified by SHA256. Related-section inspection is not represented as exhaustive auditing of every historical conversational paragraph or embedded program. Mentioned but unseen records remain outside proof coverage. Primary external literature supplies attribution or a precisely checked dependency, and is not presented as Stefan's original theorem.

The Dual Funnel manuscript identifies Griff Gurwell as its author. Its conditional geometry is included as related mathematical material with attribution. The independent rotations and project extensions are distinguished from its original projection assumptions. Historical source-access failures concerning referenced Zenodo manuscripts remain failures; recovering a later reconstruction does not authenticate those unavailable originals.

## Fresh verification and its interpretation

The package includes exact checking scripts for all six main families and the coordinator's discrete-geometry/integration examples. Most use Python integers and fractions rather than floating-point arithmetic. The recovered Fourier demo has a separate JavaScript verification record with explicit tolerances. Computational ranges and individual outputs are preserved in their JSON evidence records. The checking workload is finite; the universal arguments are the chapter proofs.

| Family | What the fresh checks examine |
| --- | --- |
| A arithmetic | Linear congruence fibers, generalized CRT, cyclic projection, residual bounds, local units, finite polynomial algebra, HNP boxes and the complete small semidirect example |
| B p-adic/cubic | Finite polynomial root sets, singular and Newton lifts, safe log/exp domains, scalar/unit coordinates, coupled exponents and rational scaling |
| C solvers | Guarded domain examples, complete finite integer/rational comparisons, quadratic stencils, brackets/Halley identities, controller transitions and homogeneous-cubic maps |
| D spectral/geometry | Fourier inversion and rank, harmonic collisions, phase/derivative identities, projections/quaternions, dual-funnel conditions and actual recovered modem/epicycle behavior |
| E patterns/statistics | Window updates, augmented walks, wheel/shell sieves, digit/carry identities, masks/discrepancy, field codes and exact sequential evidence bounds |
| F logic/computation | Fibers and atoms, four-valued operations, closure/fixed points, finite temporal graphs, LUT integrity, gate arithmetic, width guards, original mechanical code and Hanoi distances |
| G/Z integration | Simplex coordinates and metric obstruction, incidence/energy, dyadic geometry, complete bounded cubic and factor-gap/reciprocal round trips |

Fresh cross-reviews examine another family's exact statements and derivations. They do not count agent agreement as proof. They identified, among other findings, the missing k>=2 boundary in the principal-unit rank necessity claim and an insufficient uniqueness-certificate wording; both were repaired before the final editions. Detailed peer records retain the findings and their resolution.

Evidence manifests record the actual environment and commands. Version-1 records retain their legacy provenance limitations; version-2 records include stronger artifact and execution information where available. A validated manifest confirms its record structure and hashes, not the truth of a theorem. A zero process exit code records successful execution, not universal correctness. None of these records silently upgrades an incomplete search to an impossibility or uniqueness certificate.

## Editable package and regeneration

The package preserves the two content levels: corrected manuscript chapters and unchanged historical sources. It includes the final PDF and ASCII edition, an editable Markdown manuscript, chapter files, mathematical audits, peer reviews, source inventory, scripts and their finite result records. Authenticated transfer helpers and temporary page images are excluded. External literature files are not redistributed wholesale; references retain their authors, titles and public locations.

The PDF build requires Python with reportlab and pypdf. Mathematical Python checks use the standard library unless a script explicitly declares otherwise. The Fourier demo check requires Node.js and the retained demo file. The package README gives regeneration commands and identifies the record authority for each run. A new execution can change timing and timestamps without changing the mathematical results.

This edition is a seed for further mathematical work with visible interfaces. A later revision can add an adapter, sharpen a bound, replace a heuristic, or settle an open implication while retaining the original-domain meaning and the evidence needed to check the change.

# Standard terms and the project vocabulary

## Terms that keep the different methods compatible

Candidate enclosure. A represented set that contains every solution of the declared original problem. It can contain objects that will later be rejected. It need not be a literal list.

Certificate. Data and an argument that a checker can use to establish a specified conclusion. Its force depends on the conclusion: a witness certificate differs from a completeness or optimality certificate.

Soundness. Every returned answer is an admissible solution. Completeness. Every admissible solution is represented in the output. Uniqueness. Exactly one admissible solution exists. These three terms do not imply one another without additional conditions.

Observation map and fiber. An observation map sends original objects to observed data. Its fiber above a datum is the set of original objects consistent with that datum. An observation is identifying when the admissible fiber contains one object.

Anchor and gauge. An anchor supplies a reference that removes an ambiguity such as an additive offset. A gauge is a freedom in representation that leaves the relevant observations unchanged. Fixing a gauge needs a stated convention or legitimate observation.

Projection. A map retaining selected components or equivalence-class information. A projection is commonly lossy. A reconstruction must retain a fiber coordinate, add identifying observations, or return the complete permitted fiber.

Coordinate change. A representation with a stated inverse or reconstruction relation. Changing coordinates can simplify operations without reducing the number of possible answers.

Congruence. Agreement modulo an integer M: a == b (mod M) means M divides a-b. Residue class. All integers agreeing with one representative modulo M. A representative is one member, chosen by convention.

Unit. An element possessing a multiplicative inverse in its ring. Modulo M, an integer a is a unit exactly when gcd(a,M)=1. Nonzero does not imply unit in a composite-modulus ring.

Group order and element order. The group order is its cardinality. The order of an element is the smallest positive exponent giving the identity. A supplied multiple of an element order must not be treated as its exact order.

Discrete logarithm. An exponent relative to a specified generator of a cyclic subgroup. It is a residue modulo the generator's exact order. Defining that coordinate does not make it cheap to compute.

Valuation. The exponent of a specified prime in divisibility, with an explicit convention for zero. In p-adic arithmetic v_p measures divisibility and |x|_p=p^(-v_p(x)) measures the corresponding distance scale.

p-adic precision. Agreement modulo a specified prime power, or a declared valuation of the uncertainty. Absolute and relative precision must be distinguished when multiplication, division or cancellation changes valuations.

Hensel lifting. Refinement of a polynomial root modulo p^k to compatible roots at higher prime-power precision. A simple root has a unique next digit; a singular root can branch or die.

Principal unit and torsion unit. Principal units are congruent to one in the stated residue layer. Torsion units have finite multiplicative order. A logarithm that annihilates torsion needs a separate torsion coordinate for full-unit reconstruction.

Lattice. The integer span of linearly independent vectors in a real vector space, or an explicitly declared integer module embedded there. A small-vector heuristic and a complete box-lattice search have different guarantees.

Root bracket. A real interval with an existence certificate, commonly opposite signs and continuity. It is a uniqueness certificate only with additional conditions such as strict monotonicity.

Residual. The result of substituting a candidate into an equation or model. A residual norm is an objective for proposals. Its stationary points need not be equation roots.

Interval enclosure. A range guaranteed to contain the values of an expression or its admissible solutions. Rounded arithmetic must be outward if it is used as a rigorous numerical certificate.

Fourier coefficient. A coordinate in a declared harmonic basis with stated normalization. The transform can be invertible on its finite sample space while still failing to identify a continuous signal outside the sampling assumptions.

Aliasing. Different original frequencies or signals producing the same observations on a sample grid. Extra plotted precision does not recover the lost information.

Phase. An angle class associated with a nonzero complex value. A branch or unwrapped path supplies additional angle information. Phase is undefined at a zero signal.

Harmonic collision. Different terms contributing to the same observed frequency. Distinct original carrier frequencies do not by themselves exclude collisions among sums, differences and multiples.

Barycentric coordinates. Affine vertex weights summing to one. Nonnegative weights characterize membership in the simplex. Affine independence is necessary for uniqueness.

Incidence and metric. Incidence records which cells are boundaries of other cells, with orientation signs. A metric records lengths or inner products. Correct incidence does not establish a realizable metric.

Angle deficit. The difference between a reference flat angle and incident angle sum in a declared piecewise-Euclidean geometry. It is an integrated curvature quantity, not automatically a density.

State and transition. A state contains the information needed to determine the next permitted evolution under the declared input model. A transition is its update rule. An omitted input or hidden memory can invalidate a proposed finite-state model.

Hash and collision. A hash is a compact fingerprint. A collision is agreement of fingerprints for distinct original data. Exact pattern matching retains the originals and verifies candidate matches.

Statistical null and validation. A null specifies the reference distribution being tested. Validation tests a selected model on appropriate fresh or held-out data. Dependence, selection and repeated testing belong to the model contract.

Context and provenance. A context fixes the domain in which a statement is interpreted. Provenance records the observations and inference steps supporting it. Renaming a source or repeating a derived claim does not create new independent evidence.

## A dictionary for earlier informal names

Carrier becomes a coordinate space, state space, or observation channel after its type is declared. The earlier phrase carrier/projection/intersection is retained as an organizing shorthand for representation, observation, and constraint intersection.

Ratchet becomes monotone solution-preserving refinement. Precision ratchet adds compatible increasing precision. Neither phrase by itself supplies a convergence theorem.

Shake and wobble becomes oscillatory probing, harmonic coefficient extraction, or finite-difference local modeling, according to the actual experiment. The associated update becomes a quadratic or Newton proposal after its coefficients and admissibility are specified.

Resonator becomes a periodic phase encoding, an exact roots-of-unity filter, or a heuristic score. Those are different constructions even when they share a circular picture.

Mirror constraint becomes reciprocal interval propagation when the original relation is xy=N. It is a necessary enclosure, whose selectivity must be measured separately.

Descent becomes verified objective decrease or a precisely defined arithmetic height reduction. A visually downward motion in a chosen coordinate chart need not decrease the original objective.

Entropy becomes Shannon entropy only when a probability distribution and logarithm base are declared. Counting arithmetic operations or decomposing a number into offsets does not automatically define information entropy.

Clock becomes indexed state evolution with specified inputs and memory. A periodic component can be a clock; a complete program need not be periodic or easily invertible.

Three-dimensional logic array becomes a typed atlas of semantic objects, projections and transitions. Hyperedges or atoms retain joint constraints that pairwise pictures can lose.

Binary or ternary part becomes a digit, a valuation, a parity class, or an exponent residue after the actual coordinate is identified. A base-3 digit of an exponent is different from the 3-adic valuation of the group element it encodes.

Collision becomes either a repeated observation, a hash collision, a group-walk relation, an aliased frequency, or multiple problem solutions. Each meaning has its own witness and consequences; the name alone supplies no common recovery theorem.
